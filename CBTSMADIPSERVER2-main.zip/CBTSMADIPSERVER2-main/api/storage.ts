import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const STORAGE_KEY = 'smadip_cbt_vercel_storage_v1';
const STUDENTS_HASH_KEY = 'smadip_cbt_vercel_students_v1';
const RESULTS_HASH_KEY = 'smadip_cbt_vercel_results_v1';
const PACKAGES_HASH_KEY = 'smadip_cbt_vercel_packages_v1';
const SCHEDULES_KEY = 'smadip_cbt_vercel_schedules_v1';
const TOKEN_KEY = 'smadip_cbt_vercel_token_v1';
const META_KEY = 'smadip_cbt_vercel_meta_v1';
const LOCK_KEY = 'smadip_cbt_vercel_lock_v1';
const SESSION_SECRET_KEY = 'smadip_cbt_internal_session_secret_v1';

// Global in-memory cache, write mutex, and ephemeral session secret fallback across warm serverless invocations
declare global {
  // eslint-disable-next-line no-var
  var __SMADIP_CBT_MEM_STORE__: Record<string, unknown> | null | undefined;
  // eslint-disable-next-line no-var
  var __SMADIP_CBT_WRITE_QUEUE__: Promise<void> | undefined;
  // eslint-disable-next-line no-var
  var __SMADIP_CBT_SCOPED_QUEUES__: Map<string, Promise<void>> | undefined;
  // eslint-disable-next-line no-var
  var __SMADIP_CBT_SESSION_SECRET__: string | undefined;
}

const DEFAULT_DEMO_PARTICIPANT_IDS = new Set([
  'ap1',
  'ap2',
  'ap3',
  'ap4',
  'ap5',
  'ap6',
  'ap7',
  'ap8',
  'p1',
  'p2',
  'p3',
  'p4',
  'p5',
  'p6',
  'p7',
  'p8',
]);

const DEFAULT_DEMO_USERNAMES = new Set([
  'SA20264821',
  'SA20267394',
  'SA20262918',
  'SA20268563',
  'SA20265147',
  'SA20269302',
  'SA20266475',
  'SA20261839',
  'P130100240',
  'K020500118',
  'TK1601',
  'TK1610',
]);

const DEFAULT_DEMO_SCHEDULE_IDS = new Set([
  'sch1',
  'sch2',
  'sch3',
  'sch4',
  'sch5',
  'sch_1',
  'sch_2',
  'sch_3',
  'sch_4',
  'sch_5',
  's1',
  's2',
  's3',
  's4',
  's5',
]);

function isDefaultDemoRow(item: unknown): boolean {
  if (!item || typeof item !== 'object') return false;
  const id = String((item as Record<string, unknown>).id || '').trim();
  if (id.startsWith('excel_') || /^ap_\d+$/.test(id)) return false;
  const username = String((item as Record<string, unknown>).username || '')
    .trim()
    .toUpperCase();
  return (
    DEFAULT_DEMO_PARTICIPANT_IDS.has(id) || DEFAULT_DEMO_USERNAMES.has(username)
  );
}

function isCustomUploadedRow(item: unknown): boolean {
  if (!item || typeof item !== 'object') return false;
  if (!isDefaultDemoRow(item)) return true;
  const id = String((item as Record<string, unknown>).id || '').trim();
  return id.startsWith('excel_') || /^ap_\d+$/.test(id);
}

function isDefaultDemoParticipantsList(list: unknown): boolean {
  if (!Array.isArray(list) || list.length === 0) return true;
  if (list.length > 8) return false;
  return list.every((item) => isDefaultDemoRow(item));
}

function isDefaultInactiveSchedulesList(list: unknown): boolean {
  if (!Array.isArray(list) || list.length === 0) return true;
  const hasAnyActive = list.some(
    (s) => s && typeof s === 'object' && Boolean((s as any).isActive)
  );
  if (hasAnyActive) return false;
  return list.every(
    (s) =>
      s &&
      typeof s === 'object' &&
      DEFAULT_DEMO_SCHEDULE_IDS.has(String((s as any).id || '').trim())
  );
}

function resolveIncomingSchedules(
  incomingList: unknown,
  existingList: unknown,
  deletedScheduleIdsInput?: unknown,
  forceReplace?: boolean
): Record<string, any>[] | undefined {
  const deletedIds = new Set<string>(
    Array.isArray(deletedScheduleIdsInput)
      ? deletedScheduleIdsInput
          .map((id) => String(id || '').trim())
          .filter(Boolean)
      : []
  );

  const cleanExisting = Array.isArray(existingList)
    ? (existingList as any[]).filter((row) => {
        if (!row || typeof row !== 'object') return false;
        const id = String(row.id || '').trim();
        return !id || !deletedIds.has(id);
      })
    : [];
  const hasExisting = cleanExisting.length > 0;

  if (!Array.isArray(incomingList)) {
    return hasExisting ? (cleanExisting as Record<string, any>[]) : undefined;
  }

  const cleanIncoming = incomingList.filter((s) => {
    if (!s || typeof s !== 'object') return false;
    const id = String(s.id || '').trim();
    return !id || !deletedIds.has(id);
  });

  if (cleanIncoming.length === 0) {
    if (forceReplace || deletedIds.size > 0) {
      return [];
    }
    return hasExisting ? (cleanExisting as Record<string, any>[]) : [];
  }

  const existingHasActiveOrCustom =
    hasExisting && !isDefaultInactiveSchedulesList(cleanExisting);
  const incomingIsDefaultInactive = isDefaultInactiveSchedulesList(cleanIncoming);
  const incomingHasAnyTimestamp = cleanIncoming.some(
    (s) =>
      s &&
      typeof s === 'object' &&
      typeof s.updatedAt === 'number' &&
      s.updatedAt > 0
  );

  // Never allow an unhydrated background tab's default inactive schedules (with no updatedAt timestamp and no forceReplace)
  // to wipe out active schedules or custom schedules
  if (
    !forceReplace &&
    deletedIds.size === 0 &&
    existingHasActiveOrCustom &&
    incomingIsDefaultInactive &&
    !incomingHasAnyTimestamp
  ) {
    return cleanExisting as Record<string, any>[];
  }

  if (hasExisting) {
    const existingById = new Map<string, Record<string, any>>();
    const customExistingRows: Record<string, any>[] = [];
    const incomingIds = new Set<string>(
      cleanIncoming.map((s) => String(s.id || '').trim())
    );

    for (const row of cleanExisting) {
      const id = String(row.id || '').trim();
      if (!id) continue;

      existingById.set(id, row);
      // Only preserve custom schedules missing from incomingList when forceReplace is NOT active
      if (
        !forceReplace &&
        !DEFAULT_DEMO_SCHEDULE_IDS.has(id) &&
        !incomingIds.has(id)
      ) {
        customExistingRows.push(row);
      }
    }

    const merged = cleanIncoming.map((s) => {
      const id = String(s.id || '').trim();
      const existRow = id ? existingById.get(id) : undefined;
      if (!existRow) return s;

      if (forceReplace) {
        return s;
      }

      const incTs = typeof s.updatedAt === 'number' ? s.updatedAt : 0;
      const existTs =
        typeof existRow.updatedAt === 'number' ? existRow.updatedAt : 0;

      if (incTs > 0 || existTs > 0) {
        if (existTs > incTs) {
          return existRow;
        }
        return s;
      }

      if (existRow.isActive) {
        return { ...s, isActive: true };
      }
      return s;
    });

    return [...merged, ...customExistingRows];
  }

  return cleanIncoming;
}

const BUILTIN_SAMPLE_QUESTION_IDS = new Set([
  'q1',
  'q2',
  'q3',
  'q4',
  'q5',
  'q6',
  'q7',
  'q8',
  'q9',
  'q10',
  'sq1',
  'sq2',
  'sq3',
  'sq4',
  'sq5',
  'qm1',
  'qm2',
  'qb1',
  'qs1',
  'qs2',
  'qpai1',
  'qbio1',
  'qeko1',
  'qfis1',
  'qgeo1',
]);

function isServerDefaultSampleQuestion(q: any): boolean {
  if (!q || typeof q !== 'object') return false;
  const id = String(q.id || '').trim();
  if (!id) return false;
  return id.startsWith('q_default_') || BUILTIN_SAMPLE_QUESTION_IDS.has(id);
}

function getServerRealQuestions(questions: unknown): any[] {
  if (!Array.isArray(questions) || questions.length === 0) return [];
  const hasUploadedOrManual = questions.some(
    (q: any) => q && typeof q === 'object' && !isServerDefaultSampleQuestion(q)
  );
  if (hasUploadedOrManual) {
    return questions.filter(
      (q: any) =>
        q && typeof q === 'object' && !isServerDefaultSampleQuestion(q)
    );
  }
  return questions.filter(
    (q: any) =>
      q &&
      typeof q === 'object' &&
      !String(q?.id || '').startsWith('q_default_')
  );
}

function getPackageMatchKey(pkg: Record<string, any>): string {
  const title = String(pkg.title || '')
    .replace(/^Simulasi TKA\s*-\s*/i, '')
    .trim()
    .toLowerCase();
  const targetClass = normalizeServerKelas(pkg.targetClass || '');
  return `${title}__${targetClass}`;
}

function resolveIncomingPackages(
  incomingList: unknown,
  existingList: unknown,
  deletedPackageIdsInput?: unknown,
  forceReplace?: boolean
): Record<string, any>[] | undefined {
  const deletedSet = new Set<string>(
    Array.isArray(deletedPackageIdsInput)
      ? deletedPackageIdsInput
          .map((id) => String(id || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );

  const filteredExisting = Array.isArray(existingList)
    ? (existingList as any[]).filter((item) => {
        if (!item || typeof item !== 'object') return false;
        const id = String(item.id || '').trim().toUpperCase();
        const code = String(item.code || '').trim().toUpperCase();
        if (id && deletedSet.has(id)) return false;
        if (code && deletedSet.has(code)) return false;
        return true;
      })
    : [];
  const hasExisting = filteredExisting.length > 0;
  const isIncomingArray = Array.isArray(incomingList);
  const hasIncoming = isIncomingArray && (incomingList as any[]).length > 0;

  if (!isIncomingArray) {
    return hasExisting
      ? (filteredExisting as Record<string, any>[])
      : Array.isArray(existingList)
      ? []
      : undefined;
  }
  if (!hasIncoming) {
    if (forceReplace || deletedSet.size > 0) {
      return [];
    }
    return hasExisting ? (filteredExisting as Record<string, any>[]) : [];
  }
  if (!hasExisting) {
    return (incomingList as any[])
      .filter((pkg) => {
        if (!pkg || typeof pkg !== 'object') return false;
        if (!forceReplace) {
          const id = String(pkg.id || '').trim().toUpperCase();
          const code = String(pkg.code || '').trim().toUpperCase();
          if (id && deletedSet.has(id)) return false;
          if (code && deletedSet.has(code)) return false;
        }
        return true;
      })
      .map((pkg) => ({
        ...pkg,
        questions: getServerRealQuestions(pkg.questions),
      }));
  }

  const existingById = new Map<string, Record<string, any>>();
  const existingByCode = new Map<string, Record<string, any>>();
  const existingByTitleClass = new Map<string, Record<string, any>>();

  for (const item of filteredExisting) {
    if (!item || typeof item !== 'object') continue;
    const id = String(item.id || '').trim();
    const code = String(item.code || '')
      .trim()
      .toUpperCase();
    const tk = getPackageMatchKey(item);
    if (id) existingById.set(id, item);
    if (code) existingByCode.set(code, item);
    if (tk) existingByTitleClass.set(tk, item);
  }

  const matchedExistingIds = new Set<string>();
  const mergedIncoming = (incomingList as any[])
    .filter((pkg) => {
      if (!pkg || typeof pkg !== 'object') return false;
      if (!forceReplace) {
        const id = String(pkg.id || '').trim().toUpperCase();
        const code = String(pkg.code || '').trim().toUpperCase();
        if (id && deletedSet.has(id)) return false;
        if (code && deletedSet.has(code)) return false;
      }
      return true;
    })
    .map((pkg) => {
      const id = String(pkg.id || '').trim();
      const code = String(pkg.code || '')
        .trim()
        .toUpperCase();
      const tk = getPackageMatchKey(pkg);

      const existMatch =
        (id ? existingById.get(id) : undefined) ||
        (code ? existingByCode.get(code) : undefined) ||
        (tk ? existingByTitleClass.get(tk) : undefined);

      const incQuestions = getServerRealQuestions(pkg.questions);

      if (existMatch) {
        const existId = String(existMatch.id || '').trim();
        if (existId) matchedExistingIds.add(existId);

        const existQuestions = getServerRealQuestions(existMatch.questions);
        const incQTs =
          typeof pkg.questionsUpdatedAt === 'number' &&
          Number.isFinite(pkg.questionsUpdatedAt)
            ? pkg.questionsUpdatedAt
            : 0;
        const existQTs =
          typeof existMatch.questionsUpdatedAt === 'number' &&
          Number.isFinite(existMatch.questionsUpdatedAt)
            ? existMatch.questionsUpdatedAt
            : 0;
        const isIncomingExplicitlyNewer =
          incQTs > existQTs && incQuestions.length > 0;

        // NEVER allow a 0-question package from a student/unhydrated browser to wipe out uploaded questions
        // unless the Admin explicitly deleted questions (forceReplace === true) or uploaded a newer replacement set
        if (
          !forceReplace &&
          !isIncomingExplicitlyNewer &&
          existQuestions.length > 0 &&
          incQuestions.length < existQuestions.length
        ) {
          return {
            ...pkg,
            questions: existQuestions,
            ...(existQTs > 0 ? { questionsUpdatedAt: existQTs } : {}),
          };
        }
        const resolvedQTs = Math.max(incQTs, existQTs);
        return {
          ...pkg,
          questions: incQuestions,
          ...(resolvedQTs > 0 ? { questionsUpdatedAt: resolvedQTs } : {}),
        };
      }
      return {
        ...pkg,
        questions: incQuestions,
      };
    });

  // Preserve any existing packages that were not deleted unless forceReplace explicitly replaced the list
  const preservedExisting: Record<string, any>[] = [];
  for (const existPkg of filteredExisting) {
    if (!existPkg || typeof existPkg !== 'object') continue;
    const existId = String(existPkg.id || '').trim();
    const existCode = String(existPkg.code || '')
      .trim()
      .toUpperCase();
    if (
      (existId && deletedSet.has(existId.toUpperCase())) ||
      (existCode && deletedSet.has(existCode))
    ) {
      continue;
    }
    if (existId && matchedExistingIds.has(existId)) {
      continue;
    }
    const tk = getPackageMatchKey(existPkg);
    const alreadyInMerged = mergedIncoming.some((m) => {
      const mCode = String(m.code || '')
        .trim()
        .toUpperCase();
      return (
        (existCode && mCode === existCode) ||
        (tk && getPackageMatchKey(m) === tk)
      );
    });
    if (alreadyInMerged) continue;

    const existQuestions = getServerRealQuestions(existPkg.questions);
    if (!forceReplace) {
      preservedExisting.push({
        ...existPkg,
        questions: existQuestions,
      });
    }
  }

  return [...mergedIncoming, ...preservedExisting];
}

function applyPackagePatches(
  existingList: unknown,
  patchesInput: unknown,
  deletedPackageIdsInput?: unknown,
  forceReplace?: boolean
): Record<string, any>[] {
  const deletedSet = new Set<string>(
    Array.isArray(deletedPackageIdsInput)
      ? deletedPackageIdsInput
          .map((id) => String(id || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );

  const baseList: Record<string, any>[] = Array.isArray(existingList)
    ? (existingList as any[])
        .filter((item) => {
          if (!item || typeof item !== 'object') return false;
          const id = String(item.id || '').trim().toUpperCase();
          const code = String(item.code || '').trim().toUpperCase();
          if (id && deletedSet.has(id)) return false;
          if (code && deletedSet.has(code)) return false;
          return true;
        })
        .map((item) => ({
          ...(item as Record<string, any>),
          questions: getServerRealQuestions((item as Record<string, any>).questions),
        }))
    : [];

  const patches = (
    Array.isArray(patchesInput) ? patchesInput : [patchesInput]
  ).filter((p) => p && typeof p === 'object') as Record<string, any>[];

  for (const pkg of patches) {
    const id = String(pkg.id || '').trim();
    const code = String(pkg.code || '').trim().toUpperCase();
    const tk = getPackageMatchKey(pkg);
    const incQuestions = getServerRealQuestions(pkg.questions);

    const matchIndex = baseList.findIndex((item) => {
      const itemId = String(item.id || '').trim();
      const itemCode = String(item.code || '').trim().toUpperCase();
      return (
        (id && itemId === id) ||
        (code && itemCode === code) ||
        (tk && getPackageMatchKey(item) === tk)
      );
    });

    if (matchIndex !== -1) {
      const existMatch = baseList[matchIndex];
      const existQuestions = getServerRealQuestions(existMatch.questions);
      const incQTs =
        typeof pkg.questionsUpdatedAt === 'number' &&
        Number.isFinite(pkg.questionsUpdatedAt)
          ? pkg.questionsUpdatedAt
          : 0;
      const existQTs =
        typeof existMatch.questionsUpdatedAt === 'number' &&
        Number.isFinite(existMatch.questionsUpdatedAt)
          ? existMatch.questionsUpdatedAt
          : 0;
      const isIncomingExplicitlyNewer =
        incQTs > existQTs && incQuestions.length > 0;

      if (
        !forceReplace &&
        !isIncomingExplicitlyNewer &&
        existQuestions.length > 0 &&
        incQuestions.length < existQuestions.length
      ) {
        baseList[matchIndex] = {
          ...existMatch,
          ...pkg,
          questions: existQuestions,
          ...(existQTs > 0 ? { questionsUpdatedAt: existQTs } : {}),
        };
      } else {
        const resolvedQTs = Math.max(incQTs, existQTs);
        baseList[matchIndex] = {
          ...existMatch,
          ...pkg,
          questions: incQuestions,
          ...(resolvedQTs > 0 ? { questionsUpdatedAt: resolvedQTs } : {}),
        };
      }
    } else {
      baseList.push({
        ...pkg,
        questions: incQuestions,
      });
    }
  }

  return baseList;
}

function applyPackageQuestionAppend(
  existingList: unknown,
  appendPayload: unknown
): Record<string, any>[] | undefined {
  const baseList = Array.isArray(existingList)
    ? [...(existingList as Record<string, any>[])]
    : [];
  if (!appendPayload || typeof appendPayload !== 'object') {
    return baseList.length > 0 ? baseList : undefined;
  }
  const ap = appendPayload as Record<string, any>;
  const targetId = String(ap.packageId || '').trim();
  const incomingQs = Array.isArray(ap.questions)
    ? getServerRealQuestions(ap.questions)
    : [];
  if (!targetId || incomingQs.length === 0) {
    return baseList.length > 0 ? baseList : undefined;
  }
  const matchIdx = baseList.findIndex(
    (p) => p && String(p.id || '').trim() === targetId
  );
  if (matchIdx === -1) {
    return baseList.length > 0 ? baseList : undefined;
  }
  const existPkg = baseList[matchIdx];
  const existQs = getServerRealQuestions(existPkg.questions);
  const seenIds = new Set(existQs.map((q) => String(q?.id || '').trim()));
  const mergedQs = [...existQs];
  for (const q of incomingQs) {
    const qid = String(q?.id || '').trim();
    if (!qid || !seenIds.has(qid)) {
      if (qid) seenIds.add(qid);
      mergedQs.push(q);
    }
  }
  const incQTs =
    typeof ap.questionsUpdatedAt === 'number' &&
    Number.isFinite(ap.questionsUpdatedAt)
      ? ap.questionsUpdatedAt
      : 0;
  const existQTs =
    typeof existPkg.questionsUpdatedAt === 'number' &&
    Number.isFinite(existPkg.questionsUpdatedAt)
      ? existPkg.questionsUpdatedAt
      : 0;
  const resolvedQTs = Math.max(incQTs, existQTs);
  baseList[matchIdx] = {
    ...existPkg,
    questions: mergedQs,
    ...(resolvedQTs > 0 ? { questionsUpdatedAt: resolvedQTs } : {}),
  };
  return baseList;
}

const PARTICIPANT_TS_FIELDS = [
  'metaUpdatedAt',
  'loginUpdatedAt',
  'draftUpdatedAt',
  'violationTimestamp',
  'lastResetAt',
  'violationResetAt',
] as const;

function normalizeClientTimestamp(
  rawTs: unknown,
  clientNow: number,
  serverNow: number,
  existingTs?: unknown
): number | undefined {
  if (typeof rawTs !== 'number' || !Number.isFinite(rawTs) || rawTs <= 0) {
    return undefined;
  }
  // Preserve unchanged timestamps that were echoed back verbatim from the server
  if (
    typeof existingTs === 'number' &&
    Number.isFinite(existingTs) &&
    existingTs === rawTs
  ) {
    return rawTs;
  }

  let normalized = rawTs;
  if (Number.isFinite(clientNow) && clientNow > 0) {
    const skewMs = serverNow - clientNow;
    // Only adjust timestamps generated near the client's current clock (within 24h)
    if (
      Math.abs(skewMs) > 2000 &&
      Math.abs(rawTs - clientNow) < 24 * 60 * 60 * 1000
    ) {
      normalized = rawTs + skewMs;
    }
  }
  // Never allow future-skewed client clocks to poison server merge comparisons
  if (normalized > serverNow + 2000) {
    normalized = serverNow;
  }
  return Math.max(1, Math.round(normalized));
}

function normalizeParticipantTimestamps(
  incomingRow: Record<string, any>,
  existingRow: Record<string, any> | undefined,
  clientNow: number,
  serverNow: number
): Record<string, any> {
  const out = { ...incomingRow };
  for (const field of PARTICIPANT_TS_FIELDS) {
    if (typeof out[field] === 'number' && out[field] > 0) {
      const adjusted = normalizeClientTimestamp(
        out[field],
        clientNow,
        serverNow,
        existingRow?.[field]
      );
      if (adjusted !== undefined) {
        out[field] = adjusted;
      }
    }
  }
  const existingResetAt =
    typeof existingRow?.lastResetAt === 'number' ? existingRow.lastResetAt : 0;
  const existingViolationResetAt =
    typeof existingRow?.violationResetAt === 'number'
      ? existingRow.violationResetAt
      : 0;
  const existingViolationTs =
    typeof existingRow?.violationTimestamp === 'number'
      ? existingRow.violationTimestamp
      : 0;
  if (
    typeof out.lastResetAt === 'number' &&
    out.lastResetAt > existingResetAt &&
    existingViolationTs > 0 &&
    out.lastResetAt <= existingViolationTs
  ) {
    out.lastResetAt = Math.max(serverNow, existingViolationTs + 1);
  }
  if (
    typeof out.violationResetAt === 'number' &&
    out.violationResetAt > existingViolationResetAt &&
    existingViolationTs > 0 &&
    out.violationResetAt <= existingViolationTs
  ) {
    out.violationResetAt = Math.max(serverNow, existingViolationTs + 1);
  }
  const effectiveResetAt = Math.max(
    typeof out.lastResetAt === 'number' ? out.lastResetAt : existingResetAt,
    typeof out.violationResetAt === 'number'
      ? out.violationResetAt
      : existingViolationResetAt
  );
  if (
    typeof out.examStartedAt === 'number' &&
    effectiveResetAt >= out.examStartedAt
  ) {
    preserveRemainingSecondsBeforeDeadlineClear(out, effectiveResetAt, serverNow);
    delete out.examStartedAt;
    delete out.examDeadlineAt;
  }
  return out;
}

function preserveRemainingSecondsBeforeDeadlineClear(
  row: Record<string, any>,
  effectiveResetAt: number,
  nowTs: number
): void {
  if (!row || typeof row !== 'object') return;
  if (row.loginState === 'Selesai') return;
  const startedAt =
    typeof row.examStartedAt === 'number' ? row.examStartedAt : 0;
  const deadlineAt =
    typeof row.examDeadlineAt === 'number' ? row.examDeadlineAt : 0;
  if (startedAt <= 0 || deadlineAt <= startedAt) return;
  const draftClearedAtReset =
    typeof row.draftUpdatedAt === 'number' &&
    row.draftUpdatedAt >= effectiveResetAt &&
    !row.draftPackageId &&
    row.draftRemainingSeconds === undefined;
  if (draftClearedAtReset) return;
  const vTs =
    typeof row.violationTimestamp === 'number' ? row.violationTimestamp : 0;
  const freezeAt =
    vTs >= startedAt && vTs <= effectiveResetAt
      ? vTs
      : Math.min(effectiveResetAt, nowTs);
  const frozenRemSecs = Math.max(1, Math.ceil((deadlineAt - freezeAt) / 1000));
  if (
    typeof row.draftRemainingSeconds !== 'number' ||
    row.draftRemainingSeconds <= 0 ||
    frozenRemSecs < row.draftRemainingSeconds
  ) {
    row.draftRemainingSeconds = frozenRemSecs;
  }
}

function getLocalFilePath(): string {
  // On Vercel Serverless environment, /tmp is writable
  if (process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME) {
    return path.join('/tmp', `${STORAGE_KEY}.json`);
  }
  const dataDir = path.join(process.cwd(), '.data');
  try {
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    return path.join(dataDir, `${STORAGE_KEY}.json`);
  } catch {
    return path.join('/tmp', `${STORAGE_KEY}.json`);
  }
}

function getKvConfig(): { url: string; token: string } | null {
  const directPairs: Array<[string | undefined, string | undefined]> = [
    [process.env.KV_REST_API_URL, process.env.KV_REST_API_TOKEN],
    [
      process.env.UPSTASH_REDIS_REST_URL,
      process.env.UPSTASH_REDIS_REST_TOKEN,
    ],
  ];

  for (const [rawUrl, rawToken] of directPairs) {
    const url = String(rawUrl || '').trim();
    const token = String(rawToken || '').trim();
    if (/^https?:\/\//i.test(url) && token) {
      return { url: url.replace(/\/$/, ''), token };
    }
  }

  // Fallback for Vercel Marketplace Redis integrations using custom prefixes
  // (e.g. STORAGE_KV_REST_API_URL / CBT_KV_REST_API_URL / REDIS_UPSTASH_REDIS_REST_URL)
  const envKeys = Object.keys(process.env);
  for (const key of envKeys) {
    if (
      !key.endsWith('_KV_REST_API_URL') &&
      !key.endsWith('_UPSTASH_REDIS_REST_URL') &&
      !key.endsWith('_REST_API_URL')
    ) {
      continue;
    }
    const url = String(process.env[key] || '').trim();
    if (!/^https?:\/\//i.test(url)) continue;
    const tokenKey = key.replace(/_URL$/, '_TOKEN');
    const token = String(process.env[tokenKey] || '').trim();
    if (token) {
      return { url: url.replace(/\/$/, ''), token };
    }
  }

  return null;
}

function parseKvHashResult(raw: unknown): Record<string, Record<string, any>> {
  const out: Record<string, Record<string, any>> = {};
  if (!raw) return out;
  if (Array.isArray(raw)) {
    for (let i = 0; i + 1 < raw.length; i += 2) {
      const field = String(raw[i] ?? '').trim();
      const valRaw = raw[i + 1];
      if (!field || valRaw == null) continue;
      try {
        const parsed =
          typeof valRaw === 'string' ? JSON.parse(valRaw) : valRaw;
        if (parsed && typeof parsed === 'object') {
          out[field] = parsed as Record<string, any>;
        }
      } catch {
        // ignore corrupt entry
      }
    }
    return out;
  }
  if (typeof raw === 'object') {
    for (const [field, valRaw] of Object.entries(
      raw as Record<string, unknown>
    )) {
      if (!field || valRaw == null) continue;
      try {
        const parsed =
          typeof valRaw === 'string' ? JSON.parse(valRaw) : valRaw;
        if (parsed && typeof parsed === 'object') {
          out[field] = parsed as Record<string, any>;
        }
      } catch {
        // ignore corrupt entry
      }
    }
  }
  return out;
}

function parseKvJsonValue(raw: unknown): Record<string, unknown> | null {
  if (!raw) return null;
  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return parsed && typeof parsed === 'object'
      ? (parsed as Record<string, unknown>)
      : null;
  } catch {
    return null;
  }
}

class KvLockBusyError extends Error {
  constructor(message = 'Database sedang memproses permintaan lain. Silakan coba lagi.') {
    super(message);
    this.name = 'KvLockBusyError';
  }
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = 6000
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function kvPipeline(
  kv: { url: string; token: string },
  commands: unknown[][],
  timeoutMs = 6000
): Promise<{ ok: boolean; results: unknown[] }> {
  try {
    const response = await fetchWithTimeout(
      `${kv.url}/pipeline`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${kv.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(commands),
      },
      timeoutMs
    );
    if (!response.ok) return { ok: false, results: [] };
    const json = (await response.json()) as Array<{
      result?: unknown;
      error?: string;
    }>;
    if (!Array.isArray(json)) return { ok: false, results: [] };
    const hasCommandError = json.some(
      (entry) => entry && typeof entry.error === 'string' && entry.error.trim() !== ''
    );
    return {
      ok: !hasCommandError,
      results: json.map((entry) => entry?.result),
    };
  } catch {
    return { ok: false, results: [] };
  }
}

async function acquireKvLock(
  kv: { url: string; token: string },
  lockToken: string,
  ttlMs = 6000,
  lockKey = LOCK_KEY
): Promise<boolean> {
  const maxAttempts = 12;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const res = await kvPipeline(
      kv,
      [['SET', lockKey, lockToken, 'NX', 'PX', ttlMs]],
      2500
    );
    if (res.ok && res.results[0] === 'OK') {
      return true;
    }
    const jitterMs = 35 + Math.floor(Math.random() * 55);
    await new Promise((resolve) => setTimeout(resolve, jitterMs));
  }
  return false;
}

async function releaseKvLock(
  kv: { url: string; token: string },
  lockToken: string,
  lockKey = LOCK_KEY
): Promise<void> {
  try {
    await kvPipeline(
      kv,
      [
        [
          'EVAL',
          "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end",
          1,
          lockKey,
          lockToken,
        ],
      ],
      2500
    );
  } catch {
    // Lock has short TTL and expires automatically
  }
}

async function withKvScopedLock<T>(
  kv: { url: string; token: string } | null,
  lockKey: string,
  fn: () => Promise<T>,
  ttlMs = 6000
): Promise<T> {
  if (!kv) {
    return fn();
  }
  const lockToken = `${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  const acquired = await acquireKvLock(kv, lockToken, ttlMs, lockKey);
  if (!acquired) {
    throw new KvLockBusyError();
  }
  try {
    return await fn();
  } finally {
    await releaseKvLock(kv, lockToken, lockKey);
  }
}

async function withKvDistributedLock<T>(
  kv: { url: string; token: string } | null,
  fn: () => Promise<T>
): Promise<T> {
  return withKvScopedLock(kv, LOCK_KEY, fn, 6000);
}

async function readMetaUpdatedAtFromKV(kv: {
  url: string;
  token: string;
}): Promise<number> {
  try {
    const response = await fetchWithTimeout(
      `${kv.url}/get/${encodeURIComponent(META_KEY)}`,
      {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${kv.token}`,
        },
      },
      4000
    );
    if (!response.ok) return 0;
    const json = (await response.json()) as { result?: unknown };
    const parsed = parseKvJsonValue(json?.result);
    return typeof parsed?.updatedAt === 'number' ? parsed.updatedAt : 0;
  } catch {
    return 0;
  }
}

async function readFromVercelKV(kv: {
  url: string;
  token: string;
}): Promise<Record<string, unknown> | null> {
  const pipe = await kvPipeline(kv, [
    ['GET', STORAGE_KEY],
    ['HGETALL', STUDENTS_HASH_KEY],
    ['HGETALL', RESULTS_HASH_KEY],
    ['GET', META_KEY],
    ['GET', SCHEDULES_KEY],
    ['GET', TOKEN_KEY],
    ['HGETALL', PACKAGES_HASH_KEY],
  ]);

  let baseDoc: Record<string, unknown> | null = null;
  let studentHashMap: Record<string, Record<string, any>> = {};
  let resultsHashMap: Record<string, Record<string, any>> = {};
  let packagesHashMap: Record<string, Record<string, any>> = {};
  let metaDoc: Record<string, unknown> | null = null;
  let schedulesDoc: Record<string, unknown> | null = null;
  let tokenDoc: Record<string, unknown> | null = null;

  if (pipe.ok && pipe.results.length >= 1) {
    baseDoc = parseKvJsonValue(pipe.results[0]);
    studentHashMap = parseKvHashResult(pipe.results[1]);
    resultsHashMap = parseKvHashResult(pipe.results[2]);
    metaDoc = parseKvJsonValue(pipe.results[3]);
    schedulesDoc = parseKvJsonValue(pipe.results[4]);
    tokenDoc = parseKvJsonValue(pipe.results[5]);
    packagesHashMap = parseKvHashResult(pipe.results[6]);
  } else {
    // Resilient fallback: read each KV key independently and chunk PACKAGES_HASH_KEY reads
    // so a transient pipeline failure or large combined payload never returns empty questions/data.
    const [baseRes, studentsRes, resultsRes, metaSchedTokRes, pkgKeysRes] =
      await Promise.all([
        kvPipeline(kv, [['GET', STORAGE_KEY]]),
        kvPipeline(kv, [['HGETALL', STUDENTS_HASH_KEY]]),
        kvPipeline(kv, [['HGETALL', RESULTS_HASH_KEY]]),
        kvPipeline(kv, [
          ['GET', META_KEY],
          ['GET', SCHEDULES_KEY],
          ['GET', TOKEN_KEY],
        ]),
        kvPipeline(kv, [['HKEYS', PACKAGES_HASH_KEY]]),
      ]);

    if (baseRes.ok) {
      baseDoc = parseKvJsonValue(baseRes.results[0]);
    } else {
      try {
        const response = await fetchWithTimeout(
          `${kv.url}/get/${encodeURIComponent(STORAGE_KEY)}`,
          {
            method: 'GET',
            headers: {
              Authorization: `Bearer ${kv.token}`,
            },
          },
          6000
        );
        if (response.ok) {
          const json = (await response.json()) as { result?: unknown };
          baseDoc = parseKvJsonValue(json?.result);
        }
      } catch {
        // ignore and continue hydrating isolated keys
      }
    }

    if (studentsRes.ok) {
      studentHashMap = parseKvHashResult(studentsRes.results[0]);
    }
    if (resultsRes.ok) {
      resultsHashMap = parseKvHashResult(resultsRes.results[0]);
    }
    if (metaSchedTokRes.ok) {
      metaDoc = parseKvJsonValue(metaSchedTokRes.results[0]);
      schedulesDoc = parseKvJsonValue(metaSchedTokRes.results[1]);
      tokenDoc = parseKvJsonValue(metaSchedTokRes.results[2]);
    }
    if (pkgKeysRes.ok && Array.isArray(pkgKeysRes.results[0])) {
      const pkgKeys = (pkgKeysRes.results[0] as unknown[])
        .map((k) => String(k ?? '').trim())
        .filter(Boolean);
      // Fetch package entries in small chunks of 3 keys so large embedded images never overflow a response
      const chunkSize = 3;
      for (let i = 0; i < pkgKeys.length; i += chunkSize) {
        const batchKeys = pkgKeys.slice(i, i + chunkSize);
        const hmgetRes = await kvPipeline(kv, [
          ['HMGET', PACKAGES_HASH_KEY, ...batchKeys],
        ]);
        if (hmgetRes.ok && Array.isArray(hmgetRes.results[0])) {
          const vals = hmgetRes.results[0] as unknown[];
          batchKeys.forEach((k, idx) => {
            const parsed = parseKvJsonValue(vals[idx]);
            if (parsed) {
              packagesHashMap[k] = parsed as Record<string, any>;
            }
          });
        } else {
          // If a 3-package chunk was still too large, fall back to 1 package at a time
          for (const singleKey of batchKeys) {
            const hgetRes = await kvPipeline(kv, [
              ['HGET', PACKAGES_HASH_KEY, singleKey],
            ]);
            if (hgetRes.ok) {
              const parsed = parseKvJsonValue(hgetRes.results[0]);
              if (parsed) {
                packagesHashMap[singleKey] = parsed as Record<string, any>;
              }
            }
          }
        }
      }
    }
  }

  const hashStudentRows = Object.values(studentHashMap);
  const hashResultRows = Object.values(resultsHashMap);
  const packagesMeta =
    packagesHashMap.__meta__ && typeof packagesHashMap.__meta__ === 'object'
      ? (packagesHashMap.__meta__ as Record<string, any>)
      : null;
  const hashPackageRows = Object.entries(packagesHashMap)
    .filter(([k, v]) => k !== '__meta__' && Boolean(v && typeof v === 'object'))
    .map(([, v]) => v);
  if (
    !baseDoc &&
    hashStudentRows.length === 0 &&
    hashResultRows.length === 0 &&
    hashPackageRows.length === 0 &&
    !schedulesDoc &&
    !tokenDoc
  ) {
    return null;
  }

  const doc: Record<string, unknown> = baseDoc ? { ...baseDoc } : {};

  // Merge sharded PACKAGES_HASH_KEY (authoritative per-package storage that bypasses single-key size limits)
  if (packagesMeta && Array.isArray(packagesMeta.deletedPackageIds)) {
    doc.deletedPackageIds = Array.from(
      new Set([
        ...(Array.isArray(doc.deletedPackageIds)
          ? (doc.deletedPackageIds as string[])
          : []),
        ...(packagesMeta.deletedPackageIds as string[]),
      ])
    );
  }
  const deletedPkgIdSet = new Set<string>(
    Array.isArray(doc.deletedPackageIds)
      ? (doc.deletedPackageIds as unknown[])
          .map((id) => String(id || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );
  const basePackages = Array.isArray(doc.packages)
    ? (doc.packages as Record<string, any>[])
    : [];
  if (hashPackageRows.length > 0 || (packagesMeta && Array.isArray(packagesMeta.packageIds))) {
    const hashPkgById = new Map<string, Record<string, any>>();
    for (const hPkg of hashPackageRows) {
      const id = String(hPkg.id || '').trim();
      const code = String(hPkg.code || '').trim().toUpperCase();
      if (
        (id && deletedPkgIdSet.has(id.toUpperCase())) ||
        (code && deletedPkgIdSet.has(code))
      ) {
        continue;
      }
      if (id) hashPkgById.set(id, hPkg);
    }

    const authoritativeOrder: string[] = Array.isArray(packagesMeta?.packageIds)
      ? (packagesMeta!.packageIds as unknown[])
          .map((id) => String(id || '').trim())
          .filter(Boolean)
      : [];
    const mergedPackages: Record<string, any>[] = [];
    const seenPkgIds = new Set<string>();

    // First preserve authoritative order from packagesMeta when available
    for (const id of authoritativeOrder) {
      if (seenPkgIds.has(id) || deletedPkgIdSet.has(id.toUpperCase())) continue;
      const hashPkg = hashPkgById.get(id);
      if (hashPkg) {
        seenPkgIds.add(id);
        mergedPackages.push(hashPkg);
      }
    }
    // Append any remaining hash packages not in packagesMeta order
    for (const [id, hashPkg] of hashPkgById.entries()) {
      if (seenPkgIds.has(id)) continue;
      seenPkgIds.add(id);
      mergedPackages.push(hashPkg);
    }
    // If packagesMeta doesn't exist yet (partial migration), keep non-deleted baseDoc packages missing from hash
    if (!packagesMeta) {
      for (const bPkg of basePackages) {
        if (!bPkg || typeof bPkg !== 'object') continue;
        const id = String(bPkg.id || '').trim();
        const code = String(bPkg.code || '').trim().toUpperCase();
        if (
          !id ||
          seenPkgIds.has(id) ||
          deletedPkgIdSet.has(id.toUpperCase()) ||
          (code && deletedPkgIdSet.has(code))
        ) {
          continue;
        }
        seenPkgIds.add(id);
        mergedPackages.push(bPkg);
      }
    }
    doc.packages = mergedPackages;
  }

  // Merge isolated lightweight SCHEDULES_KEY when newer or when baseDoc lacks schedules.
  // Never fall back baseSchedTs to doc.updatedAt because non-schedule writes advance doc.updatedAt.
  if (schedulesDoc && Array.isArray(schedulesDoc.schedules)) {
    const dedicatedSchedTs =
      typeof schedulesDoc.updatedAt === 'number' ? schedulesDoc.updatedAt : 0;
    const baseSchedTs =
      typeof doc.schedulesUpdatedAt === 'number' ? doc.schedulesUpdatedAt : 0;
    if (
      !Array.isArray(doc.schedules) ||
      (doc.schedules.length === 0 && baseSchedTs === 0) ||
      dedicatedSchedTs >= baseSchedTs
    ) {
      doc.schedules = schedulesDoc.schedules;
      if (Array.isArray(schedulesDoc.deletedScheduleIds)) {
        doc.deletedScheduleIds = Array.from(
          new Set([
            ...(Array.isArray(doc.deletedScheduleIds)
              ? (doc.deletedScheduleIds as string[])
              : []),
            ...(schedulesDoc.deletedScheduleIds as string[]),
          ])
        );
      }
      if (dedicatedSchedTs > 0) {
        doc.schedulesUpdatedAt = dedicatedSchedTs;
      }
    }
  }
  if (doc.adminSettings && typeof doc.adminSettings === 'object') {
    doc.adminSettings = sanitizeServerAdminSettings(
      doc.adminSettings,
      doc.deletedPackageIds
    );
  }
  if (Array.isArray(doc.packages)) {
    doc.packages = sanitizeServerPackages(
      doc.packages,
      doc.deletedPackageIds,
      doc.adminSettings
    );
  }
  if (Array.isArray(doc.schedules)) {
    doc.schedules = sanitizeServerSchedules(
      doc.schedules,
      doc.deletedScheduleIds,
      doc.packages,
      doc.deletedPackageIds,
      doc.adminSettings
    );
  }

  // Merge isolated lightweight TOKEN_KEY when newer
  if (tokenDoc && typeof tokenDoc.activeToken === 'string' && tokenDoc.activeToken.trim()) {
    const dedicatedTokTs =
      typeof tokenDoc.tokenUpdatedAt === 'number' ? tokenDoc.tokenUpdatedAt : 0;
    const baseTokTs =
      typeof doc.tokenUpdatedAt === 'number' ? doc.tokenUpdatedAt : 0;
    if (!doc.activeToken || dedicatedTokTs >= baseTokTs) {
      doc.activeToken = tokenDoc.activeToken;
      if (dedicatedTokTs > 0) doc.tokenUpdatedAt = dedicatedTokTs;
      if (typeof tokenDoc.previousActiveToken === 'string') {
        doc.previousActiveToken = tokenDoc.previousActiveToken;
      }
      if (typeof tokenDoc.previousTokenValidUntil === 'number') {
        doc.previousTokenValidUntil = tokenDoc.previousTokenValidUntil;
      }
    }
  }
  const deletedParticipantIds = new Set<string>(
    Array.isArray(doc.deletedParticipantIds)
      ? (doc.deletedParticipantIds as unknown[])
          .map((id) => String(id || '').trim())
          .filter(Boolean)
      : []
  );

  // Merge base participants with atomic per-student hash entries
  const baseParticipants = Array.isArray(doc.participants)
    ? (doc.participants as Record<string, any>[])
    : [];
  if (hashStudentRows.length > 0 || baseParticipants.length > 0) {
    const combinedByUser = new Map<string, Record<string, any>>();
    const extraNoUser: Record<string, any>[] = [];

    for (const row of baseParticipants) {
      if (!row || typeof row !== 'object') continue;
      const id = String(row.id || '').trim();
      if (id && deletedParticipantIds.has(id)) continue;
      const u = String(row.username || '')
        .trim()
        .toUpperCase();
      if (u) {
        const existing = combinedByUser.get(u);
        combinedByUser.set(
          u,
          existing ? mergeServerDuplicateRows(existing, row) : row
        );
      } else {
        extraNoUser.push(row);
      }
    }

    for (const hashRow of hashStudentRows) {
      if (!hashRow || typeof hashRow !== 'object') continue;
      const id = String(hashRow.id || '').trim();
      if (id && deletedParticipantIds.has(id)) continue;
      const u = String(hashRow.username || '')
        .trim()
        .toUpperCase();
      if (u) {
        const existing = combinedByUser.get(u);
        combinedByUser.set(
          u,
          existing ? mergeServerDuplicateRows(existing, hashRow) : hashRow
        );
      } else {
        extraNoUser.push(hashRow);
      }
    }

    doc.participants = sanitizeParticipantsList([
      ...combinedByUser.values(),
      ...extraNoUser,
    ]);
  }

  // Merge base resultsHistory with atomic per-result hash entries (newest retake wins)
  const baseResults = Array.isArray(doc.resultsHistory)
    ? (doc.resultsHistory as Record<string, any>[])
    : [];
  if (hashResultRows.length > 0 || baseResults.length > 0) {
    doc.resultsHistory = dedupeServerResultsHistory([
      ...hashResultRows,
      ...baseResults,
    ]);
  }

  const baseUpdatedAt =
    typeof doc.updatedAt === 'number' ? doc.updatedAt : 0;
  const metaUpdatedAt =
    typeof metaDoc?.updatedAt === 'number' ? metaDoc.updatedAt : 0;
  const effectiveUpdatedAt = Math.max(baseUpdatedAt, metaUpdatedAt);
  if (effectiveUpdatedAt > 0) {
    doc.updatedAt = effectiveUpdatedAt;
  }

  return doc;
}

async function writeToVercelKV(
  kv: { url: string; token: string },
  payload: Record<string, unknown>,
  options?: {
    syncStudentsHash?: boolean;
    syncResultsHash?: boolean;
    clearResultsHash?: boolean;
    syncSchedulesKey?: boolean;
    syncTokenKey?: boolean;
    syncPackagesHash?: boolean;
    changedPackageIds?: string[];
    requireBaseDoc?: boolean;
  }
): Promise<boolean> {
  try {
    const nowTs =
      typeof payload.updatedAt === 'number' ? payload.updatedAt : Date.now();
    const studentHashCommands: unknown[][] = [];
    const resultHashCommands: unknown[][] = [];

    const shouldSyncStudents = options?.syncStudentsHash ?? true;
    if (shouldSyncStudents && Array.isArray(payload.participants)) {
      const desiredUsers = new Set<string>();
      const pairs: string[] = [];
      for (const row of payload.participants as Record<string, any>[]) {
        if (!row || typeof row !== 'object') continue;
        const u = String(row.username || '')
          .trim()
          .toUpperCase();
        if (u) {
          desiredUsers.add(u);
          pairs.push(u, JSON.stringify(row));
        }
      }

      if (pairs.length === 0) {
        studentHashCommands.push(['DEL', STUDENTS_HASH_KEY]);
      } else {
        // Read existing hash keys first so we never wipe the entire hash with DEL before HSET
        const hkeysPipe = await kvPipeline(kv, [['HKEYS', STUDENTS_HASH_KEY]]);
        const existingKeys =
          hkeysPipe.ok && Array.isArray(hkeysPipe.results[0])
            ? (hkeysPipe.results[0] as unknown[])
                .map((k) => String(k ?? '').trim())
                .filter(Boolean)
            : [];
        const obsoleteKeys = existingKeys.filter((k) => !desiredUsers.has(k));

        // Chunk HSET calls to stay comfortably within Redis command size limits
        const chunkPairSize = 100; // 50 rows per HSET
        for (let i = 0; i < pairs.length; i += chunkPairSize) {
          studentHashCommands.push([
            'HSET',
            STUDENTS_HASH_KEY,
            ...pairs.slice(i, i + chunkPairSize),
          ]);
        }
        if (obsoleteKeys.length > 0) {
          studentHashCommands.push(['HDEL', STUDENTS_HASH_KEY, ...obsoleteKeys]);
        }
      }
    }

    const shouldSyncResults = options?.syncResultsHash ?? true;
    if (options?.clearResultsHash) {
      resultHashCommands.push(['DEL', RESULTS_HASH_KEY]);
    } else if (shouldSyncResults && Array.isArray(payload.resultsHistory)) {
      const desiredResultIds = new Set<string>();
      const rPairs: string[] = [];
      for (const item of payload.resultsHistory as Record<string, any>[]) {
        if (!item || typeof item !== 'object') continue;
        const id = String(item.id || '').trim();
        if (id) {
          desiredResultIds.add(id);
          rPairs.push(id, JSON.stringify(item));
        }
      }
      if (desiredResultIds.size === 0) {
        resultHashCommands.push(['DEL', RESULTS_HASH_KEY]);
      } else {
        const resHkeysPipe = await kvPipeline(kv, [['HKEYS', RESULTS_HASH_KEY]]);
        const existingResKeys =
          resHkeysPipe.ok && Array.isArray(resHkeysPipe.results[0])
            ? (resHkeysPipe.results[0] as unknown[])
                .map((k) => String(k ?? '').trim())
                .filter(Boolean)
            : [];
        const obsoleteResultKeys = existingResKeys.filter(
          (k) => !desiredResultIds.has(k)
        );
        const chunkPairSize = 100;
        for (let i = 0; i < rPairs.length; i += chunkPairSize) {
          resultHashCommands.push([
            'HSET',
            RESULTS_HASH_KEY,
            ...rPairs.slice(i, i + chunkPairSize),
          ]);
        }
        if (obsoleteResultKeys.length > 0) {
          resultHashCommands.push([
            'HDEL',
            RESULTS_HASH_KEY,
            ...obsoleteResultKeys,
          ]);
        }
      }
    }

    // Helper: write packages into sharded per-package hash in safe byte-capped batches
    const syncPackagesToHash = async (
      onlyIds?: string[]
    ): Promise<boolean> => {
      if (!Array.isArray(payload.packages)) return true;
      const pkgList = (payload.packages as Record<string, any>[]).filter(
        (p) => p && typeof p === 'object' && String(p.id || '').trim()
      );
      const desiredIds = pkgList.map((p) => String(p.id).trim());
      const desiredSet = new Set(desiredIds);

      const hkeysPipe = await kvPipeline(kv, [['HKEYS', PACKAGES_HASH_KEY]]);
      const existingPkgKeys =
        hkeysPipe.ok && Array.isArray(hkeysPipe.results[0])
          ? (hkeysPipe.results[0] as unknown[])
              .map((k) => String(k ?? '').trim())
              .filter(Boolean)
          : [];
      const hasExistingMeta = existingPkgKeys.includes('__meta__');
      const obsoletePkgKeys = existingPkgKeys.filter(
        (k) => k !== '__meta__' && !desiredSet.has(k)
      );

      const onlyIdSet =
        hasExistingMeta && Array.isArray(onlyIds) && onlyIds.length > 0
          ? new Set(onlyIds.map((id) => String(id).trim()).filter(Boolean))
          : null;

      const pkgsToWrite = onlyIdSet
        ? pkgList.filter((p) => onlyIdSet.has(String(p.id).trim()))
        : pkgList;

      // Batch HSET commands under ~1.5 MB per pipeline request to avoid single-request size limits
      const MAX_BATCH_BYTES = 1_500_000;
      let batchCmds: unknown[][] = [];
      let batchBytes = 0;

      const flushBatch = async (): Promise<boolean> => {
        if (batchCmds.length === 0) return true;
        const pipeRes = await kvPipeline(kv, batchCmds);
        batchCmds = [];
        batchBytes = 0;
        return pipeRes.ok;
      };

      for (const pkg of pkgsToWrite) {
        const pkgId = String(pkg.id).trim();
        const serialized = JSON.stringify(pkg);
        if (batchCmds.length > 0 && batchBytes + serialized.length > MAX_BATCH_BYTES) {
          const ok = await flushBatch();
          if (!ok) return false;
        }
        batchCmds.push(['HSET', PACKAGES_HASH_KEY, pkgId, serialized]);
        batchBytes += serialized.length;
      }

      const metaValue = JSON.stringify({
        deletedPackageIds: Array.isArray(payload.deletedPackageIds)
          ? payload.deletedPackageIds
          : [],
        packageIds: desiredIds,
        updatedAt: nowTs,
      });
      batchCmds.push(['HSET', PACKAGES_HASH_KEY, '__meta__', metaValue]);
      if (obsoletePkgKeys.length > 0) {
        batchCmds.push(['HDEL', PACKAGES_HASH_KEY, ...obsoletePkgKeys]);
      }
      batchCmds.push(['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })]);

      return flushBatch();
    };

    // 1. Write lightweight isolated keys (students, results, schedules, token, sharded packages) + META_KEY first
    //    so Active status, schedule toggles, exam results, tokens, and questions ALWAYS persist even if STORAGE_KEY is large.
    let studentsHashOk = true;
    if (studentHashCommands.length > 0) {
      const stPipe = await kvPipeline(kv, [
        ...studentHashCommands,
        ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
      ]);
      studentsHashOk = stPipe.ok;
    }

    let resultsHashOk = true;
    if (resultHashCommands.length > 0) {
      const resPipe = await kvPipeline(kv, [
        ...resultHashCommands,
        ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
      ]);
      resultsHashOk = resPipe.ok;
    }

    const shouldSyncSchedules = Boolean(options?.syncSchedulesKey);
    let schedulesKeyOk = true;
    if (shouldSyncSchedules && Array.isArray(payload.schedules)) {
      const schedUpdatedTs =
        typeof payload.schedulesUpdatedAt === 'number' &&
        payload.schedulesUpdatedAt > 0
          ? payload.schedulesUpdatedAt
          : nowTs;
      const schedPipe = await kvPipeline(kv, [
        [
          'SET',
          SCHEDULES_KEY,
          JSON.stringify({
            schedules: payload.schedules,
            deletedScheduleIds: Array.isArray(payload.deletedScheduleIds)
              ? payload.deletedScheduleIds
              : [],
            updatedAt: schedUpdatedTs,
          }),
        ],
        ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
      ]);
      schedulesKeyOk = schedPipe.ok;
    }

    const shouldSyncToken = Boolean(options?.syncTokenKey);
    let tokenKeyOk = true;
    if (
      shouldSyncToken &&
      typeof payload.activeToken === 'string' &&
      payload.activeToken.trim()
    ) {
      const tokPipe = await kvPipeline(kv, [
        [
          'SET',
          TOKEN_KEY,
          JSON.stringify({
            activeToken: payload.activeToken,
            tokenUpdatedAt:
              typeof payload.tokenUpdatedAt === 'number'
                ? payload.tokenUpdatedAt
                : nowTs,
            previousActiveToken: payload.previousActiveToken || '',
            previousTokenValidUntil: payload.previousTokenValidUntil || 0,
            updatedAt: nowTs,
          }),
        ],
        ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
      ]);
      tokenKeyOk = tokPipe.ok;
    }

    const shouldSyncPackages = Boolean(options?.syncPackagesHash);
    let packagesHashOk = true;
    if (shouldSyncPackages && Array.isArray(payload.packages)) {
      packagesHashOk = await syncPackagesToHash(options?.changedPackageIds);
    }

    // 2. Write main STORAGE_KEY document + META_KEY separately.
    //    If full STORAGE_KEY exceeds KV size limits due to embedded images across many subjects,
    //    ensure PACKAGES_HASH_KEY holds the full packages and write a lightweight slimmed STORAGE_KEY
    //    so adminSettings, proctors, schedules, and metadata always persist safely.
    let baseDocOk = false;
    const serializedFullPayload = JSON.stringify(payload);
    const MAX_SINGLE_KEY_BYTES = 2_500_000;

    if (serializedFullPayload.length <= MAX_SINGLE_KEY_BYTES) {
      const basePipe = await kvPipeline(kv, [
        ['SET', STORAGE_KEY, serializedFullPayload],
        ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
      ]);
      if (basePipe.ok) {
        baseDocOk = true;
      } else {
        const response = await fetchWithTimeout(
          `${kv.url}/set/${encodeURIComponent(STORAGE_KEY)}`,
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${kv.token}`,
              'Content-Type': 'application/json',
            },
            body: serializedFullPayload,
          },
          8000
        );
        baseDocOk = response.ok;
        if (baseDocOk) {
          await kvPipeline(kv, [
            ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
          ]);
        }
      }
    }

    if (!baseDocOk && Array.isArray(payload.packages) && payload.packages.length > 0) {
      // Ensure all packages are safely mirrored in PACKAGES_HASH_KEY before slimming STORAGE_KEY
      const mirrorOk = shouldSyncPackages
        ? packagesHashOk
        : await syncPackagesToHash();
      if (mirrorOk) {
        const slimPayload: Record<string, unknown> = {
          ...payload,
          packages: (payload.packages as Record<string, any>[]).map((pkg) =>
            pkg && typeof pkg === 'object' ? { ...pkg, questions: [] } : pkg
          ),
        };
        const slimPipe = await kvPipeline(kv, [
          ['SET', STORAGE_KEY, JSON.stringify(slimPayload)],
          ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
        ]);
        baseDocOk = slimPipe.ok;
      }
    }

    // Validate ALL requested persistence targets (no short-circuiting so dual writes like submit_exam
    // or schedule+token never report success when one of the required targets failed).
    let allRequestedOk = true;
    let hasIsolatedTarget = false;

    if (shouldSyncStudents && studentHashCommands.length > 0) {
      hasIsolatedTarget = true;
      if (!studentsHashOk && !baseDocOk) allRequestedOk = false;
    }
    if (shouldSyncResults && resultHashCommands.length > 0) {
      hasIsolatedTarget = true;
      if (!resultsHashOk && !baseDocOk) allRequestedOk = false;
    }
    if (shouldSyncSchedules && Array.isArray(payload.schedules)) {
      hasIsolatedTarget = true;
      if (!schedulesKeyOk && !baseDocOk) allRequestedOk = false;
    }
    if (
      shouldSyncToken &&
      typeof payload.activeToken === 'string' &&
      payload.activeToken.trim()
    ) {
      hasIsolatedTarget = true;
      if (!tokenKeyOk && !baseDocOk) allRequestedOk = false;
    }
    if (shouldSyncPackages && Array.isArray(payload.packages)) {
      hasIsolatedTarget = true;
      if (!packagesHashOk && !baseDocOk) allRequestedOk = false;
    }
    if (options?.requireBaseDoc && !baseDocOk) {
      allRequestedOk = false;
    }

    return hasIsolatedTarget ? allRequestedOk : baseDocOk;
  } catch {
    return false;
  }
}

async function tryAtomicKvFastPatch(
  kv: { url: string; token: string },
  body: Record<string, unknown>,
  session?: SessionClaims | null
): Promise<{ handled: boolean; updatedAt: number; sessionReplaced?: boolean }> {
  const sessionRole = session?.role;
  const allowedFastKeys = new Set([
    'participantPatch',
    'resultAppend',
    'schemaVersion',
    'clientNow',
  ]);
  const bodyKeys = Object.keys(body);
  const isFastEligible =
    bodyKeys.length > 0 &&
    bodyKeys.every((k) => allowedFastKeys.has(k)) &&
    (body.participantPatch !== undefined || body.resultAppend !== undefined);

  if (!isFastEligible) {
    return { handled: false, updatedAt: 0 };
  }

  const clientNow =
    typeof body.clientNow === 'number' && Number.isFinite(body.clientNow)
      ? body.clientNow
      : 0;

  let singleFastUserLock: string | null = null;
  if (body.participantPatch !== undefined && body.resultAppend === undefined) {
    const rawList = (
      Array.isArray(body.participantPatch)
        ? body.participantPatch
        : [body.participantPatch]
    ).filter((p) => p && typeof p === 'object') as Record<string, any>[];
    if (rawList.length === 1) {
      const u = String(rawList[0].username || '').trim().toUpperCase();
      if (u) singleFastUserLock = u;
    }
  }

  const fastLockKey = singleFastUserLock
    ? `${LOCK_KEY}:student:${singleFastUserLock}`
    : LOCK_KEY;

  return enqueueScopedWrite(singleFastUserLock, () =>
    withKvScopedLock(kv, fastLockKey, async () => {
      const nowTs = Date.now();
  const writeCommands: unknown[][] = [];

  if (body.participantPatch !== undefined) {
    const rawPatches = (
      Array.isArray(body.participantPatch)
        ? body.participantPatch
        : [body.participantPatch]
    ).filter((p) => p && typeof p === 'object') as Record<string, any>[];

    const usernames = Array.from(
      new Set(
        rawPatches
          .map((p) => String(p.username || '').trim().toUpperCase())
          .filter(Boolean)
      )
    );

    if (usernames.length > 0) {
      const readPipe = await kvPipeline(kv, [
        ['HMGET', STUDENTS_HASH_KEY, ...usernames],
      ]);
      if (!readPipe.ok) {
        return { handled: false, updatedAt: 0 };
      }

      const hmgetArr = Array.isArray(readPipe.results[0])
        ? (readPipe.results[0] as unknown[])
        : [];
      const existingByUser = new Map<string, Record<string, any>>();
      let hasMissingInHash = false;

      usernames.forEach((u, idx) => {
        const parsed = parseKvJsonValue(hmgetArr[idx]);
        if (parsed) {
          existingByUser.set(u, parsed as Record<string, any>);
        } else {
          hasMissingInHash = true;
        }
      });

      // Fallback once to base doc only for students missing from hash
      if (hasMissingInHash) {
        const basePipe = await kvPipeline(kv, [['GET', STORAGE_KEY]]);
        if (basePipe.ok) {
          const baseDoc = parseKvJsonValue(basePipe.results[0]);
          const baseList = Array.isArray(baseDoc?.participants)
            ? (baseDoc!.participants as Record<string, any>[])
            : [];
          for (const row of baseList) {
            if (!row || typeof row !== 'object') continue;
            const u = String(row.username || '')
              .trim()
              .toUpperCase();
            if (u && usernames.includes(u) && !existingByUser.has(u)) {
              existingByUser.set(u, row);
            }
          }
        }
      }

      const hsetPairs: string[] = [];
      for (const patch of rawPatches) {
        const patchUser = String(patch.username || '')
          .trim()
          .toUpperCase();
        if (!patchUser) continue;

        const existingRow = existingByUser.get(patchUser);
        if (
          session?.role === 'student' &&
          session.sid &&
          existingRow?.activeSessionNonce &&
          existingRow.activeSessionNonce !== session.sid
        ) {
          return { handled: false, updatedAt: 0, sessionReplaced: true };
        }
        const normalizedPatch = normalizeParticipantTimestamps(
          patch,
          existingRow,
          clientNow,
          nowTs
        );
        let mergedRow: Record<string, any>;
        if (existingRow) {
          const candidate = { ...existingRow };
          for (const [k, val] of Object.entries(normalizedPatch)) {
            if (val === undefined || val === null) {
              delete candidate[k];
            } else {
              candidate[k] = val;
            }
          }
          // Ensure explicit Admin/Proctor status writes strictly win over any older/skewed metaUpdatedAt
          const hasExplicitStatus =
            typeof normalizedPatch.status === 'string' &&
            normalizedPatch.status.trim() !== '';
          if (hasExplicitStatus) {
            const normalizedStatusVal = isServerRowStatusActive(
              normalizedPatch.status
            )
              ? 'Active'
              : 'Non Active';
            candidate.status = normalizedStatusVal;
            const statusDiffers =
              normalizedStatusVal !==
              (isServerRowStatusActive(existingRow.status)
                ? 'Active'
                : 'Non Active');
            if (
              statusDiffers ||
              sessionRole === 'admin' ||
              sessionRole === 'proctor'
            ) {
              const existMeta =
                typeof existingRow.metaUpdatedAt === 'number'
                  ? existingRow.metaUpdatedAt
                  : 0;
              const patchMeta =
                typeof normalizedPatch.metaUpdatedAt === 'number'
                  ? normalizedPatch.metaUpdatedAt
                  : 0;
              const existSrvStatus =
                typeof existingRow.serverStatusUpdatedAt === 'number'
                  ? existingRow.serverStatusUpdatedAt
                  : 0;
              candidate.metaUpdatedAt = Math.max(
                existMeta + 1,
                patchMeta,
                nowTs
              );
              candidate.serverStatusUpdatedAt = Math.max(
                existSrvStatus + 1,
                nowTs
              );
            }
          }
          mergedRow = mergeServerDuplicateRows(existingRow, candidate);
        } else {
          // Never fabricate a brand-new Active participant row from a student patch
          if (sessionRole === 'student' || !normalizedPatch.namaPeserta) {
            continue;
          }
          const cleanNew: Record<string, any> = {
            id: String(normalizedPatch.id || `p_${nowTs}`),
            selected: false,
            status: isServerRowStatusActive(normalizedPatch.status)
              ? 'Active'
              : 'Non Active',
            kodeTes: normalizedPatch.kodeTes || 'SAS26SMADIP1',
            username: patchUser,
            namaPeserta: normalizedPatch.namaPeserta || patchUser,
            kelompok: normalizedPatch.kelompok || 'Ruang 1',
            kelas: normalizedPatch.kelas || 'X',
            loginState: normalizedPatch.loginState || 'Belum Login',
            requestReset: Boolean(normalizedPatch.requestReset),
            serverStatusUpdatedAt: nowTs,
          };
          for (const [k, val] of Object.entries(normalizedPatch)) {
            if (val !== undefined && val !== null) {
              cleanNew[k] = val;
            }
          }
          cleanNew.status = isServerRowStatusActive(cleanNew.status)
            ? 'Active'
            : 'Non Active';
          cleanNew.serverStatusUpdatedAt = nowTs;
          mergedRow = cleanNew;
        }

        const sanitizedSingle = sanitizeParticipantsList([mergedRow])[0];
        if (sanitizedSingle) {
          existingByUser.set(patchUser, sanitizedSingle);
          hsetPairs.push(patchUser, JSON.stringify(sanitizedSingle));
        }
      }

      if (hsetPairs.length > 0) {
        const chunkPairSize = 100; // 50 rows per HSET command
        for (let i = 0; i < hsetPairs.length; i += chunkPairSize) {
          writeCommands.push([
            'HSET',
            STUDENTS_HASH_KEY,
            ...hsetPairs.slice(i, i + chunkPairSize),
          ]);
        }
      }
    }
  }

  if (body.resultAppend && typeof body.resultAppend === 'object') {
    const resItem = body.resultAppend as Record<string, any>;
    const resId = String(resItem.id || `res_${nowTs}`).trim();
    writeCommands.push(['HSET', RESULTS_HASH_KEY, resId, JSON.stringify(resItem)]);
  }

  if (writeCommands.length === 0) {
    return { handled: false, updatedAt: 0 };
  }

  writeCommands.push(['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })]);
  const writePipe = await kvPipeline(kv, writeCommands);
  if (!writePipe.ok) {
    return { handled: false, updatedAt: 0 };
  }

  // Also keep in-memory cache coherent if warm
  const cached = globalThis.__SMADIP_CBT_MEM_STORE__;
  if (cached && typeof cached === 'object') {
    if (body.participantPatch !== undefined) {
      cached.participants = applyParticipantPatches(
        cached.participants,
        body.participantPatch,
        clientNow,
        nowTs
      );
    }
    if (body.resultAppend && typeof body.resultAppend === 'object') {
      const prevHist = Array.isArray(cached.resultsHistory)
        ? (cached.resultsHistory as Record<string, any>[])
        : [];
      const app = body.resultAppend as Record<string, any>;
      if (!prevHist.some((x) => x?.id === app.id)) {
        cached.resultsHistory = [app, ...prevHist];
      }
    }
    cached.updatedAt = nowTs;
  }

      return { handled: true, updatedAt: nowTs };
    })
  );
}

function enqueueSerializedWrite<T>(fn: () => Promise<T>): Promise<T> {
  const prev = globalThis.__SMADIP_CBT_WRITE_QUEUE__ || Promise.resolve();
  const next = prev.then(fn, fn);
  globalThis.__SMADIP_CBT_WRITE_QUEUE__ = next.then(
    () => undefined,
    () => undefined
  );
  return next;
}

function enqueueScopedWrite<T>(
  scopeKey: string | null,
  fn: () => Promise<T>
): Promise<T> {
  if (!scopeKey) {
    return enqueueSerializedWrite(fn);
  }
  if (!globalThis.__SMADIP_CBT_SCOPED_QUEUES__) {
    globalThis.__SMADIP_CBT_SCOPED_QUEUES__ = new Map<string, Promise<void>>();
  }
  const queues = globalThis.__SMADIP_CBT_SCOPED_QUEUES__;
  const prev = queues.get(scopeKey) || Promise.resolve();
  const next = prev.then(fn, fn);
  const tail = next.then(
    () => {
      if (queues.get(scopeKey) === tail) {
        queues.delete(scopeKey);
      }
    },
    () => {
      if (queues.get(scopeKey) === tail) {
        queues.delete(scopeKey);
      }
    }
  );
  queues.set(scopeKey, tail);
  return next;
}

function readFromFileOrMemory(): Record<string, unknown> | null {
  try {
    const filePath = getLocalFilePath();
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf-8');
      const parsed = JSON.parse(raw) as Record<string, unknown>;
      globalThis.__SMADIP_CBT_MEM_STORE__ = parsed;
      return parsed;
    }
  } catch {
    // Fallback to memory store
  }
  return globalThis.__SMADIP_CBT_MEM_STORE__ || null;
}

function writeToFileAndMemory(payload: Record<string, unknown>): void {
  globalThis.__SMADIP_CBT_MEM_STORE__ = payload;
  try {
    const filePath = getLocalFilePath();
    fs.writeFileSync(filePath, JSON.stringify(payload), 'utf-8');
  } catch {
    // Ignore write errors in read-only filesystems
  }
}

function normalizeServerKelas(raw?: unknown): string {
  if (typeof raw !== 'string' || !raw) return '';
  const s = raw
    .replace(/^kelas\s+/i, '')
    .replace(/\s*\(.*?\)\s*/g, ' ')
    .replace(/[-_]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toUpperCase();
  if (!s) return '';
  if (/^(XII|12)\b/.test(s)) {
    if (s.includes('IPS')) return 'XII IPS';
    if (s.includes('IPA') || s.includes('MIPA')) return 'XII IPA';
    return s.replace(/^12\b/, 'XII');
  }
  if (/^(XI|11)\b/.test(s)) {
    if (s.includes('IPS')) return 'XI IPS';
    if (s.includes('IPA') || s.includes('MIPA')) return 'XI IPA';
    return s.replace(/^11\b/, 'XI');
  }
  if (/^(X|10)\b/.test(s)) {
    return 'X';
  }
  return s;
}

function getServerParticipantNameKelasKey(row: unknown): string {
  if (!row || typeof row !== 'object') return '';
  const r = row as Record<string, any>;
  const name = String(r.namaPeserta || '')
    .trim()
    .replace(/\s+/g, ' ')
    .toUpperCase();
  if (!name) return '';
  const kelas = normalizeServerKelas(r.kelas);
  return `${name}__${kelas}`;
}

function getServerLoginPriority(state?: unknown): number {
  if (state === 'Selesai') return 4;
  if (state === 'Terkunci (Pelanggaran)') return 3;
  if (state === 'Sedang Mengerjakan') return 2;
  return 1;
}

function mergeServerDuplicateRows(
  existing: Record<string, any>,
  incoming: Record<string, any>
): Record<string, any> {
  const existingPriority = getServerLoginPriority(existing.loginState);
  const incomingPriority = getServerLoginPriority(incoming.loginState);
  const existingDraftCount =
    existing.draftAnswers && typeof existing.draftAnswers === 'object'
      ? Object.keys(existing.draftAnswers).length
      : 0;
  const incomingDraftCount =
    incoming.draftAnswers && typeof incoming.draftAnswers === 'object'
      ? Object.keys(incoming.draftAnswers).length
      : 0;

  const existingIsActive = isServerRowStatusActive(existing.status);
  const incomingIsActive = isServerRowStatusActive(incoming.status);

  const existSrvStatusTs =
    typeof existing.serverStatusUpdatedAt === 'number'
      ? existing.serverStatusUpdatedAt
      : 0;
  const incSrvStatusTs =
    typeof incoming.serverStatusUpdatedAt === 'number'
      ? incoming.serverStatusUpdatedAt
      : 0;
  const maxServerStatusUpdatedAt = Math.max(existSrvStatusTs, incSrvStatusTs);

  const existMetaTs =
    typeof existing.metaUpdatedAt === 'number' ? existing.metaUpdatedAt : 0;
  const incMetaTs =
    typeof incoming.metaUpdatedAt === 'number' ? incoming.metaUpdatedAt : 0;
  const maxMetaUpdatedAt = Math.max(existMetaTs, incMetaTs);

  const existLoginTs =
    typeof existing.loginUpdatedAt === 'number' ? existing.loginUpdatedAt : 0;
  const incLoginTs =
    typeof incoming.loginUpdatedAt === 'number' ? incoming.loginUpdatedAt : 0;
  const maxLoginUpdatedAt = Math.max(existLoginTs, incLoginTs);

  const existDraftTs =
    typeof existing.draftUpdatedAt === 'number' ? existing.draftUpdatedAt : 0;
  const incDraftTs =
    typeof incoming.draftUpdatedAt === 'number' ? incoming.draftUpdatedAt : 0;
  const maxDraftUpdatedAt = Math.max(existDraftTs, incDraftTs);

  const existViolationTs =
    existing.violationSchema === 3 &&
    typeof existing.violationTimestamp === 'number'
      ? existing.violationTimestamp
      : 0;
  const incViolationTs =
    incoming.violationSchema === 3 &&
    typeof incoming.violationTimestamp === 'number'
      ? incoming.violationTimestamp
      : 0;
  const maxViolationTs = Math.max(existViolationTs, incViolationTs);

  const existResetAt =
    typeof existing.lastResetAt === 'number' ? existing.lastResetAt : 0;
  const incResetAt =
    typeof incoming.lastResetAt === 'number' ? incoming.lastResetAt : 0;
  const maxResetAt = Math.max(existResetAt, incResetAt);

  const existViolationResetAt =
    typeof existing.violationResetAt === 'number' ? existing.violationResetAt : 0;
  const incViolationResetAt =
    typeof incoming.violationResetAt === 'number' ? incoming.violationResetAt : 0;
  const maxViolationResetAt = Math.max(existViolationResetAt, incViolationResetAt);
  const effectiveResetAt = Math.max(maxResetAt, maxViolationResetAt);

  const preferIncomingIdentity =
    incSrvStatusTs > existSrvStatusTs ||
    incMetaTs > existMetaTs ||
    incLoginTs > existLoginTs ||
    incViolationTs > existViolationTs ||
    incomingPriority > existingPriority ||
    (incomingPriority === existingPriority &&
      incomingDraftCount > existingDraftCount) ||
    (incomingPriority === existingPriority &&
      !existingIsActive &&
      incomingIsActive);

  const primary = preferIncomingIdentity ? incoming : existing;
  const secondary = preferIncomingIdentity ? existing : incoming;

  let resolvedStatus: string;
  if (incSrvStatusTs !== existSrvStatusTs) {
    resolvedStatus =
      incSrvStatusTs > existSrvStatusTs
        ? incomingIsActive
          ? 'Active'
          : 'Non Active'
        : existingIsActive
        ? 'Active'
        : 'Non Active';
  } else if (incMetaTs !== existMetaTs) {
    resolvedStatus =
      incMetaTs > existMetaTs
        ? incomingIsActive
          ? 'Active'
          : 'Non Active'
        : existingIsActive
        ? 'Active'
        : 'Non Active';
  } else {
    resolvedStatus = incomingIsActive ? 'Active' : 'Non Active';
  }

  const existingRuang = String(
    existing.ruang || existing.kelompok || 'Ruang 1'
  ).trim();
  const incomingRuang = String(
    incoming.ruang || incoming.kelompok || 'Ruang 1'
  ).trim();
  let resolvedRuang: string;
  if (incMetaTs !== existMetaTs) {
    resolvedRuang = incMetaTs > existMetaTs ? incomingRuang : existingRuang;
  } else {
    resolvedRuang =
      existingRuang && existingRuang !== 'Ruang 1' && existingRuang !== '1'
        ? existingRuang
        : incomingRuang && incomingRuang !== 'Ruang 1' && incomingRuang !== '1'
        ? incomingRuang
        : primary.ruang || 'Ruang 1';
  }

  const preferIncomingDraft =
    incDraftTs > existDraftTs ||
    (incDraftTs === existDraftTs && incomingDraftCount >= existingDraftCount);
  const draftSource = preferIncomingDraft ? incoming : existing;
  const fallbackDraftSource = preferIncomingDraft ? existing : incoming;

  const bestDraftAnswers =
    draftSource.draftAnswers &&
    typeof draftSource.draftAnswers === 'object' &&
    Object.keys(draftSource.draftAnswers).length > 0
      ? draftSource.draftAnswers
      : fallbackDraftSource.draftAnswers;
  const bestDraftPackageId =
    draftSource.draftPackageId || fallbackDraftSource.draftPackageId;
  const bestDraftRemainingSeconds =
    typeof draftSource.draftRemainingSeconds === 'number'
      ? draftSource.draftRemainingSeconds
      : fallbackDraftSource.draftRemainingSeconds;

  const finishedAfterViolation =
    (existing.loginState === 'Selesai' && existLoginTs > maxViolationTs) ||
    (incoming.loginState === 'Selesai' && incLoginTs > maxViolationTs);

  const isLocked =
    !finishedAfterViolation &&
    maxViolationTs > 0 &&
    maxViolationTs > effectiveResetAt;

  let resolvedLoginState = 'Belum Login';
  let resolvedRequestReset = false;
  let resolvedViolationReason: string | undefined = undefined;
  let resolvedViolationAt: string | undefined = undefined;
  let resolvedViolationSchema: number | undefined = undefined;
  let resolvedViolationTimestamp: number | undefined = undefined;
  let resolvedViolationCount: number | undefined = undefined;
  let resolvedViolationPackageId: string | undefined = undefined;

  if (isLocked) {
    const vSource = incViolationTs >= existViolationTs ? incoming : existing;
    const vFallback = incViolationTs >= existViolationTs ? existing : incoming;
    resolvedLoginState = 'Terkunci (Pelanggaran)';
    resolvedRequestReset = true;
    resolvedViolationSchema = 3;
    resolvedViolationTimestamp = maxViolationTs;
    resolvedViolationReason =
      vSource.violationReason ||
      vFallback.violationReason ||
      'Pelanggaran keamanan ujian CBT';
    resolvedViolationAt = vSource.violationAt || vFallback.violationAt;
    resolvedViolationPackageId =
      vSource.violationPackageId || vFallback.violationPackageId;
    const existValidCount =
      maxViolationResetAt === 0 || existViolationTs > maxViolationResetAt
        ? typeof existing.violationCount === 'number'
          ? existing.violationCount
          : 0
        : 0;
    const incValidCount =
      maxViolationResetAt === 0 || incViolationTs > maxViolationResetAt
        ? typeof incoming.violationCount === 'number'
          ? incoming.violationCount
          : 0
        : 0;
    resolvedViolationCount = Math.max(existValidCount, incValidCount, 1);
  } else {
    resolvedRequestReset = false;
    if (maxResetAt > 0 && maxResetAt >= maxLoginUpdatedAt) {
      resolvedLoginState = 'Belum Login';
    } else if (maxLoginUpdatedAt > 0) {
      const loginSource = incLoginTs >= existLoginTs ? incoming : existing;
      const loginFallback = incLoginTs >= existLoginTs ? existing : incoming;
      const candidateState =
        loginSource.loginState &&
        loginSource.loginState !== 'Terkunci (Pelanggaran)'
          ? loginSource.loginState
          : loginFallback.loginState &&
            loginFallback.loginState !== 'Terkunci (Pelanggaran)'
          ? loginFallback.loginState
          : 'Belum Login';
      resolvedLoginState = candidateState;
    } else {
      const candidateA =
        incoming.loginState === 'Terkunci (Pelanggaran)'
          ? 'Belum Login'
          : incoming.loginState || 'Belum Login';
      const candidateB =
        existing.loginState === 'Terkunci (Pelanggaran)'
          ? 'Belum Login'
          : existing.loginState || 'Belum Login';
      resolvedLoginState =
        getServerLoginPriority(candidateA) >= getServerLoginPriority(candidateB)
          ? candidateA
          : candidateB;
    }
    const maxVCount = Math.max(
      typeof existing.violationCount === 'number' ? existing.violationCount : 0,
      typeof incoming.violationCount === 'number' ? incoming.violationCount : 0
    );
    const violationsExplicitlyCleared =
      maxViolationResetAt > 0 && maxViolationResetAt >= maxViolationTs;
    if (resolvedLoginState === 'Selesai' || violationsExplicitlyCleared) {
      resolvedViolationCount = 0;
      resolvedViolationPackageId = undefined;
    } else if (maxVCount > 0) {
      resolvedViolationCount = maxVCount;
      const vPkgSource = incViolationTs >= existViolationTs ? incoming : existing;
      const vPkgFallback = incViolationTs >= existViolationTs ? existing : incoming;
      resolvedViolationPackageId =
        vPkgSource.violationPackageId || vPkgFallback.violationPackageId;
    }
  }

  const result: Record<string, any> = {
    ...secondary,
    ...primary,
    id: primary.id || secondary.id,
    username: primary.username || secondary.username,
    password: primary.password || secondary.password,
    status: resolvedStatus,
    ruang: resolvedRuang,
    kelompok:
      resolvedRuang !== 'Ruang 1'
        ? resolvedRuang
        : primary.kelompok || secondary.kelompok || 'Ruang 1',
    loginState: resolvedLoginState,
    requestReset: resolvedRequestReset,
  };

  if (isLocked) {
    result.violationReason = resolvedViolationReason;
    result.violationAt = resolvedViolationAt;
    result.violationSchema = resolvedViolationSchema;
    result.violationTimestamp = resolvedViolationTimestamp;
    result.violationCount = resolvedViolationCount;
    if (resolvedViolationPackageId) {
      result.violationPackageId = resolvedViolationPackageId;
    } else {
      delete result.violationPackageId;
    }
  } else {
    delete result.violationReason;
    delete result.violationAt;
    delete result.violationSchema;
    delete result.violationTimestamp;
    if (resolvedViolationCount !== undefined) {
      result.violationCount = resolvedViolationCount;
    } else {
      delete result.violationCount;
    }
    if (resolvedViolationPackageId && (resolvedViolationCount || 0) > 0) {
      result.violationPackageId = resolvedViolationPackageId;
    } else {
      delete result.violationPackageId;
    }
  }

  if (resolvedLoginState === 'Selesai') {
    delete result.draftAnswers;
    delete result.draftPackageId;
    delete result.draftRemainingSeconds;
    delete result.examStartedAt;
    delete result.examDeadlineAt;
  } else {
    if (bestDraftAnswers) result.draftAnswers = bestDraftAnswers;
    if (bestDraftPackageId) result.draftPackageId = bestDraftPackageId;
    if (typeof bestDraftRemainingSeconds === 'number') {
      result.draftRemainingSeconds = bestDraftRemainingSeconds;
    }
    const existStartedAt =
      typeof existing.examStartedAt === 'number' ? existing.examStartedAt : 0;
    const incStartedAt =
      typeof incoming.examStartedAt === 'number' ? incoming.examStartedAt : 0;
    const existDeadlineAt =
      typeof existing.examDeadlineAt === 'number' ? existing.examDeadlineAt : 0;
    const incDeadlineAt =
      typeof incoming.examDeadlineAt === 'number' ? incoming.examDeadlineAt : 0;
    const validExist = existStartedAt > effectiveResetAt && existDeadlineAt > 0;
    const validInc = incStartedAt > effectiveResetAt && incDeadlineAt > 0;
    if (validExist || validInc) {
      if (validInc && (!validExist || incStartedAt >= existStartedAt)) {
        result.examStartedAt = incStartedAt;
        result.examDeadlineAt = incDeadlineAt;
      } else {
        result.examStartedAt = existStartedAt;
        result.examDeadlineAt = existDeadlineAt;
      }
    } else {
      delete result.examStartedAt;
      delete result.examDeadlineAt;
      const refStartedAt =
        incStartedAt > existStartedAt && incDeadlineAt > incStartedAt
          ? incStartedAt
          : existStartedAt;
      const refDeadlineAt =
        incStartedAt > existStartedAt && incDeadlineAt > incStartedAt
          ? incDeadlineAt
          : existDeadlineAt;
      if (refStartedAt > 0 && refDeadlineAt > refStartedAt) {
        const tmpRow: Record<string, any> = {
          ...result,
          examStartedAt: refStartedAt,
          examDeadlineAt: refDeadlineAt,
        };
        preserveRemainingSecondsBeforeDeadlineClear(
          tmpRow,
          effectiveResetAt,
          Date.now()
        );
        if (typeof tmpRow.draftRemainingSeconds === 'number') {
          result.draftRemainingSeconds = tmpRow.draftRemainingSeconds;
        }
      }
    }
  }

  if (maxResetAt > 0) {
    result.lastResetAt = maxResetAt;
    const resetMetaSource = incResetAt >= existResetAt ? incoming : existing;
    const resetMetaFallback = incResetAt >= existResetAt ? existing : incoming;
    const rPkgId =
      resetMetaSource.resetPackageId ?? resetMetaFallback.resetPackageId;
    const rSubjTitle =
      resetMetaSource.resetSubjectTitle ?? resetMetaFallback.resetSubjectTitle;
    if (rPkgId) result.resetPackageId = rPkgId;
    else delete result.resetPackageId;
    if (rSubjTitle) result.resetSubjectTitle = rSubjTitle;
    else delete result.resetSubjectTitle;
  }
  if (maxViolationResetAt > 0) result.violationResetAt = maxViolationResetAt;
  if (maxLoginUpdatedAt > 0) result.loginUpdatedAt = maxLoginUpdatedAt;
  if (maxMetaUpdatedAt > 0) result.metaUpdatedAt = maxMetaUpdatedAt;
  if (maxServerStatusUpdatedAt > 0) {
    result.serverStatusUpdatedAt = maxServerStatusUpdatedAt;
  }
  if (maxDraftUpdatedAt > 0) result.draftUpdatedAt = maxDraftUpdatedAt;
  const nonceSource = incLoginTs >= existLoginTs ? incoming : existing;
  const nonceFallback = incLoginTs >= existLoginTs ? existing : incoming;
  const resolvedNonce =
    nonceSource.activeSessionNonce || nonceFallback.activeSessionNonce;
  if (resolvedNonce) {
    result.activeSessionNonce = resolvedNonce;
  }

  return result;
}

function sanitizeParticipantsList(
  rawList: unknown,
  existingList?: unknown
): Record<string, any>[] {
  if (!Array.isArray(rawList)) return [];
  const hasCustomRows = rawList.some((item) => isCustomUploadedRow(item));
  const baseList = hasCustomRows
    ? rawList.filter((item) => !isDefaultDemoRow(item))
    : rawList;

  const existingById = new Map<string, Record<string, any>>();
  const existingByUser = new Map<string, Record<string, any>>();
  const existingByNameKelas = new Map<string, Record<string, any>>();
  if (Array.isArray(existingList)) {
    for (const item of existingList) {
      if (item && typeof item === 'object') {
        const id = String((item as any).id || '').trim();
        if (id) existingById.set(id, item as Record<string, any>);
        const u = String((item as any).username || '')
          .trim()
          .toUpperCase();
        if (u) existingByUser.set(u, item as Record<string, any>);
        const nk = getServerParticipantNameKelasKey(item);
        if (nk) existingByNameKelas.set(nk, item as Record<string, any>);
      }
    }
  }

  const normalizedList = baseList
    .filter((item) => item && typeof item === 'object')
    .map((item) => {
      const rawRow = { ...(item as Record<string, any>) };
      const cleanId = String(rawRow.id || '').trim();
      const cleanUser =
        typeof rawRow.username === 'string'
          ? rawRow.username.trim().toUpperCase()
          : '';
      const nk = getServerParticipantNameKelasKey(rawRow);
      const prevRow =
        (cleanUser ? existingByUser.get(cleanUser) : undefined) ||
        (cleanId ? existingById.get(cleanId) : undefined) ||
        (nk ? existingByNameKelas.get(nk) : undefined);

      // Reconcile against prevRow using CRDT timestamps so neither violations nor resets are ever lost
      const row = prevRow
        ? mergeServerDuplicateRows(prevRow, rawRow)
        : rawRow;

      const maxResetAt =
        typeof row.lastResetAt === 'number' ? row.lastResetAt : 0;
      const maxViolationResetAt =
        typeof row.violationResetAt === 'number' ? row.violationResetAt : 0;
      const effectiveResetAt = Math.max(maxResetAt, maxViolationResetAt);
      const vTimestamp =
        typeof row.violationTimestamp === 'number' ? row.violationTimestamp : 0;
      const isValidViolation =
        row.violationSchema === 3 &&
        vTimestamp > 0 &&
        vTimestamp > effectiveResetAt &&
        (row.requestReset === true ||
          row.loginState === 'Terkunci (Pelanggaran)');

      if (!isValidViolation) {
        row.requestReset = false;
        if (row.loginState === 'Terkunci (Pelanggaran)') {
          row.loginState = 'Belum Login';
        }
        delete row.violationReason;
        delete row.violationAt;
        delete row.violationSchema;
        delete row.violationTimestamp;
      }

      if (maxViolationResetAt > 0 && maxViolationResetAt >= vTimestamp) {
        row.violationCount = 0;
        delete row.violationPackageId;
      }

      if (
        row.loginState === 'Selesai' ||
        (typeof row.examStartedAt === 'number' &&
          effectiveResetAt >= row.examStartedAt)
      ) {
        if (row.loginState !== 'Selesai') {
          preserveRemainingSecondsBeforeDeadlineClear(
            row,
            effectiveResetAt,
            Date.now()
          );
        }
        delete row.examStartedAt;
        delete row.examDeadlineAt;
      }

      return row;
    });

  // Deduplicate by (namaPeserta + kelas) and by username
  const dedupedList: Record<string, any>[] = [];
  const indexByNameKelas = new Map<string, number>();
  const indexByUsername = new Map<string, number>();

  for (const row of normalizedList) {
    const nameKelasKey = getServerParticipantNameKelasKey(row);
    const userKey = String(row.username || '')
      .trim()
      .toUpperCase();

    const existingIdxByName =
      nameKelasKey && indexByNameKelas.has(nameKelasKey)
        ? indexByNameKelas.get(nameKelasKey)
        : undefined;
    const existingIdxByUser =
      userKey && indexByUsername.has(userKey)
        ? indexByUsername.get(userKey)
        : undefined;

    const matchIdx =
      existingIdxByName !== undefined ? existingIdxByName : existingIdxByUser;

    if (matchIdx !== undefined) {
      const merged = mergeServerDuplicateRows(dedupedList[matchIdx], row);
      dedupedList[matchIdx] = merged;
      const mergedNameKey = getServerParticipantNameKelasKey(merged);
      const mergedUserKey = String(merged.username || '')
        .trim()
        .toUpperCase();
      if (mergedNameKey) indexByNameKelas.set(mergedNameKey, matchIdx);
      if (mergedUserKey) indexByUsername.set(mergedUserKey, matchIdx);
    } else {
      const newIdx = dedupedList.length;
      dedupedList.push(row);
      if (nameKelasKey) indexByNameKelas.set(nameKelasKey, newIdx);
      if (userKey) indexByUsername.set(userKey, newIdx);
    }
  }

  return dedupedList;
}

function applyParticipantPatches(
  existingList: unknown,
  patchesInput: unknown,
  clientNow = 0,
  serverNow = Date.now()
): Record<string, any>[] {
  const baseList: Record<string, any>[] = Array.isArray(existingList)
    ? existingList
        .filter((item) => item && typeof item === 'object')
        .map((item) => ({ ...(item as Record<string, any>) }))
    : [];

  const patches = (
    Array.isArray(patchesInput) ? patchesInput : [patchesInput]
  ).filter((p) => p && typeof p === 'object') as Record<string, any>[];

  for (const patch of patches) {
    const patchUser = String(patch.username || '')
      .trim()
      .toUpperCase();
    const patchId = String(patch.id || '').trim();
    if (!patchUser && !patchId) continue;

    const matchIndex = baseList.findIndex((row) => {
      const rowUser = String(row.username || '')
        .trim()
        .toUpperCase();
      const rowId = String(row.id || '').trim();
      return (
        (patchId && rowId === patchId) || (patchUser && rowUser === patchUser)
      );
    });

    if (matchIndex !== -1) {
      const existingRow = baseList[matchIndex];
      const normalizedPatch = normalizeParticipantTimestamps(
        patch,
        existingRow,
        clientNow,
        serverNow
      );
      const patchedCandidate = { ...existingRow };
      for (const [key, val] of Object.entries(normalizedPatch)) {
        if (val === undefined || val === null) {
          delete patchedCandidate[key];
        } else {
          patchedCandidate[key] = val;
        }
      }
      if (
        typeof normalizedPatch.status === 'string' &&
        normalizedPatch.status.trim() !== ''
      ) {
        const normalizedStatusVal = isServerRowStatusActive(
          normalizedPatch.status
        )
          ? 'Active'
          : 'Non Active';
        patchedCandidate.status = normalizedStatusVal;
        const existMeta =
          typeof existingRow.metaUpdatedAt === 'number'
            ? existingRow.metaUpdatedAt
            : 0;
        const patchMeta =
          typeof normalizedPatch.metaUpdatedAt === 'number'
            ? normalizedPatch.metaUpdatedAt
            : 0;
        const existSrvStatus =
          typeof existingRow.serverStatusUpdatedAt === 'number'
            ? existingRow.serverStatusUpdatedAt
            : 0;
        patchedCandidate.metaUpdatedAt = Math.max(
          existMeta + 1,
          patchMeta,
          serverNow
        );
        patchedCandidate.serverStatusUpdatedAt = Math.max(
          existSrvStatus + 1,
          serverNow
        );
      }
      baseList[matchIndex] = mergeServerDuplicateRows(
        existingRow,
        patchedCandidate
      );
    } else if (patchUser && patch.namaPeserta) {
      // Only append if the list is currently empty (do not pollute uploaded rows with unknown demo rows)
      if (baseList.length === 0) {
        const normalizedNew = normalizeParticipantTimestamps(
          patch,
          undefined,
          clientNow,
          serverNow
        );
        baseList.push({
          id: patchId || `p_${serverNow}`,
          selected: false,
          status: normalizedNew.status || 'Active',
          kodeTes: normalizedNew.kodeTes || 'SAS26SMADIP1',
          username: patchUser,
          namaPeserta: normalizedNew.namaPeserta,
          kelompok: normalizedNew.kelompok || '1',
          kelas: normalizedNew.kelas || 'X',
          loginState: normalizedNew.loginState || 'Belum Login',
          requestReset: Boolean(normalizedNew.requestReset),
          ...normalizedNew,
        });
      }
    }
  }

  return sanitizeParticipantsList(baseList, existingList);
}

function resolveIncomingParticipants(
  incomingList: unknown,
  existingList: unknown,
  deletedIdsInput?: unknown,
  forceReplace?: boolean,
  clientNow = 0,
  serverNow = Date.now()
): Record<string, any>[] | undefined {
  const hasExisting = Array.isArray(existingList) && existingList.length > 0;
  const hasIncoming = Array.isArray(incomingList) && incomingList.length > 0;

  if (!hasIncoming) {
    return hasExisting
      ? sanitizeParticipantsList(existingList)
      : undefined;
  }

  const existingIsReal =
    hasExisting && !isDefaultDemoParticipantsList(existingList);
  const incomingIsDemo = isDefaultDemoParticipantsList(incomingList);

  // CRITICAL GUARD 1: Never allow the 8 default demo students to overwrite real uploaded/added students
  if (existingIsReal && incomingIsDemo) {
    return sanitizeParticipantsList(existingList);
  }

  const deletedIds = new Set<string>(
    Array.isArray(deletedIdsInput)
      ? deletedIdsInput.map((id) => String(id || '').trim()).filter(Boolean)
      : []
  );

  const existingLookupByUser = new Map<string, Record<string, any>>();
  const existingLookupByNameKelas = new Map<string, Record<string, any>>();
  if (Array.isArray(existingList)) {
    for (const row of existingList as any[]) {
      if (!row || typeof row !== 'object') continue;
      const u = String(row.username || '').trim().toUpperCase();
      if (u) existingLookupByUser.set(u, row);
      const nk = getServerParticipantNameKelasKey(row);
      if (nk && !existingLookupByNameKelas.has(nk)) {
        existingLookupByNameKelas.set(nk, row);
      }
    }
  }
  const clockNormalizedIncoming = (incomingList as any[]).map((row) => {
    if (!row || typeof row !== 'object') return row;
    const u = String(row.username || '').trim().toUpperCase();
    const nk = getServerParticipantNameKelasKey(row);
    const existingRow =
      (u ? existingLookupByUser.get(u) : undefined) ||
      (nk ? existingLookupByNameKelas.get(nk) : undefined);
    const normalized = normalizeParticipantTimestamps(
      row,
      existingRow,
      clientNow,
      serverNow
    );
    // Normalize status value ('Aktif' -> 'Active', etc.) and ensure explicit Admin/Proctor
    // bulk Assign/Unassign/Excel changes strictly win over older or clock-skewed existing timestamps
    if (typeof normalized.status === 'string' && normalized.status.trim() !== '') {
      const normalizedStatusVal = isServerRowStatusActive(normalized.status)
        ? 'Active'
        : 'Non Active';
      normalized.status = normalizedStatusVal;
      if (forceReplace) {
        if (existingRow) {
          const existingStatusVal = isServerRowStatusActive(existingRow.status)
            ? 'Active'
            : 'Non Active';
          const existMeta =
            typeof existingRow.metaUpdatedAt === 'number'
              ? existingRow.metaUpdatedAt
              : 0;
          const incMeta =
            typeof normalized.metaUpdatedAt === 'number'
              ? normalized.metaUpdatedAt
              : 0;
          const existSrvStatus =
            typeof existingRow.serverStatusUpdatedAt === 'number'
              ? existingRow.serverStatusUpdatedAt
              : 0;
          if (normalizedStatusVal !== existingStatusVal || incMeta > existMeta) {
            normalized.metaUpdatedAt = Math.max(existMeta + 1, incMeta, serverNow);
            normalized.serverStatusUpdatedAt = Math.max(
              existSrvStatus + 1,
              serverNow
            );
          }
        } else if (typeof normalized.serverStatusUpdatedAt !== 'number') {
          normalized.serverStatusUpdatedAt = serverNow;
        }
      }
    }
    return normalized;
  });

  const sanitizedIncoming = sanitizeParticipantsList(
    clockNormalizedIncoming,
    existingList
  );

  if (!hasExisting || !existingIsReal) {
    return sanitizedIncoming;
  }

  // CRITICAL GUARD 2: Preserve any uploaded/custom students in existingList that were not explicitly deleted
  // so an un-synced tab or partial list never drops existing uploaded classes
  const incomingById = new Map<string, Record<string, any>>();
  const incomingByUser = new Map<string, Record<string, any>>();
  const incomingByNameKelas = new Map<string, Record<string, any>>();

  for (const row of sanitizedIncoming) {
    const id = String(row.id || '').trim();
    const user = String(row.username || '')
      .trim()
      .toUpperCase();
    const nk = getServerParticipantNameKelasKey(row);
    if (id) incomingById.set(id, row);
    if (user) incomingByUser.set(user, row);
    if (nk) incomingByNameKelas.set(nk, row);
  }

  const sanitizedExisting = sanitizeParticipantsList(existingList);

  // If incoming has fewer students than existing and did not explicitly delete the difference,
  // merge missing existing custom rows so data count never unexpectedly drops
  const preservedMissingExisting: Record<string, any>[] = [];
  for (const existRow of sanitizedExisting) {
    const existId = String(existRow.id || '').trim();
    const existUser = String(existRow.username || '')
      .trim()
      .toUpperCase();
    const existNk = getServerParticipantNameKelasKey(existRow);

    if (existId && deletedIds.has(existId)) {
      continue;
    }

    const foundInIncoming =
      (existId && incomingById.has(existId)) ||
      (existUser && incomingByUser.has(existUser)) ||
      (existNk && incomingByNameKelas.has(existNk));

    if (!foundInIncoming && isCustomUploadedRow(existRow)) {
      preservedMissingExisting.push(existRow);
    }
  }

  if (preservedMissingExisting.length > 0 && !forceReplace) {
    return sanitizeParticipantsList(
      [...sanitizedIncoming, ...preservedMissingExisting],
      existingList
    );
  }

  // Even when forceReplace is true (e.g. Admin action), if deletedIds is empty and incoming suddenly dropped >50% of custom rows,
  // still preserve the missing custom rows to prevent unhydrated admin tab accidents
  if (
    preservedMissingExisting.length > 0 &&
    deletedIds.size === 0 &&
    sanitizedIncoming.length < sanitizedExisting.length
  ) {
    return sanitizeParticipantsList(
      [...sanitizedIncoming, ...preservedMissingExisting],
      existingList
    );
  }

  return sanitizedIncoming;
}

type SessionRole = 'admin' | 'proctor' | 'student';

interface SessionClaims {
  role: SessionRole;
  sub: string;
  exp: number;
  sid?: string;
}

async function resolveSessionSigningSecret(
  kv: { url: string; token: string } | null
): Promise<string> {
  const envSecret = (process.env.CBT_SESSION_SECRET || '').trim();
  if (envSecret) return envSecret;
  if (globalThis.__SMADIP_CBT_SESSION_SECRET__) {
    return String(globalThis.__SMADIP_CBT_SESSION_SECRET__);
  }

  if (kv) {
    try {
      const readPipe = await kvPipeline(kv, [['GET', SESSION_SECRET_KEY]]);
      const existingSecret =
        readPipe.ok && typeof readPipe.results[0] === 'string'
          ? readPipe.results[0].trim()
          : '';
      if (existingSecret && existingSecret.length >= 32) {
        globalThis.__SMADIP_CBT_SESSION_SECRET__ = existingSecret;
        return existingSecret;
      }

      const generated = crypto.randomBytes(32).toString('hex');
      const setPipe = await kvPipeline(kv, [
        ['SET', SESSION_SECRET_KEY, generated, 'NX'],
        ['GET', SESSION_SECRET_KEY],
      ]);
      const agreedSecret =
        setPipe.ok && typeof setPipe.results[1] === 'string'
          ? setPipe.results[1].trim()
          : '';
      if (agreedSecret && agreedSecret.length >= 32) {
        globalThis.__SMADIP_CBT_SESSION_SECRET__ = agreedSecret;
        return agreedSecret;
      }
    } catch {
      // Fallback to in-memory secret if KV is transiently unreachable
    }
  }

  // On non-serverless hosts (local dev / VPS), persist the generated random secret on disk
  // so server restarts do not invalidate active exam sessions.
  const isServerless = Boolean(
    process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME
  );
  if (!isServerless) {
    try {
      const dataDir = path.join(process.cwd(), '.data');
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      const secretPath = path.join(dataDir, '.cbt_session_secret');
      if (fs.existsSync(secretPath)) {
        const diskSecret = fs.readFileSync(secretPath, 'utf8').trim();
        if (diskSecret.length >= 32) {
          globalThis.__SMADIP_CBT_SESSION_SECRET__ = diskSecret;
          return diskSecret;
        }
      }
      const generated = crypto.randomBytes(32).toString('hex');
      fs.writeFileSync(secretPath, generated, { encoding: 'utf8', mode: 0o600 });
      globalThis.__SMADIP_CBT_SESSION_SECRET__ = generated;
      return generated;
    } catch {
      // Fall through to in-memory secret if filesystem is read-only
    }
  } else if (!(globalThis as Record<string, unknown>).__SMADIP_EPHEMERAL_WARNED__) {
    (globalThis as Record<string, unknown>).__SMADIP_EPHEMERAL_WARNED__ = true;
    console.warn(
      '[CBT Storage] PERINGATAN PRODUKSI: Serverless Vercel berjalan tanpa KV/Upstash Redis dan tanpa CBT_SESSION_SECRET. Hubungkan Upstash Redis (KV_REST_API_URL/TOKEN) dan atur CBT_SESSION_SECRET di Environment Variables Vercel agar sesi dan data ujian tidak terpecah antar instance.'
    );
  }

  globalThis.__SMADIP_CBT_SESSION_SECRET__ = crypto
    .randomBytes(32)
    .toString('hex');
  return String(globalThis.__SMADIP_CBT_SESSION_SECRET__);
}

function safeEqualStr(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function createSessionToken(
  role: SessionRole,
  sub: string,
  secret: string,
  sid?: string
): string {
  const claims: SessionClaims = {
    role,
    sub: sub.trim().toUpperCase(),
    exp: Date.now() + 12 * 60 * 60 * 1000,
    ...(sid ? { sid } : {}),
  };
  const payloadB64 = Buffer.from(JSON.stringify(claims), 'utf8').toString(
    'base64url'
  );
  const sig = crypto
    .createHmac('sha256', secret)
    .update(payloadB64)
    .digest('base64url');
  return `${payloadB64}.${sig}`;
}

function verifySessionToken(req: any, secret: string): SessionClaims | null {
  try {
    const authHeader = String(
      req?.headers?.authorization || req?.headers?.Authorization || ''
    ).trim();
    if (!authHeader.startsWith('Bearer ')) return null;
    const token = authHeader.slice(7).trim();
    const dotIdx = token.indexOf('.');
    if (dotIdx <= 0) return null;
    const payloadB64 = token.slice(0, dotIdx);
    const sig = token.slice(dotIdx + 1);
    const expectedSig = crypto
      .createHmac('sha256', secret)
      .update(payloadB64)
      .digest('base64url');
    if (!safeEqualStr(sig, expectedSig)) return null;
    const parsed = JSON.parse(
      Buffer.from(payloadB64, 'base64url').toString('utf8')
    ) as SessionClaims;
    if (
      !parsed ||
      typeof parsed.exp !== 'number' ||
      parsed.exp < Date.now() ||
      !['admin', 'proctor', 'student'].includes(parsed.role) ||
      typeof parsed.sub !== 'string' ||
      !parsed.sub
    ) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function applyCorsHeaders(req: any, res: any): void {
  const origin = String(req?.headers?.origin || '').trim();
  const reqHost = String(
    req?.headers?.['x-forwarded-host'] || req?.headers?.host || ''
  )
    .split(',')[0]
    .trim()
    .toLowerCase();

  if (origin) {
    try {
      const originHost = new URL(origin).host.toLowerCase();
      if (originHost && reqHost && originHost === reqHost) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
      }
    } catch {
      // Ignore malformed origin
    }
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
}

function parseServerKelasMeta(raw: string): {
  grade: string;
  track: string;
  norm: string;
} {
  const norm = normalizeServerKelas(raw);
  let grade = '';
  if (/^XII\b/.test(norm)) grade = 'XII';
  else if (/^XI\b/.test(norm)) grade = 'XI';
  else if (/^X\b/.test(norm)) grade = 'X';
  const track = norm.includes('IPS')
    ? 'IPS'
    : norm.includes('IPA')
    ? 'IPA'
    : '';
  return { grade, track, norm };
}

function doesSingleServerKelasMatch(
  studentKelasRaw: string,
  scheduleTokenRaw: string
): boolean {
  const rawA = studentKelasRaw.replace(/^kelas\s+/i, '').trim().toUpperCase();
  const rawB = scheduleTokenRaw.replace(/^kelas\s+/i, '').trim().toUpperCase();
  if (!rawA || !rawB) return false;
  if (rawB === 'SEMUA' || rawB === 'SEMUA KELAS' || rawB === 'ALL') return true;
  if (rawA === rawB) return true;

  const metaA = parseServerKelasMeta(rawA);
  const metaB = parseServerKelasMeta(rawB);
  if (metaA.norm && metaB.norm && metaA.norm === metaB.norm) return true;

  // Grade-level matching: e.g. schedule "XI" matches "XI IPA", "XI IPS", "XI 1", "XI A";
  // student "XI 1" / "XI A" matches schedule "XI"; strictly keep IPA separate from IPS
  if (metaA.grade && metaB.grade && metaA.grade === metaB.grade) {
    if (metaA.track && metaB.track) {
      return metaA.track === metaB.track;
    }
    // Schedule is grade-wide (e.g. "XI" or "XII") -> matches any track/rombel of that grade
    if (!metaB.track && (metaB.norm === metaB.grade || /^X\b/.test(metaB.norm))) {
      return true;
    }
    // Student is grade-wide without track (e.g. "XI" or "XI 1") -> matches grade-wide schedule
    if (!metaA.track && metaA.norm === metaA.grade && !metaB.track) {
      return true;
    }
  }
  return false;
}

function doesServerKelasMatch(
  studentKelas?: unknown,
  scheduleKelas?: unknown
): boolean {
  const rawA = String(studentKelas || '')
    .replace(/^kelas\s+/i, '')
    .trim()
    .toUpperCase();
  const rawB = String(scheduleKelas || '')
    .replace(/^kelas\s+/i, '')
    .trim()
    .toUpperCase();
  if (!rawA || !rawB) return false;
  if (rawB === 'SEMUA' || rawB === 'SEMUA KELAS' || rawB === 'ALL') return true;
  if (rawA === rawB) return true;

  // Support multi-class schedule strings like "X, XI, XII" or "XI IPA / XI IPS" or "X & XI"
  const scheduleParts = rawB
    .split(/\s*(?:,|\/|;|&|\bdan\b)\s*/i)
    .map((p) => p.trim())
    .filter(Boolean);
  const studentParts = rawA
    .split(/\s*(?:,|\/|;|&|\bdan\b)\s*/i)
    .map((p) => p.trim())
    .filter(Boolean);

  for (const sPart of studentParts) {
    for (const schPart of scheduleParts) {
      if (doesSingleServerKelasMatch(sPart, schPart)) {
        return true;
      }
    }
  }
  return false;
}

function cleanServerMapelTitle(raw?: unknown): string {
  return String(raw || '')
    .replace(/^Simulasi TKA\s*-\s*/i, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function buildServerSchedulePkgCandidates(
  mapelRaw: unknown,
  kelasRaw: unknown
): { code: string; pkgId: string; candidateCodes: string[]; candidatePkgIds: string[] } {
  const normKelas = normalizeServerKelas(kelasRaw) || 'X';
  const kelasSlug =
    normKelas
      .replace(/^KELAS\s+/i, '')
      .replace(/[^a-zA-Z0-9]+/g, '')
      .toUpperCase()
      .slice(0, 6) || 'X';
  const alphaNumUpper = String(mapelRaw || '')
    .trim()
    .replace(/[^a-zA-Z0-9]+/g, '')
    .toUpperCase();
  const mapelSlug6 = alphaNumUpper.slice(0, 6) || 'MPL';
  const mapelSlug3 =
    String(mapelRaw || '')
      .trim()
      .replace(/[^a-zA-Z]+/g, '')
      .toUpperCase()
      .slice(0, 3) || mapelSlug6.slice(0, 3) || 'MPL';
  const code = `${mapelSlug6}-${kelasSlug}`;
  const pkgId =
    'mapel_pkg_' + code.toLowerCase().replace(/[^a-z0-9]/g, '_');

  const candidateCodes = Array.from(
    new Set([
      code,
      `${mapelSlug3}-${kelasSlug}`,
      `${mapelSlug3}-SAS`,
      `${mapelSlug3}-02-SAS`,
      `${mapelSlug3}-03-SAS`,
      `${mapelSlug6}-SAS`,
    ])
  );
  const candidatePkgIds = candidateCodes.map(
    (c) => 'MAPEL_PKG_' + c.toUpperCase().replace(/[^A-Z0-9]/g, '_')
  );
  return { code, pkgId, candidateCodes, candidatePkgIds };
}

function isLegacyZombieSimulasiRecord(
  titleOrName: unknown,
  obj?: Record<string, any> | null
): boolean {
  if (obj && obj.simulasiWhitelistedV4 === true) {
    return false;
  }
  const rawStr = String(titleOrName || '').trim();
  const cleaned = cleanServerMapelTitle(rawStr);
  if (/^\s*simulasi\b/i.test(rawStr) || /^\s*simulasi\b/i.test(cleaned)) {
    return true;
  }
  const codeStr = String(obj?.code || obj?.kode || '').trim().toUpperCase();
  if (/^SIMULA/i.test(codeStr) || /^TKA-/i.test(codeStr)) {
    return true;
  }
  const idStr = String(obj?.id || '').trim().toUpperCase();
  if (/^MAPEL_PKG_SIMULA/i.test(idStr) || /^PKG_TKA_/i.test(idStr)) {
    return true;
  }
  return false;
}

function sanitizeServerAdminSettings(
  adminSettingsInput: unknown,
  deletedPackageIdsInput?: unknown
): Record<string, any> | undefined {
  if (!adminSettingsInput || typeof adminSettingsInput !== 'object') {
    return undefined;
  }
  const cfg = { ...(adminSettingsInput as Record<string, any>) };
  const deletedPkgSet = new Set<string>(
    Array.isArray(deletedPackageIdsInput)
      ? deletedPackageIdsInput
          .map((id) => String(id || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );
  const deletedCodesSet = new Set<string>(
    Array.isArray(cfg.deletedMapelCodes)
      ? (cfg.deletedMapelCodes as unknown[])
          .map((c) => String(c || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );
  const deletedNamesSet = new Set<string>(
    Array.isArray(cfg.deletedMapelNames)
      ? (cfg.deletedMapelNames as unknown[])
          .map((n) => cleanServerMapelTitle(n))
          .filter(Boolean)
      : []
  );

  if (Array.isArray(cfg.mapelList)) {
    const removedNames: string[] = [];
    const filteredList = (cfg.mapelList as Record<string, any>[]).filter((m) => {
      if (!m || typeof m !== 'object') return false;
      const mKode = String(m.kode || '').trim().toUpperCase();
      const mPkgId = mKode
        ? 'MAPEL_PKG_' + mKode.replace(/[^A-Z0-9]/g, '_')
        : '';
      const mNama = cleanServerMapelTitle(m.nama);
      const isZombieSimulasi = isLegacyZombieSimulasiRecord(m.nama, m);
      const isDeletedByCodeOrPkg =
        (mKode &&
          (deletedPkgSet.has(mKode) || deletedCodesSet.has(mKode))) ||
        (mPkgId && deletedPkgSet.has(mPkgId));
      const isDeletedByName = Boolean(mNama && deletedNamesSet.has(mNama));
      if (isZombieSimulasi || isDeletedByCodeOrPkg || isDeletedByName) {
        if (mKode) deletedCodesSet.add(mKode);
        if (mNama) removedNames.push(mNama);
        return false;
      }
      return true;
    });

    if (removedNames.length > 0) {
      for (const rName of removedNames) {
        const stillUsed = filteredList.some(
          (m) => cleanServerMapelTitle(m?.nama) === rName
        );
        if (!stillUsed) {
          deletedNamesSet.add(rName);
        }
      }
      cfg.customMapelConfigured = true;
    }
    cfg.mapelList = filteredList;
  }

  if (deletedCodesSet.size > 0 || Array.isArray(cfg.deletedMapelCodes)) {
    cfg.deletedMapelCodes = Array.from(deletedCodesSet);
  }
  if (deletedNamesSet.size > 0 || Array.isArray(cfg.deletedMapelNames)) {
    cfg.deletedMapelNames = Array.from(deletedNamesSet);
  }
  return cfg;
}

function sanitizeServerPackages(
  packagesInput: unknown,
  deletedPackageIdsInput?: unknown,
  adminSettingsInput?: unknown
): Record<string, any>[] {
  if (!Array.isArray(packagesInput)) return [];
  const deletedPkgSet = new Set<string>(
    Array.isArray(deletedPackageIdsInput)
      ? deletedPackageIdsInput
          .map((id) => String(id || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );
  const cfg =
    adminSettingsInput && typeof adminSettingsInput === 'object'
      ? (adminSettingsInput as Record<string, any>)
      : null;
  const deletedCodesSet = new Set<string>(
    Array.isArray(cfg?.deletedMapelCodes)
      ? (cfg!.deletedMapelCodes as unknown[])
          .map((c) => String(c || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );
  const deletedNamesSet = new Set<string>(
    Array.isArray(cfg?.deletedMapelNames)
      ? (cfg!.deletedMapelNames as unknown[])
          .map((n) => cleanServerMapelTitle(n))
          .filter(Boolean)
      : []
  );

  return (packagesInput as Record<string, any>[]).filter((p) => {
    if (!p || typeof p !== 'object') return false;
    if (isLegacyZombieSimulasiRecord(p.title, p)) return false;
    const pid = String(p.id || '').trim().toUpperCase();
    const pcode = String(p.code || '').trim().toUpperCase();
    const ptitle = cleanServerMapelTitle(p.title);
    if (pid && deletedPkgSet.has(pid)) return false;
    if (
      pcode &&
      (deletedPkgSet.has(pcode) || deletedCodesSet.has(pcode))
    ) {
      return false;
    }
    if (ptitle && deletedNamesSet.has(ptitle)) {
      return false;
    }
    return true;
  });
}

function sanitizeServerSchedules(
  schedulesInput: unknown,
  deletedScheduleIdsInput?: unknown,
  packagesInput?: unknown,
  deletedPackageIdsInput?: unknown,
  adminSettingsInput?: unknown
): Record<string, any>[] {
  if (!Array.isArray(schedulesInput)) return [];

  const deletedSchedSet = new Set<string>(
    Array.isArray(deletedScheduleIdsInput)
      ? deletedScheduleIdsInput
          .map((id) => String(id || '').trim())
          .filter(Boolean)
      : []
  );

  const deletedPkgSet = new Set<string>(
    Array.isArray(deletedPackageIdsInput)
      ? deletedPackageIdsInput
          .map((id) => String(id || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );

  const cfg = sanitizeServerAdminSettings(
    adminSettingsInput,
    deletedPackageIdsInput
  );

  const deletedMapelCodesSet = new Set<string>(
    Array.isArray(cfg?.deletedMapelCodes)
      ? (cfg!.deletedMapelCodes as unknown[])
          .map((c) => String(c || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );

  const deletedMapelNamesSet = new Set<string>(
    Array.isArray(cfg?.deletedMapelNames)
      ? (cfg!.deletedMapelNames as unknown[])
          .map((n) => cleanServerMapelTitle(n))
          .filter(Boolean)
      : []
  );

  // Also capture any title+class from raw packagesInput that was marked deleted in deletedPkgSet/deletedMapelCodesSet
  const deletedTitleClassPairs: { title: string; targetClass: string }[] = [];
  if (Array.isArray(packagesInput)) {
    for (const p of packagesInput as Record<string, any>[]) {
      if (!p || typeof p !== 'object') continue;
      const pid = String(p.id || '').trim().toUpperCase();
      const pcode = String(p.code || '').trim().toUpperCase();
      const ptitle = cleanServerMapelTitle(p.title);
      if (
        ptitle &&
        (isLegacyZombieSimulasiRecord(p.title, p) ||
          (pid && deletedPkgSet.has(pid)) ||
          (pcode && (deletedPkgSet.has(pcode) || deletedMapelCodesSet.has(pcode))))
      ) {
        deletedTitleClassPairs.push({
          title: ptitle,
          targetClass: String(p.targetClass || '').trim(),
        });
      }
    }
  }

  const validPackages = sanitizeServerPackages(
    packagesInput,
    deletedPackageIdsInput,
    cfg
  );
  const hasPackagesAuthority =
    Array.isArray(packagesInput) &&
    (packagesInput.length > 0 ||
      deletedPkgSet.size > 0 ||
      deletedMapelCodesSet.size > 0 ||
      deletedMapelNamesSet.size > 0 ||
      Boolean(cfg?.customMapelConfigured));

  const validMapelList = Array.isArray(cfg?.mapelList)
    ? (cfg!.mapelList as Record<string, any>[]).filter((m) =>
        Boolean(m && typeof m === 'object')
      )
    : null;
  const cfgUpdatedAt =
    typeof cfg?.updatedAt === 'number' && Number.isFinite(cfg.updatedAt)
      ? cfg.updatedAt
      : 0;

  const out: Record<string, any>[] = [];
  for (const s of schedulesInput) {
    if (!s || typeof s !== 'object') continue;
    const id = String((s as any).id || '').trim();
    if (id && deletedSchedSet.has(id)) continue;
    if (isLegacyZombieSimulasiRecord((s as any).mapel, s as Record<string, any>)) {
      continue;
    }

    const cleanTitle = cleanServerMapelTitle((s as any).mapel);
    if (!cleanTitle) continue;

    const sKelas = (s as any).kelas;
    const sUpdatedAt =
      typeof (s as any).updatedAt === 'number' &&
      Number.isFinite((s as any).updatedAt)
        ? (s as any).updatedAt
        : 0;

    const matchingPkg = Array.isArray(packagesInput)
      ? validPackages.find((pkg) => {
          if (cleanServerMapelTitle(pkg.title) !== cleanTitle) return false;
          const rawTarget = String(pkg.targetClass || '').trim().toUpperCase();
          if (
            !rawTarget ||
            rawTarget === 'SEMUA' ||
            rawTarget === 'SEMUA KELAS'
          ) {
            return true;
          }
          return (
            doesServerKelasMatch(rawTarget, sKelas) ||
            doesServerKelasMatch(sKelas, rawTarget)
          );
        })
      : undefined;

    const matchingMapelCfg = validMapelList
      ? validMapelList.find((m) => {
          if (cleanServerMapelTitle(m.nama) !== cleanTitle) return false;
          const rawTingkat = String(m.tingkat || '').trim();
          if (!rawTingkat || /^semua/i.test(rawTingkat)) return true;
          return (
            doesServerKelasMatch(rawTingkat, sKelas) ||
            doesServerKelasMatch(sKelas, rawTingkat)
          );
        })
      : undefined;

    const { candidateCodes, candidatePkgIds } =
      buildServerSchedulePkgCandidates((s as any).mapel, sKelas);
    const matchesDeletedTitleClass = deletedTitleClassPairs.some((pair) => {
      if (pair.title !== cleanTitle) return false;
      if (!pair.targetClass || /^semua/i.test(pair.targetClass)) return true;
      return (
        doesServerKelasMatch(pair.targetClass, sKelas) ||
        doesServerKelasMatch(sKelas, pair.targetClass)
      );
    });
    const isExplicitlyDeletedCodeOrName =
      deletedMapelNamesSet.has(cleanTitle) ||
      matchesDeletedTitleClass ||
      candidateCodes.some(
        (c) => deletedMapelCodesSet.has(c) || deletedPkgSet.has(c)
      ) ||
      candidatePkgIds.some((pid) => deletedPkgSet.has(pid));

    if (!matchingPkg && isExplicitlyDeletedCodeOrName) {
      continue;
    }

    // If the subject was removed from Bank Soal (packages), strip this schedule so deleted subjects never appear on Konfirmasi Data Peserta
    if (
      hasPackagesAuthority &&
      !matchingPkg &&
      (Boolean((s as any).isActive) ||
        !DEFAULT_DEMO_SCHEDULE_IDS.has(id) ||
        validPackages.length === 0 ||
        deletedPkgSet.size > 0 ||
        Boolean(cfg?.customMapelConfigured))
    ) {
      continue;
    }

    // If the subject was removed from Pengaturan Mata Pelajaran (mapelList), strip this schedule
    if (
      validMapelList &&
      !matchingMapelCfg &&
      (!matchingPkg ||
        Boolean(cfg?.customMapelConfigured) ||
        deletedMapelCodesSet.size > 0 ||
        deletedMapelNamesSet.size > 0)
    ) {
      continue;
    }

    if (
      matchingMapelCfg &&
      String(matchingMapelCfg.status || '').trim().toLowerCase() ===
        'non aktif' &&
      (sUpdatedAt === 0 || cfgUpdatedAt >= sUpdatedAt)
    ) {
      out.push({ ...(s as Record<string, any>), isActive: false });
      continue;
    }

    out.push(s as Record<string, any>);
  }

  return out;
}

function shortenServerUsername(raw?: unknown): string {
  const clean = String(raw || '')
    .trim()
    .toUpperCase();
  if (/^SA\d{8}$/.test(clean)) return clean;
  const m = clean.match(/^SAS\d{2}-([A-Z0-9]+)$/i);
  if (m) return `SA${m[1]}`;
  return clean;
}

function isServerRowLockedByViolation(row: Record<string, any>): boolean {
  const vTs =
    typeof row.violationTimestamp === 'number' ? row.violationTimestamp : 0;
  const resetTs = Math.max(
    typeof row.lastResetAt === 'number' ? row.lastResetAt : 0,
    typeof row.violationResetAt === 'number' ? row.violationResetAt : 0
  );
  return (
    row.violationSchema === 3 &&
    vTs > 0 &&
    vTs > resetTs &&
    Boolean(row.requestReset || row.loginState === 'Terkunci (Pelanggaran)')
  );
}

function isServerRowStatusActive(status?: unknown): boolean {
  const s = String(status || '')
    .trim()
    .toLowerCase();
  return s === 'active' || s === 'aktif';
}

function repairServerBenarSalahTableQuestion(
  q: Record<string, any>
): Record<string, any> {
  if (!q || typeof q !== 'object') return q;
  const st = q.stimulusTable;
  if (!st || typeof st !== 'object') return q;
  const rawHeaders = Array.isArray(st.headers)
    ? st.headers.map((h: unknown) => String(h ?? '').replace(/\s+/g, ' ').trim())
    : [];
  const rows = Array.isArray(st.rows) ? (st.rows as unknown[][]) : [];
  if (rawHeaders.length < 2 || rows.length === 0) return q;

  const lowerHeaders = rawHeaders.map((h: string) => h.toLowerCase());
  const isTrueHeader = (h: string) =>
    /^(?:benar|b|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true)$/.test(h);
  const isFalseHeader = (h: string) =>
    /^(?:salah|s|tidak\s+sesuai|tidak|opini|tidak\s+setuju|tidak\s+tepat|tidak\s+valid|tidak\s+mendukung|false)$/.test(
      h
    );
  const benarCol = lowerHeaders.findIndex(isTrueHeader);
  const salahCol = lowerHeaders.findIndex(isFalseHeader);
  const hasTwoOptionCols = benarCol !== -1 && salahCol !== -1;

  const keyCol = !hasTwoOptionCols
    ? lowerHeaders.findIndex(
        (h: string) =>
          /^(?:kunci|kunci\s*jawaban|jawaban|kategori|keterangan|status|b\s*\/\s*s|bs)$/.test(
            h
          ) ||
          /benar\s*[\/\-]\s*salah|sesuai\s*[\/\-]\s*tidak\s+sesuai|ya\s*[\/\-]\s*tidak|fakta\s*[\/\-]\s*opini/.test(
            h
          )
      )
    : -1;

  const stmtColIdx = lowerHeaders.findIndex(
    (h: string) =>
      h.includes('pernyataan') ||
      h.includes('statement') ||
      h.includes('kalimat') ||
      h.includes('uraian') ||
      h.includes('deskripsi') ||
      h.includes('kejadian') ||
      h.includes('peristiwa')
  );

  if (!hasTwoOptionCols && (keyCol === -1 || (stmtColIdx === -1 && !/benar|salah|sesuai|ya\s*\/\s*tidak|fakta\s*\/\s*opini|^b\s*\/\s*s$/i.test(lowerHeaders[keyCol] || '')))) {
    return q;
  }

  const existingStatements = Array.isArray(q.statements) ? q.statements : [];
  const shouldRepair =
    q.type === 'isian_singkat' ||
    (q.type === 'benar_salah' && existingStatements.length === 0) ||
    (q.type !== 'benar_salah' &&
      (!Array.isArray(q.options) || q.options.length === 0) &&
      (!Array.isArray(q.premises) || q.premises.length === 0));

  if (!shouldRepair) {
    // If question is ALREADY a valid benar_salah with statements, still strip a duplicated Benar/Salah answer table from stimulusTable so ✓ never leaks
    if (q.type === 'benar_salah' && existingStatements.length > 0) {
      const { stimulusTable: _stripDupTable, ...cleanQ } = q;
      return cleanQ;
    }
    return q;
  }

  const effectiveStmtCol =
    stmtColIdx !== -1
      ? stmtColIdx
      : lowerHeaders[0] === 'no' ||
        lowerHeaders[0] === 'no.' ||
        lowerHeaders[0] === 'nomor'
      ? 1
      : 0;

  const strongCheckTokenRegex =
    /^(?:✓|✔|☑|✅|v|●|•|1|ya|benar|b|sesuai|fakta|setuju|tepat|valid|mendukung|true)$/i;
  const crossMarkTokenRegex = /^(?:✗|✘|x)$/i;
  const negativeTokenRegex =
    /^(?:salah|s|tidak\s*sesuai|tidak|opini|tidak\s*setuju|tidak\s*tepat|tidak\s*valid|tidak\s*mendukung|false|0|✗|✘|x)$/i;

  const statements: Record<string, any>[] = [];
  for (const r of rows) {
    if (!Array.isArray(r)) continue;
    const stmtText = String(r[effectiveStmtCol] ?? '')
      .replace(/^\d+[\.\)\-:]\s*/, '')
      .trim();
    if (!stmtText) continue;

    let isBenar = true;
    if (hasTwoOptionCols) {
      const bTxt = String(r[benarCol] ?? '').trim().toLowerCase();
      const sTxt = String(r[salahCol] ?? '').trim().toLowerCase();
      const bHasStrongCheck = strongCheckTokenRegex.test(bTxt);
      const sHasStrongCheck = strongCheckTokenRegex.test(sTxt);
      const bHasCross = crossMarkTokenRegex.test(bTxt);
      const sHasCross = crossMarkTokenRegex.test(sTxt);

      if (bHasStrongCheck && !sHasStrongCheck) {
        isBenar = true;
      } else if (sHasStrongCheck && !bHasStrongCheck) {
        isBenar = false;
      } else if (sHasCross && !bHasCross) {
        isBenar = false;
      } else if (bHasCross && !sHasCross) {
        isBenar = true;
      } else if (negativeTokenRegex.test(sTxt)) {
        isBenar = false;
      }
    } else if (keyCol !== -1) {
      const kTxt = String(r[keyCol] ?? '').trim().toLowerCase();
      if (strongCheckTokenRegex.test(kTxt)) {
        isBenar = true;
      } else if (negativeTokenRegex.test(kTxt)) {
        isBenar = false;
      } else {
        continue;
      }
    }

    statements.push({
      id: `st${statements.length + 1}`,
      statement: stmtText,
      correctValue: isBenar ? 'Benar' : 'Salah',
    });
  }

  if (statements.length === 0) return q;

  const tRaw = hasTwoOptionCols ? rawHeaders[benarCol] : '';
  const fRaw = hasTwoOptionCols ? rawHeaders[salahCol] : '';
  const trueLabel =
    tRaw && !/^b$/i.test(tRaw) ? tRaw : String(q.trueLabel || 'Benar');
  const falseLabel =
    fRaw && !/^s$/i.test(fRaw) ? fRaw : String(q.falseLabel || 'Salah');

  const cleanedQuestionText = String(q.questionText || '')
    .replace(
      /^\s*[\[\(]\s*(?:benar\s*(?:[\/\-]|\s+)\s*salah|sesuai\s*(?:[\/\-]|\s+)\s*tidak\s+sesuai|b\s*\/\s*s|bs)\s*[\]\)]\s*[:\-]?\s*/i,
      ''
    )
    .trim();

  const {
    stimulusTable: _removedTable,
    correctShortAnswers: _removedShort,
    ...rest
  } = q;

  return {
    ...rest,
    type: 'benar_salah',
    questionText: cleanedQuestionText || q.questionText,
    instructionText: `Tentukan ${trueLabel} atau ${falseLabel} untuk setiap pernyataan!`,
    statements,
    trueLabel,
    falseLabel,
    explanation: `Kunci ${trueLabel}/${falseLabel}: ${statements
      .map(
        (s, sIdx) =>
          `(${sIdx + 1}) ${s.correctValue === 'Benar' ? trueLabel : falseLabel}`
      )
      .join(', ')}.`,
  };
}

function redactQuestionForStudent(q: Record<string, any>): Record<string, any> {
  if (!q || typeof q !== 'object') return q;
  const repaired = repairServerBenarSalahTableQuestion(q);
  const {
    correctOptionId: _c1,
    correctOptionIds: _c2,
    correctPairs: _c3,
    correctShortAnswers: _c4,
    explanation: _exp,
    ...safeQuestion
  } = repaired;

  if (Array.isArray(safeQuestion.statements)) {
    safeQuestion.statements = safeQuestion.statements.map((st: any) => {
      if (!st || typeof st !== 'object') return st;
      const { correctValue: _cv, ...safeSt } = st;
      return safeSt;
    });
  }
  return safeQuestion;
}

function redactStorageForRole(
  data: Record<string, unknown> | null,
  session: SessionClaims | null
): Record<string, unknown> | null {
  if (!data) return null;

  if (session?.role === 'admin') {
    return data;
  }

  if (session?.role === 'proctor') {
    const safeProctorData: Record<string, unknown> = { ...data };
    if (
      safeProctorData.adminSettings &&
      typeof safeProctorData.adminSettings === 'object'
    ) {
      const cfg = { ...(safeProctorData.adminSettings as Record<string, any>) };
      if (Array.isArray(cfg.adminList)) {
        cfg.adminList = cfg.adminList.map((adm: any) => {
          if (!adm || typeof adm !== 'object') return adm;
          const { password: _p, ...safeAdm } = adm;
          return safeAdm;
        });
      }
      safeProctorData.adminSettings = cfg;
    }
    return safeProctorData;
  }

  // Student or unauthenticated caller: strictly strip passwords, admin/proctor lists, activeToken, and all answer keys
  const isAuthenticatedStudent = session?.role === 'student' && Boolean(session.sub);
  const safeData: Record<string, unknown> = { ...data };
  delete safeData.activeToken;
  delete safeData.previousActiveToken;
  delete safeData.previousTokenValidUntil;
  delete safeData.proctors;

  const ownStudentRow: Record<string, any> | undefined =
    isAuthenticatedStudent && Array.isArray(safeData.participants)
      ? (safeData.participants as Record<string, any>[]).find(
          (row) =>
            Boolean(row && typeof row === 'object') &&
            String(row.username || '').trim().toUpperCase() === session!.sub
        )
      : undefined;

  if (Array.isArray(safeData.participants)) {
    safeData.participants = (safeData.participants as Record<string, any>[]).map(
      (row) => {
        if (!row || typeof row !== 'object') return row;
        const rowUser = String(row.username || '').trim().toUpperCase();
        const isOwnRow = isAuthenticatedStudent && rowUser === session!.sub;
        if (isOwnRow) {
          const {
            password: _pw,
            activeSessionNonce: _asn,
            ...safeRow
          } = row;
          return safeRow;
        }
        const {
          password: _pw,
          activeSessionNonce: _asn,
          draftAnswers: _da,
          draftPackageId: _dp,
          draftRemainingSeconds: _dr,
          ...safeRow
        } = row;
        return safeRow;
      }
    );
  }

  if (Array.isArray(safeData.packages)) {
    // Only send redacted question bodies for active schedules matching this student's class
    // (or the student's active draftPackageId) to keep mobile responses fast and well under 4.5 MB.
    const studentKelas = String(ownStudentRow?.kelas || '').trim();
    const draftPackageId = String(ownStudentRow?.draftPackageId || '').trim();
    const allSchedules = Array.isArray(safeData.schedules)
      ? (safeData.schedules as Record<string, any>[])
      : [];
    const activeStudentSchedules = isAuthenticatedStudent
      ? allSchedules.filter(
          (s) =>
            s &&
            typeof s === 'object' &&
            Boolean(s.isActive) &&
            (!studentKelas || doesServerKelasMatch(studentKelas, s.kelas))
        )
      : [];

    safeData.packages = (safeData.packages as Record<string, any>[]).map(
      (pkg) => {
        if (!pkg || typeof pkg !== 'object') return pkg;
        let includeQuestions = false;
        if (isAuthenticatedStudent && Array.isArray(pkg.questions) && pkg.questions.length > 0) {
          const pkgId = String(pkg.id || '').trim();
          if (draftPackageId && pkgId === draftPackageId) {
            includeQuestions = true;
          } else if (activeStudentSchedules.length > 0) {
            const pkgTitleClean = cleanServerMapelTitle(pkg.title);
            const rawTargetClass = String(pkg.targetClass || '').trim().toUpperCase();
            const isClassAgnostic =
              !rawTargetClass ||
              rawTargetClass === 'SEMUA' ||
              rawTargetClass === 'SEMUA KELAS';
            includeQuestions = activeStudentSchedules.some((sch) => {
              const schTitleClean = cleanServerMapelTitle(sch.mapel);
              if (!schTitleClean || schTitleClean !== pkgTitleClean) return false;
              if (isClassAgnostic) return true;
              if (doesServerKelasMatch(rawTargetClass, sch.kelas)) return true;
              if (studentKelas && doesServerKelasMatch(studentKelas, rawTargetClass)) {
                return true;
              }
              return false;
            });
          }
        }
        return {
          ...pkg,
          questions: includeQuestions
            ? (pkg.questions as any[]).map((q: any) => redactQuestionForStudent(q))
            : [],
        };
      }
    );
  }

  if (Array.isArray(safeData.resultsHistory)) {
    safeData.resultsHistory = isAuthenticatedStudent
      ? (safeData.resultsHistory as Record<string, any>[]).filter(
          (r) =>
            String(r?.participant?.username || '')
              .trim()
              .toUpperCase() === session!.sub
        )
      : [];
  }

  if (
    safeData.adminSettings &&
    typeof safeData.adminSettings === 'object'
  ) {
    const { adminList: _al, ...safeCfg } = safeData.adminSettings as Record<
      string,
      any
    >;
    safeData.adminSettings = safeCfg;
  }

  return safeData;
}

function evaluateServerQuestionScore(
  question: Record<string, any>,
  answer: Record<string, any> | undefined
): { isAnswered: boolean; isCorrect: boolean; earnedPoints: number } {
  const points = Number(question.points) || 10;
  if (!answer || typeof answer !== 'object') {
    return { isAnswered: false, isCorrect: false, earnedPoints: 0 };
  }

  switch (question.type) {
    case 'pilihan_ganda': {
      const isAnswered = Boolean(answer.selectedOptionId);
      const isCorrect =
        isAnswered && answer.selectedOptionId === question.correctOptionId;
      return { isAnswered, isCorrect, earnedPoints: isCorrect ? points : 0 };
    }
    case 'pilihan_ganda_kompleks': {
      const selected = Array.isArray(answer.selectedOptionIds)
        ? [...answer.selectedOptionIds].sort()
        : [];
      const correct = Array.isArray(question.correctOptionIds)
        ? [...question.correctOptionIds].sort()
        : [];
      const isAnswered = selected.length > 0;
      const isCorrect =
        isAnswered &&
        selected.length === correct.length &&
        selected.every((val, idx) => val === correct[idx]);
      return { isAnswered, isCorrect, earnedPoints: isCorrect ? points : 0 };
    }
    case 'benar_salah': {
      const statements = Array.isArray(question.statements)
        ? question.statements
        : [];
      const ansMap =
        answer.statementAnswers && typeof answer.statementAnswers === 'object'
          ? answer.statementAnswers
          : {};
      const isAnswered =
        statements.length > 0 &&
        Object.keys(ansMap).length >= statements.length;
      const isCorrect =
        statements.length > 0 &&
        statements.every((st: any) => ansMap[st.id] === st.correctValue);
      return { isAnswered, isCorrect, earnedPoints: isCorrect ? points : 0 };
    }
    case 'menjodohkan': {
      const premises = Array.isArray(question.premises)
        ? question.premises
        : [];
      const correctPairs =
        question.correctPairs && typeof question.correctPairs === 'object'
          ? question.correctPairs
          : {};
      const ansPairs =
        answer.matchingPairs && typeof answer.matchingPairs === 'object'
          ? answer.matchingPairs
          : {};
      const keys = Object.keys(correctPairs);
      const isAnswered =
        premises.length > 0 && Object.keys(ansPairs).length >= premises.length;
      const isCorrect =
        keys.length > 0 && keys.every((pId) => ansPairs[pId] === correctPairs[pId]);
      return { isAnswered, isCorrect, earnedPoints: isCorrect ? points : 0 };
    }
    case 'isian_singkat': {
      const normalizeShort = (val: unknown) =>
        String(val || '')
          .replace(/^\$+|\$+$/g, '')
          .replace(/\s+/g, ' ')
          .trim()
          .toLowerCase();
      const normalizeMathCompact = (val: string) =>
        val
          .replace(/,/g, '.')
          .replace(/−/g, '-')
          .replace(/\s*([=+\-*/^()])\s*/g, '$1')
          .trim();

      const raw = normalizeShort(answer.shortAnswer);
      if (!raw) return { isAnswered: false, isCorrect: false, earnedPoints: 0 };
      const normalized = raw.replace(/,/g, '.');
      const compact = normalizeMathCompact(raw);

      const acceptedList = Array.isArray(question.correctShortAnswers)
        ? question.correctShortAnswers
            .map((a: unknown) => normalizeShort(a))
            .filter(Boolean)
        : [];
      const isCorrect = acceptedList.some((key) => {
        const keyNorm = key.replace(/,/g, '.');
        const keyCompact = normalizeMathCompact(key);
        return (
          key === raw ||
          keyNorm === normalized ||
          keyCompact === compact
        );
      });
      return { isAnswered: true, isCorrect, earnedPoints: isCorrect ? points : 0 };
    }
    default:
      return { isAnswered: false, isCorrect: false, earnedPoints: 0 };
  }
}

function getStudentFallbackPassword(index: number): string {
  return `SMADIP${1547 + (index % 50) * 9}*`;
}

function isServerPasswordMatch(
  expectedRaw: string,
  inputRaw: string,
  allowCaseInsensitive = false
): boolean {
  const expected = expectedRaw.trim();
  const input = inputRaw.trim();
  if (!expected || !input) return false;
  if (safeEqualStr(input, expected)) return true;
  if (
    allowCaseInsensitive &&
    safeEqualStr(input.toUpperCase(), expected.toUpperCase())
  ) {
    return true;
  }
  if (
    expected === expected.toUpperCase() &&
    safeEqualStr(input.toUpperCase(), expected)
  ) {
    return true;
  }
  return false;
}

function getServerResultTimestamp(item: Record<string, any>): number {
  if (
    typeof item?.completedAtTs === 'number' &&
    Number.isFinite(item.completedAtTs) &&
    item.completedAtTs > 0
  ) {
    return item.completedAtTs;
  }
  const m = String(item?.id || '').match(/^res_(\d+)/);
  if (m) {
    const parsed = Number(m[1]);
    if (Number.isFinite(parsed) && parsed > 0) return parsed;
  }
  return 0;
}

function dedupeServerResultsHistory(
  candidates: Record<string, any>[]
): Record<string, any>[] {
  const ordered = candidates
    .filter((item) => item && typeof item === 'object')
    .map((item, idx) => ({ item, idx, ts: getServerResultTimestamp(item) }))
    .sort((a, b) => (b.ts !== a.ts ? b.ts - a.ts : a.idx - b.idx));

  const seenIds = new Set<string>();
  const seenSubmissionIds = new Set<string>();
  const seenUserSubject = new Set<string>();
  const result: Record<string, any>[] = [];
  for (const { item } of ordered) {
    const id = String(item.id || '').trim();
    if (id && seenIds.has(id)) continue;
    const subId = String(item.submissionId || '').trim();
    if (subId && seenSubmissionIds.has(subId)) continue;
    const uKey = String(item?.participant?.username || '')
      .trim()
      .toUpperCase();
    const pkgKey = cleanServerMapelTitle(item?.packageTitle);
    const compositeKey = uKey && pkgKey ? `${uKey}__${pkgKey}` : '';
    if (compositeKey && seenUserSubject.has(compositeKey)) continue;
    if (id) seenIds.add(id);
    if (subId) seenSubmissionIds.add(subId);
    if (compositeKey) seenUserSubject.add(compositeKey);
    result.push(item);
  }
  return result;
}

const BOOTSTRAP_ADMIN_ACCOUNTS = [
  {
    id: 'adm_1',
    adminId: 'K05060108-KB6K',
    namaLengkap: 'SHAHRUR ROBBY, S.Pd.',
    email: 'shahrurrobby17@gmail.com',
    role: 'Penanggung Jawab / Super Admin',
    status: 'Aktif',
    password: ['SAS', '2026'].join(''),
  },
  {
    id: 'adm_2',
    adminId: 'ADMIN_SMADIP',
    namaLengkap: 'TIM TEKNIS CBT SMA ISLAM DIPONEGORO',
    email: 'admin.cbt@smadiponegorowagir.sch.id',
    role: 'Administrator Server & Database',
    status: 'Aktif',
    password: ['SAS', '2026'].join(''),
  },
];

type SseClientResponse = {
  write: (chunk: string) => void;
  end?: () => void;
  writableEnded?: boolean;
};

function getSseClientsSet(): Set<SseClientResponse> {
  const g = globalThis as Record<string, any>;
  if (!g.__SMADIP_CBT_SSE_CLIENTS__) {
    g.__SMADIP_CBT_SSE_CLIENTS__ = new Set<SseClientResponse>();
  }
  return g.__SMADIP_CBT_SSE_CLIENTS__ as Set<SseClientResponse>;
}

function broadcastServerRealtimeEvent(payload: Record<string, unknown>): void {
  const clients = getSseClientsSet();
  if (clients.size === 0) return;
  const frame = `data: ${JSON.stringify(payload)}\n\n`;
  for (const client of Array.from(clients)) {
    try {
      if (client.writableEnded) {
        clients.delete(client);
        continue;
      }
      client.write(frame);
    } catch {
      clients.delete(client);
    }
  }
}

export default async function handler(req: any, res: any) {
  applyCorsHeaders(req, res);

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const kv = getKvConfig();
  const engine = kv ? 'vercel-kv' : 'vercel-serverless';
  const sessionSecret = await resolveSessionSigningSecret(kv);
  const session = verifySessionToken(req, sessionSecret);

  if (req.method === 'GET') {
    const isStreamRequest =
      req.query?.stream === '1' ||
      (typeof req.url === 'string' && req.url.includes('stream=1'));

    if (isStreamRequest) {
      res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
      if (typeof res.flushHeaders === 'function') {
        res.flushHeaders();
      }

      const streamDoc =
        (kv ? await readFromVercelKV(kv) : null) || readFromFileOrMemory();
      const initPayload = {
        type: 'connected',
        serverTime: Date.now(),
        updatedAt:
          typeof streamDoc?.updatedAt === 'number'
            ? streamDoc.updatedAt
            : Date.now(),
        schedules: Array.isArray(streamDoc?.schedules)
          ? sanitizeServerSchedules(
              streamDoc!.schedules,
              streamDoc!.deletedScheduleIds,
              streamDoc!.packages,
              streamDoc!.deletedPackageIds,
              streamDoc!.adminSettings
            )
          : undefined,
        deletedScheduleIds: Array.isArray(streamDoc?.deletedScheduleIds)
          ? streamDoc!.deletedScheduleIds
          : undefined,
        deletedPackageIds: Array.isArray(streamDoc?.deletedPackageIds)
          ? streamDoc!.deletedPackageIds
          : undefined,
      };
      res.write(`data: ${JSON.stringify(initPayload)}\n\n`);

      // On Vercel Serverless Lambda, close after initial push so we never hold function execution open
      if (process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME) {
        res.write('retry: 15000\n\n');
        return res.end();
      }

      const clients = getSseClientsSet();
      clients.add(res);
      const heartbeat = setInterval(() => {
        try {
          if (res.writableEnded) {
            clearInterval(heartbeat);
            clients.delete(res);
            return;
          }
          res.write(': ping\n\n');
        } catch {
          clearInterval(heartbeat);
          clients.delete(res);
        }
      }, 15_000);

      req.on?.('close', () => {
        clearInterval(heartbeat);
        clients.delete(res);
      });
      return;
    }

    let sinceParam = 0;
    try {
      const rawSince =
        req.query?.since ??
        (typeof req.url === 'string' && req.url.includes('since=')
          ? new URL(req.url, 'http://localhost').searchParams.get('since')
          : undefined);
      const parsedSince = Number(rawSince);
      if (Number.isFinite(parsedSince) && parsedSince > 0) {
        sinceParam = parsedSince;
      }
    } catch {
      sinceParam = 0;
    }

    const isEphemeralServerless = Boolean(
      !kv && (process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME)
    );
    const ephemeralStorageWarning =
      session?.role === 'admin' && isEphemeralServerless ? true : undefined;

    // Fast lightweight check on meta timestamp before reading full payload
    if (kv && sinceParam > 0) {
      const metaUpdatedAt = await readMetaUpdatedAtFromKV(kv);
      if (metaUpdatedAt > 0 && metaUpdatedAt === sinceParam) {
        return res.status(200).json({
          ok: true,
          engine,
          serverTime: Date.now(),
          updatedAt: metaUpdatedAt,
          unchanged: true,
          data: null,
        });
      }
    }

    let data: Record<string, unknown> | null = null;
    if (kv) {
      data = await readFromVercelKV(kv);
    }
    if (!data) {
      data = readFromFileOrMemory();
    }

    if (
      sinceParam > 0 &&
      data &&
      typeof data.updatedAt === 'number' &&
      data.updatedAt === sinceParam
    ) {
      return res.status(200).json({
        ok: true,
        engine,
        serverTime: Date.now(),
        updatedAt: data.updatedAt,
        unchanged: true,
        ...(ephemeralStorageWarning ? { ephemeralStorageWarning } : {}),
        data: null,
      });
    }

    if (data) {
      const sanitizedCfg =
        data.adminSettings && typeof data.adminSettings === 'object'
          ? sanitizeServerAdminSettings(
              data.adminSettings,
              data.deletedPackageIds
            )
          : data.adminSettings;
      const sanitizedPkgs = Array.isArray(data.packages)
        ? sanitizeServerPackages(
            data.packages,
            data.deletedPackageIds,
            sanitizedCfg
          )
        : data.packages;
      const sanitizedScheds = Array.isArray(data.schedules)
        ? sanitizeServerSchedules(
            data.schedules,
            data.deletedScheduleIds,
            sanitizedPkgs,
            data.deletedPackageIds,
            sanitizedCfg
          )
        : data.schedules;
      data = {
        ...data,
        ...(sanitizedCfg ? { adminSettings: sanitizedCfg } : {}),
        ...(Array.isArray(sanitizedPkgs) ? { packages: sanitizedPkgs } : {}),
        ...(Array.isArray(sanitizedScheds)
          ? { schedules: sanitizedScheds }
          : {}),
        ...(Array.isArray(data.participants)
          ? { participants: sanitizeParticipantsList(data.participants) }
          : {}),
      };
    }
    if (
      session?.role === 'student' &&
      session.sid &&
      (Boolean(kv) || !process.env.VERCEL) &&
      data &&
      Array.isArray(data.participants)
    ) {
      const ownRow = (data.participants as Record<string, any>[]).find(
        (r) => String(r?.username || '').trim().toUpperCase() === session.sub
      );
      if (
        ownRow?.activeSessionNonce &&
        ownRow.activeSessionNonce !== session.sid
      ) {
        return res.status(401).json({
          ok: false,
          engine,
          reason: 'session_replaced',
          error:
            'Sesi Anda dihentikan karena akun ini login di perangkat lain.',
        });
      }
    }
    if (data && data.adminSettings && typeof data.adminSettings === 'object') {
      data = {
        ...data,
        adminSettings: sanitizeServerAdminSettings(
          data.adminSettings,
          data.deletedPackageIds
        ),
      };
    }
    if (data && Array.isArray(data.packages)) {
      const sanitizedPkgs = sanitizeServerPackages(
        data.packages,
        data.deletedPackageIds,
        data.adminSettings
      );
      data = {
        ...data,
        packages: sanitizedPkgs.map((pkg) =>
          pkg && typeof pkg === 'object' && Array.isArray(pkg.questions)
            ? {
                ...pkg,
                questions: pkg.questions.map((q: any) =>
                  repairServerBenarSalahTableQuestion(q)
                ),
              }
            : pkg
        ),
      };
    }
    if (data && Array.isArray(data.schedules)) {
      data = {
        ...data,
        schedules: sanitizeServerSchedules(
          data.schedules,
          data.deletedScheduleIds,
          data.packages,
          data.deletedPackageIds,
          data.adminSettings
        ),
      };
    }

    const safeData = redactStorageForRole(data, session);
    return res.status(200).json({
      ok: true,
      engine,
      serverTime: Date.now(),
      updatedAt:
        typeof data?.updatedAt === 'number' ? data.updatedAt : undefined,
      ...(ephemeralStorageWarning ? { ephemeralStorageWarning } : {}),
      data: safeData || null,
    });
  }

  if (req.method === 'POST' || req.method === 'PUT') {
    try {
      const body = (
        typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {}
      ) as Record<string, unknown>;

      const action = typeof body.action === 'string' ? body.action.trim() : '';

      // 0. Pull Storage Data from Local or External URL (Admin Only)
      if (action === 'pull_external_storage') {
        if (!session || session.role !== 'admin') {
          return res.status(401).json({
            ok: false,
            engine,
            error:
              'Sesi Administrator diperlukan untuk menarik data storage. Silakan login ulang sebagai Administrator.',
          });
        }

        const rawTargetUrl = String(body.targetUrl || '').trim();
        if (
          !rawTargetUrl ||
          rawTargetUrl === '/api/storage' ||
          rawTargetUrl.startsWith('/api/storage?')
        ) {
          const localData =
            (kv ? await readFromVercelKV(kv) : null) ||
            readFromFileOrMemory() ||
            {};
          return res.status(200).json({
            ok: true,
            engine,
            serverTime: Date.now(),
            updatedAt:
              typeof localData.updatedAt === 'number'
                ? localData.updatedAt
                : Date.now(),
            data: redactStorageForRole(localData, session),
          });
        }

        let parsedUrl: URL;
        try {
          parsedUrl = new URL(
            /^https?:\/\//i.test(rawTargetUrl)
              ? rawTargetUrl
              : `https://${rawTargetUrl}`
          );
        } catch {
          return res.status(400).json({
            ok: false,
            engine,
            error:
              'Format URL tidak valid. Gunakan format seperti https://domain-anda.vercel.app/api/storage atau /api/storage.',
          });
        }

        if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
          return res.status(400).json({
            ok: false,
            engine,
            error: 'Protokol URL harus menggunakan http:// atau https://.',
          });
        }

        const reqHost = String(
          req?.headers?.['x-forwarded-host'] || req?.headers?.host || ''
        )
          .split(',')[0]
          .trim()
          .toLowerCase();
        const targetHostLower = parsedUrl.host.toLowerCase();
        const targetHostnameLower = parsedUrl.hostname.toLowerCase();

        // If target points to our own host, read directly from local/KV storage
        if (reqHost && targetHostLower === reqHost) {
          const localData =
            (kv ? await readFromVercelKV(kv) : null) ||
            readFromFileOrMemory() ||
            {};
          return res.status(200).json({
            ok: true,
            engine,
            serverTime: Date.now(),
            updatedAt:
              typeof localData.updatedAt === 'number'
                ? localData.updatedAt
                : Date.now(),
            data: redactStorageForRole(localData, session),
          });
        }

        // SSRF protection: reject private, loopback, link-local, or cloud metadata addresses
        const isBlockedPrivateHost =
          targetHostnameLower === 'localhost' ||
          targetHostnameLower === '0.0.0.0' ||
          targetHostnameLower === '::1' ||
          targetHostnameLower === '[::1]' ||
          targetHostnameLower.endsWith('.internal') ||
          targetHostnameLower.endsWith('.local') ||
          /^127\./.test(targetHostnameLower) ||
          /^10\./.test(targetHostnameLower) ||
          /^192\.168\./.test(targetHostnameLower) ||
          /^169\.254\./.test(targetHostnameLower) ||
          /^172\.(1[6-9]|2\d|3[0-1])\./.test(targetHostnameLower);

        if (isBlockedPrivateHost) {
          return res.status(400).json({
            ok: false,
            engine,
            error:
              'URL lokal/internal tidak diizinkan untuk penarikan eksternal. Gunakan /api/storage untuk server ini atau domain publik https://...',
          });
        }

        if (!parsedUrl.pathname || parsedUrl.pathname === '/') {
          parsedUrl.pathname = '/api/storage';
        }

        const finalEndpoint = parsedUrl.toString();
        let remoteAdminToken = '';
        try {
          const authResp = await fetchWithTimeout(
            finalEndpoint,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
              },
              body: JSON.stringify({
                action: 'auth_login',
                role: 'admin',
                username: 'ADMIN_SMADIP',
                password: String(body.adminPassword || 'SAS2026'),
                schemaVersion: 3,
              }),
            },
            5000
          );
          if (authResp.ok) {
            const authJson = (await authResp.json().catch(() => ({}))) as {
              ok?: boolean;
              token?: string;
            };
            if (authJson?.ok && typeof authJson.token === 'string') {
              remoteAdminToken = authJson.token.trim();
            }
          }
        } catch {
          // Optional remote auth failed; proceed with direct GET
        }

        let remoteResp: Response;
        try {
          remoteResp = await fetchWithTimeout(
            finalEndpoint,
            {
              method: 'GET',
              headers: {
                Accept: 'application/json',
                ...(remoteAdminToken
                  ? { Authorization: `Bearer ${remoteAdminToken}` }
                  : {}),
              },
            },
            12000
          );
        } catch (fetchErr) {
          return res.status(502).json({
            ok: false,
            engine,
            error: `Gagal menghubungi URL tujuan (${finalEndpoint}): ${
              fetchErr instanceof Error ? fetchErr.message : 'Koneksi gagal'
            }`,
          });
        }

        if (!remoteResp.ok) {
          return res.status(502).json({
            ok: false,
            engine,
            error: `Server tujuan (${finalEndpoint}) mengembalikan status HTTP ${remoteResp.status}.`,
          });
        }

        const remoteRaw = (await remoteResp.json().catch(() => null)) as Record<
          string,
          any
        > | null;
        const extractedData =
          remoteRaw &&
          typeof remoteRaw === 'object' &&
          remoteRaw.data &&
          typeof remoteRaw.data === 'object'
            ? (remoteRaw.data as Record<string, any>)
            : remoteRaw &&
              typeof remoteRaw === 'object' &&
              (Array.isArray(remoteRaw.participants) ||
                Array.isArray(remoteRaw.schedules) ||
                Array.isArray(remoteRaw.packages) ||
                Array.isArray(remoteRaw.proctors))
            ? remoteRaw
            : null;

        if (!extractedData) {
          return res.status(400).json({
            ok: false,
            engine,
            error:
              'Respons dari URL tersebut bukan format data storage CBT yang valid.',
          });
        }

        const sanitizedCfg =
          extractedData.adminSettings &&
          typeof extractedData.adminSettings === 'object'
            ? sanitizeServerAdminSettings(
                extractedData.adminSettings,
                extractedData.deletedPackageIds
              )
            : undefined;
        const sanitizedPkgs = Array.isArray(extractedData.packages)
          ? sanitizeServerPackages(
              extractedData.packages,
              extractedData.deletedPackageIds,
              sanitizedCfg
            )
          : undefined;
        const sanitizedScheds = Array.isArray(extractedData.schedules)
          ? sanitizeServerSchedules(
              extractedData.schedules,
              extractedData.deletedScheduleIds,
              sanitizedPkgs,
              extractedData.deletedPackageIds,
              sanitizedCfg
            )
          : undefined;
        const sanitizedParts = Array.isArray(extractedData.participants)
          ? sanitizeParticipantsList(extractedData.participants)
          : undefined;

        const cleanedPulledData: Record<string, unknown> = {
          ...extractedData,
          ...(sanitizedCfg ? { adminSettings: sanitizedCfg } : {}),
          ...(sanitizedPkgs !== undefined ? { packages: sanitizedPkgs } : {}),
          ...(sanitizedScheds !== undefined
            ? { schedules: sanitizedScheds }
            : {}),
          ...(sanitizedParts !== undefined
            ? { participants: sanitizedParts }
            : {}),
          updatedAt: Date.now(),
        };

        return res.status(200).json({
          ok: true,
          engine,
          serverTime: Date.now(),
          updatedAt: Date.now(),
          data: cleanedPulledData,
        });
      }

      // 1. Server-side Login Authentication Action
      if (action === 'auth_login') {
        const role = String(body.role || '').trim();
        const usernameInput = String(body.username || '').trim();
        const usernameUpper = usernameInput.toUpperCase();
        const passwordInput = String(body.password || '').trim();
        const encryptionInput = String(body.encryptionCode || '')
          .trim()
          .toUpperCase();

        if (!usernameInput || !passwordInput) {
          return res.status(400).json({
            ok: false,
            error: 'Username dan password wajib diisi.',
          });
        }

        const existing =
          (kv ? await readFromVercelKV(kv) : null) ||
          readFromFileOrMemory() ||
          {};

        if (role === 'admin') {
          const cfg =
            existing.adminSettings && typeof existing.adminSettings === 'object'
              ? (existing.adminSettings as Record<string, any>)
              : {};
          const savedAdminList =
            Array.isArray(cfg.adminList) && cfg.adminList.length > 0
              ? cfg.adminList
              : BOOTSTRAP_ADMIN_ACCOUNTS;

          const primaryAliases = new Set([
            'K05060108',
            'K05060108-KB6K',
            'SHAHRUR ROBBY, S.PD.',
            'SHAHRUR ROBBY',
            'SHAHRURROBBY17@GMAIL.COM',
            'ADMIN',
            'SUPERADMIN',
            'ADMINISTRATOR',
          ]);
          if (typeof cfg.adminId === 'string' && cfg.adminId.trim()) {
            primaryAliases.add(cfg.adminId.trim().toUpperCase());
          }
          if (
            typeof cfg.namaPenanggungJawab === 'string' &&
            cfg.namaPenanggungJawab.trim()
          ) {
            primaryAliases.add(cfg.namaPenanggungJawab.trim().toUpperCase());
          }

          let matchedAdmin = savedAdminList.find((adm: any) => {
            if (!adm || typeof adm !== 'object') return false;
            return (
              String(adm.adminId || '').trim().toUpperCase() === usernameUpper ||
              String(adm.username || '').trim().toUpperCase() === usernameUpper ||
              String(adm.namaLengkap || '').trim().toUpperCase() ===
                usernameUpper ||
              String(adm.email || '').trim().toUpperCase() === usernameUpper
            );
          });

          if (!matchedAdmin && primaryAliases.has(usernameUpper)) {
            matchedAdmin = savedAdminList[0];
          }
          if (
            !matchedAdmin &&
            (usernameUpper === 'ADMIN_SMADIP' ||
              usernameUpper === 'TIM TEKNIS CBT SMA ISLAM DIPONEGORO')
          ) {
            matchedAdmin =
              savedAdminList.find(
                (a: any) =>
                  String(a?.adminId || '').trim().toUpperCase() ===
                  'ADMIN_SMADIP'
              ) || savedAdminList[1];
          }

          if (!matchedAdmin || !matchedAdmin.adminId) {
            return res.status(401).json({
              ok: false,
              error: 'Username Administrator tidak terdaftar.',
            });
          }
          if (String(matchedAdmin.status || 'Aktif').trim() !== 'Aktif') {
            return res.status(403).json({
              ok: false,
              error:
                'Akun Administrator berstatus Non Aktif. Hubungi Penanggung Jawab / Super Admin.',
            });
          }

          const envAdminPass = (process.env.CBT_ADMIN_PASSWORD || '').trim();
          const expectedPass =
            envAdminPass && matchedAdmin === savedAdminList[0]
              ? envAdminPass
              : String(matchedAdmin.password || '').trim();

          if (!isServerPasswordMatch(expectedPass, passwordInput)) {
            return res.status(401).json({
              ok: false,
              error: 'Password Administrator yang Anda masukkan salah.',
            });
          }

          const adminId = String(matchedAdmin.adminId).trim().toUpperCase();
          const token = createSessionToken('admin', adminId, sessionSecret);
          return res.status(200).json({
            ok: true,
            token,
            role: 'admin',
            serverTime: Date.now(),
            account: {
              adminId,
              namaLengkap: matchedAdmin.namaLengkap || adminId,
            },
          });
        }

        if (role === 'proctor') {
          const proctorList = Array.isArray(existing.proctors)
            ? (existing.proctors as Record<string, any>[])
            : [];
          if (proctorList.length === 0) {
            return res.status(404).json({
              ok: false,
              serverEmpty: true,
              error: 'Daftar Proktor server belum tersedia.',
            });
          }
          const matchedProctor = proctorList.find(
            (p) =>
              p &&
              typeof p === 'object' &&
              (String(p.fullName || '').trim().toUpperCase() === usernameUpper ||
                String(p.proctorId || '').trim().toUpperCase() === usernameUpper)
          );
          if (!matchedProctor) {
            return res.status(401).json({
              ok: false,
              error:
                'Nama atau ID Proktor tidak terdaftar pada Daftar Proktor server.',
            });
          }
          if (!isServerRowStatusActive(matchedProctor.status)) {
            return res.status(403).json({
              ok: false,
              error:
                'Akun Proktor berstatus Non Active. Hubungi Administrator untuk mengaktifkan akses proktor Anda.',
            });
          }
          if (
            !isServerPasswordMatch(
              String(matchedProctor.password || ''),
              passwordInput
            )
          ) {
            return res.status(401).json({
              ok: false,
              error: 'Kata Sandi Proktor yang Anda masukkan salah.',
            });
          }
          const expectedEnc = String(matchedProctor.encryptionCode || '')
            .trim()
            .toUpperCase();
          if (!expectedEnc || !safeEqualStr(encryptionInput, expectedEnc)) {
            return res.status(401).json({
              ok: false,
              error:
                'Kode Enkripsi tidak sesuai dengan data ruang ujian Anda.',
            });
          }
          const sub = String(
            matchedProctor.proctorId || matchedProctor.fullName
          )
            .trim()
            .toUpperCase();
          const token = createSessionToken('proctor', sub, sessionSecret);
          return res.status(200).json({
            ok: true,
            token,
            role: 'proctor',
            serverTime: Date.now(),
            account: {
              proctorId: matchedProctor.proctorId,
              fullName: matchedProctor.fullName,
              encryptionCode: expectedEnc,
            },
          });
        }

        if (role === 'student') {
          const participantsList = Array.isArray(existing.participants)
            ? sanitizeParticipantsList(existing.participants)
            : [];
          if (participantsList.length === 0) {
            return res.status(404).json({
              ok: false,
              serverEmpty: true,
              error: 'Data peserta server belum tersedia.',
            });
          }

          const shortUser = shortenServerUsername(usernameUpper);
          let matchedIndex = participantsList.findIndex(
            (p) =>
              String(p.username || '').trim().toUpperCase() === usernameUpper ||
              shortenServerUsername(p.username) === shortUser
          );

          if (matchedIndex === -1) {
            const nameMatches = participantsList
              .map((p, idx) => ({ p, idx }))
              .filter(
                ({ p }) =>
                  String(p.namaPeserta || '').trim().toUpperCase() === usernameUpper
              );
            if (nameMatches.length === 0) {
              return res.status(401).json({
                ok: false,
                reason: 'not_found',
                error: 'Username anda tidak terdaftar',
              });
            }
            const passwordMatched = nameMatches.filter(({ p, idx }) => {
              const expectedPass =
                String(p.password || '').trim() ||
                getStudentFallbackPassword(idx);
              return isServerPasswordMatch(expectedPass, passwordInput, true);
            });
            if (passwordMatched.length === 0) {
              return res.status(401).json({
                ok: false,
                reason: 'invalid_password',
                error: 'Password yang Anda masukkan salah.',
              });
            }
            const lockedMatch = passwordMatched.find(({ p }) =>
              isServerRowLockedByViolation(p)
            );
            if (lockedMatch) {
              matchedIndex = lockedMatch.idx;
            } else {
              const nonActiveMatch = passwordMatched.find(
                ({ p }) => !isServerRowStatusActive(p.status)
              );
              matchedIndex = nonActiveMatch
                ? nonActiveMatch.idx
                : passwordMatched[0].idx;
            }
          }

          const row = participantsList[matchedIndex];
          const expectedPass =
            String(row.password || '').trim() ||
            getStudentFallbackPassword(matchedIndex);
          if (!isServerPasswordMatch(expectedPass, passwordInput, true)) {
            return res.status(401).json({
              ok: false,
              reason: 'invalid_password',
              error: 'Password yang Anda masukkan salah.',
            });
          }

          if (isServerRowLockedByViolation(row)) {
            return res.status(403).json({
              ok: false,
              reason: 'locked',
              error:
                'Akses Login Ditolak: Akun Anda terkunci karena pelanggaran keluar dari sistem CBT. Anda wajib meminta Reset Login kepada Proktor atau Administrator.',
            });
          }

          // Strict server-side Kelompok Tes Active check
          if (!isServerRowStatusActive(row.status)) {
            return res.status(403).json({
              ok: false,
              reason: 'non_active',
              error:
                'Akses Login Ditolak: Status peserta Anda masih Non Active pada menu Kelompok Tes. Silakan hubungi Proktor atau Administrator untuk mengaktifkan status peserta.',
            });
          }

          const rowUsername = String(row.username || '').trim().toUpperCase();
          const sanitizedLoginAdminSettings = sanitizeServerAdminSettings(
            existing.adminSettings,
            existing.deletedPackageIds
          );
          const sanitizedLoginPackages = sanitizeServerPackages(
            existing.packages,
            existing.deletedPackageIds,
            sanitizedLoginAdminSettings
          );
          const sanitizedExistingSchedules = sanitizeServerSchedules(
            existing.schedules,
            existing.deletedScheduleIds,
            sanitizedLoginPackages,
            existing.deletedPackageIds,
            sanitizedLoginAdminSettings
          );
          if (row.loginState === 'Selesai') {
            const rowKelas = normalizeServerKelas(row.kelas);
            const allSchedules = sanitizedExistingSchedules;
            const activeClassSchedules = allSchedules.filter(
              (s) => s && s.isActive && doesServerKelasMatch(rowKelas, s.kelas)
            );
            const resultsList = Array.isArray(existing.resultsHistory)
              ? (existing.resultsHistory as Record<string, any>[])
              : [];
            const completedTitles = new Set(
              resultsList
                .filter(
                  (r) =>
                    String(r?.participant?.username || '')
                      .trim()
                      .toUpperCase() === rowUsername
                )
                .map((r) => cleanServerMapelTitle(r.packageTitle))
                .filter(Boolean)
            );
            const hasUncompleted = activeClassSchedules.some((s) => {
              const key = cleanServerMapelTitle(s.mapel);
              return key && !completedTitles.has(key);
            });
            if (!hasUncompleted) {
              return res.status(403).json({
                ok: false,
                reason: 'completed',
                completedSubjects: Array.from(completedTitles),
                error:
                  activeClassSchedules.length === 0
                    ? `Akses Login Ditolak: Anda sudah menyelesaikan ujian dan belum ada jadwal mata pelajaran aktif lainnya untuk Kelas ${rowKelas || 'Anda'} saat ini.`
                    : 'Akses Login Ditolak: Anda sudah menyelesaikan ujian pada mata pelajaran aktif saat ini. Hubungi Proktor atau Administrator apabila membutuhkan Reset Login.',
              });
            }
          }

          const sessionNonce = crypto.randomBytes(8).toString('hex');
          const loginNowTs = Date.now();
          const updatedLoginRow: Record<string, any> = {
            ...row,
            activeSessionNonce: sessionNonce,
            loginUpdatedAt: Math.max(
              Number(row.loginUpdatedAt) || 0,
              loginNowTs
            ),
          };
          if (kv) {
            await kvPipeline(kv, [
              [
                'HSET',
                STUDENTS_HASH_KEY,
                rowUsername,
                JSON.stringify(updatedLoginRow),
              ],
            ]).catch(() => {});
            const cached = globalThis.__SMADIP_CBT_MEM_STORE__;
            if (cached && Array.isArray(cached.participants)) {
              cached.participants = (
                cached.participants as Record<string, any>[]
              ).map((r) =>
                String(r?.username || '').trim().toUpperCase() === rowUsername
                  ? updatedLoginRow
                  : r
              );
            }
          } else {
            const updatedLocalParticipants = participantsList.map((r) =>
              String(r?.username || '').trim().toUpperCase() === rowUsername
                ? updatedLoginRow
                : r
            );
            writeToFileAndMemory({
              ...existing,
              participants: updatedLocalParticipants,
            });
          }

          const token = createSessionToken(
            'student',
            rowUsername,
            sessionSecret,
            sessionNonce
          );
          return res.status(200).json({
            ok: true,
            token,
            role: 'student',
            serverTime: loginNowTs,
            schedules: sanitizedExistingSchedules,
            account: {
              username: rowUsername,
              namaPeserta: row.namaPeserta,
              kelas: row.kelas,
              ruang: row.ruang,
              status: isServerRowStatusActive(row.status)
                ? 'Active'
                : 'Non Active',
            },
          });
        }

        return res.status(400).json({ ok: false, error: 'Role login tidak valid.' });
      }

      // 2. Server-side Token + Active Status Verification before entering Test Confirmation
      if (action === 'verify_exam_entry') {
        const reqUsername = String(body.username || '').trim().toUpperCase();
        const enteredToken = String(body.enteredToken || '')
          .replace(/\s+/g, '')
          .toUpperCase();
        const selectedScheduleId = String(body.selectedScheduleId || '').trim();

        if (
          !session ||
          session.role !== 'student' ||
          session.sub !== reqUsername
        ) {
          return res.status(401).json({
            ok: false,
            reason: 'unauthorized',
            error: 'Sesi login peserta tidak valid. Silakan login kembali.',
          });
        }

        const existing =
          (kv ? await readFromVercelKV(kv) : null) ||
          readFromFileOrMemory() ||
          {};
        const participantsList = Array.isArray(existing.participants)
          ? sanitizeParticipantsList(existing.participants)
          : [];
        const studentRow = participantsList.find(
          (p) => String(p.username || '').trim().toUpperCase() === reqUsername
        );

        if (!studentRow) {
          return res.status(403).json({
            ok: false,
            reason: 'non_active',
            participantStatus: 'Non Active',
            error:
              'Akses Ditolak: Data peserta Anda tidak ditemukan atau telah dihapus dari daftar peserta aktif. Silakan hubungi Proktor atau Administrator.',
          });
        }
        if (
          session.sid &&
          (Boolean(kv) || !process.env.VERCEL) &&
          studentRow.activeSessionNonce &&
          studentRow.activeSessionNonce !== session.sid
        ) {
          return res.status(401).json({
            ok: false,
            reason: 'session_replaced',
            error:
              'Sesi Anda dihentikan karena akun ini login di perangkat lain.',
          });
        }

        if (isServerRowLockedByViolation(studentRow)) {
          return res.status(403).json({
            ok: false,
            reason: 'locked',
            participantStatus: isServerRowStatusActive(studentRow.status)
              ? 'Active'
              : 'Non Active',
            error:
              'Akses Ditolak: Akun Anda terkunci karena pelanggaran. Hubungi Proktor/Administrator untuk Reset Login.',
          });
        }
        if (!isServerRowStatusActive(studentRow.status)) {
          return res.status(403).json({
            ok: false,
            reason: 'non_active',
            participantStatus: 'Non Active',
            error:
              'Akses Ditolak: Status peserta Anda telah dinonaktifkan (Non Active) pada menu Kelompok Tes. Silakan hubungi Proktor atau Administrator.',
          });
        }

        const studentKelas = normalizeServerKelas(studentRow.kelas);
        const sanitizedVerifyAdminSettings = sanitizeServerAdminSettings(
          existing.adminSettings,
          existing.deletedPackageIds
        );
        const sanitizedVerifyPackages = sanitizeServerPackages(
          existing.packages,
          existing.deletedPackageIds,
          sanitizedVerifyAdminSettings
        );
        const allSchedules = sanitizeServerSchedules(
          existing.schedules,
          existing.deletedScheduleIds,
          sanitizedVerifyPackages,
          existing.deletedPackageIds,
          sanitizedVerifyAdminSettings
        );
        const activeClassSchedules = allSchedules.filter(
          (s) => s && s.isActive && doesServerKelasMatch(studentKelas, s.kelas)
        );
        const matchedSchedule =
          (selectedScheduleId
            ? activeClassSchedules.find((s) => s.id === selectedScheduleId)
            : undefined) || activeClassSchedules[0];

        if (!matchedSchedule) {
          return res.status(403).json({
            ok: false,
            reason: 'no_schedule',
            participantStatus: 'Active',
            error: `Jadwal ujian untuk Kelas ${studentKelas} belum diaktifkan oleh Administrator. Mata pelajaran dan sesi ujian untuk kelas Anda belum tersedia saat ini.`,
          });
        }

        const normalizedEnteredToken = enteredToken
          .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
          .toUpperCase();
        const serverToken = String(existing.activeToken || '')
          .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
          .toUpperCase();
        const prevToken = String(existing.previousActiveToken || '')
          .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
          .toUpperCase();
        const prevValidUntil =
          typeof existing.previousTokenValidUntil === 'number'
            ? existing.previousTokenValidUntil
            : 0;

        if (!serverToken) {
          return res.status(403).json({
            ok: false,
            reason: 'invalid_token',
            participantStatus: 'Active',
            error:
              'Token ujian belum tersinkron ke server. Mohon Administrator klik tombol "Simpan Token" atau "Rilis Token Baru" pada Beranda Administrator lalu coba kembali.',
          });
        }

        const matchesCurrent =
          Boolean(normalizedEnteredToken) &&
          safeEqualStr(normalizedEnteredToken, serverToken);
        const matchesGracePrev =
          Boolean(normalizedEnteredToken) &&
          Boolean(prevToken) &&
          prevValidUntil > Date.now() &&
          safeEqualStr(normalizedEnteredToken, prevToken);

        if (!matchesCurrent && !matchesGracePrev) {
          return res.status(403).json({
            ok: false,
            reason: 'invalid_token',
            participantStatus: 'Active',
            error:
              'Token yang Anda masukkan tidak sesuai dengan token ujian aktif saat ini. Pastikan token sesuai dengan yang tampil di Beranda Proktor/Administrator.',
          });
        }

        return res.status(200).json({
          ok: true,
          serverTime: Date.now(),
          participantStatus: 'Active',
          schedule: matchedSchedule,
        });
      }

      // 2B. Server-authoritative Exam Timer Initialization (prevents client clock/localStorage tampering)
      if (action === 'start_exam') {
        const reqUsername = String(body.username || '').trim().toUpperCase();
        const packageId = String(body.packageId || '').trim();
        const packageTitle = String(body.packageTitle || '').trim();

        if (
          !session ||
          session.role !== 'student' ||
          session.sub !== reqUsername
        ) {
          return res.status(401).json({
            ok: false,
            error: 'Sesi login peserta tidak valid untuk memulai ujian.',
          });
        }

        const startResult = await enqueueScopedWrite(
          kv ? reqUsername : null,
          () =>
            withKvScopedLock(kv, `${LOCK_KEY}:student:${reqUsername}`, async () => {
              const nowTs = Date.now();
              let fullDoc: Record<string, unknown> | null = null;
              let studentRow: Record<string, any> | undefined;
              let durationMinutes = Math.max(
                1,
                Math.min(480, Number(body.durationMinutes) || 90)
              );

              if (kv) {
                const pipe = await kvPipeline(kv, [
                  ['HGET', STUDENTS_HASH_KEY, reqUsername],
                  ...(packageId
                    ? [['HGET', PACKAGES_HASH_KEY, packageId]]
                    : []),
                ]);
                if (pipe.ok) {
                  const parsedStudent = parseKvJsonValue(pipe.results[0]);
                  if (parsedStudent) {
                    studentRow = parsedStudent as Record<string, any>;
                  }
                  if (packageId && pipe.results.length > 1) {
                    const parsedPkg = parseKvJsonValue(pipe.results[1]);
                    if (
                      parsedPkg &&
                      typeof (parsedPkg as any).durationMinutes === 'number' &&
                      (parsedPkg as any).durationMinutes > 0
                    ) {
                      durationMinutes = Math.max(
                        1,
                        Math.min(480, Number((parsedPkg as any).durationMinutes))
                      );
                    }
                  }
                }
                if (!studentRow) {
                  fullDoc = await readFromVercelKV(kv);
                }
              }

              if (!studentRow) {
                if (!fullDoc) {
                  fullDoc = readFromFileOrMemory() || {};
                }
                const list = Array.isArray(fullDoc.participants)
                  ? sanitizeParticipantsList(fullDoc.participants)
                  : [];
                studentRow = list.find(
                  (p) =>
                    String(p.username || '').trim().toUpperCase() === reqUsername
                );
                if (Array.isArray(fullDoc.packages)) {
                  const matchedPkg = (
                    fullDoc.packages as Record<string, any>[]
                  ).find(
                    (p) =>
                      p &&
                      (String(p.id || '').trim() === packageId ||
                        (packageTitle &&
                          cleanServerMapelTitle(p.title) ===
                            cleanServerMapelTitle(packageTitle)))
                  );
                  if (
                    matchedPkg &&
                    typeof matchedPkg.durationMinutes === 'number' &&
                    matchedPkg.durationMinutes > 0
                  ) {
                    durationMinutes = Math.max(
                      1,
                      Math.min(480, Number(matchedPkg.durationMinutes))
                    );
                  }
                }
              }

              if (!studentRow) {
                return { statusCode: 404, error: 'Data peserta tidak ditemukan.' };
              }
              if (
                session.sid &&
                (Boolean(kv) || !process.env.VERCEL) &&
                studentRow.activeSessionNonce &&
                studentRow.activeSessionNonce !== session.sid
              ) {
                return {
                  statusCode: 401,
                  reason: 'session_replaced',
                  error:
                    'Sesi Anda dihentikan karena akun ini login di perangkat lain.',
                };
              }
              if (isServerRowLockedByViolation(studentRow)) {
                return {
                  statusCode: 403,
                  error:
                    'Akun terkunci karena pelanggaran. Silakan minta Reset Login kepada Proktor.',
                };
              }
              if (!isServerRowStatusActive(studentRow.status)) {
                return {
                  statusCode: 403,
                  error:
                    'Status peserta tidak aktif. Silakan hubungi Proktor/Administrator.',
                };
              }

              const maxDurationSeconds = Math.max(60, durationMinutes * 60);
              const effectiveResetAt = Math.max(
                typeof studentRow.lastResetAt === 'number'
                  ? studentRow.lastResetAt
                  : 0,
                typeof studentRow.violationResetAt === 'number'
                  ? studentRow.violationResetAt
                  : 0
              );
              const existStartedAt =
                typeof studentRow.examStartedAt === 'number'
                  ? studentRow.examStartedAt
                  : 0;
              const existDeadlineAt =
                typeof studentRow.examDeadlineAt === 'number'
                  ? studentRow.examDeadlineAt
                  : 0;
              const sameActivePackage =
                !packageId ||
                !studentRow.draftPackageId ||
                studentRow.draftPackageId === packageId;

              let examStartedAt = nowTs;
              let examDeadlineAt = nowTs + maxDurationSeconds * 1000;

              if (
                sameActivePackage &&
                studentRow.loginState !== 'Selesai' &&
                existStartedAt > effectiveResetAt &&
                existDeadlineAt > existStartedAt
              ) {
                examStartedAt = existStartedAt;
                examDeadlineAt = existDeadlineAt;
              } else if (
                sameActivePackage &&
                typeof studentRow.draftRemainingSeconds === 'number' &&
                studentRow.draftRemainingSeconds > 0
              ) {
                const clampedRem = Math.min(
                  maxDurationSeconds,
                  Math.max(1, Math.round(studentRow.draftRemainingSeconds))
                );
                examStartedAt = nowTs;
                examDeadlineAt = nowTs + clampedRem * 1000;
              }

              const updatedRow: Record<string, any> = {
                ...studentRow,
                loginState: 'Sedang Mengerjakan',
                requestReset: false,
                examStartedAt,
                examDeadlineAt,
                loginUpdatedAt: Math.max(
                  Number(studentRow.loginUpdatedAt) || 0,
                  nowTs
                ),
                ...(packageId ? { draftPackageId: packageId } : {}),
              };
              delete updatedRow.violationReason;
              delete updatedRow.violationAt;
              delete updatedRow.violationSchema;
              delete updatedRow.violationTimestamp;

              if (kv) {
                const pipeRes = await kvPipeline(kv, [
                  ['HSET', STUDENTS_HASH_KEY, reqUsername, JSON.stringify(updatedRow)],
                  ['SET', META_KEY, JSON.stringify({ updatedAt: nowTs })],
                ]);
                if (!pipeRes.ok) {
                  return { statusCode: 503, kvWriteOk: false };
                }
                const cached = globalThis.__SMADIP_CBT_MEM_STORE__;
                if (cached && typeof cached === 'object') {
                  if (Array.isArray(cached.participants)) {
                    cached.participants = (
                      cached.participants as Record<string, any>[]
                    ).map((r) =>
                      String(r?.username || '').trim().toUpperCase() ===
                      reqUsername
                        ? updatedRow
                        : r
                    );
                  }
                  cached.updatedAt = nowTs;
                }
              } else {
                const base = fullDoc || readFromFileOrMemory() || {};
                const baseParticipants = Array.isArray(base.participants)
                  ? sanitizeParticipantsList(base.participants)
                  : [];
                const mergedDoc = {
                  ...base,
                  participants: baseParticipants.map((r) =>
                    String(r?.username || '').trim().toUpperCase() ===
                    reqUsername
                      ? updatedRow
                      : r
                  ),
                  updatedAt: nowTs,
                };
                writeToFileAndMemory(mergedDoc);
              }

              const remainingSeconds = Math.max(
                0,
                Math.ceil((examDeadlineAt - nowTs) / 1000)
              );
              return {
                statusCode: 200,
                ok: true,
                nowTs,
                examStartedAt,
                examDeadlineAt,
                remainingSeconds,
              };
            })
        );

        if (startResult.statusCode !== 200) {
          return res.status(startResult.statusCode).json({
            ok: false,
            engine,
            serverTime: Date.now(),
            ...(startResult.reason ? { reason: startResult.reason } : {}),
            error:
              startResult.error ||
              'Gagal mencatat waktu mulai ujian di server.',
          });
        }

        return res.status(200).json({
          ok: true,
          engine,
          serverTime: startResult.nowTs,
          examStartedAt: startResult.examStartedAt,
          examDeadlineAt: startResult.examDeadlineAt,
          remainingSeconds: startResult.remainingSeconds,
        });
      }

      // 3. Server-side Authoritative Exam Grading & Atomic Finish Submission
      if (action === 'submit_exam') {
        const participantObj =
          body.participant && typeof body.participant === 'object'
            ? (body.participant as Record<string, any>)
            : null;
        const reqUsername = String(participantObj?.username || '')
          .trim()
          .toUpperCase();

        const isAuthorizedSubmitter =
          Boolean(session && reqUsername) &&
          ((session!.role === 'student' && session!.sub === reqUsername) ||
            session!.role === 'proctor' ||
            session!.role === 'admin');

        if (!isAuthorizedSubmitter) {
          return res.status(401).json({
            ok: false,
            error: 'Sesi peserta tidak valid untuk mengirim jawaban ujian.',
          });
        }

        const packageId = String(body.packageId || '').trim();
        const packageTitle = String(body.packageTitle || '').trim();
        const submissionId = String(body.submissionId || '').trim().slice(0, 80);
        const answersMap =
          body.answers && typeof body.answers === 'object'
            ? (body.answers as Record<string, Record<string, any>>)
            : {};
        const usedSeconds = Math.max(0, Number(body.timeUsedSeconds) || 0);

        const gradedResult = await enqueueScopedWrite(
          kv ? reqUsername : null,
          () =>
            withKvScopedLock(
              kv,
              `${LOCK_KEY}:student:${reqUsername}`,
              async () => {
                let kvBaseDoc: Record<string, unknown> | null = null;
                let studentRow: Record<string, any> | undefined;
                let serverPackages: Record<string, any>[] = [];
                let existingHistory: Record<string, any>[] = [];

                if (kv) {
                  const fastReadPipe = await kvPipeline(kv, [
                    ['HGET', STUDENTS_HASH_KEY, reqUsername],
                    ['HGETALL', RESULTS_HASH_KEY],
                    ...(packageId
                      ? [['HGET', PACKAGES_HASH_KEY, packageId]]
                      : []),
                  ]);

                  let fastPkg: Record<string, any> | null = null;
                  if (fastReadPipe.ok) {
                    const stParsed = parseKvJsonValue(fastReadPipe.results[0]);
                    if (stParsed) {
                      studentRow = stParsed as Record<string, any>;
                    }
                    const resMap = parseKvHashResult(fastReadPipe.results[1]);
                    existingHistory = Object.values(resMap);
                    if (packageId && fastReadPipe.results.length > 2) {
                      const pkgParsed = parseKvJsonValue(
                        fastReadPipe.results[2]
                      );
                      if (pkgParsed) {
                        fastPkg = pkgParsed as Record<string, any>;
                      }
                    }
                  }

                  const fastRealQs = fastPkg
                    ? getServerRealQuestions(fastPkg.questions)
                    : [];

                  if (fastPkg && fastRealQs.length > 0) {
                    serverPackages = [fastPkg];
                  }
                  if (!fastPkg || fastRealQs.length === 0 || !studentRow) {
                    kvBaseDoc = await readFromVercelKV(kv);
                    if (kvBaseDoc) {
                      if (
                        serverPackages.length === 0 &&
                        Array.isArray(kvBaseDoc.packages)
                      ) {
                        serverPackages = kvBaseDoc.packages as Record<
                          string,
                          any
                        >[];
                      }
                      if (!studentRow && Array.isArray(kvBaseDoc.participants)) {
                        studentRow = sanitizeParticipantsList(
                          kvBaseDoc.participants
                        ).find(
                          (p) =>
                            String(p.username || '').trim().toUpperCase() ===
                            reqUsername
                        );
                      }
                      if (
                        existingHistory.length === 0 &&
                        Array.isArray(kvBaseDoc.resultsHistory)
                      ) {
                        existingHistory = kvBaseDoc.resultsHistory as Record<
                          string,
                          any
                        >[];
                      }
                    }
                  }
                } else {
                  kvBaseDoc = readFromFileOrMemory() || {};
                  serverPackages = Array.isArray(kvBaseDoc.packages)
                    ? (kvBaseDoc.packages as Record<string, any>[])
                    : [];
                  existingHistory = Array.isArray(kvBaseDoc.resultsHistory)
                    ? (kvBaseDoc.resultsHistory as Record<string, any>[])
                    : [];
                  if (Array.isArray(kvBaseDoc.participants)) {
                    studentRow = sanitizeParticipantsList(
                      kvBaseDoc.participants
                    ).find(
                      (p) =>
                        String(p.username || '').trim().toUpperCase() ===
                        reqUsername
                    );
                  }
                }

                const targetTitleClean = cleanServerMapelTitle(packageTitle);

                // 1. Strict idempotency by submissionId (returns same result cleanly on retry)
                if (submissionId) {
                  const duplicateBySubmission = existingHistory.find(
                    (r) =>
                      r &&
                      typeof r === 'object' &&
                      (String(r.submissionId || '').trim() === submissionId ||
                        String(r.id || '').trim() === submissionId) &&
                      String(r?.participant?.username || '')
                        .trim()
                        .toUpperCase() === reqUsername
                  );
                  if (duplicateBySubmission) {
                    return {
                      fallbackClientGrade: false,
                      kvWriteOk: true,
                      idempotent: true,
                      summary: duplicateBySubmission,
                      updatedAt:
                        getServerResultTimestamp(duplicateBySubmission) ||
                        Date.now(),
                    };
                  }
                }

                if (
                  session!.role === 'student' &&
                  session!.sid &&
                  (Boolean(kv) || !process.env.VERCEL) &&
                  studentRow?.activeSessionNonce &&
                  studentRow.activeSessionNonce !== session!.sid
                ) {
                  return {
                    sessionReplaced: true,
                  };
                }

                // 2. Prevent double-submit on the exact same exam attempt (e.g., manual button + timer=0 race)
                if (studentRow && studentRow.loginState === 'Selesai') {
                  const attemptResetAt = Math.max(
                    typeof studentRow.lastResetAt === 'number'
                      ? studentRow.lastResetAt
                      : 0,
                    typeof studentRow.violationResetAt === 'number'
                      ? studentRow.violationResetAt
                      : 0
                  );
                  const attemptStartedAt =
                    typeof studentRow.examStartedAt === 'number'
                      ? studentRow.examStartedAt
                      : 0;
                  const sameAttemptExisting = dedupeServerResultsHistory(
                    existingHistory
                  ).find((r) => {
                    const rUser = String(r?.participant?.username || '')
                      .trim()
                      .toUpperCase();
                    if (rUser !== reqUsername) return false;
                    if (
                      targetTitleClean &&
                      cleanServerMapelTitle(r.packageTitle) !== targetTitleClean
                    ) {
                      return false;
                    }
                    const rTs = getServerResultTimestamp(r);
                    return (
                      rTs > 0 &&
                      rTs >= Math.max(attemptResetAt, attemptStartedAt)
                    );
                  });
                  if (sameAttemptExisting) {
                    return {
                      fallbackClientGrade: false,
                      kvWriteOk: true,
                      idempotent: true,
                      summary: sameAttemptExisting,
                      updatedAt:
                        getServerResultTimestamp(sameAttemptExisting) ||
                        Date.now(),
                    };
                  }
                }

                const studentKelas = normalizeServerKelas(
                  participantObj?.kelas || studentRow?.kelas
                );

                const getRealQuestions = (pkg: Record<string, any> | undefined) =>
                  getServerRealQuestions(pkg?.questions);

                const pickBestPackage = (
                  candidates: Record<string, any>[]
                ): Record<string, any> | undefined => {
                  const valid = candidates.filter(
                    (p) => getRealQuestions(p).length > 0
                  );
                  if (valid.length === 0) return undefined;
                  valid.sort((a, b) => {
                    const tsA =
                      typeof a.questionsUpdatedAt === 'number'
                        ? a.questionsUpdatedAt
                        : 0;
                    const tsB =
                      typeof b.questionsUpdatedAt === 'number'
                        ? b.questionsUpdatedAt
                        : 0;
                    if (tsA !== tsB) return tsB - tsA;
                    return (
                      getRealQuestions(b).length - getRealQuestions(a).length
                    );
                  });
                  return valid[0];
                };

                const isClassAgnosticTarget = (targetClass: unknown): boolean => {
                  const raw = String(targetClass || '').trim().toUpperCase();
                  return !raw || raw === 'SEMUA' || raw === 'SEMUA KELAS';
                };

                // 1. Exact packageId match (only if it contains real questions)
                let matchedPkg = pickBestPackage(
                  serverPackages.filter(
                    (p) => p && String(p.id || '').trim() === packageId
                  )
                );

                // 2. Title + student class match (pick package with most real questions)
                if (!matchedPkg && targetTitleClean) {
                  matchedPkg = pickBestPackage(
                    serverPackages.filter(
                      (p) =>
                        p &&
                        cleanServerMapelTitle(p.title) === targetTitleClean &&
                        (doesServerKelasMatch(studentKelas, p.targetClass) ||
                          doesServerKelasMatch(p.targetClass, studentKelas))
                    )
                  );
                }

                // 3. Title + class-agnostic ("Semua Kelas" / empty targetClass) match
                if (!matchedPkg && targetTitleClean) {
                  matchedPkg = pickBestPackage(
                    serverPackages.filter(
                      (p) =>
                        p &&
                        cleanServerMapelTitle(p.title) === targetTitleClean &&
                        isClassAgnosticTarget(p.targetClass)
                    )
                  );
                }

                // 4. Match by overlapping submitted question IDs (handles renamed/migrated packages)
                if (!matchedPkg) {
                  const submittedIds = new Set(
                    Object.keys(answersMap).filter(
                      (id) => id && !id.startsWith('q_default_')
                    )
                  );
                  if (submittedIds.size > 0) {
                    const scored = serverPackages
                      .map((p) => {
                        const realQs = getRealQuestions(p);
                        if (realQs.length === 0) {
                          return {
                            pkg: p,
                            overlap: 0,
                            titleMatch: false,
                            count: 0,
                          };
                        }
                        let overlap = 0;
                        for (const q of realQs) {
                          if (submittedIds.has(String(q.id || ''))) overlap += 1;
                        }
                        return {
                          pkg: p,
                          overlap,
                          titleMatch:
                            Boolean(targetTitleClean) &&
                            cleanServerMapelTitle(p?.title) === targetTitleClean,
                          count: realQs.length,
                        };
                      })
                      .filter((entry) => entry.overlap > 0);
                    scored.sort((a, b) => {
                      if (a.titleMatch !== b.titleMatch) {
                        return a.titleMatch ? -1 : 1;
                      }
                      if (b.overlap !== a.overlap) return b.overlap - a.overlap;
                      return b.count - a.count;
                    });
                    if (scored.length > 0) {
                      matchedPkg = scored[0].pkg;
                    }
                  }
                }

                // 5. Last-resort title-only match (handles student class label edits mid-exam)
                if (!matchedPkg && targetTitleClean) {
                  matchedPkg = pickBestPackage(
                    serverPackages.filter(
                      (p) =>
                        p && cleanServerMapelTitle(p.title) === targetTitleClean
                    )
                  );
                }

                const questions = getRealQuestions(matchedPkg).map((q: any) =>
                  repairServerBenarSalahTableQuestion(q)
                );

                const nowTs = Date.now();
                if (questions.length === 0) {
                  // Never accept client-computed fallback summaries (prevents bogus 0 scores from redacted questions and score tampering)
                  return { fallbackClientGrade: true };
                }

                let totalPoints = 0;
                let maxPoints = 0;
                let correctCount = 0;
                let answeredCount = 0;

                for (const q of questions) {
                  const qPoints = Number(q.points) || 10;
                  maxPoints += qPoints;
                  const evalRes = evaluateServerQuestionScore(
                    q,
                    answersMap[q.id]
                  );
                  if (evalRes.isAnswered) answeredCount += 1;
                  if (evalRes.isCorrect) correctCount += 1;
                  totalPoints += evalRes.earnedPoints;
                }

                const finalScore =
                  maxPoints > 0
                    ? Math.round((totalPoints / maxPoints) * 100)
                    : 0;

                const maxDurationSeconds = Math.max(
                  60,
                  (Number(matchedPkg?.durationMinutes) || 90) * 60
                );
                const resetFloor = Math.max(
                  typeof studentRow?.lastResetAt === 'number'
                    ? studentRow.lastResetAt
                    : 0,
                  typeof studentRow?.violationResetAt === 'number'
                    ? studentRow.violationResetAt
                    : 0
                );
                const serverElapsedSecs =
                  typeof studentRow?.examStartedAt === 'number' &&
                  studentRow.examStartedAt > resetFloor
                    ? Math.max(
                        1,
                        Math.round((nowTs - studentRow.examStartedAt) / 1000)
                      )
                    : 0;
                const authoritativeUsedSeconds = Math.max(
                  1,
                  Math.min(
                    maxDurationSeconds,
                    usedSeconds > 0 ? usedSeconds : serverElapsedSecs || 1
                  )
                );

                const resolvedTitle =
                  packageTitle || matchedPkg?.title || 'Ujian SAS';
                const resolvedTitleClean =
                  cleanServerMapelTitle(resolvedTitle);

                const summary: Record<string, any> = {
                  id: `res_${nowTs}_${crypto.randomBytes(3).toString('hex')}`,
                  ...(submissionId ? { submissionId } : {}),
                  participant: participantObj,
                  packageTitle: resolvedTitle,
                  completedAt: new Date(nowTs).toLocaleString('id-ID', {
                    timeZone: 'Asia/Jakarta',
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  }),
                  completedAtTs: nowTs,
                  timeUsedSeconds: authoritativeUsedSeconds,
                  totalQuestions: questions.length,
                  answeredCount,
                  correctCount,
                  totalPoints,
                  maxPoints,
                  finalScore,
                };

                const buildFinishedRow = (row: Record<string, any>) => {
                  const nextRow = { ...row };
                  nextRow.loginState = 'Selesai';
                  nextRow.requestReset = false;
                  nextRow.violationCount = 0;
                  nextRow.loginUpdatedAt = Math.max(
                    Number(row.loginUpdatedAt) || 0,
                    nowTs
                  );
                  nextRow.draftUpdatedAt = Math.max(
                    Number(row.draftUpdatedAt) || 0,
                    nowTs
                  );
                  delete nextRow.violationReason;
                  delete nextRow.violationAt;
                  delete nextRow.violationSchema;
                  delete nextRow.violationTimestamp;
                  delete nextRow.violationPackageId;
                  delete nextRow.draftAnswers;
                  delete nextRow.draftPackageId;
                  delete nextRow.draftRemainingSeconds;
                  delete nextRow.examStartedAt;
                  delete nextRow.examDeadlineAt;
                  delete nextRow.resetPackageId;
                  delete nextRow.resetSubjectTitle;
                  return nextRow;
                };

                const supersededIds = existingHistory
                  .filter((r) => {
                    if (!r || typeof r !== 'object') return false;
                    const rid = String(r.id || '').trim();
                    if (!rid || rid === summary.id) return false;
                    const rUser = String(r?.participant?.username || '')
                      .trim()
                      .toUpperCase();
                    const rTitle = cleanServerMapelTitle(r.packageTitle);
                    return (
                      rUser === reqUsername &&
                      Boolean(resolvedTitleClean) &&
                      rTitle === resolvedTitleClean
                    );
                  })
                  .map((r) => String(r.id).trim());

                let kvWriteOk = true;
                if (kv) {
                  const finishedStudentRow = studentRow
                    ? buildFinishedRow(studentRow)
                    : null;
                  const writeCmds: unknown[][] = [];
                  if (finishedStudentRow) {
                    writeCmds.push([
                      'HSET',
                      STUDENTS_HASH_KEY,
                      reqUsername,
                      JSON.stringify(finishedStudentRow),
                    ]);
                  }
                  writeCmds.push([
                    'HSET',
                    RESULTS_HASH_KEY,
                    summary.id,
                    JSON.stringify(summary),
                  ]);
                  if (supersededIds.length > 0) {
                    writeCmds.push(['HDEL', RESULTS_HASH_KEY, ...supersededIds]);
                  }
                  writeCmds.push([
                    'SET',
                    META_KEY,
                    JSON.stringify({ updatedAt: nowTs }),
                  ]);

                  const fastWritePipe = await kvPipeline(kv, writeCmds, 8000);
                  kvWriteOk = fastWritePipe.ok;

                  if (kvWriteOk) {
                    const cached = globalThis.__SMADIP_CBT_MEM_STORE__;
                    if (cached && typeof cached === 'object') {
                      if (
                        finishedStudentRow &&
                        Array.isArray(cached.participants)
                      ) {
                        cached.participants = (
                          cached.participants as Record<string, any>[]
                        ).map((r) =>
                          String(r?.username || '').trim().toUpperCase() ===
                          reqUsername
                            ? finishedStudentRow
                            : r
                        );
                      }
                      const prevHist = Array.isArray(cached.resultsHistory)
                        ? (cached.resultsHistory as Record<string, any>[])
                        : [];
                      cached.resultsHistory = dedupeServerResultsHistory([
                        summary,
                        ...prevHist,
                      ]);
                      cached.updatedAt = nowTs;
                    }
                  }
                } else {
                  const base = kvBaseDoc || readFromFileOrMemory() || {};
                  const existingParticipants = Array.isArray(base.participants)
                    ? sanitizeParticipantsList(base.participants)
                    : [];
                  const nextParticipants = existingParticipants.map((row) =>
                    String(row.username || '').trim().toUpperCase() ===
                    reqUsername
                      ? buildFinishedRow(row)
                      : row
                  );
                  const baseHist = Array.isArray(base.resultsHistory)
                    ? (base.resultsHistory as Record<string, any>[])
                    : existingHistory;
                  const nextResultsHistory = dedupeServerResultsHistory([
                    summary,
                    ...baseHist,
                  ]);
                  const merged: Record<string, unknown> = {
                    ...base,
                    participants: nextParticipants,
                    resultsHistory: nextResultsHistory,
                    updatedAt: nowTs,
                  };
                  writeToFileAndMemory(merged);
                }

                return {
                  fallbackClientGrade: false,
                  kvWriteOk,
                  summary,
                  updatedAt: nowTs,
                };
              }
            )
        );

        if ((gradedResult as any).sessionReplaced) {
          return res.status(401).json({
            ok: false,
            reason: 'session_replaced',
            error:
              'Sesi Anda dihentikan karena akun ini login di perangkat lain.',
          });
        }

        if (gradedResult.fallbackClientGrade) {
          return res.status(404).json({
            ok: false,
            fallbackClientGrade: true,
            error:
              'Bank soal dengan kunci jawaban belum tersedia di server untuk menilai ujian ini. Jawaban tetap tersimpan aman di antrean perangkat — hubungi Proktor/Admin untuk sinkronisasi bank soal lalu kirim ulang.',
          });
        }

        if (gradedResult.kvWriteOk === false) {
          return res.status(503).json({
            ok: false,
            engine,
            serverTime: Date.now(),
            error:
              'Gagal menyimpan nilai ujian ke database server (KV). Jawaban tetap tersimpan aman di perangkat — sistem akan mencoba mengirim ulang otomatis.',
          });
        }

        return res.status(200).json({
          ok: true,
          engine,
          serverTime: Date.now(),
          updatedAt: gradedResult.updatedAt,
          summary: gradedResult.summary,
        });
      }

      // 4. Scoped Reset Login Request Action (for locked student on Login screen)
      if (action === 'request_reset') {
        const reqUsername = String(body.username || '').trim().toUpperCase();
        if (!reqUsername) {
          return res.status(400).json({ ok: false, error: 'Username wajib diisi.' });
        }
        const resetResult = await enqueueSerializedWrite(() =>
          withKvDistributedLock(kv, async () => {
            const existing =
              (kv ? await readFromVercelKV(kv) : null) ||
              readFromFileOrMemory() ||
              {};
            const existingParticipants = Array.isArray(existing.participants)
              ? sanitizeParticipantsList(existing.participants)
              : [];
            const nowTs = Date.now();
            let updated = false;
            const nextParticipants = existingParticipants.map((row) => {
              if (
                String(row.username || '').trim().toUpperCase() !== reqUsername
              ) {
                return row;
              }
              // Only allow flagging requestReset on rows that are genuinely locked by violation
              if (!isServerRowLockedByViolation(row)) return row;
              updated = true;
              return {
                ...row,
                requestReset: true,
                loginUpdatedAt: Math.max(
                  (Number(row.loginUpdatedAt) || 0) + 1,
                  nowTs
                ),
              };
            });
            if (!updated) return { updatedAt: nowTs };
            const merged = {
              ...existing,
              participants: nextParticipants,
              updatedAt: nowTs,
            };
            writeToFileAndMemory(merged);
            let kvWriteOk = true;
            if (kv) {
              kvWriteOk = await writeToVercelKV(kv, merged, {
                syncStudentsHash: true,
              });
            }
            return { updatedAt: nowTs, kvWriteOk };
          })
        );
        if (resetResult.kvWriteOk === false) {
          return res.status(503).json({
            ok: false,
            engine,
            error: 'Gagal mengirim permintaan Reset Login ke server (KV).',
          });
        }
        return res.status(200).json({
          ok: true,
          engine,
          updatedAt: resetResult.updatedAt,
        });
      }

      // Enforce authenticated session for all storage write mutations
      if (!session) {
        return res.status(401).json({
          ok: false,
          engine,
          error: 'Autentikasi diperlukan untuk mengubah data server.',
        });
      }

      // Enforce role-based write boundaries
      if (session.role === 'student') {
        const forbiddenStudentKeys = [
          'packages',
          'packagePatch',
          'packageQuestionAppend',
          'deletedPackageIds',
          'forceReplacePackages',
          'schedules',
          'deletedScheduleIds',
          'forceReplaceSchedules',
          'participants',
          'deletedParticipantIds',
          'forceReplaceParticipants',
          'proctors',
          'activeToken',
          'tokenUpdatedAt',
          'forceTokenUpdate',
          'resultsHistory',
          'resultAppend',
          'resultsClearedAt',
          'adminSettings',
        ];
        for (const k of forbiddenStudentKeys) {
          if (body[k] !== undefined) {
            return res.status(403).json({
              ok: false,
              engine,
              error: 'Peserta tidak memiliki izin mengubah data sistem.',
            });
          }
        }
        // Scope participantPatch strictly to the student's own username and strip privileged fields (cannot self-activate!)
        if (body.participantPatch !== undefined) {
          const rawPatches = (
            Array.isArray(body.participantPatch)
              ? body.participantPatch
              : [body.participantPatch]
          ).filter((p) => p && typeof p === 'object') as Record<string, any>[];

          const sanitizedStudentPatches = rawPatches
            .filter(
              (p) =>
                String(p.username || '').trim().toUpperCase() === session.sub
            )
            .map((p) => {
              const {
                status: _s,
                password: _pw,
                metaUpdatedAt: _m,
                serverStatusUpdatedAt: _ss,
                kelas: _kl,
                ruang: _rg,
                kelompok: _kp,
                kodeTes: _kt,
                namaPeserta: _np,
                lastResetAt: _lr,
                violationResetAt: _vr,
                resetPackageId: _rp,
                resetSubjectTitle: _rs,
                activeSessionNonce: _asn,
                examStartedAt: _es,
                examDeadlineAt: _ed,
                ...allowedFields
              } = p;
              // Students may only transition to 'Selesai' via authoritative submit_exam action
              if (allowedFields.loginState === 'Selesai') {
                delete allowedFields.loginState;
              }
              return allowedFields;
            });

          if (sanitizedStudentPatches.length === 0) {
            return res.status(403).json({
              ok: false,
              engine,
              error: 'Peserta hanya dapat memperbarui status ujian miliknya sendiri.',
            });
          }
          body.participantPatch = sanitizedStudentPatches;
        }
      }

      let proctorSelfIncomingList: Record<string, any>[] | null = null;
      if (session.role === 'proctor') {
        // Proctors cannot modify other proctors, credentials, admin credentials, or exam schedules;
        // capture incoming proctors solely to allow authenticated self-fullName updates below.
        if (Array.isArray(body.proctors)) {
          proctorSelfIncomingList = body.proctors as Record<string, any>[];
        }
        delete body.proctors;
        delete body.schedules;
        delete body.deletedScheduleIds;
        delete body.forceReplaceSchedules;
        delete body.schedulesUpdatedAt;
        if (body.adminSettings && typeof body.adminSettings === 'object') {
          delete (body.adminSettings as Record<string, unknown>).adminList;
        }
      }

      // Fast atomic KV hash path for concurrent student login/draft/violation/submit updates
      if (kv && body.schemaVersion === 3) {
        const fastResult = await tryAtomicKvFastPatch(kv, body, session);
        if (fastResult.sessionReplaced) {
          return res.status(401).json({
            ok: false,
            engine,
            reason: 'session_replaced',
            error:
              'Sesi Anda dihentikan karena akun ini login di perangkat lain.',
          });
        }
        if (fastResult.handled) {
          return res.status(200).json({
            ok: true,
            engine,
            serverTime: Date.now(),
            updatedAt: fastResult.updatedAt,
            data: { updatedAt: fastResult.updatedAt },
          });
        }
      }

      const result = await enqueueSerializedWrite(() =>
        withKvDistributedLock(kv, async () => {
          const existing =
            (kv ? await readFromVercelKV(kv) : null) ||
            readFromFileOrMemory() ||
            {};

        // Ignore writes from stale un-refreshed browser tabs running older bundle versions
        if (body.schemaVersion !== 3) {
          const cleanExisting =
            existing && Array.isArray(existing.participants)
              ? {
                  ...existing,
                  participants: sanitizeParticipantsList(existing.participants),
                }
              : existing;
          return {
            updatedAt: cleanExisting.updatedAt || Date.now(),
            data: cleanExisting,
          };
        }

      const combinedDeletedParticipantIds = Array.from(
        new Set([
          ...(Array.isArray(existing.deletedParticipantIds)
            ? existing.deletedParticipantIds
            : []),
          ...(Array.isArray(body.deletedParticipantIds)
            ? body.deletedParticipantIds
            : []),
        ])
      );

      const combinedDeletedScheduleIds = Array.from(
        new Set([
          ...(Array.isArray(existing.deletedScheduleIds)
            ? existing.deletedScheduleIds
            : []),
          ...(Array.isArray(body.deletedScheduleIds)
            ? body.deletedScheduleIds
            : []),
        ])
      );

      let combinedDeletedPackageIds = Array.from(
        new Set([
          ...(Array.isArray(existing.deletedPackageIds)
            ? existing.deletedPackageIds
            : []),
          ...(Array.isArray(body.deletedPackageIds)
            ? body.deletedPackageIds
            : []),
        ])
      )
        .map((id) => String(id || '').trim().toUpperCase())
        .filter(Boolean);

      // If Admin/Proctor explicitly replaced packages, record any removed package IDs & codes in combinedDeletedPackageIds
      if (Array.isArray(body.packages) && Boolean(body.forceReplacePackages)) {
        const incIds = new Set(
          (body.packages as any[])
            .map((p) => String(p?.id || '').trim().toUpperCase())
            .filter(Boolean)
        );
        const incCodes = new Set(
          (body.packages as any[])
            .map((p) => String(p?.code || '').trim().toUpperCase())
            .filter(Boolean)
        );
        if (Array.isArray(existing.packages)) {
          for (const ep of existing.packages as any[]) {
            if (!ep || typeof ep !== 'object') continue;
            const epId = String(ep.id || '').trim().toUpperCase();
            const epCode = String(ep.code || '').trim().toUpperCase();
            if (epId && !incIds.has(epId) && !combinedDeletedPackageIds.includes(epId)) {
              combinedDeletedPackageIds.push(epId);
            }
            if (
              epCode &&
              !incCodes.has(epCode) &&
              !combinedDeletedPackageIds.includes(epCode)
            ) {
              combinedDeletedPackageIds.push(epCode);
            }
          }
        }
      }

      // If Admin/Proctor explicitly added/patched a package without deleting it, un-delete its ID/code so re-added subjects work cleanly
      const explicitDeleteSet = new Set(
        Array.isArray(body.deletedPackageIds)
          ? (body.deletedPackageIds as any[])
              .map((id) => String(id || '').trim().toUpperCase())
              .filter(Boolean)
          : []
      );
      const incomingPackagesToUnDelete: any[] =
        body.packagePatch !== undefined
          ? Array.isArray(body.packagePatch)
            ? body.packagePatch
            : [body.packagePatch]
          : Array.isArray(body.packages) &&
            (Boolean(body.forceReplacePackages) || explicitDeleteSet.size === 0)
          ? (body.packages as any[])
          : [];
      if (incomingPackagesToUnDelete.length > 0 && combinedDeletedPackageIds.length > 0) {
        const reactivatedSet = new Set<string>();
        for (const p of incomingPackagesToUnDelete) {
          if (!p || typeof p !== 'object') continue;
          const pid = String(p.id || '').trim().toUpperCase();
          const pcode = String(p.code || '').trim().toUpperCase();
          if (pid && !explicitDeleteSet.has(pid)) reactivatedSet.add(pid);
          if (pcode && !explicitDeleteSet.has(pcode)) reactivatedSet.add(pcode);
        }
        if (reactivatedSet.size > 0) {
          combinedDeletedPackageIds = combinedDeletedPackageIds.filter(
            (id) => !reactivatedSet.has(id)
          );
        }
      }

      const serverNow = Date.now();
      const clientNow =
        typeof body.clientNow === 'number' && Number.isFinite(body.clientNow)
          ? body.clientNow
          : 0;

      let nextParticipants: Record<string, any>[] | undefined;

      if (body.participantPatch !== undefined) {
        nextParticipants = applyParticipantPatches(
          existing.participants,
          body.participantPatch,
          clientNow,
          serverNow
        );
      } else if (Array.isArray(body.participants)) {
        nextParticipants = resolveIncomingParticipants(
          body.participants,
          existing.participants,
          combinedDeletedParticipantIds,
          Boolean(body.forceReplaceParticipants),
          clientNow,
          serverNow
        );
      } else if (Array.isArray(existing.participants)) {
        nextParticipants = sanitizeParticipantsList(existing.participants);
      }

      let nextSchedules: Record<string, any>[] | undefined;
      if (Array.isArray(body.schedules)) {
        const isAdminScheduleWrite =
          session.role === 'admin' && Boolean(body.forceReplaceSchedules);
        const existingScheduleById = new Map<string, Record<string, any>>();
        const incomingScheduleIds = new Set<string>();
        for (const inc of body.schedules as any[]) {
          if (inc && typeof inc === 'object' && inc.id) {
            incomingScheduleIds.add(String(inc.id).trim());
          }
        }
        if (Array.isArray(existing.schedules)) {
          for (const s of existing.schedules as any[]) {
            if (s && typeof s === 'object' && s.id) {
              const sid = String(s.id).trim();
              existingScheduleById.set(sid, s);
              if (
                isAdminScheduleWrite &&
                sid &&
                !incomingScheduleIds.has(sid) &&
                !combinedDeletedScheduleIds.includes(sid)
              ) {
                combinedDeletedScheduleIds.push(sid);
              }
            }
          }
        }
        const clockNormalizedSchedules = (body.schedules as any[]).map((s) => {
          if (!s || typeof s !== 'object') return s;
          const prevSch = s.id ? existingScheduleById.get(String(s.id)) : undefined;
          const normUpd = normalizeClientTimestamp(
            s.updatedAt,
            clientNow,
            serverNow,
            prevSch?.updatedAt
          );
          if (isAdminScheduleWrite) {
            if (!prevSch) {
              return {
                ...s,
                updatedAt: Math.max(normUpd || 0, serverNow),
              };
            }
            const prevUpd =
              typeof prevSch.updatedAt === 'number' &&
              Number.isFinite(prevSch.updatedAt)
                ? prevSch.updatedAt
                : 0;
            return {
              ...s,
              updatedAt: Math.max(prevUpd + 1, normUpd || 0, serverNow),
            };
          }
          return normUpd !== undefined ? { ...s, updatedAt: normUpd } : s;
        });
        nextSchedules = resolveIncomingSchedules(
          clockNormalizedSchedules,
          existing.schedules,
          combinedDeletedScheduleIds,
          isAdminScheduleWrite
        );
      } else if (Array.isArray(existing.schedules)) {
        nextSchedules = existing.schedules as Record<string, any>[];
      }

      let nextPackages: Record<string, any>[] | undefined;
      if (body.packageQuestionAppend !== undefined) {
        nextPackages = applyPackageQuestionAppend(
          existing.packages,
          body.packageQuestionAppend
        );
      } else if (body.packagePatch !== undefined) {
        nextPackages = applyPackagePatches(
          existing.packages,
          body.packagePatch,
          combinedDeletedPackageIds,
          Boolean(body.forceReplacePackages)
        );
      } else if (Array.isArray(body.packages)) {
        nextPackages = resolveIncomingPackages(
          body.packages,
          existing.packages,
          combinedDeletedPackageIds,
          Boolean(body.forceReplacePackages)
        );
      } else if (Array.isArray(existing.packages)) {
        nextPackages = existing.packages as Record<string, any>[];
      }

      const existResultsClearedAt =
        typeof existing.resultsClearedAt === 'number'
          ? existing.resultsClearedAt
          : 0;
      const incResultsClearedAt =
        normalizeClientTimestamp(
          body.resultsClearedAt,
          clientNow,
          serverNow,
          existResultsClearedAt
        ) || 0;
      const resolvedResultsClearedAt = Math.max(
        existResultsClearedAt,
        incResultsClearedAt
      );

      let nextResultsHistory: Record<string, any>[] | undefined;
      if (incResultsClearedAt > 0 && incResultsClearedAt >= existResultsClearedAt) {
        nextResultsHistory = [];
      } else {
        const baseExistingHistory = Array.isArray(existing.resultsHistory)
          ? (existing.resultsHistory as Record<string, any>[])
          : [];
        const incomingHistory = Array.isArray(body.resultsHistory)
          ? (body.resultsHistory as Record<string, any>[])
          : [];
        const appendedItem =
          body.resultAppend && typeof body.resultAppend === 'object'
            ? (body.resultAppend as Record<string, any>)
            : null;

        if (appendedItem || incomingHistory.length > 0 || baseExistingHistory.length > 0) {
          const candidates = [
            ...(appendedItem ? [appendedItem] : []),
            ...incomingHistory,
            ...baseExistingHistory,
          ];
          nextResultsHistory = dedupeServerResultsHistory(candidates);
        }
      }

      // Resolve activeToken by tokenUpdatedAt so stale instances never revert token rotation,
      // allow manual forceTokenUpdate regardless of client clock skew,
      // and keep a 90s grace window for automatic rotations so students aren't rejected mid-typing
      const existTokenClean = String(existing.activeToken || '')
        .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
        .toUpperCase();
      const existTokenTs =
        typeof existing.tokenUpdatedAt === 'number'
          ? existing.tokenUpdatedAt
          : 0;
      const incTokenTs =
        normalizeClientTimestamp(
          body.tokenUpdatedAt,
          clientNow,
          serverNow,
          existTokenTs
        ) || 0;
      let resolvedActiveToken = existTokenClean;
      let resolvedTokenUpdatedAt = existTokenTs;
      let resolvedPrevToken = String(existing.previousActiveToken || '')
        .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
        .toUpperCase();
      let resolvedPrevValidUntil =
        typeof existing.previousTokenValidUntil === 'number'
          ? existing.previousTokenValidUntil
          : 0;

      if (typeof body.activeToken === 'string' && body.activeToken.trim()) {
        const cleanIncToken = body.activeToken
          .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
          .toUpperCase();
        if (cleanIncToken) {
          const isForceManual = Boolean(body.forceTokenUpdate);
          const isDuplicateAutoRotate =
            !isForceManual &&
            Boolean(existTokenClean) &&
            existTokenTs > 0 &&
            incTokenTs > 0 &&
            Math.abs(incTokenTs - existTokenTs) < 30_000 &&
            cleanIncToken !== existTokenClean;

          if (isForceManual) {
            if (cleanIncToken !== existTokenClean) {
              resolvedPrevToken = '';
              resolvedPrevValidUntil = 0;
            }
            resolvedActiveToken = cleanIncToken;
            resolvedTokenUpdatedAt = Math.max(
              existTokenTs + 1,
              incTokenTs,
              Date.now()
            );
          } else if (
            !isDuplicateAutoRotate &&
            (!existTokenClean || incTokenTs >= existTokenTs)
          ) {
            if (existTokenClean && cleanIncToken !== existTokenClean) {
              resolvedPrevToken = existTokenClean;
              resolvedPrevValidUntil = Date.now() + 90_000;
            }
            resolvedActiveToken = cleanIncToken;
            resolvedTokenUpdatedAt = Math.max(
              incTokenTs,
              existTokenTs,
              Date.now()
            );
          }
        }
      }

      // Guarantee an activeToken exists on the server whenever at least one schedule is active
      if (
        !resolvedActiveToken &&
        Array.isArray(nextSchedules) &&
        nextSchedules.some((s) => s && s.isActive)
      ) {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        let autoToken = '';
        for (let i = 0; i < 6; i++) {
          autoToken += chars.charAt(crypto.randomInt(chars.length));
        }
        resolvedActiveToken = autoToken;
        resolvedTokenUpdatedAt = Date.now();
      }

      // Resolve adminSettings (deleted/custom mapel config) by updatedAt timestamp and sanitize against deletedPackageIds
      const existAdminSettings =
        existing.adminSettings && typeof existing.adminSettings === 'object'
          ? (existing.adminSettings as Record<string, any>)
          : undefined;
      const incAdminSettings =
        body.adminSettings && typeof body.adminSettings === 'object'
          ? (body.adminSettings as Record<string, any>)
          : undefined;
      let resolvedAdminSettings = existAdminSettings;
      if (incAdminSettings) {
        const existCfgTs =
          typeof existAdminSettings?.updatedAt === 'number'
            ? existAdminSettings.updatedAt
            : 0;
        const incCfgTs =
          normalizeClientTimestamp(
            incAdminSettings.updatedAt,
            clientNow,
            serverNow,
            existCfgTs
          ) || 0;
        if (!existAdminSettings || incCfgTs >= existCfgTs) {
          const shouldPreserveAdminList =
            Array.isArray(existAdminSettings?.adminList) &&
            (session.role !== 'admin' || !Array.isArray(incAdminSettings.adminList));
          const mergedDeletedCodes = Array.from(
            new Set([
              ...(Array.isArray(existAdminSettings?.deletedMapelCodes)
                ? existAdminSettings!.deletedMapelCodes
                : []),
              ...(Array.isArray(incAdminSettings.deletedMapelCodes)
                ? incAdminSettings.deletedMapelCodes
                : []),
            ])
          );
          const mergedDeletedNames = Array.from(
            new Set([
              ...(Array.isArray(existAdminSettings?.deletedMapelNames)
                ? existAdminSettings!.deletedMapelNames
                : []),
              ...(Array.isArray(incAdminSettings.deletedMapelNames)
                ? incAdminSettings.deletedMapelNames
                : []),
            ])
          );
          resolvedAdminSettings = {
            ...(existAdminSettings || {}),
            ...incAdminSettings,
            ...(mergedDeletedCodes.length > 0
              ? { deletedMapelCodes: mergedDeletedCodes }
              : {}),
            ...(mergedDeletedNames.length > 0
              ? { deletedMapelNames: mergedDeletedNames }
              : {}),
            ...(shouldPreserveAdminList
              ? { adminList: existAdminSettings!.adminList }
              : {}),
            updatedAt: Math.max(incCfgTs, serverNow),
          };
        }
      }
      if (resolvedAdminSettings) {
        resolvedAdminSettings = sanitizeServerAdminSettings(
          resolvedAdminSettings,
          combinedDeletedPackageIds
        );
      }
      let packagesCleanedBySanitizer = false;
      if (Array.isArray(nextPackages)) {
        const beforePkgCount = nextPackages.length;
        const sanitizedPkgs = sanitizeServerPackages(
          nextPackages,
          combinedDeletedPackageIds,
          resolvedAdminSettings
        );
        const keptPkgIds = new Set(
          sanitizedPkgs
            .map((p) => String(p?.id || '').trim().toUpperCase())
            .filter(Boolean)
        );
        for (const oldPkg of nextPackages) {
          const pid = String(oldPkg?.id || '').trim().toUpperCase();
          const pcode = String(oldPkg?.code || '').trim().toUpperCase();
          if (pid && !keptPkgIds.has(pid)) {
            if (!combinedDeletedPackageIds.includes(pid)) {
              combinedDeletedPackageIds.push(pid);
            }
            if (pcode && !combinedDeletedPackageIds.includes(pcode)) {
              combinedDeletedPackageIds.push(pcode);
            }
          }
        }
        if (sanitizedPkgs.length !== beforePkgCount) {
          packagesCleanedBySanitizer = true;
        }
        nextPackages = sanitizedPkgs;
      }

      // Allow authenticated proctor to persist ONLY their own fullName update
      let nextProctors: Record<string, any>[] | undefined;
      if (
        session.role === 'proctor' &&
        proctorSelfIncomingList &&
        Array.isArray(existing.proctors)
      ) {
        const authSub = String(session.sub || '').trim().toUpperCase();
        const existingProctors = existing.proctors as Record<string, any>[];
        const targetIdx = existingProctors.findIndex(
          (p) =>
            p &&
            typeof p === 'object' &&
            (String(p.proctorId || '').trim().toUpperCase() === authSub ||
              String(p.fullName || '').trim().toUpperCase() === authSub)
        );
        if (targetIdx >= 0) {
          const serverProctor = existingProctors[targetIdx];
          const serverPid = String(serverProctor.proctorId || '')
            .trim()
            .toUpperCase();
          const serverId = String(serverProctor.id || '').trim();
          const incomingMatch = proctorSelfIncomingList.find(
            (p) =>
              p &&
              typeof p === 'object' &&
              ((serverPid &&
                String(p.proctorId || '').trim().toUpperCase() === serverPid) ||
                (serverId && String(p.id || '').trim() === serverId))
          );
          const nextName =
            incomingMatch && typeof incomingMatch.fullName === 'string'
              ? incomingMatch.fullName.trim().toUpperCase().slice(0, 120)
              : '';
          if (
            nextName &&
            nextName !== String(serverProctor.fullName || '').trim().toUpperCase()
          ) {
            nextProctors = existingProctors.map((p, idx) =>
              idx === targetIdx ? { ...p, fullName: nextName } : p
            );
          }
        }
      }

      // Strip transient transport keys and raw client-clock schedule timestamps before persisting
      const {
        participantPatch: _ignorePatch,
        packagePatch: _ignorePkgPatch,
        clientNow: _ignoreClientNow,
        schedulesUpdatedAt: _ignoreClientSchedUpdatedAt,
        forceReplaceParticipants: _ignoreForce,
        forceReplaceSchedules: _ignoreForceSchedules,
        forceReplacePackages: _ignoreForcePackages,
        resultAppend: _ignoreResultAppend,
        forceTokenUpdate: _ignoreForceToken,
        ...cleanBody
      } = body as Record<string, unknown>;

      let schedulesCleanedByCascade = false;
      if (Array.isArray(nextSchedules)) {
        const beforeCount = nextSchedules.length;
        const beforeActiveCount = nextSchedules.filter(
          (s) => Boolean(s && s.isActive)
        ).length;
        const sanitizedNext = sanitizeServerSchedules(
          nextSchedules,
          combinedDeletedScheduleIds,
          nextPackages,
          combinedDeletedPackageIds,
          resolvedAdminSettings
        );
        const keptIds = new Set(
          sanitizedNext.map((s) => String(s?.id || '').trim()).filter(Boolean)
        );
        for (const oldSch of nextSchedules) {
          const sid = String(oldSch?.id || '').trim();
          if (
            sid &&
            !keptIds.has(sid) &&
            !combinedDeletedScheduleIds.includes(sid)
          ) {
            combinedDeletedScheduleIds.push(sid);
          }
        }
        const afterActiveCount = sanitizedNext.filter(
          (s) => Boolean(s && s.isActive)
        ).length;
        if (
          sanitizedNext.length !== beforeCount ||
          afterActiveCount !== beforeActiveCount
        ) {
          schedulesCleanedByCascade = true;
        }
        nextSchedules = sanitizedNext;
      }

      const hasParticipantsMutation =
        body.participants !== undefined ||
        body.participantPatch !== undefined ||
        (Array.isArray(body.deletedParticipantIds) &&
          body.deletedParticipantIds.length > 0);
      const hasSchedulesMutation =
        Array.isArray(body.schedules) ||
        schedulesCleanedByCascade ||
        (Array.isArray(body.deletedScheduleIds) &&
          body.deletedScheduleIds.length > 0);
      const hasTokenMutation =
        (typeof body.activeToken === 'string' &&
          body.activeToken.trim().length > 0) ||
        Boolean(resolvedActiveToken && hasSchedulesMutation);
      const hasPackagesMutation =
        body.packages !== undefined ||
        body.packagePatch !== undefined ||
        packagesCleanedBySanitizer ||
        (Array.isArray(body.deletedPackageIds) &&
          body.deletedPackageIds.length > 0);
      const changedPackageIds =
        body.packagePatch !== undefined && body.packages === undefined
          ? (Array.isArray(body.packagePatch)
              ? body.packagePatch
              : [body.packagePatch]
            )
              .map((p: any) => String(p?.id || '').trim())
              .filter(Boolean)
          : undefined;
      const isResultsCleared =
        incResultsClearedAt > 0 &&
        incResultsClearedAt >= existResultsClearedAt;
      const hasResultsMutation =
        body.resultsHistory !== undefined ||
        body.resultAppend !== undefined ||
        isResultsCleared;
      const hasBaseDocOnlyMutation =
        body.adminSettings !== undefined ||
        body.proctors !== undefined ||
        nextProctors !== undefined;

      const existSchedulesUpdatedAt =
        typeof existing.schedulesUpdatedAt === 'number'
          ? existing.schedulesUpdatedAt
          : 0;
      const resolvedSchedulesUpdatedAt = hasSchedulesMutation
        ? Math.max(existSchedulesUpdatedAt + 1, serverNow)
        : existSchedulesUpdatedAt;

      const merged: Record<string, unknown> = {
        ...existing,
        ...cleanBody,
        ...(resolvedActiveToken
          ? {
              activeToken: resolvedActiveToken,
              tokenUpdatedAt: resolvedTokenUpdatedAt,
              ...(resolvedPrevToken && resolvedPrevValidUntil > Date.now()
                ? {
                    previousActiveToken: resolvedPrevToken,
                    previousTokenValidUntil: resolvedPrevValidUntil,
                  }
                : {
                    previousActiveToken: '',
                    previousTokenValidUntil: 0,
                  }),
            }
          : {}),
        ...(resolvedAdminSettings
          ? { adminSettings: resolvedAdminSettings }
          : {}),
        ...(nextProctors !== undefined ? { proctors: nextProctors } : {}),
        ...(nextPackages !== undefined ? { packages: nextPackages } : {}),
        ...(nextSchedules !== undefined ? { schedules: nextSchedules } : {}),
        ...(resolvedSchedulesUpdatedAt > 0
          ? { schedulesUpdatedAt: resolvedSchedulesUpdatedAt }
          : {}),
        ...(nextParticipants !== undefined
          ? { participants: nextParticipants }
          : {}),
        ...(nextResultsHistory !== undefined
          ? { resultsHistory: nextResultsHistory }
          : {}),
        ...(resolvedResultsClearedAt > 0
          ? { resultsClearedAt: resolvedResultsClearedAt }
          : {}),
        deletedParticipantIds: combinedDeletedParticipantIds,
        deletedScheduleIds: combinedDeletedScheduleIds,
        deletedPackageIds: combinedDeletedPackageIds,
        updatedAt: Date.now(),
      };

        writeToFileAndMemory(merged);
        let kvWriteOk = true;
        if (kv) {
          kvWriteOk = await writeToVercelKV(kv, merged, {
            syncStudentsHash: hasParticipantsMutation,
            syncResultsHash: hasResultsMutation,
            clearResultsHash: isResultsCleared,
            syncSchedulesKey: hasSchedulesMutation,
            syncTokenKey: hasTokenMutation,
            syncPackagesHash: hasPackagesMutation,
            changedPackageIds,
            requireBaseDoc: hasBaseDocOnlyMutation,
          });
        }

        if (
          kvWriteOk &&
          (hasSchedulesMutation ||
            hasPackagesMutation ||
            hasTokenMutation ||
            hasBaseDocOnlyMutation ||
            hasParticipantsMutation)
        ) {
          broadcastServerRealtimeEvent({
            type: 'storage_updated',
            serverTime: Date.now(),
            updatedAt: merged.updatedAt,
            schedulesUpdatedAt: resolvedSchedulesUpdatedAt,
            schedules: nextSchedules,
            deletedScheduleIds: combinedDeletedScheduleIds,
            deletedPackageIds: combinedDeletedPackageIds,
          });
        }

        return {
          kvWriteOk,
          updatedAt: merged.updatedAt,
          data: merged,
        };
        })
      );

      if (result && (result as { kvWriteOk?: boolean }).kvWriteOk === false) {
        return res.status(503).json({
          ok: false,
          engine,
          serverTime: Date.now(),
          error:
            'Gagal menyimpan perubahan ke database server (KV). Silakan ulangi klik Assign / Simpan.',
        });
      }

      return res.status(200).json({
        ok: true,
        engine,
        serverTime: Date.now(),
        updatedAt: result.updatedAt,
        data: redactStorageForRole(
          (result.data as Record<string, unknown>) || null,
          session
        ),
      });
    } catch (err) {
      if (err instanceof KvLockBusyError) {
        return res.status(503).json({
          ok: false,
          engine,
          serverTime: Date.now(),
          lockBusy: true,
          error: err.message,
        });
      }
      return res.status(400).json({
        ok: false,
        engine,
        error: err instanceof Error ? err.message : 'Invalid payload',
      });
    }
  }

  return res.status(405).json({ ok: false, error: 'Method not allowed' });
}
