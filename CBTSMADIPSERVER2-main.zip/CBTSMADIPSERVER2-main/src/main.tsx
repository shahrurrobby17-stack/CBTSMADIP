import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import 'katex/dist/katex.min.css';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

// Recover automatically (once per session) if a stale PWA/CDN chunk fails to load after a new deploy
window.addEventListener('vite:preloadError', (event) => {
  event.preventDefault();
  try {
    const reloadKey = 'cbt_chunk_reload_once';
    if (!sessionStorage.getItem(reloadKey)) {
      sessionStorage.setItem(reloadKey, String(Date.now()));
      window.location.reload();
    }
  } catch {
    window.location.reload();
  }
});

try {
  let refreshing = false;
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    });
  }
  registerSW({
    immediate: true,
    onRegisteredSW(_swUrl, registration) {
      if (!registration) return;
      registration.update().catch(() => {});
      window.addEventListener('focus', () => {
        registration.update().catch(() => {});
      });
    },
    onRegisterError() {
      // Ignore SW registration failure so app boot is never blocked
    },
  });
} catch {
  // Ignore SW registration errors in restricted browsers/iframes
}

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
  (window as Window & { __CBT_APP_MOUNTED__?: boolean }).__CBT_APP_MOUNTED__ = true;
  try {
    sessionStorage.removeItem('cbt_boot_recover_once');
    sessionStorage.removeItem('cbt_chunk_reload_once');
  } catch {
    // ignore
  }
}
