import React, { useMemo } from 'react';
import katex from 'katex';

interface MathTextProps {
  text?: string | null;
  className?: string;
  inline?: boolean;
}

interface MathSegment {
  kind: 'text' | 'inline-math' | 'display-math';
  value: string;
}

const RAW_LATEX_COMMAND_REGEX =
  /\\(?:frac|dfrac|tfrac|cfrac|sqrt|lim|sum|prod|int|iint|oint|begin\{(?:pmatrix|bmatrix|vmatrix|Bmatrix|matrix|cases|aligned|array)\}|vec|overline|underline|widehat|hat|bar|tilde|dot|ddot|binom|log|ln|sin|cos|tan|cot|sec|csc|alpha|beta|gamma|delta|theta|lambda|mu|pi|sigma|omega|Delta|Sigma|Omega|infty|pm|mp|times|div|cdot|le|leq|ge|geq|ne|neq|approx|equiv|to|rightarrow|Rightarrow|Leftrightarrow|in|notin|subset|subseteq|cup|cap|emptyset|angle|perp|parallel|forall|exists|therefore|because)\b/;

/**
 * Normalizes a LaTeX math expression slightly so common Word/Indonesian conventions
 * (like Unicode math symbols or `^2\log 8`) always render cleanly with KaTeX.
 */
function normalizeLatexForKatex(raw: string): string {
  let s = raw.trim();
  if (!s) return '';

  // Convert bare leading `^2\log` or `^{2}\log` into `{}^{2}\!\log` so KaTeX renders Indonesian pre-superscript logarithms cleanly
  s = s.replace(/(^|[\s=+\-(,;])\^(\{[^{}]+\}|[0-9a-zA-Z])\s*\\?(log)\b/g, '$1{}^{$2}\\!\\log');
  s = s.replace(/(^|[\s=+\-(,;])\^(\{[^{}]+\}|[0-9a-zA-Z])\s*(C|P)_(\{[^{}]+\}|[0-9a-zA-Z])/g, '$1{}^{$2}\\mathrm{$3}_{$4}');

  // Clean up accidental double braces inside the replacement above: {^{2}} -> ^{2}
  s = s.replace(/\{\}\^\{\{([^{}]+)\}\}/g, '{}^{$1}');

  // Map common Unicode operators that might sit inside $...$ into KaTeX commands
  s = s
    .replace(/×/g, '\\times ')
    .replace(/÷/g, '\\div ')
    .replace(/±/g, '\\pm ')
    .replace(/∓/g, '\\mp ')
    .replace(/≤/g, '\\le ')
    .replace(/≥/g, '\\ge ')
    .replace(/≠/g, '\\ne ')
    .replace(/≈/g, '\\approx ')
    .replace(/≡/g, '\\equiv ')
    .replace(/∞/g, '\\infty ')
    .replace(/→/g, '\\to ')
    .replace(/⇒/g, '\\Rightarrow ')
    .replace(/⇔/g, '\\Leftrightarrow ')
    .replace(/∈/g, '\\in ')
    .replace(/∉/g, '\\notin ')
    .replace(/⊂/g, '\\subset ')
    .replace(/⊆/g, '\\subseteq ')
    .replace(/∪/g, '\\cup ')
    .replace(/∩/g, '\\cap ')
    .replace(/∅/g, '\\emptyset ')
    .replace(/∠/g, '\\angle ')
    .replace(/⊥/g, '\\perp ')
    .replace(/∥/g, '\\parallel ')
    .replace(/∀/g, '\\forall ')
    .replace(/∃/g, '\\exists ')
    .replace(/∴/g, '\\therefore ')
    .replace(/∵/g, '\\because ')
    .replace(/·|⋅/g, '\\cdot ')
    .replace(/−/g, '-')
    .replace(/°/g, '^\\circ ')
    .replace(/α/g, '\\alpha ')
    .replace(/β/g, '\\beta ')
    .replace(/γ/g, '\\gamma ')
    .replace(/δ/g, '\\delta ')
    .replace(/ε/g, '\\varepsilon ')
    .replace(/θ/g, '\\theta ')
    .replace(/λ/g, '\\lambda ')
    .replace(/μ/g, '\\mu ')
    .replace(/π/g, '\\pi ')
    .replace(/ρ/g, '\\rho ')
    .replace(/σ/g, '\\sigma ')
    .replace(/φ/g, '\\varphi ')
    .replace(/ω/g, '\\omega ')
    .replace(/Δ/g, '\\Delta ')
    .replace(/Σ/g, '\\Sigma ')
    .replace(/Ω/g, '\\Omega ')
    .replace(/Π/g, '\\Pi ')
    .replace(/Θ/g, '\\Theta ');

  return s;
}

/**
 * Splits a plain-text chunk (outside explicit $...$ / \(...\) delimiters)
 * to catch raw LaTeX expressions (\frac{...}{...}, \begin{pmatrix}...\end{pmatrix}, etc.)
 * or braced exponent/subscript expressions (2^{x+1}, a_{n-1}) pasted without $ delimiters.
 */
function splitImplicitMathFromText(chunk: string): MathSegment[] {
  if (!chunk) return [];

  // 1. Catch \begin{env}...\end{env} blocks pasted without $ delimiters
  const envRegex =
    /(\\begin\{(?:pmatrix|bmatrix|vmatrix|Bmatrix|matrix|cases|aligned|array)\}[\s\S]*?\\end\{(?:pmatrix|bmatrix|vmatrix|Bmatrix|matrix|cases|aligned|array)\})/g;
  if (envRegex.test(chunk)) {
    const out: MathSegment[] = [];
    let last = 0;
    envRegex.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = envRegex.exec(chunk)) !== null) {
      if (m.index > last) {
        out.push(...splitImplicitMathFromText(chunk.slice(last, m.index)));
      }
      out.push({ kind: 'inline-math', value: m[1] });
      last = m.index + m[0].length;
    }
    if (last < chunk.length) {
      out.push(...splitImplicitMathFromText(chunk.slice(last)));
    }
    return out;
  }

  // 2. Catch inline raw LaTeX commands (\frac{a}{b}, \sqrt[3]{8}, \lim_{x \to 0}, etc.) or braced superscripts/subscripts (2^{x+1}, a_{n-1}, ^{2}\log 8)
  const hasRawLatex = RAW_LATEX_COMMAND_REGEX.test(chunk);
  const hasBracedScript = /(?:[A-Za-z0-9)\]}])\s*[\^_]\{[^{}]+\}|(?:^|\s)\^\{[^{}]+\}\s*\\?log\b/.test(chunk);
  if (!hasRawLatex && !hasBracedScript) {
    return [{ kind: 'text', value: chunk }];
  }

  // Match contiguous raw LaTeX / braced-script expressions without swallowing normal Indonesian prose words
  const implicitRegex =
    /(\\(?:dfrac|tfrac|cfrac|frac)\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}|\\sqrt(?:\[[^\]]+\])?\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}|\\(?:lim|sum|prod|int|iint|oint)(?:_\{[^{}]+\}|_[A-Za-z0-9])?(?:\^\{[^{}]+\}|\^[A-Za-z0-9])?|\\(?:vec|overline|underline|widehat|hat|bar|tilde|dot|ddot)\{[^{}]+\}|\\binom\{[^{}]+\}\{[^{}]+\}|(?:\^\{[^{}]+\}\s*\\?log(?:_\{[^{}]+\})?)|(?:[A-Za-z0-9)\]}]+(?:[\^_]\{[^{}]+\})+)|\\(?:alpha|beta|gamma|delta|theta|lambda|mu|pi|sigma|omega|Delta|Sigma|Omega|infty|pm|mp|times|div|cdot|leq?|geq?|neq?|approx|equiv|to|rightarrow|Rightarrow|Leftrightarrow|in|notin|subset|subseteq|cup|cap|emptyset|angle|perp|parallel|forall|exists|therefore|because)\b)/g;

  const out: MathSegment[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = implicitRegex.exec(chunk)) !== null) {
    if (m.index > last) {
      out.push({ kind: 'text', value: chunk.slice(last, m.index) });
    }
    out.push({ kind: 'inline-math', value: m[1] });
    last = m.index + m[0].length;
  }
  if (last < chunk.length) {
    out.push({ kind: 'text', value: chunk.slice(last) });
  }
  return out;
}

/**
 * Tokenizes a string into plain text, inline math ($...$ or \(...\)), and display math ($$...$$ or \[...\]).
 */
function parseMathSegments(input: string): MathSegment[] {
  if (!input) return [];

  const segments: MathSegment[] = [];
  let idx = 0;
  let textStart = 0;

  const flushText = (endIdx: number) => {
    if (endIdx > textStart) {
      const slice = input.slice(textStart, endIdx);
      segments.push(...splitImplicitMathFromText(slice));
    }
  };

  while (idx < input.length) {
    // Escaped dollar sign \$ -> keep as literal text
    if (input[idx] === '\\' && input[idx + 1] === '$') {
      idx += 2;
      continue;
    }

    // Display math: $$...$$
    if (input[idx] === '$' && input[idx + 1] === '$') {
      const closeIdx = input.indexOf('$$', idx + 2);
      if (closeIdx !== -1 && closeIdx > idx + 2) {
        flushText(idx);
        segments.push({
          kind: 'display-math',
          value: input.slice(idx + 2, closeIdx),
        });
        idx = closeIdx + 2;
        textStart = idx;
        continue;
      }
    }

    // Display math: \[...\]
    if (input[idx] === '\\' && input[idx + 1] === '[') {
      const closeIdx = input.indexOf('\\]', idx + 2);
      if (closeIdx !== -1 && closeIdx > idx + 2) {
        flushText(idx);
        segments.push({
          kind: 'display-math',
          value: input.slice(idx + 2, closeIdx),
        });
        idx = closeIdx + 2;
        textStart = idx;
        continue;
      }
    }

    // Inline math: \(...\)
    if (input[idx] === '\\' && input[idx + 1] === '(') {
      const closeIdx = input.indexOf('\\)', idx + 2);
      if (closeIdx !== -1 && closeIdx > idx + 2) {
        flushText(idx);
        segments.push({
          kind: 'inline-math',
          value: input.slice(idx + 2, closeIdx),
        });
        idx = closeIdx + 2;
        textStart = idx;
        continue;
      }
    }

    // Inline math: $...$
    if (input[idx] === '$' && input[idx + 1] !== '$') {
      // Find matching unescaped single $ on the same paragraph (allow single newline only inside \begin{...})
      let searchIdx = idx + 1;
      let closeIdx = -1;
      while (searchIdx < input.length) {
        if (input[searchIdx] === '\\' && searchIdx + 1 < input.length) {
          searchIdx += 2;
          continue;
        }
        if (input[searchIdx] === '$' && input[searchIdx + 1] !== '$') {
          closeIdx = searchIdx;
          break;
        }
        searchIdx += 1;
      }

      if (closeIdx !== -1 && closeIdx > idx + 1) {
        const inner = input.slice(idx + 1, closeIdx);
        const isBlankEdge = /^\s|\s$/.test(inner);
        const looksLikeCurrencyPair =
          /^\d[\d.,]*\s+(?:dan|atau|sampai|hingga|s\/d|hingga|to|and|or|-)\s*$/i.test(
            inner
          );
        const hasDoubleNewline = /\n\s*\n/.test(inner);

        if (!isBlankEdge && !looksLikeCurrencyPair && !hasDoubleNewline) {
          flushText(idx);
          segments.push({
            kind: 'inline-math',
            value: inner,
          });
          idx = closeIdx + 1;
          textStart = idx;
          continue;
        }
      }
    }

    idx += 1;
  }

  flushText(input.length);
  return segments;
}

function renderKatexHtml(expr: string, displayMode: boolean): string {
  const normalized = normalizeLatexForKatex(expr);
  if (!normalized) return '';
  try {
    return katex.renderToString(normalized, {
      displayMode,
      throwOnError: false,
      strict: false,
      trust: false,
      output: 'htmlAndMathml',
    });
  } catch {
    return '';
  }
}

export const MathText: React.FC<MathTextProps> = ({
  text,
  className = '',
  inline = false,
}) => {
  const renderedParts = useMemo(() => {
    if (!text) return null;
    const segments = parseMathSegments(text);
    const hasMath = segments.some((seg) => seg.kind !== 'text');
    if (!hasMath) return null;

    return segments.map((seg, i) => {
      if (seg.kind === 'text') {
        return <React.Fragment key={i}>{seg.value}</React.Fragment>;
      }
      const displayMode = seg.kind === 'display-math' && !inline;
      const html = renderKatexHtml(seg.value, displayMode);
      if (!html) {
        return <React.Fragment key={i}>{seg.value}</React.Fragment>;
      }
      if (displayMode) {
        return (
          <span
            key={i}
            className="block my-2 overflow-x-auto max-w-full py-0.5"
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
      }
      return (
        <span
          key={i}
          className="inline-block align-baseline max-w-full overflow-x-auto align-middle"
          style={{ verticalAlign: 'baseline' }}
          dangerouslySetInnerHTML={{ __html: html }}
        />
      );
    });
  }, [text, inline]);

  if (!text) return null;

  const Wrapper = inline ? 'span' : 'div';
  return (
    <Wrapper className={className}>
      {renderedParts ?? text}
    </Wrapper>
  );
};
