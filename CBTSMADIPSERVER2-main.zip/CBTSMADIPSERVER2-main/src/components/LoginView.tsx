import React, { useRef, useState } from 'react';
import {
  AlertTriangle,
  Download,
  Eye,
  EyeOff,
  Power,
  X,
} from 'lucide-react';
import {
  ProctorParticipantRow,
  isParticipantLockedByViolation,
  shortenStudentUsername,
} from './ProctorDashboardView';
import { AdminScheduleItem, ExamResultSummary } from '../types/cbt';
import { authenticateWithServer } from '../utils/vercelStorage';
import { usePWAInstall } from '../hooks/usePWAInstall';

export interface ViolationAlertInfo {
  username: string;
  fullName: string;
  reason: string;
  timestamp: string;
  violationCount?: number;
  answersWiped?: boolean;
}

export interface PendingSubmissionNotice {
  localResultId: string;
  username: string;
  fullName: string;
  packageTitle: string;
}

interface LoginViewProps {
  onLoginSuccess: (
    username: string,
    serverAccount?: {
      username?: string;
      namaPeserta?: string;
      kelas?: string;
      ruang?: string;
      status?: string;
    },
    serverSchedules?: AdminScheduleItem[]
  ) => void;
  onOpenProctorModal?: () => void;
  participants?: ProctorParticipantRow[];
  activeSchedules?: AdminScheduleItem[];
  resultsHistory?: ExamResultSummary[];
  lastViolationInfo?: ViolationAlertInfo | null;
  violationMessage?: string;
  pendingSubmissions?: PendingSubmissionNotice[];
  onRequestResetLogin?: (username: string) => void;
  onReconcileCompletedSubjects?: (
    username: string,
    completedSubjects?: string[]
  ) => number;
  onRefreshParticipants?: () => Promise<ProctorParticipantRow[]>;
  onExitApp?: () => void;
  sessionNotice?: string | null;
  onClearSessionNotice?: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({
  onLoginSuccess,
  participants = [],
  lastViolationInfo,
  violationMessage,
  pendingSubmissions = [],
  onReconcileCompletedSubjects,
  onRefreshParticipants,
  onOpenProctorModal,
  onExitApp,
  sessionNotice,
  onClearSessionNotice,
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isCheckingLogin, setIsCheckingLogin] = useState(false);

  React.useEffect(() => {
    if (sessionNotice) {
      setErrorMsg(sessionNotice);
    }
  }, [sessionNotice]);
  const [showMobileInstallModal, setShowMobileInstallModal] = useState(false);
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const isAndroidWebView =
    typeof navigator !== 'undefined' &&
    /; wv\)/i.test(navigator.userAgent || '');

  const usernameInputRef = useRef<HTMLInputElement>(null);
  const passwordInputRef = useRef<HTMLInputElement>(null);
  const lastFullscreenAttemptRef = useRef<number>(0);

  const handleMobileInstallClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) return;
    }
    setShowMobileInstallModal(true);
  };

  const requestMobileFullscreenAndHideStatusBar = (
    refocusInput?: HTMLInputElement | null
  ) => {
    try {
      const isCoarseTouchOnly =
        Boolean(window.matchMedia?.('(pointer: coarse)').matches) &&
        Boolean(window.matchMedia?.('(hover: none)').matches) &&
        window.innerWidth < 1024;
      const isMobileViewport =
        window.innerWidth < 768 ||
        isCoarseTouchOnly ||
        /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '');

      try {
        if ('wakeLock' in navigator && navigator.wakeLock) {
          navigator.wakeLock.request('screen').catch(() => {});
        }
      } catch {
        // Ignore
      }

      const isAlreadyTrueMobileFullscreenOrWebView =
        (isMobileViewport &&
          Boolean(window.matchMedia?.('(display-mode: fullscreen)').matches)) ||
        /; wv\)/i.test(navigator.userAgent || '');
      if (isAlreadyTrueMobileFullscreenOrWebView) return;

      const doc = document as Document & {
        webkitFullscreenElement?: Element | null;
        msFullscreenElement?: Element | null;
      };
      const docEl = document.documentElement as HTMLElement & {
        webkitRequestFullscreen?: (options?: FullscreenOptions) => Promise<void>;
        msRequestFullscreen?: () => Promise<void>;
      };
      if (
        !doc.fullscreenElement &&
        !doc.webkitFullscreenElement &&
        !doc.msFullscreenElement
      ) {
        const now = Date.now();
        if (now - lastFullscreenAttemptRef.current < 450) {
          return;
        }
        lastFullscreenAttemptRef.current = now;
        if (typeof docEl.requestFullscreen === 'function') {
          docEl
            .requestFullscreen({ navigationUI: 'hide' })
            .then(() => {
              if (refocusInput) {
                window.setTimeout(() => {
                  if (document.activeElement !== refocusInput) {
                    refocusInput.focus({ preventScroll: true });
                  }
                }, 40);
              }
            })
            .catch(() => {});
        } else if (typeof docEl.webkitRequestFullscreen === 'function') {
          docEl.webkitRequestFullscreen();
        } else if (typeof docEl.msRequestFullscreen === 'function') {
          docEl.msRequestFullscreen();
        }
      }
    } catch {
      // Ignore
    }
  };

  const cleanUpperUsername = username.trim().toUpperCase();
  const shortUpperUsername = shortenStudentUsername(cleanUpperUsername);
  const matchedParticipant = participants.find(
    (p) =>
      p.username.trim().toUpperCase() === cleanUpperUsername ||
      shortenStudentUsername(p.username) === shortUpperUsername ||
      p.namaPeserta.trim().toUpperCase() === cleanUpperUsername
  );

  const lastViolationUserUpper =
    lastViolationInfo?.username?.trim().toUpperCase() || '';
  const shouldApplyFallbackViolation =
    !cleanUpperUsername ||
    (Boolean(lastViolationUserUpper) &&
      cleanUpperUsername === lastViolationUserUpper);

  const fallbackLockedParticipant =
    !matchedParticipant && lastViolationInfo && shouldApplyFallbackViolation
      ? participants.find(
          (p) =>
            p.username.trim().toUpperCase() === lastViolationUserUpper
        )
      : undefined;

  const activeLockedParticipant =
    matchedParticipant && isParticipantLockedByViolation(matchedParticipant)
      ? matchedParticipant
      : fallbackLockedParticipant &&
        isParticipantLockedByViolation(fallbackLockedParticipant)
      ? fallbackLockedParticipant
      : undefined;

  const isLockedByViolation = Boolean(activeLockedParticipant);
  const activeViolationCount =
    activeLockedParticipant?.violationCount ||
    lastViolationInfo?.violationCount ||
    1;
  const isMaxViolationReached =
    activeViolationCount >= 6 || Boolean(lastViolationInfo?.answersWiped);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isCheckingLogin) return;
    const cleanUser = username.trim().toUpperCase();
    const shortUser = shortenStudentUsername(cleanUser);
    const cleanPass = password.trim();
    if (!cleanUser || !cleanPass) {
      setErrorMsg('Username dan password wajib diisi.');
      return;
    }

    // Request fullscreen synchronously inside the user click/submit gesture BEFORE awaiting network calls
    // so mobile browsers (Android Chrome / WebView) do not expire transient user activation.
    requestMobileFullscreenAndHideStatusBar();

    const findMatched = (list: ProctorParticipantRow[]) =>
      list.find(
        (p) =>
          p.username.trim().toUpperCase() === cleanUser ||
          shortenStudentUsername(p.username) === shortUser ||
          p.namaPeserta.trim().toUpperCase() === cleanUser
      );

    let row = findMatched(participants);
    setIsCheckingLogin(true);
    let serverAuthPassed = false;
    let serverAuthRowUsername = '';
    let serverAuthAccount:
      | {
          username?: string;
          namaPeserta?: string;
          kelas?: string;
          ruang?: string;
          status?: string;
        }
      | undefined;
    let serverAuthSchedules: AdminScheduleItem[] | undefined;
    try {
      const authRes = await authenticateWithServer({
        role: 'student',
        username: cleanUser,
        password: cleanPass,
      });

      if (authRes.ok) {
        serverAuthPassed = true;
        serverAuthAccount = authRes.account;
        serverAuthSchedules = Array.isArray(authRes.schedules)
          ? authRes.schedules
          : undefined;
        serverAuthRowUsername = String(
          authRes.account?.username || row?.username || cleanUser
        )
          .trim()
          .toUpperCase();
        // Refresh local participant list so confirmation page has fresh server data
        if (onRefreshParticipants) {
          try {
            const freshList = await onRefreshParticipants();
            if (Array.isArray(freshList) && freshList.length > 0) {
              row = findMatched(freshList) || row;
            }
          } catch {
            // ignore secondary refresh error
          }
        }
      } else if (authRes.serverEmpty) {
        setErrorMsg(
          'Data peserta pada server CBT belum tersedia. Hubungi Proktor atau Administrator untuk menginisialisasi data peserta di server.'
        );
        return;
      } else if (authRes.networkError) {
        setErrorMsg(
          'Tidak dapat terhubung ke server ujian CBT. Periksa koneksi WiFi/internet Anda lalu coba login kembali.'
        );
        return;
      } else {
        // Server authoritatively rejected login (e.g. Non Active in Kelompok Tes, locked, wrong password, Selesai)
        if (onRefreshParticipants) {
          onRefreshParticipants().catch(() => {});
        }
        if (authRes.reason === 'completed' && onReconcileCompletedSubjects) {
          const clearedCount = onReconcileCompletedSubjects(
            row?.username?.trim().toUpperCase() || cleanUser,
            authRes.completedSubjects
          );
          if (clearedCount > 0) {
            setErrorMsg(
              'Jawaban ujian Anda sebelumnya sudah tercatat tersimpan di server sehingga antrean lokal di perangkat ini telah dibersihkan. Hubungi Proktor/Administrator jika membutuhkan Reset Login.'
            );
            return;
          }
        }
        setErrorMsg(
          authRes.error ||
            'Akses Login Ditolak. Periksa kembali username, password, dan status peserta Anda.'
        );
        return;
      }
    } finally {
      setIsCheckingLogin(false);
    }

    if (!serverAuthPassed) {
      setErrorMsg(
        'Verifikasi sesi peserta ke server gagal. Silakan coba login kembali.'
      );
      return;
    }

    const finalLoginUsername =
      serverAuthRowUsername || row?.username?.trim().toUpperCase() || cleanUser;

    requestMobileFullscreenAndHideStatusBar();

    setErrorMsg('');
    onClearSessionNotice?.();
    onLoginSuccess(finalLoginUsername, serverAuthAccount, serverAuthSchedules);
  };

  return (
    <main className="flex-1 flex flex-col items-center justify-center px-4 py-10 min-h-[calc(100vh-10rem)]">
      {/* Main Login Card matching Pusmendik Simulasi TKA screenshot */}
      <div className="w-full max-w-[425px] bg-white rounded-[14px] px-9 sm:px-11 py-10 sm:py-11 shadow-[0_24px_60px_-12px_rgba(15,23,42,0.16)] border border-slate-100/80 animate-cbt-slide-up">
        <h1 className="text-[18px] font-bold text-[#1e293b] tracking-tight">
          Selamat Datang
        </h1>
        <p className="mt-1.5 text-[13.5px] leading-[1.55] text-[#475569]">
          Silakan login dengan menggunakan username dan password yang anda miliki
        </p>

        {/* Pemberitahuan Antrean Jawaban Ujian Belum Terkirim ke Server */}
        {pendingSubmissions.length > 0 && (
          <div className="mt-4 p-3.5 rounded-xl bg-amber-50 border border-amber-300 space-y-1.5">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed text-amber-900 space-y-1">
                <div className="font-extrabold text-amber-950">
                  {pendingSubmissions.length} Hasil Ujian Belum Terkirim ke Server
                </div>
                <p>
                  Terdapat jawaban ujian tersimpan di perangkat ini yang tertunda saat koneksi terputus:
                </p>
                <ul className="list-disc pl-4 space-y-0.5 font-semibold text-amber-950">
                  {pendingSubmissions.slice(0, 3).map((item) => (
                    <li key={item.localResultId}>
                      {item.fullName} (<span className="font-mono">{item.username}</span>) — {item.packageTitle}
                    </li>
                  ))}
                  {pendingSubmissions.length > 3 && (
                    <li>dan {pendingSubmissions.length - 3} hasil lainnya</li>
                  )}
                </ul>
                <p className="text-[11px] text-amber-800">
                  Silakan <strong>login kembali</strong> dengan akun peserta tersebut (atau login Proktor/Admin) saat jaringan aktif agar jawaban otomatis terkirim ke server.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Peringatan Pelanggaran Keluar Sistem CBT */}
        {isLockedByViolation && activeLockedParticipant && (
          <div className="mt-4 p-4 rounded-xl bg-rose-50 border border-rose-200 space-y-2.5">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="space-y-1.5 w-full">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="text-xs font-extrabold uppercase tracking-wide text-rose-800">
                    Pelanggaran Terdeteksi — Sesi Terkunci
                  </div>
                  <span
                    className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-extrabold ${
                      isMaxViolationReached
                        ? 'bg-rose-600 text-white'
                        : 'bg-amber-100 text-amber-900 border border-amber-300'
                    }`}
                  >
                    Pelanggaran {Math.min(activeViolationCount, 6)}/6
                  </span>
                </div>
                {violationMessage && violationMessage.trim() && (
                  <p className="text-xs leading-relaxed font-medium text-rose-800 bg-white/80 px-2.5 py-2 rounded-lg border border-rose-200">
                    {violationMessage}
                  </p>
                )}
                <p className="text-xs leading-relaxed text-rose-700">
                  Peserta <strong>{activeLockedParticipant.namaPeserta}</strong> (
                  <span className="font-mono font-bold">
                    {activeLockedParticipant.username}
                  </span>
                  ) terdeteksi melakukan pelanggaran keluar dari sistem CBT.
                  Untuk masuk kembali, Anda wajib meminta{' '}
                  <strong>Reset Login</strong> ke Proktor atau Administrator.
                </p>
                {isMaxViolationReached ? (
                  <div className="p-2.5 rounded-lg bg-rose-600 text-white text-[11px] font-bold leading-relaxed">
                    Batas Maksimal Pelanggaran (6/6) Tercapai! Seluruh jawaban
                    ujian yang telah Anda kerjakan otomatis dihapus oleh sistem.
                  </div>
                ) : (
                  <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px] font-semibold leading-relaxed">
                    Jawaban yang sudah Anda kirim masih tersimpan aman.{' '}
                    <span className="font-bold text-rose-700">
                      Peringatan: Jika melanggar hingga 6 kali (saat ini{' '}
                      {activeViolationCount}/6), maka seluruh jawaban Anda akan
                      terhapus otomatis!
                    </span>
                  </div>
                )}
                {activeLockedParticipant.violationReason && (
                  <p className="text-[11px] font-medium text-rose-600">
                    Keterangan: {activeLockedParticipant.violationReason}
                    {activeLockedParticipant.violationAt
                      ? ` (${activeLockedParticipant.violationAt})`
                      : ''}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {errorMsg &&
          (!isLockedByViolation ||
            (Boolean(cleanUpperUsername) &&
              activeLockedParticipant?.username?.trim().toUpperCase() !==
                cleanUpperUsername)) && (
          <div className="mt-4 px-3.5 py-2.5 rounded-lg bg-rose-50 border border-rose-200 text-xs font-medium text-rose-700">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-7 space-y-6">
          {/* Username Input Row */}
          <div
            className="flex items-center gap-3.5"
            onClick={() =>
              requestMobileFullscreenAndHideStatusBar(usernameInputRef.current)
            }
          >
            {/* Solid circular user icon matching screenshot */}
            <div className="shrink-0 text-[#1e293b]" aria-hidden="true">
              <svg
                className="w-[18px] h-[18px]"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm0 14c-2.03 0-4.43-.82-6.14-2.88a9.947 9.947 0 0 1 12.28 0C16.43 19.18 14.03 20 12 20z" />
              </svg>
            </div>
            <div className="flex-1">
              <input
                ref={usernameInputRef}
                type="text"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value.toUpperCase());
                  setErrorMsg('');
                  onClearSessionNotice?.();
                }}
                placeholder="Username"
                aria-label="Username"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="characters"
                spellCheck={false}
                className="w-full pb-2 pt-1 text-[14px] uppercase placeholder:normal-case text-slate-800 placeholder:text-slate-400 bg-transparent border-b border-slate-200 focus:border-[#0066ff] focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Password Input Row */}
          <div
            className="flex items-center gap-3.5"
            onClick={(e) => {
              const target = e.target as HTMLElement | null;
              if (target?.closest('button')) return;
              requestMobileFullscreenAndHideStatusBar(passwordInputRef.current);
            }}
          >
            {/* Solid padlock icon matching screenshot */}
            <div className="shrink-0 text-[#1e293b]" aria-hidden="true">
              <svg
                className="w-[18px] h-[18px]"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" />
              </svg>
            </div>
            <div className="relative flex-1 flex items-center border-b border-slate-200 focus-within:border-[#0066ff] transition-colors">
              <input
                ref={passwordInputRef}
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrorMsg('');
                  onClearSessionNotice?.();
                }}
                placeholder="Password"
                aria-label="Password"
                autoComplete="new-password"
                autoCorrect="off"
                autoCapitalize="none"
                spellCheck={false}
                className="w-full pb-2 pt-1 pr-8 text-[14px] text-slate-800 placeholder:text-slate-400 bg-transparent focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="absolute right-0 bottom-2 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                aria-label={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          {/* Login Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isCheckingLogin}
              className={`w-full py-2.5 px-6 rounded-full text-white text-[14px] font-semibold transition-all cursor-pointer disabled:opacity-70 ${
                isLockedByViolation
                  ? 'bg-slate-400 hover:bg-slate-500'
                  : 'bg-[#0066ff] hover:bg-[#0052cc] active:scale-[0.99] shadow-[0_6px_16px_rgba(0,102,255,0.28)]'
              }`}
            >
              {isCheckingLogin
                ? 'Memeriksa status akun...'
                : isLockedByViolation
                ? 'Akun Terkunci (Wajib Reset Proktor/Admin)'
                : 'Login'}
            </button>
          </div>
        </form>
      </div>

      {/* Tombol Pasang Aplikasi (Layar Penuh) & Keluar CBT Mobile */}
      {(!isInstalled && !isAndroidWebView) || onExitApp ? (
        <div className="md:hidden mt-4 w-full max-w-[425px] flex flex-col gap-2">
          {!isInstalled && !isAndroidWebView && (
            <button
              type="button"
              onClick={handleMobileInstallClick}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-100" />
              <span>Pasang Aplikasi CBT (Layar Penuh)</span>
            </button>
          )}
          {onExitApp && (
            <button
              type="button"
              onClick={onExitApp}
              className="w-full py-2.5 px-4 rounded-xl bg-rose-600/90 hover:bg-rose-700 active:scale-[0.99] text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Power className="w-4 h-4 text-rose-200" />
              <span>Keluar CBT</span>
            </button>
          )}
        </div>
      ) : null}

      {/* Copyright Footer */}
      <div className="mt-4 flex flex-wrap items-center justify-center text-xs text-slate-500 font-medium text-center">
        Copyright © 2026. CBT SMA Islam Diponegoro Wagir
      </div>

      {/* Modal Panduan Pasang Aplikasi di HP */}
      {showMobileInstallModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-3.5 text-slate-800 animate-cbt-slide-up">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Buka CBT Layar Penuh di HP
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Agar langsung penuh saat dibuka tanpa bar browser
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowMobileInstallModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
                aria-label="Tutup"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2.5 text-xs text-slate-600 leading-relaxed">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                <div className="font-bold text-slate-800">Android (Chrome):</div>
                <p>
                  Ketuk menu <strong>⋮</strong> di pojok kanan atas Chrome → pilih{' '}
                  <strong>Tambahkan ke layar utama</strong> /{' '}
                  <strong>Install aplikasi</strong>, lalu buka CBT dari ikon di layar utama HP.
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                <div className="font-bold text-slate-800">iPhone / iPad (Safari):</div>
                <p>
                  Ketuk tombol <strong>Bagikan (Share)</strong> di bawah → pilih{' '}
                  <strong>Tambah ke Layar Utama (Add to Home Screen)</strong>.
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
                <strong>Tips Ujian:</strong> Aktifkan mode{' '}
                <strong>Jangan Ganggu (Do Not Disturb)</strong> di HP sebelum mulai ujian agar notifikasi WA/aplikasi lain tidak masuk dan memicu kunci pelanggaran.
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowMobileInstallModal(false)}
              className="w-full py-2 rounded-lg bg-[#0066ff] hover:bg-[#0052cc] text-white text-xs font-semibold cursor-pointer"
            >
              Mengerti
            </button>
          </div>
        </div>
      )}
    </main>
  );
};


