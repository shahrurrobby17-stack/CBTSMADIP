import React, { useState } from 'react';
import { Eye, EyeOff, ShieldCheck, KeyRound, ArrowLeft, Lock, UserCheck } from 'lucide-react';
import { AdminProctorItem } from './AdminViews';
import { authenticateWithServer } from '../utils/vercelStorage';

interface ProctorLoginViewProps {
  onProctorLoginSuccess: (
    proctorName: string,
    encryptionCode: string,
    proctorId?: string
  ) => void;
  onBackToStudentLogin: () => void;
  onGoToAdminLogin?: () => void;
  proctors?: AdminProctorItem[];
  onRefreshProctors?: () => Promise<AdminProctorItem[]>;
}

export const ProctorLoginView: React.FC<ProctorLoginViewProps> = ({
  onProctorLoginSuccess,
  onBackToStudentLogin,
  proctors = [],
  onRefreshProctors,
}) => {
  const [proctorName, setProctorName] = useState('');
  const [password, setPassword] = useState('');
  const [encryptionCode, setEncryptionCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showEncryption, setShowEncryption] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [isCheckingLogin, setIsCheckingLogin] = useState(false);

  const findProctor = (list: AdminProctorItem[], cleanNameUpper: string) =>
    list.find(
      (p) =>
        String(p.fullName || '').trim().toUpperCase() === cleanNameUpper ||
        String(p.proctorId || '').trim().toUpperCase() === cleanNameUpper
    );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isCheckingLogin) return;
    const cleanName = proctorName.trim();
    const cleanNameUpper = cleanName.toUpperCase();
    const cleanPass = password.trim();
    const cleanEnc = encryptionCode.trim().toUpperCase();

    if (!cleanName || !cleanPass || !cleanEnc) {
      setErrorMsg('Nama Proktor, Kata Sandi, dan Kode Enkripsi wajib diisi lengkap.');
      return;
    }

    // Request fullscreen synchronously on mobile devices inside the click/submit gesture BEFORE network awaits
    const requestMobileFullscreenSync = () => {
      try {
        const isMobileDevice =
          window.innerWidth < 768 ||
          Boolean(window.matchMedia?.('(pointer: coarse)').matches) ||
          /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
        if (isMobileDevice) {
          const doc = document as Document & {
            webkitFullscreenElement?: Element | null;
          };
          const docEl = document.documentElement as HTMLElement & {
            webkitRequestFullscreen?: (options?: FullscreenOptions) => Promise<void>;
          };
          if (!doc.fullscreenElement && !doc.webkitFullscreenElement) {
            if (docEl.requestFullscreen) {
              docEl.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
            } else if (docEl.webkitRequestFullscreen) {
              docEl.webkitRequestFullscreen();
            }
          }
        }
      } catch {
        // Ignore
      }
    };
    requestMobileFullscreenSync();

    const matched = findProctor(proctors, cleanNameUpper);
    let serverAuthPassed = false;
    let serverProctorName = '';
    let serverProctorEnc = '';
    let serverProctorId = '';

    setIsCheckingLogin(true);
    try {
      const authRes = await authenticateWithServer({
        role: 'proctor',
        username: cleanNameUpper,
        password: cleanPass,
        encryptionCode: cleanEnc,
      });
      if (authRes.ok) {
        serverAuthPassed = true;
        serverProctorName = String(
          authRes.account?.fullName || matched?.fullName || cleanName
        );
        serverProctorEnc = String(
          authRes.account?.encryptionCode || matched?.encryptionCode || cleanEnc
        )
          .trim()
          .toUpperCase();
        serverProctorId = String(
          authRes.account?.proctorId || matched?.proctorId || ''
        )
          .trim()
          .toUpperCase();
        if (onRefreshProctors) {
          onRefreshProctors().catch(() => {});
        }
      } else if (authRes.serverEmpty) {
        setErrorMsg(
          'Daftar Proktor di server belum tersedia. Silakan minta Administrator login terlebih dahulu untuk menyinkronkan data server.'
        );
        return;
      } else if (authRes.networkError) {
        setErrorMsg(
          'Gagal terhubung ke server CBT untuk verifikasi sesi Proktor. Periksa koneksi internet lalu coba login kembali.'
        );
        return;
      } else {
        setErrorMsg(
          authRes.error ||
            'Login Proktor ditolak. Periksa Nama/ID Proktor, Kata Sandi, Kode Enkripsi, dan status akun Anda.'
        );
        return;
      }
    } finally {
      setIsCheckingLogin(false);
    }

    if (!serverAuthPassed) {
      setErrorMsg(
        'Verifikasi sesi Proktor ke server gagal. Silakan coba login kembali.'
      );
      return;
    }

    setErrorMsg('');
    requestMobileFullscreenSync();

    onProctorLoginSuccess(
      String(serverProctorName || matched?.fullName || cleanName)
        .trim()
        .toUpperCase(),
      String(serverProctorEnc || matched?.encryptionCode || cleanEnc)
        .trim()
        .toUpperCase(),
      serverProctorId || undefined
    );
  };

  return (
    <main className="flex-1 flex flex-col items-center justify-center px-4 py-10 min-h-[calc(100vh-10rem)]">
      {/* Proctor Login Card matching the CBT aesthetic */}
      <div className="w-full max-w-[445px] bg-white rounded-[14px] px-9 sm:px-11 py-10 shadow-[0_24px_60px_-12px_rgba(15,23,42,0.16)] border border-slate-100/80 animate-cbt-slide-up">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-[18px] font-bold text-[#1e293b] tracking-tight">
            Login Proktor
          </h1>
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#0066ff]">
            <ShieldCheck className="w-4 h-4" />
            <span>Akses Server Ruang</span>
          </span>
        </div>

        <p className="mt-1.5 text-[13.5px] leading-[1.55] text-[#475569]">
          Masukkan nama proktor, kata sandi, dan kode enkripsi ruang ujian untuk mengelola sesi dan bank soal.
        </p>

        {errorMsg && (
          <div className="mt-4 px-3.5 py-2.5 rounded-lg bg-rose-50 border border-rose-200 text-xs font-medium text-rose-700">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-7 space-y-6">
          {/* 1. Nama Proktor */}
          <div className="flex items-center gap-3.5">
            <div className="shrink-0 text-[#1e293b]" aria-hidden="true">
              <UserCheck className="w-[18px] h-[18px]" />
            </div>
            <div className="flex-1">
              <input
                type="text"
                value={proctorName}
                onChange={(e) => setProctorName(e.target.value)}
                placeholder="Nama Proktor"
                aria-label="Nama Proktor"
                autoComplete="off"
                className="w-full pb-2 pt-1 text-[14px] text-slate-800 placeholder:text-slate-400 bg-transparent border-b border-slate-200 focus:border-[#0066ff] focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* 2. Kata Sandi */}
          <div className="flex items-center gap-3.5">
            <div className="shrink-0 text-[#1e293b]" aria-hidden="true">
              <Lock className="w-[18px] h-[18px]" />
            </div>
            <div className="relative flex-1 flex items-center border-b border-slate-200 focus-within:border-[#0066ff] transition-colors">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Kata Sandi"
                aria-label="Kata Sandi"
                autoComplete="new-password"
                className="w-full pb-2 pt-1 pr-8 text-[14px] text-slate-800 placeholder:text-slate-400 bg-transparent focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="absolute right-0 bottom-2 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                aria-label={showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          {/* 3. Kode Enkripsi */}
          <div className="flex items-center gap-3.5">
            <div className="shrink-0 text-[#1e293b]" aria-hidden="true">
              <KeyRound className="w-[18px] h-[18px]" />
            </div>
            <div className="relative flex-1 flex items-center border-b border-slate-200 focus-within:border-[#0066ff] transition-colors">
              <input
                type={showEncryption ? 'text' : 'password'}
                value={encryptionCode}
                onChange={(e) => setEncryptionCode(e.target.value.toUpperCase())}
                placeholder="Kode Enkripsi"
                aria-label="Kode Enkripsi"
                className="w-full pb-2 pt-1 pr-8 font-mono text-[14px] tracking-wider text-slate-800 placeholder:font-sans placeholder:tracking-normal placeholder:text-slate-400 bg-transparent focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowEncryption((prev) => !prev)}
                className="absolute right-0 bottom-2 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                aria-label={showEncryption ? 'Sembunyikan kode enkripsi' : 'Tampilkan kode enkripsi'}
              >
                {showEncryption ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 space-y-2.5">
            <button
              type="submit"
              disabled={isCheckingLogin}
              className="w-full py-2.5 px-6 rounded-full bg-[#0066ff] hover:bg-[#0052cc] active:scale-[0.99] text-white text-[14px] font-semibold shadow-[0_6px_16px_rgba(0,102,255,0.28)] transition-all cursor-pointer disabled:opacity-70"
            >
              {isCheckingLogin ? 'Memverifikasi Akun...' : 'Login Proktor'}
            </button>

            <button
              type="button"
              onClick={onBackToStudentLogin}
              className="w-full py-2 px-4 rounded-full border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Kembali ke Halaman Login Peserta</span>
            </button>
          </div>
        </form>
      </div>
    </main>
  );
};
