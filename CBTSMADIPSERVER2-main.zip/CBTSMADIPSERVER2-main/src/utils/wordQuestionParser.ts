import * as XLSX from 'xlsx';
import {
  Question,
  QuestionType,
  OptionItem,
  StatementItem,
  MatchingPremise,
  MatchingResponse,
  QuestionTableData,
} from '../types/cbt';

type PdfJsModule = typeof import('pdfjs-dist/legacy/build/pdf.mjs');
let cachedPdfJsModule: PdfJsModule | null = null;
let pdfWorkerConfigured = false;

async function loadPdfJs(): Promise<PdfJsModule> {
  if (!cachedPdfJsModule) {
    cachedPdfJsModule = await import('pdfjs-dist/legacy/build/pdf.mjs');
  }
  if (!pdfWorkerConfigured && typeof window !== 'undefined') {
    try {
      const workerMod = await import('pdfjs-dist/legacy/build/pdf.worker.min.mjs?url');
      if (workerMod?.default) {
        cachedPdfJsModule.GlobalWorkerOptions.workerSrc = workerMod.default;
        pdfWorkerConfigured = true;
      }
    } catch {
      // Non-Vite test environment
    }
  }
  return cachedPdfJsModule;
}

const SUPERSCRIPT_CHAR_MAP: Record<string, string> = {
  '0': '⁰',
  '1': '¹',
  '2': '²',
  '3': '³',
  '4': '⁴',
  '5': '⁵',
  '6': '⁶',
  '7': '⁷',
  '8': '⁸',
  '9': '⁹',
  '+': '⁺',
  '-': '⁻',
  n: 'ⁿ',
  i: 'ⁱ',
};

const SUBSCRIPT_CHAR_MAP: Record<string, string> = {
  '0': '₀',
  '1': '₁',
  '2': '₂',
  '3': '₃',
  '4': '₄',
  '5': '₅',
  '6': '₆',
  '7': '₇',
  '8': '₈',
  '9': '₉',
  '+': '₊',
  '-': '₋',
};

function convertToUnicodeScript(
  raw: string,
  kind: 'sup' | 'sub'
): string {
  const map = kind === 'sup' ? SUPERSCRIPT_CHAR_MAP : SUBSCRIPT_CHAR_MAP;
  let out = '';
  for (const ch of raw) {
    out += map[ch] ?? ch;
  }
  return out;
}

interface TextSegment {
  text: string;
  isRed: boolean;
  isBold?: boolean;
  isUnderline?: boolean;
  isHighlight?: boolean;
}

interface ParsedParagraph {
  fullText: string;
  hasRed: boolean;
  hasBold?: boolean;
  hasUnderline?: boolean;
  hasHighlight?: boolean;
  isAllBold?: boolean;
  segments: TextSegment[];
  images?: string[];
  numId?: string;
  ilvl?: number;
  numFormat?: string;
  autoQuestionNumber?: number;
  autoOptionLetter?: string;
}

interface ParsedTableCell {
  fullText: string;
  hasRed: boolean;
  hasBold?: boolean;
  hasUnderline?: boolean;
  hasHighlight?: boolean;
  paragraphs: ParsedParagraph[];
  nestedTables: ParsedTable[];
  images?: string[];
}

interface ParsedTable {
  rows: ParsedTableCell[][];
}

type DocumentBlock =
  | { kind: 'paragraph'; paragraph: ParsedParagraph }
  | { kind: 'table'; table: ParsedTable };

const SAFE_DATA_IMAGE_REGEX =
  /^data:image\/(png|jpeg|jpg|gif|webp|bmp);base64,[a-zA-Z0-9+/=\s]+$/i;

function isSafeImageDataUrl(src: string | null | undefined): boolean {
  if (!src) return false;
  return SAFE_DATA_IMAGE_REGEX.test(src.trim());
}

function uint8ArrayToBase64(bytes: Uint8Array): string {
  const chunkSize = 0x8000;
  const parts: string[] = [];
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const sub = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    let bin = '';
    for (let j = 0; j < sub.length; j++) {
      bin += String.fromCharCode(sub[j]);
    }
    parts.push(bin);
  }
  return btoa(parts.join(''));
}

function mimeFromMediaPath(path: string): string | null {
  const lower = path.toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.gif')) return 'image/gif';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.bmp')) return 'image/bmp';
  return null;
}

async function compressDataUrlIfNeeded(
  dataUrl: string,
  maxWidth: number = 920
): Promise<string> {
  const clean = dataUrl.trim();
  if (!isSafeImageDataUrl(clean)) return '';
  if (typeof document === 'undefined' || typeof Image === 'undefined') {
    return clean;
  }
  // Keep small GIFs intact to avoid losing animation or transparency
  if (/^data:image\/gif;base64,/i.test(clean) && clean.length < 220000) {
    return clean;
  }

  return new Promise<string>((resolve) => {
    let settled = false;
    const finish = (val: string) => {
      if (!settled) {
        settled = true;
        resolve(val);
      }
    };
    const timer = setTimeout(() => finish(clean), 2500);

    try {
      const img = new Image();
      img.onload = () => {
        clearTimeout(timer);
        try {
          const origW = img.naturalWidth || img.width;
          const origH = img.naturalHeight || img.height;
          if (!origW || !origH) {
            finish(clean);
            return;
          }
          const scale = origW > maxWidth ? maxWidth / origW : 1;
          const targetW = Math.max(1, Math.round(origW * scale));
          const targetH = Math.max(1, Math.round(origH * scale));

          if (scale === 1 && clean.length < 75000) {
            finish(clean);
            return;
          }

          const canvas = document.createElement('canvas');
          canvas.width = targetW;
          canvas.height = targetH;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            finish(clean);
            return;
          }
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, targetW, targetH);
          ctx.drawImage(img, 0, 0, targetW, targetH);

          const isPng = /^data:image\/png;base64,/i.test(clean);
          const jpegOut = canvas.toDataURL('image/jpeg', 0.82);
          if (isPng && scale === 1) {
            const pngOut = canvas.toDataURL('image/png');
            finish(
              pngOut.length <= Math.min(clean.length, jpegOut.length * 1.25)
                ? pngOut
                : jpegOut
            );
            return;
          }
          finish(jpegOut.length < clean.length ? jpegOut : clean);
        } catch {
          finish(clean);
        }
      };
      img.onerror = () => {
        clearTimeout(timer);
        finish(clean);
      };
      img.src = clean;
    } catch {
      clearTimeout(timer);
      finish(clean);
    }
  });
}

function mergeUniqueImages(
  ...lists: (string[] | undefined)[]
): string[] | undefined {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const list of lists) {
    if (!list) continue;
    for (const img of list) {
      if (img && !seen.has(img)) {
        seen.add(img);
        out.push(img);
      }
    }
  }
  return out.length > 0 ? out : undefined;
}

/**
 * Checks whether a Word color string (hex, named color, or rgb()) represents red.
 */
export function isRedColorValue(rawColor: string | null | undefined): boolean {
  if (!rawColor) return false;
  const val = rawColor.trim().toLowerCase();
  if (
    !val ||
    val === 'auto' ||
    val === 'none' ||
    val === '000000' ||
    val === '#000000' ||
    val === 'ffffff' ||
    val === '#ffffff' ||
    val === 'black' ||
    val === 'white'
  ) {
    return false;
  }

  const namedReds = new Set([
    'red',
    'darkred',
    'crimson',
    'firebrick',
    'indianred',
    'maroon',
    'lightcoral',
    'salmon',
    'tomato',
    'orangered',
  ]);
  if (namedReds.has(val)) return true;

  // Check rgb(r, g, b) or rgba(r, g, b, a)
  const rgbMatch = val.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
  if (rgbMatch) {
    const r = parseInt(rgbMatch[1], 10);
    const g = parseInt(rgbMatch[2], 10);
    const b = parseInt(rgbMatch[3], 10);
    return r >= 120 && g <= 105 && b <= 105 && r >= g * 1.5 && r >= b * 1.5;
  }

  // Check hex (#RRGGBB, RRGGBB, #RGB, RGB)
  const cleanedHex = val.replace(/^#/, '');
  let r = -1;
  let g = -1;
  let b = -1;

  if (/^[0-9a-f]{6}$/i.test(cleanedHex)) {
    r = parseInt(cleanedHex.slice(0, 2), 16);
    g = parseInt(cleanedHex.slice(2, 4), 16);
    b = parseInt(cleanedHex.slice(4, 6), 16);
  } else if (/^[0-9a-f]{3}$/i.test(cleanedHex)) {
    r = parseInt(cleanedHex[0] + cleanedHex[0], 16);
    g = parseInt(cleanedHex[1] + cleanedHex[1], 16);
    b = parseInt(cleanedHex[2] + cleanedHex[2], 16);
  }

  if (r >= 0 && g >= 0 && b >= 0) {
    // Typical Word reds: FF0000, C00000, EE0000, CC0000, 990000, EF4444, DC2626, E53935, etc.
    return r >= 120 && g <= 105 && b <= 105 && r >= g * 1.5 && r >= b * 1.5;
  }

  return false;
}

/**
 * Decompresses raw DEFLATE bytes using browser's native DecompressionStream.
 */
async function inflateRaw(compressed: Uint8Array): Promise<Uint8Array> {
  const ds = new DecompressionStream('deflate-raw');
  const writer = ds.writable.getWriter();
  writer.write(compressed as unknown as BufferSource).catch(() => {});
  writer.close().catch(() => {});

  const reader = ds.readable.getReader();
  const chunks: Uint8Array[] = [];
  let totalLen = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      totalLen += value.byteLength;
    }
  }

  const output = new Uint8Array(totalLen);
  let offset = 0;
  for (const chunk of chunks) {
    output.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return output;
}

/**
 * Extracts XML text files and embedded media binaries from a ZIP archive (.docx) in browser memory.
 */
async function extractZipFiles(buffer: ArrayBuffer): Promise<{
  textFiles: Record<string, string>;
  binaryFiles: Record<string, Uint8Array>;
}> {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  const decoder = new TextDecoder('utf-8');
  const textFiles: Record<string, string> = {};
  const binaryFiles: Record<string, Uint8Array> = {};

  let eocdOffset = -1;
  const minEocdSearch = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= minEocdSearch; i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }

  if (eocdOffset !== -1) {
    const totalEntries = view.getUint16(eocdOffset + 10, true);
    const cdOffset = view.getUint32(eocdOffset + 16, true);
    let ptr = cdOffset;

    for (let e = 0; e < totalEntries && ptr + 46 <= bytes.length; e++) {
      const sig = view.getUint32(ptr, true);
      if (sig !== 0x02014b50) break;

      const compressionMethod = view.getUint16(ptr + 10, true);
      const compressedSize = view.getUint32(ptr + 20, true);
      const fileNameLen = view.getUint16(ptr + 28, true);
      const extraLen = view.getUint16(ptr + 30, true);
      const commentLen = view.getUint16(ptr + 32, true);
      const localHeaderOffset = view.getUint32(ptr + 42, true);

      const fileName = decoder.decode(bytes.subarray(ptr + 46, ptr + 46 + fileNameLen));
      ptr += 46 + fileNameLen + extraLen + commentLen;

      const isWantedText =
        fileName === 'word/document.xml' ||
        fileName === 'word/numbering.xml' ||
        fileName === 'word/styles.xml' ||
        fileName === 'word/_rels/document.xml.rels';
      const isWantedMedia =
        fileName.toLowerCase().startsWith('word/media/') &&
        mimeFromMediaPath(fileName) !== null;

      if (isWantedText || isWantedMedia) {
        if (localHeaderOffset + 30 <= bytes.length) {
          const localNameLen = view.getUint16(localHeaderOffset + 26, true);
          const localExtraLen = view.getUint16(localHeaderOffset + 28, true);
          const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
          const compressedData = bytes.subarray(dataStart, dataStart + compressedSize);

          let rawBytes: Uint8Array | null = null;
          if (compressionMethod === 0) {
            rawBytes = compressedData;
          } else if (compressionMethod === 8) {
            rawBytes = await inflateRaw(compressedData);
          }

          if (rawBytes) {
            if (isWantedText) {
              textFiles[fileName] = decoder.decode(rawBytes);
            } else if (isWantedMedia) {
              binaryFiles[fileName] = rawBytes;
            }
          }
        }
      }
    }
  }

  return { textFiles, binaryFiles };
}

/**
 * Resolves word/_rels/document.xml.rels relationships to compressed base64 data URLs.
 */
async function buildDocxRelImageMap(
  relsXml: string | undefined,
  binaryFiles: Record<string, Uint8Array>
): Promise<Record<string, string>> {
  const relImageMap: Record<string, string> = {};
  if (!relsXml || Object.keys(binaryFiles).length === 0) return relImageMap;

  const lowerLookup: Record<string, { path: string; bytes: Uint8Array }> = {};
  Object.entries(binaryFiles).forEach(([path, data]) => {
    lowerLookup[path.toLowerCase()] = { path, bytes: data };
  });

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(relsXml, 'application/xml');
    const relEls = doc.getElementsByTagName('*');
    const pending: { id: string; mediaPath: string; bytes: Uint8Array; mime: string }[] = [];

    for (let i = 0; i < relEls.length; i++) {
      const el = relEls[i];
      const local = el.localName || el.tagName.replace(/^.*:/, '');
      if (local !== 'Relationship') continue;

      const id = el.getAttribute('Id') || '';
      const target = (el.getAttribute('Target') || '').replace(/\\/g, '/').trim();
      if (!id || !target || /^https?:\/\//i.test(target)) continue;

      let resolved = target.replace(/^\/+/, '');
      if (resolved.startsWith('../')) {
        resolved = resolved.replace(/^\.\.\//, '');
      } else if (!resolved.toLowerCase().startsWith('word/')) {
        resolved = `word/${resolved}`;
      }

      const found = lowerLookup[resolved.toLowerCase()];
      if (!found) continue;
      const mime = mimeFromMediaPath(found.path);
      if (!mime) continue;

      pending.push({ id, mediaPath: found.path, bytes: found.bytes, mime });
    }

    const encodedCache: Record<string, string> = {};
    for (const item of pending) {
      const cacheKey = item.mediaPath.toLowerCase();
      if (!encodedCache[cacheKey]) {
        const rawDataUrl = `data:${item.mime};base64,${uint8ArrayToBase64(item.bytes)}`;
        encodedCache[cacheKey] = await compressDataUrlIfNeeded(rawDataUrl);
      }
      if (encodedCache[cacheKey]) {
        relImageMap[item.id] = encodedCache[cacheKey];
      }
    }
  } catch {
    // Ignore malformed rels XML
  }

  return relImageMap;
}

/**
 * Checks if an XML element <w:rPr>, <w:pPr>, or <w:tcPr> has red text color, highlight, or fill.
 */
function checkXmlNodeHasRed(node: Element | null | undefined): boolean {
  if (!node) return false;

  const allDescendants = node.getElementsByTagName('*');
  for (let i = 0; i < allDescendants.length; i++) {
    const el = allDescendants[i];
    const local = el.localName || el.tagName.replace(/^.*:/, '');

    if (local === 'color' || local === 'highlight' || local === 'srgbClr') {
      const val =
        el.getAttribute('w:val') ||
        el.getAttribute('val') ||
        el.getAttribute('w:color') ||
        '';
      if (isRedColorValue(val)) {
        return true;
      }
    } else if (local === 'shd') {
      const fillVal = el.getAttribute('w:fill') || el.getAttribute('fill') || '';
      if (isRedColorValue(fillVal)) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Checks whether a Word XML <w:rPr> or <w:tcPr> carries bold, underline, or non-white highlight/shading.
 */
function checkXmlNodeFormattingFlags(node: Element | null | undefined): {
  isBold: boolean;
  isUnderline: boolean;
  isHighlight: boolean;
} {
  const flags = { isBold: false, isUnderline: false, isHighlight: false };
  if (!node) return flags;

  for (let i = 0; i < node.children.length; i++) {
    const el = node.children[i];
    const local = el.localName || el.tagName.replace(/^.*:/, '');
    const val = (el.getAttribute('w:val') || el.getAttribute('val') || '')
      .trim()
      .toLowerCase();

    if (local === 'b' || local === 'bCs') {
      if (val !== '0' && val !== 'false' && val !== 'off') {
        flags.isBold = true;
      }
    } else if (local === 'u') {
      if (val && val !== 'none' && val !== '0' && val !== 'false') {
        flags.isUnderline = true;
      }
    } else if (local === 'highlight') {
      if (val && val !== 'none' && val !== 'white' && val !== 'auto') {
        flags.isHighlight = true;
      }
    } else if (local === 'shd') {
      const fill = (el.getAttribute('w:fill') || el.getAttribute('fill') || '')
        .trim()
        .toLowerCase();
      if (
        fill &&
        fill !== 'auto' &&
        fill !== 'none' &&
        fill !== 'ffffff' &&
        fill !== 'f8fafc' &&
        fill !== 'f1f5f9' &&
        fill !== 'eeeeee' &&
        fill !== 'f5f5f5' &&
        fill !== 'fafafa'
      ) {
        flags.isHighlight = true;
      }
    }
  }
  return flags;
}

/**
 * Maps Symbol / MT Extra font Private Use Area codepoints (0xF000..0xF0FF) and ASCII Symbol font chars
 * into standard Unicode math symbols (Greek letters, operators, set theory, logic).
 */
const SYMBOL_FONT_ASCII_MAP: Record<string, string> = {
  a: 'α',
  b: 'β',
  g: 'γ',
  d: 'δ',
  e: 'ε',
  z: 'ζ',
  h: 'η',
  q: 'θ',
  i: 'ι',
  k: 'κ',
  l: 'λ',
  m: 'μ',
  n: 'ν',
  x: 'ξ',
  p: 'π',
  r: 'ρ',
  s: 'σ',
  t: 'τ',
  u: 'υ',
  f: 'φ',
  c: 'χ',
  y: 'ψ',
  w: 'ω',
  G: 'Γ',
  D: 'Δ',
  Q: 'Θ',
  L: 'Λ',
  X: 'Ξ',
  P: 'Π',
  S: 'Σ',
  F: 'Φ',
  Y: 'Ψ',
  W: 'Ω',
  '"': '∀',
  '$': '∃',
  '^': '⊥',
  '~': '∼',
  '-': '−',
};

const SYMBOL_PUA_HEX_MAP: Record<number, string> = {
  0x22: '∀',
  0x24: '∃',
  0x2d: '−',
  0x44: 'Δ',
  0x46: 'Φ',
  0x47: 'Γ',
  0x4c: 'Λ',
  0x50: 'Π',
  0x51: 'Θ',
  0x53: 'Σ',
  0x57: 'Ω',
  0x58: 'Ξ',
  0x59: 'Ψ',
  0x5e: '⊥',
  0x61: 'α',
  0x62: 'β',
  0x63: 'χ',
  0x64: 'δ',
  0x65: 'ε',
  0x66: 'φ',
  0x67: 'γ',
  0x68: 'η',
  0x69: 'ι',
  0x6b: 'κ',
  0x6c: 'λ',
  0x6d: 'μ',
  0x6e: 'ν',
  0x70: 'π',
  0x71: 'θ',
  0x72: 'ρ',
  0x73: 'σ',
  0x74: 'τ',
  0x75: 'υ',
  0x77: 'ω',
  0x78: 'ξ',
  0x79: 'ψ',
  0x7a: 'ζ',
  0xa2: '′',
  0xa3: '≤',
  0xa4: '/',
  0xa5: '∞',
  0xab: '↔',
  0xac: '←',
  0xad: '↑',
  0xae: '→',
  0xaf: '↓',
  0xb0: '°',
  0xb1: '±',
  0xb2: '″',
  0xb3: '≥',
  0xb4: '×',
  0xb5: '∝',
  0xb6: '∂',
  0xb7: '•',
  0xb8: '÷',
  0xb9: '≠',
  0xba: '≡',
  0xbb: '≈',
  0xbc: '…',
  0xc5: '⊕',
  0xc6: '∅',
  0xc7: '∩',
  0xc8: '∪',
  0xc9: '⊃',
  0xca: '⊇',
  0xcb: '⊄',
  0xcc: '⊂',
  0xcd: '⊆',
  0xce: '∈',
  0xcf: '∉',
  0xd0: '∠',
  0xd1: '∇',
  0xd5: '∏',
  0xd6: '√',
  0xd7: '·',
  0xd8: '¬',
  0xd9: '∧',
  0xda: '∨',
  0xdb: '⇔',
  0xdc: '⇐',
  0xde: '⇒',
  0xe5: '∑',
  0xf2: '∫',
};

function decodeSymbolFontText(text: string): string {
  let out = '';
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code >= 0xf020 && code <= 0xf0ff) {
      const low = code - 0xf000;
      out += SYMBOL_PUA_HEX_MAP[low] ?? String.fromCharCode(low);
    } else {
      const ch = text[i];
      out += SYMBOL_FONT_ASCII_MAP[ch] ?? ch;
    }
  }
  return out;
}

/**
 * Normalizes Mathematical Alphanumeric Unicode characters (e.g. italic 𝑥, 𝑦, 𝐴, bold 𝟏)
 * and Symbol PUA chars into standard characters so KaTeX and regexes handle them reliably.
 */
function normalizeMathUnicodeChars(input: string): string {
  if (!input) return '';
  let out = '';
  for (const ch of input) {
    const cp = ch.codePointAt(0) ?? 0;
    // Symbol PUA range
    if (cp >= 0xf020 && cp <= 0xf0ff) {
      const low = cp - 0xf000;
      if (low === 0xfc || low === 0xfe) {
        out += '✓';
      } else if (SYMBOL_PUA_HEX_MAP[low]) {
        out += SYMBOL_PUA_HEX_MAP[low];
      } else if (low >= 0x20 && low <= 0x7e) {
        out += String.fromCharCode(low);
      }
      continue;
    }
    // Mathematical Bold / Italic / Bold-Italic / Sans / Mono Latin letters (U+1D400..U+1D6A3)
    if (cp >= 0x1d400 && cp <= 0x1d6a3) {
      const offset = (cp - 0x1d400) % 52;
      out +=
        offset < 26
          ? String.fromCharCode(65 + offset)
          : String.fromCharCode(97 + (offset - 26));
      continue;
    }
    // Mathematical Italic h (Planck constant U+210E)
    if (cp === 0x210e) {
      out += 'h';
      continue;
    }
    // Mathematical Bold/Double-Struck/Sans/Mono Digits (U+1D7CE..U+1D7FF)
    if (cp >= 0x1d7ce && cp <= 0x1d7ff) {
      const d = (cp - 0x1d7ce) % 10;
      out += String(d);
      continue;
    }
    // Mathematical Italic Greek lowercase/uppercase (common blocks)
    if (cp >= 0x1d6fc && cp <= 0x1d714) {
      const greekLower = 'αβγδεζηθικλμνξοπρςστυφχψω';
      out += greekLower[cp - 0x1d6fc] || ch;
      continue;
    }
    if (cp >= 0x1d6e2 && cp <= 0x1d6fa) {
      const greekUpper = 'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΘΣΤΥΦΧΨΩ';
      out += greekUpper[cp - 0x1d6e2] || ch;
      continue;
    }
    out += ch;
  }
  return out;
}

/**
 * Splits comma-separated arguments inside a Word EQ field respecting nested parentheses.
 */
function splitEqFieldArgs(rawArgs: string): string[] {
  const args: string[] = [];
  let depth = 0;
  let cur = '';
  for (let i = 0; i < rawArgs.length; i++) {
    const ch = rawArgs[i];
    if (ch === '(') {
      depth++;
      cur += ch;
    } else if (ch === ')') {
      depth = Math.max(0, depth - 1);
      cur += ch;
    } else if ((ch === ',' || ch === ';') && depth === 0) {
      args.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  if (cur.trim().length > 0 || args.length > 0) {
    args.push(cur.trim());
  }
  return args;
}

/**
 * Converts legacy Microsoft Word EQ field instructions (e.g. "EQ \f(1,2)", "EQ \r(3,8)", "EQ \s\up(2)")
 * into KaTeX-compatible LaTeX wrapped in $...$.
 */
function decodeWordEqField(rawInstr: string): string {
  const cleaned = rawInstr.trim().replace(/^EQ\s+/i, '');
  if (!cleaned) return '';

  const convertExpr = (expr: string): string => {
    let s = expr.trim();
    // Recursively replace \f(num,den) -> \frac{num}{den}
    const replaceSwitch = (
      input: string,
      pattern: RegExp,
      builder: (args: string[], match: RegExpExecArray) => string
    ): string => {
      let result = input;
      let guard = 0;
      while (guard++ < 25) {
        pattern.lastIndex = 0;
        const m = pattern.exec(result);
        if (!m) break;
        const openIdx = m.index + m[0].length - 1;
        let depth = 1;
        let i = openIdx + 1;
        while (i < result.length && depth > 0) {
          if (result[i] === '(') depth++;
          else if (result[i] === ')') depth--;
          i++;
        }
        if (depth !== 0) break;
        const inner = result.slice(openIdx + 1, i - 1);
        const args = splitEqFieldArgs(inner).map((a) => convertExpr(a));
        const replacement = builder(args, m);
        result = result.slice(0, m.index) + replacement + result.slice(i);
      }
      return result;
    };

    s = replaceSwitch(s, /\\f\s*\(/gi, (args) => {
      if (args.length >= 2) return `\\frac{${args[0]}}{${args[1]}}`;
      return args[0] || '';
    });
    s = replaceSwitch(s, /\\r\s*\(/gi, (args) => {
      if (args.length >= 2 && args[0]) return `\\sqrt[${args[0]}]{${args[1]}}`;
      return `\\sqrt{${args[0] || ''}}`;
    });
    s = replaceSwitch(s, /\\s\\up(?:\d+)?\s*\(/gi, (args) => `^{${args.join(',')}}`);
    s = replaceSwitch(s, /\\s\\do(?:\d+)?\s*\(/gi, (args) => `_{${args.join(',')}}`);
    s = replaceSwitch(s, /\\i(?:\\su|\\pr)?\s*\(/gi, (args, m) => {
      const cmd = /\\su/i.test(m[0])
        ? '\\sum'
        : /\\pr/i.test(m[0])
        ? '\\prod'
        : '\\int';
      const lower = args[0] ? `_{${args[0]}}` : '';
      const upper = args[1] ? `^{${args[1]}}` : '';
      const body = args[2] || '';
      return `${cmd}${lower}${upper} ${body}`.trim();
    });
    s = replaceSwitch(s, /\\x\\to\s*\(/gi, (args) => `\\overline{${args.join(',')}}`);
    s = replaceSwitch(s, /\\b(?:\\lc\\[^\s(]+|\\rc\\[^\s(]+)*\s*\(/gi, (args) => `\\left(${args.join(',')}\\right)`);
    return s;
  };

  const latex = convertExpr(cleaned).trim();
  if (!latex) return '';
  return `$${latex}$`;
}

/**
 * Escapes raw text inside OMML <m:t> for safe KaTeX LaTeX rendering.
 */
function ommlTextToLatex(raw: string): string {
  const norm = normalizeMathUnicodeChars(raw);
  let out = '';
  for (const ch of norm) {
    switch (ch) {
      case '%':
        out += '\\%';
        break;
      case '#':
        out += '\\#';
        break;
      case '&':
        out += '\\&';
        break;
      case '×':
        out += ' \\times ';
        break;
      case '÷':
        out += ' \\div ';
        break;
      case '±':
        out += ' \\pm ';
        break;
      case '∓':
        out += ' \\mp ';
        break;
      case '≤':
        out += ' \\le ';
        break;
      case '≥':
        out += ' \\ge ';
        break;
      case '≠':
        out += ' \\ne ';
        break;
      case '≈':
        out += ' \\approx ';
        break;
      case '≡':
        out += ' \\equiv ';
        break;
      case '∞':
        out += '\\infty ';
        break;
      case '→':
        out += ' \\to ';
        break;
      case '←':
        out += ' \\leftarrow ';
        break;
      case '↔':
        out += ' \\leftrightarrow ';
        break;
      case '⇒':
        out += ' \\Rightarrow ';
        break;
      case '⇐':
        out += ' \\Leftarrow ';
        break;
      case '⇔':
        out += ' \\Leftrightarrow ';
        break;
      case '°':
        out += '^\\circ ';
        break;
      case '·':
      case '⋅':
        out += ' \\cdot ';
        break;
      case '−':
        out += '-';
        break;
      case '∈':
        out += ' \\in ';
        break;
      case '∉':
        out += ' \\notin ';
        break;
      case '⊂':
        out += ' \\subset ';
        break;
      case '⊆':
        out += ' \\subseteq ';
        break;
      case '⊃':
        out += ' \\supset ';
        break;
      case '⊇':
        out += ' \\supseteq ';
        break;
      case '∪':
        out += ' \\cup ';
        break;
      case '∩':
        out += ' \\cap ';
        break;
      case '∅':
        out += '\\emptyset ';
        break;
      case '∠':
        out += '\\angle ';
        break;
      case '⊥':
        out += ' \\perp ';
        break;
      case '∥':
        out += ' \\parallel ';
        break;
      case '∀':
        out += '\\forall ';
        break;
      case '∃':
        out += '\\exists ';
        break;
      case '∧':
        out += ' \\land ';
        break;
      case '∨':
        out += ' \\lor ';
        break;
      case '¬':
        out += '\\neg ';
        break;
      case '∴':
        out += ' \\therefore ';
        break;
      case '∵':
        out += ' \\because ';
        break;
      case '∂':
        out += '\\partial ';
        break;
      case '∇':
        out += '\\nabla ';
        break;
      case '…':
        out += '\\ldots ';
        break;
      case '′':
        out += "'";
        break;
      case '″':
        out += "''";
        break;
      case 'α':
        out += '\\alpha ';
        break;
      case 'β':
        out += '\\beta ';
        break;
      case 'γ':
        out += '\\gamma ';
        break;
      case 'δ':
        out += '\\delta ';
        break;
      case 'ε':
        out += '\\varepsilon ';
        break;
      case 'ζ':
        out += '\\zeta ';
        break;
      case 'η':
        out += '\\eta ';
        break;
      case 'θ':
        out += '\\theta ';
        break;
      case 'ι':
        out += '\\iota ';
        break;
      case 'κ':
        out += '\\kappa ';
        break;
      case 'λ':
        out += '\\lambda ';
        break;
      case 'μ':
        out += '\\mu ';
        break;
      case 'ν':
        out += '\\nu ';
        break;
      case 'ξ':
        out += '\\xi ';
        break;
      case 'π':
        out += '\\pi ';
        break;
      case 'ρ':
        out += '\\rho ';
        break;
      case 'σ':
        out += '\\sigma ';
        break;
      case 'τ':
        out += '\\tau ';
        break;
      case 'υ':
        out += '\\upsilon ';
        break;
      case 'φ':
        out += '\\varphi ';
        break;
      case 'χ':
        out += '\\chi ';
        break;
      case 'ψ':
        out += '\\psi ';
        break;
      case 'ω':
        out += '\\omega ';
        break;
      case 'Γ':
        out += '\\Gamma ';
        break;
      case 'Δ':
        out += '\\Delta ';
        break;
      case 'Θ':
        out += '\\Theta ';
        break;
      case 'Λ':
        out += '\\Lambda ';
        break;
      case 'Ξ':
        out += '\\Xi ';
        break;
      case 'Π':
        out += '\\Pi ';
        break;
      case 'Σ':
        out += '\\Sigma ';
        break;
      case 'Φ':
        out += '\\Phi ';
        break;
      case 'Ψ':
        out += '\\Psi ';
        break;
      case 'Ω':
        out += '\\Omega ';
        break;
      default:
        out += ch;
        break;
    }
  }
  return out;
}

function escapeLatexDelimiter(chr: string, isLeft: boolean): string {
  const c = chr.trim();
  if (!c) return '.';
  if (c === '{') return '\\{';
  if (c === '}') return '\\}';
  if (c === '‖' || c === '||') return '\\|';
  if (c === '⟨' || c === '〈') return '\\langle';
  if (c === '⟩' || c === '〉') return '\\rangle';
  if (c === '⌊') return '\\lfloor';
  if (c === '⌋') return '\\rfloor';
  if (c === '⌈') return '\\lceil';
  if (c === '⌉') return '\\rceil';
  if (c === '(' || c === ')' || c === '[' || c === ']' || c === '|') return c;
  return isLeft ? '(' : ')';
}

function getDirectOmmlChildren(parent: Element, name: string): Element[] {
  const out: Element[] = [];
  for (let i = 0; i < parent.children.length; i++) {
    const ch = parent.children[i];
    const cl = ch.localName || ch.tagName.replace(/^.*:/, '');
    if (cl === name) out.push(ch);
  }
  return out;
}

function getDirectOmmlChild(parent: Element, name: string): Element | null {
  for (let i = 0; i < parent.children.length; i++) {
    const ch = parent.children[i];
    const cl = ch.localName || ch.tagName.replace(/^.*:/, '');
    if (cl === name) return ch;
  }
  return null;
}

function getOmmlValAttr(el: Element | null): string | null {
  if (!el) return null;
  const v = el.getAttribute('m:val') ?? el.getAttribute('val');
  return v;
}

function extractOmathMatrixLatex(mNode: Element, envName: string): string {
  const rows = getDirectOmmlChildren(mNode, 'mr');
  if (rows.length === 0) return '';
  const rowStrings = rows.map((mr) => {
    const cells = getDirectOmmlChildren(mr, 'e');
    return cells.map((cell) => extractOmathLatex(cell).trim()).join(' & ');
  });
  return `\\begin{${envName}} ${rowStrings.join(' \\\\ ')} \\end{${envName}}`;
}

/**
 * Serializes a Word Office Math ML (<m:oMath> / <m:oMathPara>) element into KaTeX-ready LaTeX
 * supporting fractions, radicals, exponents, subscripts, Indonesian pre-superscript logs (^2 log 8),
 * matrices, determinants, piecewise systems, limits, integrals, summations, vectors, bars, and Greek symbols.
 */
function extractOmathLatex(node: Element): string {
  const local = node.localName || node.tagName.replace(/^.*:/, '');

  if (local === 't') {
    return ommlTextToLatex(node.textContent || '');
  }

  // Fractions: <m:f> (bar / noBar binomial / skw / lin)
  if (local === 'f') {
    const fPr = getDirectOmmlChild(node, 'fPr');
    const fType = getOmmlValAttr(fPr ? getDirectOmmlChild(fPr, 'type') : null) || 'bar';
    const numEl = getDirectOmmlChild(node, 'num');
    const denEl = getDirectOmmlChild(node, 'den');
    const num = numEl ? extractOmathLatex(numEl).trim() : '';
    const den = denEl ? extractOmathLatex(denEl).trim() : '';
    if (!num && !den) return '';
    if (fType === 'noBar') {
      return `\\binom{${num}}{${den}}`;
    }
    return `\\frac{${num}}{${den}}`;
  }

  // Superscript: <m:sSup>
  if (local === 'sSup') {
    const eEl = getDirectOmmlChild(node, 'e');
    const supEl = getDirectOmmlChild(node, 'sup');
    const base = eEl ? extractOmathLatex(eEl).trim() : '';
    const sup = supEl ? extractOmathLatex(supEl).trim() : '';
    if (!sup) return base;
    if (!base) return `{}^{${sup}}`;
    return `${base}^{${sup}}`;
  }

  // Subscript: <m:sSub>
  if (local === 'sSub') {
    const eEl = getDirectOmmlChild(node, 'e');
    const subEl = getDirectOmmlChild(node, 'sub');
    const base = eEl ? extractOmathLatex(eEl).trim() : '';
    const sub = subEl ? extractOmathLatex(subEl).trim() : '';
    if (!sub) return base;
    if (!base) return `{}_{${sub}}`;
    return `${base}_{${sub}}`;
  }

  // Subscript + Superscript: <m:sSubSup>
  if (local === 'sSubSup') {
    const eEl = getDirectOmmlChild(node, 'e');
    const subEl = getDirectOmmlChild(node, 'sub');
    const supEl = getDirectOmmlChild(node, 'sup');
    const base = eEl ? extractOmathLatex(eEl).trim() : '';
    const sub = subEl ? extractOmathLatex(subEl).trim() : '';
    const sup = supEl ? extractOmathLatex(supEl).trim() : '';
    return `${base}${sub ? `_{${sub}}` : ''}${sup ? `^{${sup}}` : ''}`;
  }

  // Pre-Subscript / Pre-Superscript: <m:sPre> (Indonesian logarithms ^2 log 8, combinatorics ^nC_r)
  if (local === 'sPre') {
    const eEl = getDirectOmmlChild(node, 'e');
    const subEl = getDirectOmmlChild(node, 'sub');
    const supEl = getDirectOmmlChild(node, 'sup');
    const base = eEl ? extractOmathLatex(eEl).trim() : '';
    const sub = subEl ? extractOmathLatex(subEl).trim() : '';
    const sup = supEl ? extractOmathLatex(supEl).trim() : '';
    return `{}${sub ? `_{${sub}}` : ''}${sup ? `^{${sup}}` : ''}${base}`;
  }

  // Radical / Root: <m:rad>
  if (local === 'rad') {
    const degEl = getDirectOmmlChild(node, 'deg');
    const eEl = getDirectOmmlChild(node, 'e');
    const deg = degEl ? extractOmathLatex(degEl).trim() : '';
    const inner = eEl ? extractOmathLatex(eEl).trim() : '';
    return deg ? `\\sqrt[${deg}]{${inner}}` : `\\sqrt{${inner}}`;
  }

  // Delimiters: <m:d> — smartly detects matrices & piecewise systems inside delimiters!
  if (local === 'd') {
    const dPr = getDirectOmmlChild(node, 'dPr');
    let begChr = '(';
    let endChr = ')';
    let sepChr = ', ';
    if (dPr) {
      const begEl = getDirectOmmlChild(dPr, 'begChr');
      const endEl = getDirectOmmlChild(dPr, 'endChr');
      const sepEl = getDirectOmmlChild(dPr, 'sepChr');
      if (begEl) {
        const bv = getOmmlValAttr(begEl);
        if (bv !== null) begChr = bv;
      }
      if (endEl) {
        const ev = getOmmlValAttr(endEl);
        if (ev !== null) endChr = ev;
      }
      if (sepEl) {
        const sv = getOmmlValAttr(sepEl);
        if (sv !== null) sepChr = sv ? `${sv} ` : ', ';
      }
    }

    const eChildren = getDirectOmmlChildren(node, 'e');
    // Check if delimiter wraps a matrix <m:m> or equation array <m:eqArr>
    if (eChildren.length === 1) {
      const singleE = eChildren[0];
      const matrixChild = getDirectOmmlChild(singleE, 'm');
      const eqArrChild = getDirectOmmlChild(singleE, 'eqArr');
      const nonEmptyChildren = Array.from(singleE.children).filter((ch) => {
        const cl = ch.localName || ch.tagName.replace(/^.*:/, '');
        return !cl.endsWith('Pr');
      });
      if (matrixChild && nonEmptyChildren.length === 1) {
        if (begChr === '(' && endChr === ')') return extractOmathMatrixLatex(matrixChild, 'pmatrix');
        if (begChr === '[' && endChr === ']') return extractOmathMatrixLatex(matrixChild, 'bmatrix');
        if (begChr === '|' && endChr === '|') return extractOmathMatrixLatex(matrixChild, 'vmatrix');
        if (begChr === '{' && endChr === '}') return extractOmathMatrixLatex(matrixChild, 'Bmatrix');
        if (begChr === '{' && !endChr.trim()) return extractOmathMatrixLatex(matrixChild, 'cases');
      }
      if (eqArrChild && nonEmptyChildren.length === 1 && begChr === '{' && !endChr.trim()) {
        const eqRows = getDirectOmmlChildren(eqArrChild, 'e').map((er) =>
          extractOmathLatex(er).trim()
        );
        return `\\begin{cases} ${eqRows.join(' \\\\ ')} \\end{cases}`;
      }
    }

    const parts = eChildren.map((ch) => extractOmathLatex(ch).trim());
    const leftDelim = escapeLatexDelimiter(begChr, true);
    const rightDelim = escapeLatexDelimiter(endChr, false);
    const joined = parts.join(sepChr);
    return `\\left${leftDelim}${joined}\\right${rightDelim}`;
  }

  // Standalone Matrix: <m:m>
  if (local === 'm') {
    return extractOmathMatrixLatex(node, 'matrix');
  }

  // Equation Array (multi-line aligned equations): <m:eqArr>
  if (local === 'eqArr') {
    const eqRows = getDirectOmmlChildren(node, 'e').map((er) =>
      extractOmathLatex(er).trim()
    );
    if (eqRows.length === 0) return '';
    if (eqRows.length === 1) return eqRows[0];
    return `\\begin{aligned} ${eqRows.join(' \\\\ ')} \\end{aligned}`;
  }

  // N-ary operators: <m:nary> (integrals, summations, products, big unions/intersections)
  if (local === 'nary') {
    const naryPr = getDirectOmmlChild(node, 'naryPr');
    let rawSym = '∫';
    if (naryPr) {
      const chrEl = getDirectOmmlChild(naryPr, 'chr');
      const v = getOmmlValAttr(chrEl);
      if (v) rawSym = v;
    }
    const naryCmdMap: Record<string, string> = {
      '∫': '\\int',
      '∬': '\\iint',
      '∭': '\\iiint',
      '∮': '\\oint',
      '∑': '\\sum',
      '∏': '\\prod',
      '⋃': '\\bigcup',
      '⋂': '\\bigcap',
    };
    const symCmd = naryCmdMap[rawSym] || ommlTextToLatex(rawSym).trim() || '\\sum';
    const subEl = getDirectOmmlChild(node, 'sub');
    const supEl = getDirectOmmlChild(node, 'sup');
    const eEl = getDirectOmmlChild(node, 'e');
    const sub = subEl ? extractOmathLatex(subEl).trim() : '';
    const sup = supEl ? extractOmathLatex(supEl).trim() : '';
    const body = eEl ? extractOmathLatex(eEl).trim() : '';
    return `${symCmd}${sub ? `_{${sub}}` : ''}${sup ? `^{${sup}}` : ''}${body ? ` ${body}` : ''}`;
  }

  // Lower limit: <m:limLow> (e.g. lim_{x -> 0}, max_{...}, min_{...})
  if (local === 'limLow') {
    const eEl = getDirectOmmlChild(node, 'e');
    const limEl = getDirectOmmlChild(node, 'lim');
    const base = eEl ? extractOmathLatex(eEl).trim() : '';
    const lim = limEl ? extractOmathLatex(limEl).trim() : '';
    const cleanBase = base.replace(/\s+/g, '').toLowerCase();
    if (['lim', 'max', 'min', 'sup', 'inf', 'det', 'gcd'].includes(cleanBase)) {
      return `\\${cleanBase}${lim ? `_{${lim}}` : ''}`;
    }
    return lim ? `\\underset{${lim}}{${base}}` : base;
  }

  // Upper limit: <m:limUpp>
  if (local === 'limUpp') {
    const eEl = getDirectOmmlChild(node, 'e');
    const limEl = getDirectOmmlChild(node, 'lim');
    const base = eEl ? extractOmathLatex(eEl).trim() : '';
    const lim = limEl ? extractOmathLatex(limEl).trim() : '';
    return lim ? `\\overset{${lim}}{${base}}` : base;
  }

  // Named Functions: <m:func> (sin, cos, tan, log, ln, lim, etc.)
  if (local === 'func') {
    const fNameEl = getDirectOmmlChild(node, 'fName');
    const eEl = getDirectOmmlChild(node, 'e');
    let fName = fNameEl ? extractOmathLatex(fNameEl).trim() : '';
    const arg = eEl ? extractOmathLatex(eEl).trim() : '';
    const plainFn = fName.replace(/\s+/g, '');
    if (
      /^(?:sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|sinh|cosh|tanh|log|ln|exp|det|lim|max|min|mod)$/i.test(
        plainFn
      )
    ) {
      fName = `\\${plainFn.toLowerCase()}`;
    }
    return `${fName}${arg ? ` ${arg}` : ''}`;
  }

  // Bar / Overline / Underline: <m:bar>
  if (local === 'bar') {
    const barPr = getDirectOmmlChild(node, 'barPr');
    const pos = getOmmlValAttr(barPr ? getDirectOmmlChild(barPr, 'pos') : null) || 'top';
    const eEl = getDirectOmmlChild(node, 'e');
    const inner = eEl ? extractOmathLatex(eEl).trim() : '';
    return pos === 'bot' ? `\\underline{${inner}}` : `\\overline{${inner}}`;
  }

  // Accents (Vectors, hats, bars, dots): <m:acc>
  if (local === 'acc') {
    const accPr = getDirectOmmlChild(node, 'accPr');
    const chr = getOmmlValAttr(accPr ? getDirectOmmlChild(accPr, 'chr') : null) || '\u0302';
    const eEl = getDirectOmmlChild(node, 'e');
    const inner = eEl ? extractOmathLatex(eEl).trim() : '';
    if (chr === '\u20D7' || chr === '→' || chr === '\u2192') return `\\vec{${inner}}`;
    if (chr === '\u0302' || chr === '^') return inner.length > 1 ? `\\widehat{${inner}}` : `\\hat{${inner}}`;
    if (chr === '\u0304' || chr === '\u0305' || chr === '¯') return inner.length > 1 ? `\\overline{${inner}}` : `\\bar{${inner}}`;
    if (chr === '\u0303' || chr === '~') return `\\tilde{${inner}}`;
    if (chr === '\u0307' || chr === '˙') return `\\dot{${inner}}`;
    if (chr === '\u0308' || chr === '¨') return `\\ddot{${inner}}`;
    return `\\bar{${inner}}`;
  }

  // Group Character (overbrace / underbrace): <m:groupChr>
  if (local === 'groupChr') {
    const gcPr = getDirectOmmlChild(node, 'groupChrPr');
    const chr = getOmmlValAttr(gcPr ? getDirectOmmlChild(gcPr, 'chr') : null) || '⏟';
    const pos = getOmmlValAttr(gcPr ? getDirectOmmlChild(gcPr, 'pos') : null) || 'bot';
    const eEl = getDirectOmmlChild(node, 'e');
    const inner = eEl ? extractOmathLatex(eEl).trim() : '';
    if (chr === '⏞' || pos === 'top') return `\\overbrace{${inner}}`;
    return `\\underbrace{${inner}}`;
  }

  // Box / BorderBox / Phantom
  if (local === 'borderBox') {
    const eEl = getDirectOmmlChild(node, 'e');
    const inner = eEl ? extractOmathLatex(eEl).trim() : '';
    return `\\boxed{${inner}}`;
  }

  if (
    local === 'rPr' ||
    local === 'ctrlPr' ||
    local === 'fPr' ||
    local === 'radPr' ||
    local === 'dPr' ||
    local === 'naryPr' ||
    local === 'sSupPr' ||
    local === 'sSubPr' ||
    local === 'sSubSupPr' ||
    local === 'sPrePr' ||
    local === 'mPr' ||
    local === 'eqArrPr' ||
    local === 'funcPr' ||
    local === 'limLowPr' ||
    local === 'limUppPr' ||
    local === 'barPr' ||
    local === 'accPr' ||
    local === 'groupChrPr' ||
    local === 'boxPr' ||
    local === 'borderBoxPr' ||
    local === 'phantPr' ||
    local === 'oMathParaPr'
  ) {
    return '';
  }

  let out = '';
  for (let i = 0; i < node.children.length; i++) {
    out += extractOmathLatex(node.children[i]);
  }
  return out;
}

/**
 * Wraps an extracted OMML expression into clean $...$ LaTeX (normalizing excess spaces)
 * while preserving plain readability for simple punctuation-only fragments.
 */
function extractOmathText(node: Element): string {
  const raw = extractOmathLatex(node)
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
  if (!raw) return '';
  // If the entire OMML box is just simple punctuation or a bare number with no math syntax, keep cleanly wrapped or plain
  if (/^[.,;:!?]+$/.test(raw)) return raw;
  return `$${raw}$`;
}

interface DocxStyleAndNumMeta {
  numFormatMap: Record<string, string>; // `${numId}:${ilvl}` -> 'decimal' | 'upperLetter' | 'lowerLetter' | ...
  styleNumMap: Record<string, { numId: string; ilvl: number }>;
  redStyleIds: Set<string>;
  relImageMap: Record<string, string>;
}

/**
 * Parses both word/numbering.xml and word/styles.xml so we can resolve numbering formats,
 * style-based numbering, style-based red colors, and relationship image maps.
 */
function parseDocxStyleAndNumbering(
  numberingXml?: string,
  stylesXml?: string,
  relImageMap: Record<string, string> = {}
): DocxStyleAndNumMeta {
  const numFormatMap: Record<string, string> = {};
  const styleNumMap: Record<string, { numId: string; ilvl: number }> = {};
  const redStyleIds = new Set<string>();
  const styleToNumStyleLink: Record<string, string> = {};
  const styleBasedOnMap: Record<string, string> = {};

  const parser = new DOMParser();

  if (stylesXml) {
    try {
      const sDoc = parser.parseFromString(stylesXml, 'application/xml');
      const allEls = sDoc.getElementsByTagName('*');
      for (let i = 0; i < allEls.length; i++) {
        const el = allEls[i];
        const local = el.localName || el.tagName.replace(/^.*:/, '');
        if (local === 'style') {
          const styleId =
            el.getAttribute('w:styleId') || el.getAttribute('styleId') || '';
          if (!styleId) continue;

          if (checkXmlNodeHasRed(el)) {
            redStyleIds.add(styleId);
          }

          let numId: string | undefined;
          let ilvl = 0;
          const children = el.getElementsByTagName('*');
          for (let j = 0; j < children.length; j++) {
            const c = children[j];
            const cLocal = c.localName || c.tagName.replace(/^.*:/, '');
            if (cLocal === 'basedOn') {
              const parentStyle =
                c.getAttribute('w:val') || c.getAttribute('val') || '';
              if (parentStyle) {
                styleBasedOnMap[styleId] = parentStyle;
              }
            } else if (cLocal === 'numId') {
              numId = c.getAttribute('w:val') || c.getAttribute('val') || undefined;
            } else if (cLocal === 'ilvl') {
              const v = c.getAttribute('w:val') || c.getAttribute('val');
              if (v !== null) ilvl = parseInt(v, 10);
            }
          }
          if (numId) {
            styleNumMap[styleId] = { numId, ilvl };
          }
        }
      }

      // Resolve basedOn inheritance up to 5 levels deep
      for (let pass = 0; pass < 5; pass++) {
        Object.entries(styleBasedOnMap).forEach(([childId, parentId]) => {
          if (!styleNumMap[childId] && styleNumMap[parentId]) {
            styleNumMap[childId] = { ...styleNumMap[parentId] };
          }
          if (redStyleIds.has(parentId)) {
            redStyleIds.add(childId);
          }
        });
      }
    } catch {
      // Ignore styles XML error
    }
  }

  if (numberingXml) {
    try {
      const doc = parser.parseFromString(numberingXml, 'application/xml');
      const abstractMap: Record<string, Record<string, string>> = {};

      const allEls = doc.getElementsByTagName('*');
      for (let i = 0; i < allEls.length; i++) {
        const el = allEls[i];
        const local = el.localName || el.tagName.replace(/^.*:/, '');
        if (local === 'abstractNum') {
          const absId =
            el.getAttribute('w:abstractNumId') ||
            el.getAttribute('abstractNumId') ||
            '';
          if (!absId) continue;
          abstractMap[absId] = {};
          const children = el.getElementsByTagName('*');
          for (let j = 0; j < children.length; j++) {
            const child = children[j];
            const cLocal = child.localName || child.tagName.replace(/^.*:/, '');
            if (cLocal === 'numStyleLink' || cLocal === 'styleLink') {
              const linkedStyle =
                child.getAttribute('w:val') || child.getAttribute('val') || '';
              if (linkedStyle) {
                styleToNumStyleLink[absId] = linkedStyle;
              }
            } else if (cLocal === 'lvl') {
              const ilvl =
                child.getAttribute('w:ilvl') || child.getAttribute('ilvl') || '0';
              const lvlChildren = child.getElementsByTagName('*');
              for (let k = 0; k < lvlChildren.length; k++) {
                const lc = lvlChildren[k];
                const lcLocal = lc.localName || lc.tagName.replace(/^.*:/, '');
                if (lcLocal === 'numFmt') {
                  const fmtVal =
                    lc.getAttribute('w:val') || lc.getAttribute('val') || '';
                  abstractMap[absId][ilvl] = fmtVal;
                }
              }
            }
          }
        }
      }

      const numToAbsId: Record<string, string> = {};
      for (let i = 0; i < allEls.length; i++) {
        const el = allEls[i];
        const local = el.localName || el.tagName.replace(/^.*:/, '');
        if (local === 'num') {
          const numId =
            el.getAttribute('w:numId') || el.getAttribute('numId') || '';
          if (!numId) continue;
          const children = el.getElementsByTagName('*');
          for (let j = 0; j < children.length; j++) {
            const child = children[j];
            const cLocal = child.localName || child.tagName.replace(/^.*:/, '');
            if (cLocal === 'abstractNumId') {
              const absId =
                child.getAttribute('w:val') || child.getAttribute('val') || '';
              if (absId) {
                numToAbsId[numId] = absId;
                if (abstractMap[absId]) {
                  Object.entries(abstractMap[absId]).forEach(([ilvl, fmt]) => {
                    numFormatMap[`${numId}:${ilvl}`] = fmt;
                  });
                }
              }
            } else if (cLocal === 'lvlOverride') {
              const ilvl =
                child.getAttribute('w:ilvl') || child.getAttribute('ilvl') || '0';
              const ovChildren = child.getElementsByTagName('*');
              for (let k = 0; k < ovChildren.length; k++) {
                const oc = ovChildren[k];
                const ocLocal = oc.localName || oc.tagName.replace(/^.*:/, '');
                if (ocLocal === 'numFmt') {
                  const fmtVal =
                    oc.getAttribute('w:val') || oc.getAttribute('val') || '';
                  if (fmtVal) {
                    numFormatMap[`${numId}:${ilvl}`] = fmtVal;
                  }
                }
              }
            }
          }
        }
      }

      // Second pass for numStyleLink / styleLink
      Object.entries(numToAbsId).forEach(([numId, absId]) => {
        const linkedStyleId = styleToNumStyleLink[absId];
        if (linkedStyleId && styleNumMap[linkedStyleId]) {
          const targetNumId = styleNumMap[linkedStyleId].numId;
          const targetAbsId = numToAbsId[targetNumId];
          if (targetAbsId && abstractMap[targetAbsId]) {
            Object.entries(abstractMap[targetAbsId]).forEach(([ilvl, fmt]) => {
              numFormatMap[`${numId}:${ilvl}`] = fmt;
            });
          }
        }
      });
    } catch {
      // Ignore numbering XML parse error
    }
  }

  return { numFormatMap, styleNumMap, redStyleIds, relImageMap };
}

/**
 * Checks if a node is inside a nested <w:tbl>, <w:txbxContent>, <m:oMath>, or <w:del> relative to pEl.
 */
function isInsideNestedContainer(node: Element, pEl: Element): boolean {
  let curr: Element | null = node.parentElement;
  while (curr && curr !== pEl) {
    const local = curr.localName || curr.tagName.replace(/^.*:/, '');
    if (
      local === 'txbxContent' ||
      local === 'tbl' ||
      local === 'oMath' ||
      local === 'del'
    ) {
      return true;
    }
    curr = curr.parentElement;
  }
  return false;
}

/**
 * Parses a single <w:p> element into one or more ParsedParagraphs.
 */
function parseSingleDocxParagraphElement(
  pEl: Element,
  meta: DocxStyleAndNumMeta,
  inheritedRed: boolean = false
): ParsedParagraph[] {
  let paragraphLevelRed = inheritedRed;
  let numId: string | undefined;
  let ilvl: number | undefined;
  let pStyleId: string | undefined;

  for (let c = 0; c < pEl.children.length; c++) {
    const child = pEl.children[c];
    const cLocal = child.localName || child.tagName.replace(/^.*:/, '');
    if (cLocal === 'pPr') {
      if (checkXmlNodeHasRed(child)) {
        paragraphLevelRed = true;
      }
      for (let pc = 0; pc < child.children.length; pc++) {
        const pSub = child.children[pc];
        const pSubLocal = pSub.localName || pSub.tagName.replace(/^.*:/, '');
        if (pSubLocal === 'pStyle') {
          pStyleId =
            pSub.getAttribute('w:val') || pSub.getAttribute('val') || undefined;
          if (pStyleId && meta.redStyleIds.has(pStyleId)) {
            paragraphLevelRed = true;
          }
        } else if (pSubLocal === 'rPr' && checkXmlNodeHasRed(pSub)) {
          paragraphLevelRed = true;
        } else if (pSubLocal === 'numPr') {
          const numChildren = pSub.getElementsByTagName('*');
          for (let nc = 0; nc < numChildren.length; nc++) {
            const nEl = numChildren[nc];
            const nLocal = nEl.localName || nEl.tagName.replace(/^.*:/, '');
            if (nLocal === 'numId') {
              numId = nEl.getAttribute('w:val') || nEl.getAttribute('val') || undefined;
            } else if (nLocal === 'ilvl') {
              const rawIlvl = nEl.getAttribute('w:val') || nEl.getAttribute('val');
              if (rawIlvl !== null) ilvl = parseInt(rawIlvl, 10);
            }
          }
        }
      }
    }
  }

  if (!numId && pStyleId && meta.styleNumMap[pStyleId]) {
    numId = meta.styleNumMap[pStyleId].numId;
    ilvl = meta.styleNumMap[pStyleId].ilvl;
  }
  if (numId === '0') {
    numId = undefined;
  }

  const segments: TextSegment[] = [];
  const paragraphImages: string[] = [];
  let hasEmbeddedDrawing = false;

  const extractRelImageId = (el: Element): string =>
    el.getAttribute('r:embed') ||
    el.getAttribute('embed') ||
    el.getAttribute('r:id') ||
    el.getAttribute('o:relid') ||
    el.getAttribute('id') ||
    '';

  const collectImagesFromDrawingNode = (node: Element) => {
    const directId = extractRelImageId(node);
    if (directId && meta.relImageMap[directId] && !paragraphImages.includes(meta.relImageMap[directId])) {
      paragraphImages.push(meta.relImageMap[directId]);
    }
    const subNodes = node.getElementsByTagName('*');
    for (let sIdx = 0; sIdx < subNodes.length; sIdx++) {
      const sub = subNodes[sIdx];
      const sLocal = sub.localName || sub.tagName.replace(/^.*:/, '');
      if (sLocal === 'blip' || sLocal === 'imagedata') {
        const rid = extractRelImageId(sub);
        if (rid && meta.relImageMap[rid] && !paragraphImages.includes(meta.relImageMap[rid])) {
          paragraphImages.push(meta.relImageMap[rid]);
        }
      }
    }
  };

  const pDescendants = pEl.getElementsByTagName('*');
  let activeEqInstrBuffer = '';
  let insideEqField = false;

  for (let rIdx = 0; rIdx < pDescendants.length; rIdx++) {
    const rEl = pDescendants[rIdx];
    const rLocal = rEl.localName || rEl.tagName.replace(/^.*:/, '');

    if (isInsideNestedContainer(rEl, pEl)) continue;

    if (rLocal === 'drawing' || rLocal === 'pict' || rLocal === 'imagedata') {
      hasEmbeddedDrawing = true;
      collectImagesFromDrawingNode(rEl);
      continue;
    }

    if (rLocal === 'fldSimple') {
      const instr = rEl.getAttribute('w:instr') || rEl.getAttribute('instr') || '';
      if (/^\s*EQ\s+/i.test(instr)) {
        const eqLatex = decodeWordEqField(instr);
        if (eqLatex) {
          segments.push({
            text: eqLatex,
            isRed: paragraphLevelRed || checkXmlNodeHasRed(rEl),
          });
        }
      }
      continue;
    }

    if (rLocal === 'oMath') {
      const mathText = extractOmathText(rEl).trim();
      if (mathText) {
        const mathIsRed = paragraphLevelRed || checkXmlNodeHasRed(rEl);
        let mathIsBold = false;
        let mathIsUnderline = false;
        let mathIsHighlight = false;
        const rPrNodes = rEl.getElementsByTagName('*');
        for (let mIdx = 0; mIdx < rPrNodes.length; mIdx++) {
          const mNode = rPrNodes[mIdx];
          const mLocal = mNode.localName || mNode.tagName.replace(/^.*:/, '');
          if (mLocal === 'rPr') {
            const mf = checkXmlNodeFormattingFlags(mNode);
            if (mf.isBold) mathIsBold = true;
            if (mf.isUnderline) mathIsUnderline = true;
            if (mf.isHighlight) mathIsHighlight = true;
          }
        }
        segments.push({
          text: mathText,
          isRed: mathIsRed,
          isBold: mathIsBold,
          isUnderline: mathIsUnderline,
          isHighlight: mathIsHighlight,
        });
      }
      continue;
    }

    if (rLocal !== 'r') continue;

    let runIsRed = paragraphLevelRed;
    let runIsBold = false;
    let runIsUnderline = false;
    let runIsHighlight = false;
    let runIsSymbolFont = false;
    let runText = '';
    let vertAlign: 'sup' | 'sub' | null = null;

    for (let rc = 0; rc < rEl.children.length; rc++) {
      const rChild = rEl.children[rc];
      const rcLocal = rChild.localName || rChild.tagName.replace(/^.*:/, '');
      if (rcLocal === 'rPr') {
        if (checkXmlNodeHasRed(rChild)) {
          runIsRed = true;
        }
        const rFlags = checkXmlNodeFormattingFlags(rChild);
        if (rFlags.isBold) runIsBold = true;
        if (rFlags.isUnderline) runIsUnderline = true;
        if (rFlags.isHighlight) runIsHighlight = true;

        for (let rSubIdx = 0; rSubIdx < rChild.children.length; rSubIdx++) {
          const rSub = rChild.children[rSubIdx];
          const rSubLocal = rSub.localName || rSub.tagName.replace(/^.*:/, '');
          if (rSubLocal === 'rStyle') {
            const rStyleId =
              rSub.getAttribute('w:val') || rSub.getAttribute('val') || '';
            if (rStyleId && meta.redStyleIds.has(rStyleId)) {
              runIsRed = true;
            }
          } else if (rSubLocal === 'vertAlign') {
            const va = (
              rSub.getAttribute('w:val') ||
              rSub.getAttribute('val') ||
              ''
            ).toLowerCase();
            if (va === 'superscript') vertAlign = 'sup';
            else if (va === 'subscript') vertAlign = 'sub';
          } else if (rSubLocal === 'rFonts') {
            const fontName = (
              rSub.getAttribute('w:ascii') ||
              rSub.getAttribute('w:hAnsi') ||
              rSub.getAttribute('ascii') ||
              ''
            )
              .trim()
              .toLowerCase();
            if (fontName === 'symbol' || fontName === 'mt extra') {
              runIsSymbolFont = true;
            }
          }
        }
      } else if (rcLocal === 'fldChar') {
        const fldType = (
          rChild.getAttribute('w:fldCharType') ||
          rChild.getAttribute('fldCharType') ||
          ''
        ).toLowerCase();
        if (fldType === 'begin') {
          insideEqField = true;
          activeEqInstrBuffer = '';
        } else if (fldType === 'end' || fldType === 'separate') {
          if (insideEqField && /^\s*EQ\s+/i.test(activeEqInstrBuffer)) {
            const eqLatex = decodeWordEqField(activeEqInstrBuffer);
            if (eqLatex) runText += eqLatex;
          }
          insideEqField = false;
          activeEqInstrBuffer = '';
        }
      } else if (rcLocal === 'instrText') {
        if (insideEqField) {
          activeEqInstrBuffer += rChild.textContent || '';
        }
      } else if (rcLocal === 't') {
        const rawT = rChild.textContent || '';
        runText += runIsSymbolFont
          ? decodeSymbolFontText(rawT)
          : normalizeMathUnicodeChars(rawT);
      } else if (rcLocal === 'sym') {
        const symFont = (
          rChild.getAttribute('w:font') ||
          rChild.getAttribute('font') ||
          ''
        )
          .trim()
          .toLowerCase();
        const symChar = rChild.getAttribute('w:char') || rChild.getAttribute('char') || '';
        const code = parseInt(symChar, 16);
        if (!Number.isNaN(code) && code > 0) {
          const symLower = symChar.toUpperCase();
          if (symLower === 'F0FC' || symLower === 'F0FE' || symLower === '00FC') {
            runText += '✓';
          } else if (symLower === 'F0A8' || symLower === 'F06F') {
            runText += '☐';
          } else if (symLower === 'F0AE' || symLower === 'F0E0') {
            runText += '→';
          } else if (code >= 0xf020 && code <= 0xf0ff) {
            const low = code - 0xf000;
            if (symFont === 'symbol' || symFont === 'mt extra' || SYMBOL_PUA_HEX_MAP[low]) {
              runText += SYMBOL_PUA_HEX_MAP[low] ?? String.fromCharCode(low);
            }
          } else if (code < 0xf000) {
            const ch = String.fromCharCode(code);
            runText +=
              symFont === 'symbol' ? SYMBOL_FONT_ASCII_MAP[ch] ?? ch : ch;
          }
        }
      } else if (rcLocal === 'tab' || rcLocal === 'ptab') {
        runText += '\t';
      } else if (rcLocal === 'br' || rcLocal === 'cr') {
        runText += '\n';
      }
    }

    if (runText.length > 0) {
      if (vertAlign) {
        const trimmedRun = runText.trim();
        if (
          trimmedRun.length > 0 &&
          trimmedRun.length <= 8 &&
          /^[0-9+\-ni()\s.,]+$/i.test(trimmedRun)
        ) {
          runText = convertToUnicodeScript(runText, vertAlign);
        } else if (
          trimmedRun.length > 0 &&
          trimmedRun.length <= 24 &&
          !/[\n]/.test(trimmedRun)
        ) {
          // Preserve algebraic superscripts/subscripts (e.g. 2^{x+1}, a_{n-1}, x^{2n}) for KaTeX rendering!
          runText = vertAlign === 'sup' ? `^{${trimmedRun}}` : `_{${trimmedRun}}`;
        }
      }
      const nonEmpty = runText.trim().length > 0;
      segments.push({
        text: runText,
        isRed: runIsRed && nonEmpty,
        isBold: runIsBold && nonEmpty,
        isUnderline: runIsUnderline && nonEmpty,
        isHighlight: runIsHighlight && nonEmpty,
      });
    }
  }

  // Only emit text placeholder "[Gambar]" if a drawing existed but could not be extracted (e.g. EMF/WMF vector)
  if (segments.length === 0 && hasEmbeddedDrawing && paragraphImages.length === 0) {
    segments.push({
      text: '[Gambar]',
      isRed: paragraphLevelRed,
    });
  } else if (hasEmbeddedDrawing && paragraphImages.length === 0) {
    const combinedTrimmed = segments.map((s) => s.text).join('').trim();
    if (/^(?:\(?[A-Ea-e][\.\)\]]|[A-Ea-e][\.\)\-:]|\d+[\.\)\-:])$/.test(combinedTrimmed)) {
      segments.push({
        text: ' [Gambar]',
        isRed: paragraphLevelRed,
      });
    }
  }

  const fullText = segments.map((s) => s.text).join('').trim();
  const result: ParsedParagraph[] = [];
  const numFormat =
    numId !== undefined ? meta.numFormatMap[`${numId}:${ilvl ?? 0}`] : undefined;

  const computeLineFormatFlags = (lineSegs: TextSegment[]) => {
    const nonEmptySegs = lineSegs.filter((s) => s.text.trim().length > 0);
    const hasBold = nonEmptySegs.some((s) => s.isBold);
    const hasUnderline = nonEmptySegs.some((s) => s.isUnderline);
    const hasHighlight = nonEmptySegs.some((s) => s.isHighlight);
    // Check if the majority of non-whitespace characters are bold
    const totalChars = nonEmptySegs.reduce((sum, s) => sum + s.text.trim().length, 0);
    const boldChars = nonEmptySegs.reduce(
      (sum, s) => sum + (s.isBold ? s.text.trim().length : 0),
      0
    );
    const isAllBold = totalChars > 0 && boldChars >= totalChars * 0.7;
    return { hasBold, hasUnderline, hasHighlight, isAllBold };
  };

  if (fullText) {
    if (fullText.includes('\n')) {
      const lines: TextSegment[][] = [[]];
      for (const seg of segments) {
        const parts = seg.text.split('\n');
        for (let pIdx = 0; pIdx < parts.length; pIdx++) {
          if (pIdx > 0) lines.push([]);
          if (parts[pIdx].length > 0) {
            const nonEmpty = parts[pIdx].trim().length > 0;
            lines[lines.length - 1].push({
              text: parts[pIdx],
              isRed: seg.isRed && nonEmpty,
              isBold: seg.isBold && nonEmpty,
              isUnderline: seg.isUnderline && nonEmpty,
              isHighlight: seg.isHighlight && nonEmpty,
            });
          }
        }
      }
      const nonEmptyLines = lines.filter(
        (lineSegs) => lineSegs.map((s) => s.text).join('').trim().length > 0
      );
      nonEmptyLines.forEach((lineSegs, lIdx) => {
        const lineText = lineSegs.map((s) => s.text).join('').trim();
        const flags = computeLineFormatFlags(lineSegs);
        result.push({
          fullText: lineText,
          hasRed: lineSegs.some((s) => s.isRed),
          ...flags,
          segments: lineSegs,
          images:
            lIdx === nonEmptyLines.length - 1 && paragraphImages.length > 0
              ? [...paragraphImages]
              : undefined,
          numId: lIdx === 0 ? numId : undefined,
          ilvl: lIdx === 0 ? ilvl : undefined,
          numFormat: lIdx === 0 ? numFormat : undefined,
        });
      });
    } else {
      const flags = computeLineFormatFlags(segments);
      result.push({
        fullText,
        hasRed: segments.some((s) => s.isRed),
        ...flags,
        segments,
        images: paragraphImages.length > 0 ? [...paragraphImages] : undefined,
        numId,
        ilvl,
        numFormat,
      });
    }
  } else if (paragraphImages.length > 0) {
    result.push({
      fullText: '',
      hasRed: paragraphLevelRed,
      segments: [],
      images: [...paragraphImages],
      numId,
      ilvl,
      numFormat,
    });
  }

  // Also extract any paragraphs inside nested <w:txbxContent> (Word Text Boxes)
  for (let i = 0; i < pDescendants.length; i++) {
    const dEl = pDescendants[i];
    const dLocal = dEl.localName || dEl.tagName.replace(/^.*:/, '');
    if (dLocal === 'txbxContent') {
      for (let tcIdx = 0; tcIdx < dEl.children.length; tcIdx++) {
        const tChild = dEl.children[tcIdx];
        const tLocal = tChild.localName || tChild.tagName.replace(/^.*:/, '');
        if (tLocal === 'p') {
          result.push(
            ...parseSingleDocxParagraphElement(tChild, meta, inheritedRed)
          );
        }
      }
    }
  }

  return result;
}

/**
 * Parses a <w:tbl> XML element into a ParsedTable.
 */
function parseDocxTableElement(
  tblEl: Element,
  meta: DocxStyleAndNumMeta
): ParsedTable {
  const rows: ParsedTableCell[][] = [];

  for (let i = 0; i < tblEl.children.length; i++) {
    const trEl = tblEl.children[i];
    const trLocal = trEl.localName || trEl.tagName.replace(/^.*:/, '');
    if (trLocal !== 'tr') continue;

    const rowCells: ParsedTableCell[] = [];
    for (let j = 0; j < trEl.children.length; j++) {
      const tcEl = trEl.children[j];
      const tcLocal = tcEl.localName || tcEl.tagName.replace(/^.*:/, '');
      if (tcLocal !== 'tc') continue;

      let cellHasRedBg = false;
      let cellHasHighlightBg = false;
      const cellParagraphs: ParsedParagraph[] = [];
      const nestedTables: ParsedTable[] = [];

      for (let k = 0; k < tcEl.children.length; k++) {
        const cChild = tcEl.children[k];
        const cLocal = cChild.localName || cChild.tagName.replace(/^.*:/, '');
        if (cLocal === 'tcPr') {
          if (checkXmlNodeHasRed(cChild)) {
            cellHasRedBg = true;
          }
          if (checkXmlNodeFormattingFlags(cChild).isHighlight) {
            cellHasHighlightBg = true;
          }
        } else if (cLocal === 'p') {
          cellParagraphs.push(
            ...parseSingleDocxParagraphElement(cChild, meta, cellHasRedBg)
          );
        } else if (cLocal === 'tbl') {
          nestedTables.push(parseDocxTableElement(cChild, meta));
        }
      }

      const fullText = cellParagraphs
        .map((p) => p.fullText)
        .filter(Boolean)
        .join('\n')
        .trim();
      const hasRed = cellHasRedBg || cellParagraphs.some((p) => p.hasRed);
      const hasBold = cellParagraphs.some((p) => p.isAllBold);
      const hasUnderline = cellParagraphs.some((p) => p.hasUnderline);
      const hasHighlight =
        cellHasHighlightBg || cellParagraphs.some((p) => p.hasHighlight);
      const cellImages = mergeUniqueImages(...cellParagraphs.map((p) => p.images));

      rowCells.push({
        fullText,
        hasRed,
        hasBold,
        hasUnderline,
        hasHighlight,
        paragraphs: cellParagraphs,
        nestedTables,
        images: cellImages,
      });
    }

    if (rowCells.length > 0) {
      rows.push(rowCells);
    }
  }

  return { rows };
}

/**
 * Annotates paragraphs that use Word's automatic list numbering (<w:numPr>)
 * with autoQuestionNumber (1, 2, 3...) or autoOptionLetter ('A'..'E').
 */
function annotateAutoNumberedParagraphs(paragraphs: ParsedParagraph[]): void {
  const counters: Record<string, number> = {};
  const consecutiveRunLen: Record<string, number> = {};
  let prevKey: string | null = null;

  for (let i = 0; i < paragraphs.length; i++) {
    const p = paragraphs[i];
    const ilvl = p.ilvl ?? 0;
    const isNonOptionNumFmt =
      p.numFormat === 'bullet' ||
      p.numFormat === 'decimal' ||
      p.numFormat === 'decimalZero' ||
      p.numFormat === 'lowerRoman' ||
      p.numFormat === 'upperRoman' ||
      p.numFormat === 'none';
    const isOptionNum =
      Boolean(p.numId) &&
      (p.numFormat === 'upperLetter' ||
        p.numFormat === 'lowerLetter' ||
        (ilvl > 0 && !isNonOptionNumFmt));

    // If this paragraph is NOT an auto-numbered option, reset all option counters
    // so the next question's auto-numbered options ALWAYS start at 'A'!
    if (!isOptionNum) {
      Object.keys(counters).forEach((k) => {
        if (k.startsWith('OPT:')) {
          delete counters[k];
        }
      });
    }

    // If the previous paragraph was part of a consecutive decimal list cluster (>= 2 adjacent items, like statements 1, 2, 3, 4)
    // and this paragraph has a different key, reset that cluster counter so the next question's statement list starts at 1!
    const currDecimalKey =
      p.numId && !isOptionNum ? `DEC:${p.numId}:${ilvl}` : null;
    if (prevKey && prevKey !== currDecimalKey && (consecutiveRunLen[prevKey] || 0) >= 2) {
      delete counters[prevKey];
      delete consecutiveRunLen[prevKey];
    }

    if (!p.numId) {
      prevKey = null;
      continue;
    }

    if (isOptionNum) {
      const optKey = `OPT:${p.numId}:${ilvl}`;
      counters[optKey] = (counters[optKey] || 0) + 1;
      const count = counters[optKey];
      const letters = ['A', 'B', 'C', 'D', 'E'];
      p.autoOptionLetter = letters[(count - 1) % 5];
      prevKey = null;
    } else if ((p.numFormat === 'decimal' || p.numFormat === 'decimalZero') && ilvl === 0) {
      const decKey = `DEC:${p.numId}:${ilvl}`;
      counters[decKey] = (counters[decKey] || 0) + 1;
      if (prevKey === decKey) {
        consecutiveRunLen[decKey] = (consecutiveRunLen[decKey] || 1) + 1;
      } else {
        consecutiveRunLen[decKey] = 1;
      }
      p.autoQuestionNumber = counters[decKey];
      prevKey = decKey;
    } else {
      prevKey = null;
    }
  }
}

/**
 * Extracts ordered DocumentBlocks (paragraphs and tables) from word/document.xml
 */
function parseDocxDocumentBlocks(
  documentXml: string,
  numberingXml?: string,
  stylesXml?: string,
  relImageMap: Record<string, string> = {}
): DocumentBlock[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(documentXml, 'application/xml');
  const meta = parseDocxStyleAndNumbering(numberingXml, stylesXml, relImageMap);
  const blocks: DocumentBlock[] = [];
  const allTopParagraphs: ParsedParagraph[] = [];

  const walkContainer = (container: Element) => {
    for (let i = 0; i < container.children.length; i++) {
      const el = container.children[i];
      const local = el.localName || el.tagName.replace(/^.*:/, '');
      if (local === 'p') {
        const paras = parseSingleDocxParagraphElement(el, meta, false);
        for (const p of paras) {
          allTopParagraphs.push(p);
          blocks.push({ kind: 'paragraph', paragraph: p });
        }
      } else if (local === 'tbl') {
        const table = parseDocxTableElement(el, meta);
        if (table.rows.length > 0) {
          for (const r of table.rows) {
            for (const c of r) {
              annotateAutoNumberedParagraphs(c.paragraphs);
            }
          }
          blocks.push({ kind: 'table', table });
        }
      } else if (
        local === 'body' ||
        local === 'sdt' ||
        local === 'sdtContent' ||
        local === 'customXml'
      ) {
        walkContainer(el);
      }
    }
  };

  if (doc.documentElement) {
    walkContainer(doc.documentElement);
  }

  annotateAutoNumberedParagraphs(allTopParagraphs);
  return blocks;
}

/**
 * Parses HTML or plain-text .doc files into DocumentBlocks (supporting <table> as well as <p>)
 */
function parseHtmlOrTextDocBlocks(rawContent: string): DocumentBlock[] {
  const blocks: DocumentBlock[] = [];

  if (/<(html|body|p|div|span|font|table)/i.test(rawContent)) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(rawContent, 'text/html');

    const redClasses = new Set<string>();
    const styles = doc.querySelectorAll('style');
    styles.forEach((styleEl) => {
      const css = styleEl.textContent || '';
      const ruleRegex = /\.([a-zA-Z0-9_-]+)\s*\{([^}]*)\}/g;
      let match: RegExpExecArray | null;
      while ((match = ruleRegex.exec(css)) !== null) {
        const className = match[1];
        const body = match[2];
        const colorMatch = body.match(/(?:^|;|\s)color\s*:\s*([^;]+)/i);
        if (colorMatch && isRedColorValue(colorMatch[1])) {
          redClasses.add(className);
        }
      }
    });

    function cleanStyleVal(s: string): string {
      return s.replace(/!important/i, '').trim();
    }

    const getElementFormatting = (
      el: Element | null,
      stopAt?: Element
    ): { isRed: boolean; isBold: boolean; isUnderline: boolean; isHighlight: boolean } => {
      let isRed = false;
      let isBold = false;
      let isUnderline = false;
      let isHighlight = false;
      let curr: Element | null = el;
      while (curr && curr !== doc.body && curr !== doc.documentElement) {
        const tag = curr.tagName.toUpperCase();
        if (tag === 'B' || tag === 'STRONG') isBold = true;
        if (tag === 'U') isUnderline = true;
        if (tag === 'MARK') isHighlight = true;

        const styleAttr = curr.getAttribute('style') || '';
        const colorStyleMatch = styleAttr.match(/(?:^|;|\s)color\s*:\s*([^;]+)/i);
        if (colorStyleMatch && isRedColorValue(cleanStyleVal(colorStyleMatch[1]))) {
          isRed = true;
        }

        const bgStyleMatch = styleAttr.match(/background(?:-color)?\s*:\s*([^;]+)/i);
        if (bgStyleMatch) {
          const bgVal = cleanStyleVal(bgStyleMatch[1]).toLowerCase();
          if (isRedColorValue(bgVal)) {
            isRed = true;
          } else if (
            bgVal &&
            bgVal !== 'transparent' &&
            bgVal !== 'none' &&
            bgVal !== 'white' &&
            bgVal !== '#fff' &&
            bgVal !== '#ffffff' &&
            !/^rgba?\(\s*255\s*,\s*255\s*,\s*255/.test(bgVal)
          ) {
            isHighlight = true;
          }
        }

        const fwMatch = styleAttr.match(/font-weight\s*:\s*([^;]+)/i);
        if (fwMatch) {
          const fw = cleanStyleVal(fwMatch[1]).toLowerCase();
          if (fw === 'bold' || fw === 'bolder' || parseInt(fw, 10) >= 600) {
            isBold = true;
          }
        }

        const tdMatch = styleAttr.match(/text-decoration(?:-[a-z]+)?\s*:\s*([^;]+)/i);
        if (tdMatch && /underline/i.test(tdMatch[1])) {
          isUnderline = true;
        }

        const fontColor = curr.getAttribute('color') || curr.getAttribute('bgcolor');
        if (fontColor && isRedColorValue(fontColor)) isRed = true;

        for (let i = 0; i < curr.classList.length; i++) {
          if (redClasses.has(curr.classList[i])) isRed = true;
        }
        if (stopAt && curr === stopAt) break;
        curr = curr.parentElement;
      }
      return { isRed, isBold, isUnderline, isHighlight };
    };

    const extractParagraphsFromNode = (node: Element): ParsedParagraph[] => {
      const lines: { segments: TextSegment[]; images: string[] }[] = [
        { segments: [], images: [] },
      ];

      const pushImg = (imgEl: Element) => {
        const src = (imgEl.getAttribute('src') || '').trim();
        const curLine = lines[lines.length - 1];
        if (isSafeImageDataUrl(src) && !curLine.images.includes(src)) {
          curLine.images.push(src);
        }
      };

      const mathmlToLatex = (mEl: Element): string => {
        const mTag = (mEl.localName || mEl.tagName).toLowerCase();
        const children = Array.from(mEl.children);
        if (mTag === 'mi' || mTag === 'mn' || mTag === 'mo' || mTag === 'mtext') {
          return ommlTextToLatex(mEl.textContent || '');
        }
        if (mTag === 'mfrac' && children.length >= 2) {
          return `\\frac{${mathmlToLatex(children[0]).trim()}}{${mathmlToLatex(children[1]).trim()}}`;
        }
        if (mTag === 'msqrt') {
          return `\\sqrt{${children.map(mathmlToLatex).join('').trim()}}`;
        }
        if (mTag === 'mroot' && children.length >= 2) {
          return `\\sqrt[${mathmlToLatex(children[1]).trim()}]{${mathmlToLatex(children[0]).trim()}}`;
        }
        if (mTag === 'msup' && children.length >= 2) {
          return `{${mathmlToLatex(children[0]).trim()}}^{${mathmlToLatex(children[1]).trim()}}`;
        }
        if (mTag === 'msub' && children.length >= 2) {
          return `{${mathmlToLatex(children[0]).trim()}}_{${mathmlToLatex(children[1]).trim()}}`;
        }
        if (mTag === 'msubsup' && children.length >= 3) {
          return `{${mathmlToLatex(children[0]).trim()}}_{${mathmlToLatex(children[1]).trim()}}^{${mathmlToLatex(children[2]).trim()}}`;
        }
        if (mTag === 'mover' && children.length >= 2) {
          const over = (children[1].textContent || '').trim();
          const base = mathmlToLatex(children[0]).trim();
          if (over === '→' || over === '\u2192') return `\\vec{${base}}`;
          if (over === '¯' || over === '‾' || over === '-') return `\\overline{${base}}`;
          return `\\overset{${mathmlToLatex(children[1]).trim()}}{${base}}`;
        }
        if (mTag === 'munder' && children.length >= 2) {
          const base = mathmlToLatex(children[0]).trim();
          const under = mathmlToLatex(children[1]).trim();
          if (/^lim$/i.test(base)) return `\\lim_{${under}}`;
          return `\\underset{${under}}{${base}}`;
        }
        if (mTag === 'mtable') {
          const rowStrs = children.map((tr) =>
            Array.from(tr.children)
              .map((td) => mathmlToLatex(td).trim())
              .join(' & ')
          );
          return `\\begin{pmatrix} ${rowStrs.join(' \\\\ ')} \\end{pmatrix}`;
        }
        return children.map(mathmlToLatex).join('');
      };

      const walk = (curr: Node) => {
        if (curr.nodeType === Node.TEXT_NODE) {
          const txt = normalizeMathUnicodeChars(curr.textContent || '');
          if (txt.length > 0) {
            const fmt = getElementFormatting(curr.parentElement, node);
            const hasContent = txt.trim().length > 0;
            lines[lines.length - 1].segments.push({
              text: txt,
              isRed: fmt.isRed && hasContent,
              isBold: fmt.isBold && hasContent,
              isUnderline: fmt.isUnderline && hasContent,
              isHighlight: fmt.isHighlight && hasContent,
            });
          }
          return;
        }
        if (curr.nodeType === Node.ELEMENT_NODE) {
          const el = curr as Element;
          const tag = el.tagName.toUpperCase();
          if (tag === 'BR') {
            lines.push({ segments: [], images: [] });
            return;
          }
          if (tag === 'IMG') {
            pushImg(el);
            return;
          }
          if (tag === 'TABLE' && el !== node) {
            return;
          }
          if (tag === 'MATH') {
            const latex = mathmlToLatex(el).replace(/[ \t]{2,}/g, ' ').trim();
            if (latex) {
              const fmt = getElementFormatting(el, node);
              lines[lines.length - 1].segments.push({
                text: `$${latex}$`,
                isRed: fmt.isRed,
                isBold: fmt.isBold,
                isUnderline: fmt.isUnderline,
                isHighlight: fmt.isHighlight,
              });
            }
            return;
          }
          if (tag === 'SUP' || tag === 'SUB') {
            const innerTxt = normalizeMathUnicodeChars(el.textContent || '').trim();
            if (innerTxt) {
              const fmt = getElementFormatting(el, node);
              const kind = tag === 'SUP' ? 'sup' : 'sub';
              const rendered =
                innerTxt.length <= 8 && /^[0-9+\-ni().,]+$/i.test(innerTxt)
                  ? convertToUnicodeScript(innerTxt, kind)
                  : kind === 'sup'
                  ? `^{${innerTxt}}`
                  : `_{${innerTxt}}`;
              lines[lines.length - 1].segments.push({
                text: rendered,
                isRed: fmt.isRed,
                isBold: fmt.isBold,
                isUnderline: fmt.isUnderline,
                isHighlight: fmt.isHighlight,
              });
            }
            return;
          }
          for (let i = 0; i < el.childNodes.length; i++) {
            walk(el.childNodes[i]);
          }
        }
      };

      walk(node);

      const out: ParsedParagraph[] = [];
      for (const ln of lines) {
        const fullText = ln.segments
          .map((s) => s.text)
          .join('')
          .replace(/\s+/g, ' ')
          .trim();
        if (!fullText && ln.images.length === 0) continue;
        const nonEmptySegs = ln.segments.filter((s) => s.text.trim().length > 0);
        const boldLen = nonEmptySegs
          .filter((s) => s.isBold)
          .reduce((acc, s) => acc + s.text.trim().length, 0);
        const totalLen = nonEmptySegs.reduce((acc, s) => acc + s.text.trim().length, 0);
        out.push({
          fullText,
          hasRed: ln.segments.some((s) => s.isRed),
          hasHighlight: ln.segments.some((s) => s.isHighlight),
          hasUnderline: ln.segments.some((s) => s.isUnderline),
          isAllBold: totalLen > 0 && boldLen / totalLen >= 0.75,
          segments: ln.segments,
          images: ln.images.length > 0 ? ln.images : undefined,
        });
      }
      return out;
    };

    const parseHtmlTable = (tableEl: Element): ParsedTable => {
      const rows: ParsedTableCell[][] = [];
      const trElements = tableEl.querySelectorAll(
        ':scope > tbody > tr, :scope > thead > tr, :scope > tr'
      );
      trElements.forEach((tr) => {
        const cells: ParsedTableCell[] = [];
        const tdElements = tr.querySelectorAll(':scope > td, :scope > th');
        tdElements.forEach((td) => {
          const nestedTables: ParsedTable[] = [];
          td.querySelectorAll(':scope > table').forEach((nt) => {
            nestedTables.push(parseHtmlTable(nt));
          });

          const pNodes = td.querySelectorAll(':scope > p, :scope > div, :scope > li');
          const cellParagraphs: ParsedParagraph[] = [];
          if (pNodes.length > 0) {
            pNodes.forEach((pNode) => {
              cellParagraphs.push(...extractParagraphsFromNode(pNode));
            });
          } else {
            cellParagraphs.push(...extractParagraphsFromNode(td));
          }

          const cellFmt = getElementFormatting(td, td);
          const cellBgRed = cellFmt.isRed;
          const fullText = cellParagraphs.map((p) => p.fullText).filter(Boolean).join('\n').trim();
          const hasRed = cellBgRed || cellParagraphs.some((p) => p.hasRed);
          const hasHighlight = cellFmt.isHighlight || cellParagraphs.some((p) => p.hasHighlight);
          const hasUnderline = cellFmt.isUnderline || cellParagraphs.some((p) => p.hasUnderline);
          const isAllBold =
            cellParagraphs.length > 0 &&
            cellParagraphs.every((p) => p.isAllBold || !p.fullText);
          const cellImages = mergeUniqueImages(...cellParagraphs.map((p) => p.images));
          cells.push({
            fullText,
            hasRed: hasRed && (fullText.length > 0 || Boolean(cellImages?.length)),
            hasHighlight: hasHighlight && fullText.length > 0,
            hasUnderline: hasUnderline && fullText.length > 0,
            hasBold: isAllBold && fullText.length > 0,
            paragraphs: cellParagraphs.map((p) =>
              cellBgRed ? { ...p, hasRed: true } : p
            ),
            nestedTables,
            images: cellImages,
          });
        });
        if (cells.length > 0) rows.push(cells);
      });
      return { rows };
    };

    const walkHtmlNodes = (container: Element) => {
      for (let i = 0; i < container.children.length; i++) {
        const child = container.children[i];
        const tag = child.tagName.toUpperCase();
        if (tag === 'TABLE') {
          const parsedTbl = parseHtmlTable(child);
          if (parsedTbl.rows.length > 0) {
            blocks.push({ kind: 'table', table: parsedTbl });
          }
        } else if (tag === 'IMG') {
          extractParagraphsFromNode(child).forEach((p) =>
            blocks.push({ kind: 'paragraph', paragraph: p })
          );
        } else if (
          tag === 'P' ||
          tag === 'LI' ||
          tag === 'H1' ||
          tag === 'H2' ||
          tag === 'H3' ||
          tag === 'H4' ||
          tag === 'FIGURE'
        ) {
          if (child.querySelector('table')) {
            walkHtmlNodes(child);
          } else {
            extractParagraphsFromNode(child).forEach((p) =>
              blocks.push({ kind: 'paragraph', paragraph: p })
            );
          }
        } else if (
          tag === 'DIV' ||
          tag === 'SECTION' ||
          tag === 'ARTICLE' ||
          tag === 'BODY' ||
          tag === 'OL' ||
          tag === 'UL'
        ) {
          if (child.querySelector('p, li, table, div, ol, ul')) {
            walkHtmlNodes(child);
          } else {
            extractParagraphsFromNode(child).forEach((p) =>
              blocks.push({ kind: 'paragraph', paragraph: p })
            );
          }
        }
      }
    };

    if (doc.body) {
      walkHtmlNodes(doc.body);
    }
    if (blocks.length > 0) return blocks;
  }

  const lines = rawContent.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    blocks.push({
      kind: 'paragraph',
      paragraph: {
        fullText: trimmed,
        hasRed: false,
        segments: [{ text: trimmed, isRed: false }],
      },
    });
  }

  return blocks;
}

/**
 * Converts a ParsedTable into QuestionTableData (for rendering stimulus/data tables inside a question).
 */
function convertParsedTableToQuestionTableData(
  table: ParsedTable
): QuestionTableData | undefined {
  const nonEmptyRows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0)
  );
  if (nonEmptyRows.length === 0) return undefined;

  const maxCols = Math.max(...nonEmptyRows.map((r) => r.length));
  if (maxCols === 0) return undefined;

  const normalizeRow = (r: ParsedTableCell[]) => {
    const arr = r.map((c) => c.fullText.replace(/\n+/g, ' ').trim());
    while (arr.length < maxCols) arr.push('');
    return arr;
  };

  const headers = normalizeRow(nonEmptyRows[0]);
  const rows =
    nonEmptyRows.length > 1
      ? nonEmptyRows.slice(1).map(normalizeRow)
      : [headers];

  return {
    headers:
      nonEmptyRows.length > 1
        ? headers
        : headers.map((_, idx) => `Kolom ${idx + 1}`),
    rows,
  };
}

/**
 * Cleans invisible zero-width characters, weird non-breaking spaces, and full-width punctuation
 * that frequently appear in messy copy-pasted Word documents.
 */
function sanitizeMessyLineText(raw: string): string {
  return raw
    .replace(/[\u200B-\u200D\uFEFF\u00AD\u2060]/g, '')
    .replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ')
    .replace(/．/g, '.')
    .replace(/）/g, ')')
    .replace(/（/g, '(')
    .replace(/：/g, ':')
    .replace(/；/g, ';');
}

function sanitizeParsedParagraph(para: ParsedParagraph): ParsedParagraph {
  const cleanSegments: TextSegment[] = para.segments.map((seg) => ({
    ...seg,
    text: sanitizeMessyLineText(seg.text),
  }));
  const cleanFull = sanitizeMessyLineText(para.fullText).replace(/[ \t]{2,}/g, (m) =>
    m.length >= 2 ? m : ' '
  ).trim();
  return {
    ...para,
    fullText: cleanFull,
    segments: cleanSegments,
  };
}

/**
 * Extracts trailing inline answer keys glued onto a question stem or last option,
 * e.g. "D. Jakarta (Kunci: B)", "E. Mitokondria Kunci: B", or "1. Ibukota Indonesia? (Jawaban: Jakarta)".
 */
function splitTrailingInlineKey(para: ParsedParagraph): ParsedParagraph[] {
  const txt = para.fullText.trim();
  if (!txt || EXPLICIT_KEY_LINE_REGEX.test(txt)) return [para];

  // Match trailing parenthesized/bracketed key: "(Kunci: B)", "[Jawaban: Mitokondria]", "(Jwb: A, C)"
  const parenKeyMatch = txt.match(
    /^(.*?)[\s\-–—]+[\(\[]\s*(?:kunci(?:\s*jawaban)?|jawaban(?:\s*benar)?|jawab|jwb|kj|key|ans)\s*[:=\-]\s*([^\)\]]+?)\s*[\)\]]\s*$/i
  );
  if (parenKeyMatch && parenKeyMatch[1].trim().length >= 3 && parenKeyMatch[2].trim()) {
    const bodyText = parenKeyMatch[1].trim();
    const keyVal = parenKeyMatch[2].trim();
    return [
      { ...para, fullText: bodyText, segments: [{ text: bodyText, isRed: para.hasRed, isBold: para.isAllBold, isUnderline: para.hasUnderline, isHighlight: para.hasHighlight }] },
      { fullText: `Kunci: ${keyVal}`, hasRed: false, segments: [{ text: `Kunci: ${keyVal}`, isRed: false }] },
    ];
  }

  // Match unparenthesized trailing "Kunci: B" or "Jawaban: Mitokondria" glued onto the same line
  const gluedKeyMatch = txt.match(
    /^(.*?)[\s;|]+(?:kunci\s*jawaban|kunci|jawaban\s*benar|jawaban|jwb|kj)\s*[:=]\s*([^\n]+?)\s*$/i
  );
  if (gluedKeyMatch && gluedKeyMatch[1].trim().length >= 3 && gluedKeyMatch[2].trim()) {
    const bodyText = gluedKeyMatch[1].trim();
    const keyVal = gluedKeyMatch[2].trim();
    return [
      { ...para, fullText: bodyText, segments: [{ text: bodyText, isRed: para.hasRed, isBold: para.isAllBold, isUnderline: para.hasUnderline, isHighlight: para.hasHighlight }] },
      { fullText: `Kunci: ${keyVal}`, hasRed: false, segments: [{ text: `Kunci: ${keyVal}`, isRed: false }] },
    ];
  }

  return [para];
}

/**
 * Safely splits a paragraph that contains inline options (e.g., "A. Satu   B. Dua   C. Tiga",
 * no-space messy "A.Satu B.Dua C.Tiga D.Empat", mixed-delimiter "A. Satu b) Dua C. Tiga",
 * or 2-col "A. Satu   D. Empat") AND/OR multiple run-on numbered questions or glued trailing keys,
 * while preserving per-character red/bold/underline/highlight formatting.
 */
function splitInlineOptionsIfPresent(rawPara: ParsedParagraph): ParsedParagraph[] {
  const para = sanitizeParsedParagraph(rawPara);
  // Never split standalone section headers like "B. Pilihan Ganda Kompleks (...)"
  if (matchSectionTypeHeader(para.fullText)) {
    return [para];
  }

  let rawCombined = '';
  const charRedMap: boolean[] = [];
  const charBoldMap: boolean[] = [];
  const charUnderlineMap: boolean[] = [];
  const charHighlightMap: boolean[] = [];

  const sourceSegs =
    para.segments.length > 0
      ? para.segments
      : [{ text: para.fullText, isRed: para.hasRed, isBold: para.isAllBold, isUnderline: para.hasUnderline, isHighlight: para.hasHighlight }];

  for (const seg of sourceSegs) {
    for (let i = 0; i < seg.text.length; i++) {
      rawCombined += seg.text[i];
      charRedMap.push(Boolean(seg.isRed));
      charBoldMap.push(Boolean(seg.isBold));
      charUnderlineMap.push(Boolean(seg.isUnderline));
      charHighlightMap.push(Boolean(seg.isHighlight));
    }
  }

  const buildSlicePara = (
    startIdx: number,
    endIdx: number,
    preserveAutoNum: boolean = false
  ): ParsedParagraph | null => {
    const sliceText = rawCombined.slice(startIdx, endIdx).trim();
    if (!sliceText) return null;
    let sliceHasRed = false;
    let sliceHasUnderline = false;
    let sliceHasHighlight = false;
    let boldChars = 0;
    let totalChars = 0;
    for (let c = startIdx; c < endIdx; c++) {
      if (rawCombined[c].trim()) {
        totalChars++;
        if (charRedMap[c]) sliceHasRed = true;
        if (charBoldMap[c]) boldChars++;
        if (charUnderlineMap[c]) sliceHasUnderline = true;
        if (charHighlightMap[c]) sliceHasHighlight = true;
      }
    }
    const isAllBold = totalChars > 0 && boldChars >= totalChars * 0.7;
    return {
      fullText: sliceText,
      hasRed: sliceHasRed,
      hasBold: boldChars > 0,
      hasUnderline: sliceHasUnderline,
      hasHighlight: sliceHasHighlight,
      isAllBold,
      segments: [
        {
          text: sliceText,
          isRed: sliceHasRed,
          isBold: isAllBold,
          isUnderline: sliceHasUnderline,
          isHighlight: sliceHasHighlight,
        },
      ],
      ...(preserveAutoNum
        ? {
            numId: para.numId,
            ilvl: para.ilvl,
            numFormat: para.numFormat,
            autoQuestionNumber: para.autoQuestionNumber,
          }
        : {}),
    };
  };

  // Compute protected $...$ and $$...$$ math spans so we NEVER split inside equations/matrices
  const mathSpans: Array<[number, number]> = [];
  {
    let mIdx = 0;
    while (mIdx < rawCombined.length) {
      if (rawCombined[mIdx] === '\\' && rawCombined[mIdx + 1] === '$') {
        mIdx += 2;
        continue;
      }
      if (rawCombined[mIdx] === '$' && rawCombined[mIdx + 1] === '$') {
        const close = rawCombined.indexOf('$$', mIdx + 2);
        if (close !== -1) {
          mathSpans.push([mIdx, close + 2]);
          mIdx = close + 2;
          continue;
        }
      }
      if (rawCombined[mIdx] === '$') {
        let close = mIdx + 1;
        while (close < rawCombined.length) {
          if (rawCombined[close] === '\\') {
            close += 2;
            continue;
          }
          if (rawCombined[close] === '$') break;
          close++;
        }
        if (close < rawCombined.length) {
          mathSpans.push([mIdx, close + 1]);
          mIdx = close + 1;
          continue;
        }
      }
      mIdx++;
    }
  }
  const isInsideMathSpan = (pos: number): boolean =>
    mathSpans.some(([s, e]) => pos > s && pos < e);

  // Check for giant run-on paragraph containing MULTIPLE numbered questions + options glued together
  // e.g. "1. Organel sel... A. X B. Y C. Z D. W 2. Enzim lambung... A. P B. Q C. R D. S"
  if (rawCombined.length >= 60) {
    const runOnQRegex = /(?:^|[\s\t]+)([1-9]\d{0,2})\s*[\.\)]\s*(?=[A-Za-z"'$(“\\√])/g;
    const qMatches = Array.from(rawCombined.matchAll(runOnQRegex));
    const sequentialQStarts: { idx: number; num: number }[] = [];
    for (const qm of qMatches) {
      const qNum = parseInt(qm[1], 10);
      if (qNum < 1 || qNum > 200) continue;
      const leadLen = (qm[0].match(/^[\s\t]*/)?.[0] ?? '').length;
      const start = (qm.index ?? 0) + leadLen;
      if (isInsideMathSpan(start)) continue;
      if (sequentialQStarts.length === 0) {
        sequentialQStarts.push({ idx: start, num: qNum });
      } else {
        const prev = sequentialQStarts[sequentialQStarts.length - 1];
        const between = rawCombined.slice(prev.idx, start);
        // Split only when the chunk between Q_k and Q_{k+1} clearly contains options A..B or ends a question!
        if (
          qNum === prev.num + 1 &&
          between.length >= 25 &&
          (/(?:^|\s)[Aa][\.\)]\s*\S+.*?(?:^|\s)[Bb][\.\)]\s*\S+/.test(between) ||
            /[?…\.]{1}\s*$/.test(between.trim()))
        ) {
          sequentialQStarts.push({ idx: start, num: qNum });
        }
      }
    }
    if (sequentialQStarts.length >= 2) {
      const splitChunks: ParsedParagraph[] = [];
      for (let i = 0; i < sequentialQStarts.length; i++) {
        const sIdx = i === 0 ? 0 : sequentialQStarts[i].idx;
        const eIdx =
          i + 1 < sequentialQStarts.length
            ? sequentialQStarts[i + 1].idx
            : rawCombined.length;
        const chunkPara = buildSlicePara(sIdx, eIdx, i === 0);
        if (chunkPara) {
          if (i === 0 && para.images?.length) {
            chunkPara.images = mergeUniqueImages(chunkPara.images, para.images);
          }
          splitChunks.push(...splitInlineOptionsIfPresent(chunkPara));
        }
      }
      if (splitChunks.length > 1) return splitChunks;
    }
  }

  // Match option markers like "A. ", "B) ", "(A) ", "[A] ", "A: ", or messy no-space "A.Jawaban" / "A.$\frac{1}{2}$"
  const regex =
    /(?:^|[\s\t]+)(?:([\*✓✔☑])\s*)?(?:\(\s*([A-Ea-e])\s*\)|\[\s*([A-Ea-e])\s*\]|([A-Ea-e])\s*([\*✓✔☑])?\s*[\.\)\]:])(?:[\s\t]+|(?=[A-Za-z0-9"'(“\-−±$\\√{](?![\.\)])))/g;
  const allMatches = Array.from(rawCombined.matchAll(regex)).filter((m) => {
    const leadLen = (m[0].match(/^[\s\t]*/)?.[0] ?? '').length;
    return !isInsideMathSpan((m.index ?? 0) + leadLen);
  });
  if (allMatches.length <= 1) {
    return splitTrailingInlineKey(para);
  }

  // Words that commonly precede a single letter "A.", "B.", "C." inside a normal sentence
  const sentenceConnectorBeforeLetter =
    /\b(?:dan|atau|dengan|ke|dari|antara|pada|oleh|adalah|yaitu|seperti|darah|vitamin|individu|titik|gambar|larutan|kelompok|poin|huruf|kelas|tipe|gen|alel|gamet|kromosom|tabung|label|bagian|nomor|spesies|bakteri)\s+$/i;

  const validMatches: {
    match: RegExpMatchArray;
    letter: string;
    rawLetter: string;
    isUpper: boolean;
    delimKind: string;
    tokenStart: number;
    markerEnd: number;
    hasTabOrMultiSpaceBefore: boolean;
  }[] = [];

  for (const m of allMatches) {
    const rawLetter = m[2] || m[3] || m[4] || '';
    const letter = rawLetter.toUpperCase();
    const isUpper = rawLetter === letter;
    const leadingWhitespace = m[0].match(/^[\s\t]*/)?.[0] ?? '';
    const leadingWhitespaceLen = leadingWhitespace.length;
    const tokenStart = (m.index ?? 0) + leadingWhitespaceLen;
    const markerEnd = (m.index ?? 0) + m[0].length;
    const delimKind = m[2]
      ? 'paren'
      : m[3]
      ? 'bracket'
      : m[0].includes(')')
      ? 'rpar'
      : m[0].includes(':')
      ? 'colon'
      : 'dot';
    const hasTabOrMultiSpaceBefore =
      tokenStart === 0 ||
      leadingWhitespace.includes('\t') ||
      leadingWhitespace.length >= 2;

    // Skip abbreviations like "a.n.", "a.l.", "d.k.k."
    const afterSnippet = rawCombined.slice(tokenStart, tokenStart + 5).toLowerCase();
    if (/^(?:a\.n\.|a\.l\.|d\.k\.k|d\.p\.l|e\.g\.|c\.q\.|b\.d\.)/.test(afterSnippet)) {
      continue;
    }

    if (validMatches.length === 0) {
      if (['A', 'B', 'C', 'D'].includes(letter)) {
        if (tokenStart > 0) {
          const textBefore = rawCombined.slice(0, tokenStart);
          if (
            !hasTabOrMultiSpaceBefore &&
            sentenceConnectorBeforeLetter.test(textBefore)
          ) {
            continue;
          }
        }
        validMatches.push({
          match: m,
          letter,
          rawLetter,
          isUpper,
          delimKind,
          tokenStart,
          markerEnd,
          hasTabOrMultiSpaceBefore,
        });
      }
    } else {
      const prev = validMatches[validMatches.length - 1];
      const prevLetterCode = prev.letter.charCodeAt(0);
      const currLetterCode = letter.charCodeAt(0);

      // The previous option must have actual text before this new option marker (prevents splitting "A. B. subtilis")
      const prevOptionBody = rawCombined.slice(prev.markerEnd, tokenStart).trim();
      if (prevOptionBody.length < 1) {
        continue;
      }

      const textBefore = rawCombined.slice(prev.markerEnd, tokenStart);
      if (
        !hasTabOrMultiSpaceBefore &&
        sentenceConnectorBeforeLetter.test(textBefore)
      ) {
        continue;
      }

      // Allow step of 1 (A->B), 2 (A->C, B->D), or 3 (A->D, B->E in 2-column layouts!)
      // Be tolerant of messy mixed case/delimiters (e.g., "A. Satu b) Dua C. Tiga") when step === 1 or tab/multi-space separated
      const step = currLetterCode - prevLetterCode;
      const styleMatches = isUpper === prev.isUpper && delimKind === prev.delimKind;
      if (step > 0 && step <= 3 && (styleMatches || step === 1 || hasTabOrMultiSpaceBefore)) {
        validMatches.push({
          match: m,
          letter,
          rawLetter,
          isUpper,
          delimKind,
          tokenStart,
          markerEnd,
          hasTabOrMultiSpaceBefore,
        });
      }
    }
  }

  if (validMatches.length <= 1) {
    return splitTrailingInlineKey(para);
  }

  // If the first match is inside a sentence (tokenStart > 0), it must start with 'A'
  if (validMatches[0].tokenStart > 0 && validMatches[0].letter !== 'A') {
    return splitTrailingInlineKey(para);
  }

  if (
    validMatches.length === 2 &&
    !validMatches[1].hasTabOrMultiSpaceBefore &&
    validMatches[1].letter.charCodeAt(0) - validMatches[0].letter.charCodeAt(0) > 1
  ) {
    return splitTrailingInlineKey(para);
  }

  const result: ParsedParagraph[] = [];

  // CRITICAL: Preserve any question text BEFORE the first inline option!
  if (validMatches[0].tokenStart > 0) {
    const prefixPara = buildSlicePara(0, validMatches[0].tokenStart, true);
    if (prefixPara) {
      result.push(prefixPara);
    }
  }

  for (let i = 0; i < validMatches.length; i++) {
    const startIdx = validMatches[i].tokenStart;
    const endIdx =
      i + 1 < validMatches.length
        ? validMatches[i + 1].tokenStart
        : rawCombined.length;

    const slicePara = buildSlicePara(startIdx, endIdx, false);
    if (slicePara) {
      if (i === validMatches.length - 1) {
        result.push(...splitTrailingInlineKey(slicePara));
      } else {
        result.push(slicePara);
      }
    }
  }

  if (result.length > 0 && para.images && para.images.length > 0) {
    result[0] = {
      ...result[0],
      images: mergeUniqueImages(result[0].images, para.images),
    };
  }

  return result.length > 0 ? result : [para];
}

interface ParagraphRecord {
  para: ParsedParagraph;
  matchedOption?: {
    letter: string;
    text: string;
    isRed: boolean;
    isBold?: boolean;
    isUnderline?: boolean;
    isHighlight?: boolean;
    images?: string[];
  };
}

interface DraftQuestion {
  explicitNumber?: number;
  detectedType?: QuestionType;
  sectionKey?: string;
  explicitCategory?: string;
  explicitExplanation?: string;
  explicitInstruction?: string;
  trueLabel?: string;
  falseLabel?: string;
  stimulusTitle?: string;
  stimulusText?: string;
  stimulusImages?: string[];
  stimulusTable?: QuestionTableData;
  questionLines: string[];
  questionImages?: string[];
  unprefixedParagraphs: ParsedParagraph[];
  allParagraphs?: ParagraphRecord[];
  options: {
    id: string;
    text: string;
    isRed: boolean;
    isBold?: boolean;
    isUnderline?: boolean;
    isHighlight?: boolean;
    images?: string[];
  }[];
  explicitKeys: string[];
  explicitTextAnswers?: string[];
  explicitStatements?: StatementItem[];
  explicitMatchingPairs?: {
    premise: string;
    response: string;
    premiseImages?: string[];
    responseImages?: string[];
  }[];
  explicitPremises?: MatchingPremise[];
  explicitResponses?: MatchingResponse[];
  explicitMatchingCorrectPairs?: Record<string, string>;
  explicitMatchingKeyMap?: Record<number, string>;
  matchingListMode?: 'premise' | 'response';
  explicitPoints?: number;
}

/**
 * Detects custom True/False column labels (e.g. Sesuai/Tidak Sesuai, Ya/Tidak, Fakta/Opini, Setuju/Tidak Setuju).
 */
function detectBenarSalahPairLabels(
  rawText: string
): { trueLabel: string; falseLabel: string } | null {
  const t = rawText.toLowerCase();
  if (/sesuai\s*(?:\/|\-|atau)\s*tidak\s+sesuai/i.test(t)) {
    return { trueLabel: 'Sesuai', falseLabel: 'Tidak Sesuai' };
  }
  if (/\bya\s*(?:\/|\-|atau)\s*tidak\b/i.test(t)) {
    return { trueLabel: 'Ya', falseLabel: 'Tidak' };
  }
  if (/\bfakta\s*(?:\/|\-|atau)\s*opini\b/i.test(t)) {
    return { trueLabel: 'Fakta', falseLabel: 'Opini' };
  }
  if (/\bsetuju\s*(?:\/|\-|atau)\s*tidak\s+setuju\b/i.test(t)) {
    return { trueLabel: 'Setuju', falseLabel: 'Tidak Setuju' };
  }
  if (/\btepat\s*(?:\/|\-|atau)\s*tidak\s+tepat\b/i.test(t)) {
    return { trueLabel: 'Tepat', falseLabel: 'Tidak Tepat' };
  }
  if (/\bvalid\s*(?:\/|\-|atau)\s*tidak\s+valid\b/i.test(t)) {
    return { trueLabel: 'Valid', falseLabel: 'Tidak Valid' };
  }
  if (/\bmendukung\s*(?:\/|\-|atau)\s*tidak\s+mendukung\b/i.test(t)) {
    return { trueLabel: 'Mendukung', falseLabel: 'Tidak Mendukung' };
  }
  if (/\btrue\s*(?:\/|\-|or)\s*false\b/i.test(t)) {
    return { trueLabel: 'True', falseLabel: 'False' };
  }
  return null;
}

/**
 * Extracts explicit bracketed question-type tags at the start or end of a question,
 * e.g. "[PG]", "[PGK]", "[B/S]", "[MENJODOHKAN]", "[ISIAN]", "[URAIAN]".
 */
function extractInlineQuestionTypeTag(rawText: string): {
  type: QuestionType | null;
  cleanedText: string;
} {
  const trimmed = rawText.trim();
  const tagRegex =
    /^\s*[\[\(]\s*(pilihan\s+ganda\s+kompleks|pg\s*kompleks|pgk|mcma|benar\s*(?:[\/\-]|\s+)\s*salah|sesuai\s*(?:[\/\-]|\s+)\s*tidak\s+sesuai|b\s*\/\s*s|bs|menjodohkan|jodohkan|jodoh|matching|isian\s+singkat|isian|uraian\s+singkat|uraian|essay|esai|pilihan\s+ganda|pg)\s*[\]\)]\s*[:\-]?\s*/i;
  const m = trimmed.match(tagRegex);
  if (!m) return { type: null, cleanedText: trimmed };
  const rawTag = m[1].trim().toLowerCase();
  let type: QuestionType | null = null;
  if (/kompleks|pgk|mcma/.test(rawTag)) type = 'pilihan_ganda_kompleks';
  else if (/benar|sesuai|^bs$|^b\s*\/\s*s$/.test(rawTag)) type = 'benar_salah';
  else if (/jodoh|matching/.test(rawTag)) type = 'menjodohkan';
  else if (/isian|uraian|essay|esai/.test(rawTag)) type = 'isian_singkat';
  else if (/pilihan\s+ganda|^pg$/.test(rawTag)) type = 'pilihan_ganda';
  return {
    type,
    cleanedText: trimmed.slice(m[0].length).trim(),
  };
}

/**
 * Parses matching answer key strings like "1-C, 2-A, 3-B", "1C, 2A, 3B", or "1->B; 2->A; 3->C".
 * Returns a map of 1-based premise number -> uppercase response key (e.g. 'A'..'H' or '1'..'8').
 */
function parseMatchingKeyString(raw: string): Record<number, string> | null {
  const cleaned = raw.trim();
  if (!cleaned) return null;
  const pairRegex = /(\d+)\s*(?:->|=>|===>|↔|<->|[\-:=])\s*([A-Ha-h]|\d+)\b|(\d+)([A-Ha-h])\b/g;
  const result: Record<number, string> = {};
  let match: RegExpExecArray | null;
  while ((match = pairRegex.exec(cleaned)) !== null) {
    const pNum = parseInt(match[1] || match[3], 10);
    const rCode = (match[2] || match[4] || '').toUpperCase();
    if (pNum >= 1 && pNum <= 20 && rCode) {
      result[pNum] = rCode;
    }
  }
  return Object.keys(result).length >= 2 ? result : null;
}

/**
 * Detects a QuestionType from a section header, label, or instruction text.
 */
export function detectQuestionTypeFromText(
  rawText: string
): QuestionType | null {
  const t = rawText.trim().toLowerCase();
  if (!t) return null;

  if (
    /\b(pilihan\s+ganda\s+kompleks|pg\s+kompleks|pgk|mcma|multiple\s+response|pilih(?:lah)?\s+lebih\s+dari\s+satu|jawaban\s+benar\s+(?:bisa\s+)?lebih\s+dari\s+(?:satu|1)|pilih\s+semua\s+yang\s+benar|pilih(?:lah)?\s+(?:2|3|4|dua|tiga|empat)\s+jawaban|beri(?:lah)?\s+tanda\s+centang)\b/i.test(
      t
    )
  ) {
    return 'pilihan_ganda_kompleks';
  }

  if (
    /\b(benar\s*[\/\-]\s*salah|benar\s+atau\s+salah|benar\s+salah|tentukan\s+benar\s+atau\s+salah|sesuai\s*[\/\-]\s*tidak\s+sesuai|sesuai\s+atau\s+tidak\s+sesuai|ya\s*[\/\-]\s*tidak|fakta\s*[\/\-]\s*opini|setuju\s*[\/\-]\s*tidak\s+setuju|tepat\s*[\/\-]\s*tidak\s+tepat|valid\s*[\/\-]\s*tidak\s+valid|mendukung\s*[\/\-]\s*tidak\s+mendukung|kategori\s+benar\s+salah|true\s*[\/\-]\s*false|b\s*\/\s*s|b\s+atau\s+s)\b/i.test(
      t
    ) ||
    /^(?:bs|b\/s)$/i.test(t)
  ) {
    return 'benar_salah';
  }

  if (
    /\b(menjodohkan|soal\s+jodohkan|pasangkan(?:lah)?|jodohkan(?:lah)?|matching)\b/i.test(
      t
    ) ||
    /^(?:jodoh|jodohkan)$/i.test(t)
  ) {
    return 'menjodohkan';
  }

  if (
    /\b(isian\s+singkat|soal\s+isian|jawaban\s+singkat|uraian\s+singkat|soal\s+uraian|soal\s+essay|soal\s+esai|uraian|essay|esai|short\s+answer|isilah\s+titik)\b/i.test(
      t
    ) ||
    /^(?:isian|is)$/i.test(t)
  ) {
    return 'isian_singkat';
  }

  if (
    /\b(pilihan\s+ganda|soal\s+pg|multiple\s+choice)\b/i.test(t) ||
    /^(?:pg|pilihan\s+ganda)$/i.test(t)
  ) {
    return 'pilihan_ganda';
  }

  return null;
}

/**
 * Checks if a paragraph is a standalone section header for a question type
 * (e.g., "BAGIAN I: PILIHAN GANDA (1 JAWABAN BENAR)", "BAGIAN II: PILIHAN GANDA KOMPLEKS", "BAGIAN III: BENAR ATAU SALAH")
 */
function matchSectionTypeHeader(text: string): QuestionType | null {
  const trimmed = text.trim();
  if (!trimmed || trimmed.length > 180) return null;
  if (/\?|\.\.\./.test(trimmed)) return null;

  const cleaned = trimmed
    .replace(
      /^(?:(?:bagian|section|romawi|tipe|jenis|kelompok)\s*(?:[ivx]+|[a-e]|\d+)?\s*[\.\)\-:]?\s*|(?:[ivx]+|[a-e]|\d+)\s*[\.\)\-:]\s*)/i,
      ''
    )
    .trim();

  if (
    /^(?:soal\s+)?(?:pilihan\s+ganda\s+kompleks|pg\s+kompleks|pgk|mcma)(?:\s*(?:\(.*\)|[\-–—:].*))?\s*[:\-]?$/i.test(
      cleaned
    )
  ) {
    return 'pilihan_ganda_kompleks';
  }
  if (
    /^(?:soal\s+)?(?:benar\s*[\/\-]?\s*salah|benar\s+atau\s+salah|sesuai\s*[\/\-]\s*tidak\s+sesuai|b\s*\/\s*s)(?:\s*(?:\(.*\)|[\-–—:].*))?\s*[:\-]?$/i.test(
      cleaned
    )
  ) {
    return 'benar_salah';
  }
  if (
    /^(?:soal\s+)?(?:menjodohkan|pasangkan|jodohkan)(?:\s*(?:\(.*\)|[\-–—:].*))?\s*[:\-]?$/i.test(
      cleaned
    )
  ) {
    return 'menjodohkan';
  }
  if (
    /^(?:soal\s+)?(?:isian\s+singkat|isian|uraian\s+singkat|uraian|essay|esai)(?:\s*(?:\(.*\)|[\-–—:].*))?\s*[:\-]?$/i.test(
      cleaned
    )
  ) {
    return 'isian_singkat';
  }
  if (
    /^(?:soal\s+)?(?:pilihan\s+ganda|pg)(?:\s*(?:\(.*\)|[\-–—:].*))?\s*[:\-]?$/i.test(
      cleaned
    )
  ) {
    return 'pilihan_ganda';
  }

  return null;
}

/**
 * Regex helpers for options, checkboxes, stimuli, and numbered questions — resilient to messy punctuation & missing spaces
 */
const OPTION_LINE_REGEX =
  /^(?:([\*✓✔☑]|\[[xvXV✓✔]\])\s*)?(?:[•\-\*▪▫◦☐]\s*)?(?:\(\s*([A-Ea-e])\s*\)|\[\s*([A-Ea-e])\s*\]|([A-Ea-e])\s*([\*✓✔☑])?\s*(?:\.{1,2}|[\)\-:_=]))\s*(.*)$/;
const OPTION_TAB_REGEX = /^([\*✓✔☑])?\s*([A-Ea-e])(?:\t+|\s{2,})(.+)$/;
const CHECKBOX_OPTION_REGEX =
  /^(?:\[\s*([✓✔vxVX]?)\s*\]|([☐☑✅✓✔]))\s+(.+)$/;
const STIMULUS_HEADER_REGEX =
  /^\[?\s*(?:STIMULUS|WACANA|TEKS\s+BACAAN|TEKS|BACAAN|STUDI\s+KASUS|INFOGRAFIS)(?:\s+(\d+))?\s*(?:[:\-]\s*(.*?))?\s*\]?$/i;
const NUMBERED_QUESTION_REGEX =
  /^(?:[•\-\*▪▫]\s*)?(?:(?:pertanyaan|soal)\s*(?:no\.?|nomor)?\s*|no\.?\s*|nomor\s*)?(?:\(\s*(\d{1,3})\s*\)|\[\s*(\d{1,3})\s*\]|(\d{1,3})\s*(?:\.{1,2}|[\)\-:_]))\s*(.+)$/i;
const EXPLICIT_KEY_LINE_REGEX =
  /^[\(\[]?\s*(?:kunci(?:\s*jawaban(?:\s*singkat)?)?|jawaban(?:\s*benar|\s*singkat)?|jawab|jwb|kj|answer(?:\s*key)?|ans|key)\s*[\)\]]?\s*[:=\-]\s*(.+?)\s*[\)\]]?$/i;

function matchStimulusHeader(rawText: string): {
  num?: number;
  title: string;
} | null {
  const cleaned = rawText
    .replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/gu, '')
    .trim();
  // Avoid matching long full sentences that start with "Teks ..." (e.g. "Teks di atas membahas tentang...")
  if (
    cleaned.length > 140 ||
    /\?$/.test(cleaned) ||
    /^(?:teks|bacaan)\s+(?:di\s*atas|tersebut|ini|berikut\s+untuk\s+soal)/i.test(cleaned)
  ) {
    return null;
  }
  const m = cleaned.match(STIMULUS_HEADER_REGEX);
  if (!m) return null;
  // Require colon/dash/brackets/number for short words "TEKS" or "BACAAN"
  if (
    /^(?:teks|bacaan)$/i.test(cleaned) &&
    !m[1] &&
    !m[2]
  ) {
    return null;
  }
  const unwrappedTitle = cleaned.replace(/^\[(.*)\]$/, '$1').trim();
  return {
    num: m[1] ? parseInt(m[1], 10) : undefined,
    title: unwrappedTitle,
  };
}

function extractTrailingCorrectMarker(rawText: string): {
  cleanedText: string;
  isMarkedCorrect: boolean;
} {
  let cleaned = rawText.trim();
  let isMarked = false;

  if (
    /(?:\s*[\(\[](?:benar|kunci|jawaban\s*benar|correct|✓|✔|v|x|\*)[\)\]]|\s*[✓✔☑✅]|(?<=\S)\s*\*)$/i.test(
      cleaned
    )
  ) {
    isMarked = true;
    cleaned = cleaned
      .replace(
        /(?:\s*[\(\[](?:benar|kunci|jawaban\s*benar|correct|✓|✔|v|x|\*)[\)\]]|\s*[✓✔☑✅]|(?<=\S)\s*\*)+$/i,
        ''
      )
      .trim();
  }

  return { cleanedText: cleaned, isMarkedCorrect: isMarked };
}

function matchOptionLine(
  para: ParsedParagraph,
  nextCheckboxIndex: number = 0
): {
  letter: string;
  text: string;
  isRed: boolean;
  isBold?: boolean;
  isUnderline?: boolean;
  isHighlight?: boolean;
  isCheckbox?: boolean;
  isBarePrefix?: boolean;
} | null {
  const trimmed = sanitizeMessyLineText(para.fullText).trim();
  // Guard against common Indonesian/Latin abbreviations like "a.n.", "a.l.", "d.k.k.", "d.p.l.", "e.g.", "c.q."
  if (/^(?:a\.n\.|a\.l\.|d\.k\.k\.|d\.p\.l\.|e\.g\.|c\.q\.|b\.d\.)/i.test(trimmed)) {
    return null;
  }

  const cbM = trimmed.match(CHECKBOX_OPTION_REGEX);
  if (cbM) {
    const insideChecked = Boolean(cbM[1]);
    const glyphChecked = cbM[2] && cbM[2] !== '☐';
    const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const letter =
      letters[nextCheckboxIndex] || String.fromCharCode(65 + nextCheckboxIndex);
    const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
      (cbM[3] || '').trim()
    );
    return {
      letter,
      text: cleanedText || `Pernyataan ${nextCheckboxIndex + 1}`,
      isRed: Boolean(
        para.hasRed || insideChecked || glyphChecked || isMarkedCorrect
      ),
      isBold: Boolean(para.isAllBold),
      isUnderline: Boolean(para.hasUnderline),
      isHighlight: Boolean(para.hasHighlight),
      isCheckbox: true,
    };
  }

  const m = trimmed.match(OPTION_LINE_REGEX);
  if (m) {
    const leadingMark = Boolean(m[1]);
    const letter = (m[2] || m[3] || m[4] || 'A').toUpperCase();
    const afterLetterMark = Boolean(m[5]);
    const rawBody = (m[6] || '').trim();
    // Guard against algebraic math assignments & subtractions like "a = 2, b = 3", "A = [[1,2],[3,4]]", "a - b = 5"
    if (
      m[4] &&
      !leadingMark &&
      !afterLetterMark &&
      (/^[A-Ea-e]\s*=\s*(?:\$|\(|\[|\{|\\|[0-9\-−√±]|.*[=,+])/.test(trimmed) ||
        /^[A-Ea-e]\s*-\s*[A-Za-z0-9\\$\(].*=/.test(trimmed))
    ) {
      return null;
    }
    const { cleanedText, isMarkedCorrect } =
      extractTrailingCorrectMarker(rawBody);
    const isBarePrefix = cleanedText.length === 0;
    const optText = cleanedText || `Pilihan ${letter}`;
    return {
      letter,
      text: optText,
      isRed: para.hasRed || leadingMark || afterLetterMark || isMarkedCorrect,
      isBold: Boolean(para.isAllBold),
      isUnderline: Boolean(para.hasUnderline),
      isHighlight: Boolean(para.hasHighlight),
      isBarePrefix,
    };
  }
  const tabM = trimmed.match(OPTION_TAB_REGEX);
  if (tabM) {
    const leadingMark = Boolean(tabM[1]);
    const letter = tabM[2].toUpperCase();
    const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
      tabM[3]
    );
    const optText = cleanedText || `Pilihan ${letter}`;
    return {
      letter,
      text: optText,
      isRed: para.hasRed || leadingMark || isMarkedCorrect,
      isBold: Boolean(para.isAllBold),
      isUnderline: Boolean(para.hasUnderline),
      isHighlight: Boolean(para.hasHighlight),
    };
  }
  if (para.autoOptionLetter) {
    const { cleanedText, isMarkedCorrect } =
      extractTrailingCorrectMarker(trimmed);
    return {
      letter: para.autoOptionLetter,
      text: cleanedText || trimmed,
      isRed: para.hasRed || isMarkedCorrect,
      isBold: Boolean(para.isAllBold),
      isUnderline: Boolean(para.hasUnderline),
      isHighlight: Boolean(para.hasHighlight),
    };
  }
  return null;
}

function matchNumberedQuestionLine(
  para: ParsedParagraph
): { qNum: number; qText: string } | null {
  const trimmed = sanitizeMessyLineText(para.fullText).trim();
  const m = trimmed.match(NUMBERED_QUESTION_REGEX);
  if (m) {
    const numStr = m[1] || m[2] || m[3] || '';
    const qText = (m[4] || '').trim();
    const bareLead = trimmed.replace(/^[•\-\*▪▫\s]+/, '');
    // Guard against decimal numbers like "1.5 liter" or "2.75 gram" when there was no space after "."
    if (m[3] && /^\d+\.\d/.test(bareLead)) {
      return null;
    }
    // Guard against algebraic math equations/ratios like "2 - x = 5", "1 - sin^2 x", or "2 : 3 = 4 : 6"
    if (
      m[3] &&
      (/^\d+\s*-\s*(?:[a-zA-Z0-9\\$\(\[]|.*=)/.test(bareLead) ||
        /^\d+\s*:\s*\d+\s*=/.test(bareLead))
    ) {
      return null;
    }
    const qNum = parseInt(numStr, 10);
    // Reject years (e.g., "1803), John Dalton...") or absurd inline numbers
    if (Number.isNaN(qNum) || qNum <= 0 || qNum > 200) {
      return null;
    }
    if (!qText) return null;
    return {
      qNum,
      qText,
    };
  }
  if (para.autoQuestionNumber !== undefined && !para.autoOptionLetter) {
    return {
      qNum: para.autoQuestionNumber,
      qText: trimmed,
    };
  }
  return null;
}

/**
 * Finalizes a DraftQuestion:
 * - Reconciles partially prefixed options (e.g. when 1-4 options had A..E and 1-4 options lost their prefix/numId).
 * - Recovers options from allParagraphs / unprefixedParagraphs when options had no A..E prefixes.
 * - Sorts 2-column options (e.g. A, D, B, E, C) into A, B, C, D, E order.
 */
function finalizeDraftQuestion(draft: DraftQuestion | null): DraftQuestion | null {
  if (!draft) return null;

  const allRecords = draft.allParagraphs || [];

  // 0. If this draft ALREADY has structured Benar/Salah statements, Menjodohkan pairs/lists,
  //    or is explicitly an Isian Singkat / Menjodohkan question without A..E options,
  //    NEVER cannibalize its paragraphs into fake Pilihan Ganda options!
  const hasExplicitStructuredType =
    (draft.explicitStatements && draft.explicitStatements.length > 0) ||
    (draft.explicitMatchingPairs && draft.explicitMatchingPairs.length > 0) ||
    (draft.explicitPremises && draft.explicitPremises.length >= 2) ||
    (draft.detectedType === 'isian_singkat' && draft.options.length < 2) ||
    (draft.detectedType === 'menjodohkan' && draft.options.length < 2) ||
    (draft.explicitTextAnswers &&
      draft.explicitTextAnswers.length > 0 &&
      draft.options.length < 2);

  if (hasExplicitStructuredType) {
    if (draft.questionLines.length === 0) {
      if (draft.explicitStatements && draft.explicitStatements.length > 0) {
        draft.questionLines = [
          draft.explicitInstruction ||
            'Tentukan Benar atau Salah untuk setiap pernyataan berikut!',
        ];
      } else if (
        (draft.explicitMatchingPairs && draft.explicitMatchingPairs.length > 0) ||
        (draft.explicitPremises && draft.explicitPremises.length > 0)
      ) {
        draft.questionLines = [
          draft.explicitInstruction ||
            'Pasangkan setiap pernyataan pada kolom kiri dengan pasangan yang sesuai di kolom kanan!',
        ];
      } else if (draft.questionImages && draft.questionImages.length > 0) {
        draft.questionLines = [
          'Perhatikan gambar berikut untuk menjawab pertanyaan!',
        ];
      } else if (draft.stimulusTable) {
        draft.questionLines = [
          'Perhatikan tabel berikut untuk menjawab pertanyaan!',
        ];
      }
    }
    return draft;
  }

  // Also detect inline "Pernyataan 1: ... [Kunci: Benar]" or arrow matching lines before fake option recovery
  const nonEmptyLines = draft.questionLines
    .map((l) => l.trim())
    .filter(Boolean);
  const inlineArrowPairLines = nonEmptyLines.filter((l) =>
    /^(?:[-•*▪▫]\s*|\d+[\.\)\-:]\s*)?.+?\s*(?:===>|==>|--->|->|=>|<->|↔|—)\s*.+$/.test(
      l
    )
  );
  if (inlineArrowPairLines.length >= 2 && draft.options.length < 2) {
    return draft;
  }
  const inlineBsStatementLines = nonEmptyLines.filter((l) =>
    /^(?:pernyataan\s*\d+\s*[:\.\-]\s*|(?:[-•*▪▫]|\d+[\.\)])\s*).+?(?:[\(\[]\s*(?:kunci\s*:\s*)?(?:benar|salah|sesuai|tidak\s+sesuai|ya|tidak|fakta|opini|setuju|tidak\s+setuju|b|s)\s*[\)\]])\s*$/i.test(
      l
    )
  );
  if (
    draft.options.length < 2 &&
    (inlineBsStatementLines.length >= 2 ||
      (inlineBsStatementLines.length === 1 &&
        (draft.detectedType === 'benar_salah' ||
          /^pernyataan\s*\d+/i.test(inlineBsStatementLines[0]))))
  ) {
    return draft;
  }

  // 0B. Convert trailing bullet-only options ("- CO2", "- H2O (Benar)", "- O2", "- NaCl") into PG/PGK options A..F
  if (
    draft.options.length === 0 &&
    allRecords.length >= 3 &&
    draft.detectedType !== 'benar_salah' &&
    draft.detectedType !== 'menjodohkan' &&
    draft.detectedType !== 'isian_singkat'
  ) {
    let firstBulletIdx = allRecords.length;
    while (
      firstBulletIdx > 1 &&
      /^[•\-\*▪▫◦○●]\s+\S/.test(allRecords[firstBulletIdx - 1].para.fullText.trim())
    ) {
      firstBulletIdx--;
    }
    const bulletCount = allRecords.length - firstBulletIdx;
    if (bulletCount >= 2 && bulletCount <= 6 && firstBulletIdx >= 1) {
      const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
      const stemRecs = allRecords.slice(0, firstBulletIdx);
      const bulletRecs = allRecords.slice(firstBulletIdx);
      draft.questionLines = stemRecs
        .map((r) => r.para.fullText.trim())
        .filter(Boolean);
      draft.questionImages = mergeUniqueImages(
        draft.questionImages,
        ...stemRecs.map((r) => r.para.images)
      );
      draft.options = bulletRecs.map((r, bIdx) => {
        const stripped = r.para.fullText.trim().replace(/^[•\-\*▪▫◦○●]\s+/, '').trim();
        const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(stripped);
        return {
          id: letters[bIdx] || String.fromCharCode(65 + bIdx),
          text: cleanedText || stripped,
          isRed: r.para.hasRed || isMarkedCorrect,
          isBold: Boolean(r.para.isAllBold),
          isUnderline: Boolean(r.para.hasUnderline),
          isHighlight: Boolean(r.para.hasHighlight),
          images: r.para.images,
        };
      });
    }
  }

  // 1. If some options were matched (1..4 options) AND there are unprefixed paragraphs after/between options
  //    (e.g. when 1 or more options lost their A..E prefix or auto-numbering!)
  if (
    draft.options.length >= 1 &&
    draft.options.length < 5 &&
    allRecords.length >= 5 &&
    draft.detectedType !== 'menjodohkan' &&
    draft.detectedType !== 'benar_salah'
  ) {
    const firstOptIdx = allRecords.findIndex((r) => Boolean(r.matchedOption));
    if (firstOptIdx !== -1) {
      const trailingCount = allRecords.length - firstOptIdx;
      // Case 1A: From firstOptIdx to the end there are 4 or 5 paragraphs (some matched, some unprefixed)
      if (trailingCount === 5 || trailingCount === 4) {
        const stemRecords = allRecords.slice(0, firstOptIdx);
        const optRecords = allRecords.slice(firstOptIdx);
        if (stemRecords.length >= 1 || draft.stimulusTable) {
          const letters = ['A', 'B', 'C', 'D', 'E'];
          draft.questionLines = stemRecords
            .map((r) => r.para.fullText.trim())
            .filter(Boolean);
          draft.questionImages = mergeUniqueImages(
            draft.questionImages,
            ...stemRecords.map((r) => r.para.images)
          );
          draft.options = optRecords.map((r, idx) => ({
            id: letters[idx] || 'E',
            text: r.matchedOption
              ? r.matchedOption.text
              : r.para.fullText.replace(/^[•\-\*▪▫◦☐☑✓✔\d]+[\.\)\-:]?\s*/, '').trim(),
            isRed: r.matchedOption ? r.matchedOption.isRed : r.para.hasRed,
            isBold: r.matchedOption ? r.matchedOption.isBold : Boolean(r.para.isAllBold),
            isUnderline: r.matchedOption
              ? r.matchedOption.isUnderline
              : Boolean(r.para.hasUnderline),
            isHighlight: r.matchedOption
              ? r.matchedOption.isHighlight
              : Boolean(r.para.hasHighlight),
            images: mergeUniqueImages(r.matchedOption?.images, r.para.images),
          }));
        }
      } else if (allRecords.length >= 6) {
        // Case 1B: First option was NOT at index firstOptIdx (e.g., Option A lost its prefix, and B..E or only C was matched!)
        const stemRecords = allRecords.slice(0, allRecords.length - 5);
        const optRecords = allRecords.slice(allRecords.length - 5);
        const letters = ['A', 'B', 'C', 'D', 'E'];
        draft.questionLines = stemRecords
          .map((r) => r.para.fullText.trim())
          .filter(Boolean);
        draft.questionImages = mergeUniqueImages(
          draft.questionImages,
          ...stemRecords.map((r) => r.para.images)
        );
        draft.options = optRecords.map((r, idx) => ({
          id: letters[idx] || 'E',
          text: r.matchedOption
            ? r.matchedOption.text
            : r.para.fullText.replace(/^[•\-\*▪▫◦☐☑✓✔\d]+[\.\)\-:]?\s*/, '').trim(),
          isRed: r.matchedOption ? r.matchedOption.isRed : r.para.hasRed,
          isBold: r.matchedOption ? r.matchedOption.isBold : Boolean(r.para.isAllBold),
          isUnderline: r.matchedOption
            ? r.matchedOption.isUnderline
            : Boolean(r.para.hasUnderline),
          isHighlight: r.matchedOption
            ? r.matchedOption.isHighlight
            : Boolean(r.para.hasHighlight),
          images: mergeUniqueImages(r.matchedOption?.images, r.para.images),
        }));
      }
    }
  }

  // 2. If only 4 options (B, C, D, E) were matched and Option A was glued at the end of the last question stem line!
  if (
    draft.options.length === 4 &&
    !draft.options.some((o) => o.id === 'A') &&
    draft.questionLines.length > 0
  ) {
    const lastStemIdx = draft.questionLines.length - 1;
    const lastStem = draft.questionLines[lastStemIdx];
    const inlineAMatch = lastStem.match(/^(.*?)[\s\t]+(?:[Aa][\.\)\-:]|\([Aa]\))\s+(.+)$/);
    if (inlineAMatch && inlineAMatch[1].trim() && inlineAMatch[2].trim()) {
      draft.questionLines[lastStemIdx] = inlineAMatch[1].trim();
      draft.options.unshift({
        id: 'A',
        text: inlineAMatch[2].trim(),
        isRed: false,
      });
    }
  }

  // 3. If < 2 options were found, recover options from allRecords or unprefixedParagraphs ONLY when they look like options!
  if (draft.options.length < 2) {
    const sourceParas =
      allRecords.length >= 2
        ? allRecords.map((r) => r.para)
        : draft.unprefixedParagraphs;
    const totalParas = sourceParas.length;

    // For benar_salah with unprefixed bullet/numbered statement lines, convert statements cleanly instead of guessing PG options
    if (draft.detectedType === 'benar_salah' && totalParas >= 2) {
      const stemPara = sourceParas[0];
      const stmtParas = sourceParas.slice(1);
      draft.questionLines = [stemPara.fullText.trim()];
      draft.explicitStatements = stmtParas.map((sp, sIdx) => {
        const cleanStmt = sp.fullText
          .replace(/^(?:pernyataan\s*\d+\s*[:\.\-]\s*|(?:[-•*▪▫]|\d+[\.\)\-:])\s*)/i, '')
          .trim();
        const suffixM = cleanStmt.match(
          /^(.*?)[\s\-:]*[\(\[]\s*(?:kunci\s*:\s*)?(benar|salah|sesuai|tidak\s+sesuai|ya|tidak|fakta|opini|setuju|tidak\s+setuju|tepat|tidak\s+tepat|valid|tidak\s+valid|mendukung|tidak\s+mendukung|true|false|b|s)\s*[\)\]]\s*$/i
        );
        const rawText = suffixM ? suffixM[1].trim() : cleanStmt;
        const rawVal = suffixM ? suffixM[2].trim().toLowerCase() : '';
        const explicitKey = draft.explicitKeys[sIdx];
        let isBenar = sp.hasRed;
        if (rawVal) {
          isBenar = /^(?:benar|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true|b)$/i.test(
            rawVal
          );
        } else if (explicitKey === 'BENAR') {
          isBenar = true;
        } else if (explicitKey === 'SALAH') {
          isBenar = false;
        }
        return {
          id: `st${sIdx + 1}`,
          statement: rawText || cleanStmt,
          correctValue: isBenar ? 'Benar' : 'Salah',
          images: sp.images,
        };
      });
      return draft;
    }

    // For PGK with numbered statement lines (1., 2., 3., 4.) and no A..E options
    if (draft.detectedType === 'pilihan_ganda_kompleks' && totalParas >= 3) {
      const numberedItems = sourceParas.slice(1);
      const allLookLikeItems = numberedItems.every(
        (p) =>
          /^(?:[-•*▪▫☐☑]|\(?\d+[\.\)\-:])\s+/.test(p.fullText.trim()) ||
          p.fullText.trim().length < 220
      );
      if (allLookLikeItems && numberedItems.length >= 2 && numberedItems.length <= 8) {
        const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
        draft.questionLines = [sourceParas[0].fullText.trim()];
        draft.options = numberedItems.map((p, idx) => {
          const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
            p.fullText.replace(/^(?:[-•*▪▫☐☑✓✔]|\(?\d+[\.\)\-:])\s*/, '').trim()
          );
          return {
            id: letters[idx] || String.fromCharCode(65 + idx),
            text: cleanedText,
            isRed: p.hasRed || isMarkedCorrect,
            isBold: Boolean(p.isAllBold),
            isUnderline: Boolean(p.hasUnderline),
            isHighlight: Boolean(p.hasHighlight),
            images: p.images,
          };
        });
      }
    }

    if (draft.options.length < 2 && totalParas >= 2) {
      // Only recover unprefixed options when either:
      // - at least one trailing paragraph is colored red / highlighted / has an explicit A..E key, OR
      // - there are >= 4 trailing short paragraphs (classic unprefixed 4/5-choice PG!)
      const hasOptionKeySignal =
        draft.explicitKeys.some((k) => /^[A-E]$/.test(k)) ||
        sourceParas.slice(1).some((p) => p.hasRed || p.hasHighlight);

      let optCount = 0;
      if (totalParas >= 6) {
        optCount = 5;
      } else if (totalParas === 5) {
        optCount =
          draft.stimulusTable && !/[?:]|(?:\.\.\.)/.test(sourceParas[0].fullText)
            ? 5
            : 4;
      } else if (totalParas >= 3 && hasOptionKeySignal) {
        optCount = totalParas - 1;
      } else if (totalParas === 2) {
        // Check if the 2nd paragraph contains multiple options separated by tabs, 2+ spaces, or semicolons
        const secondPara = sourceParas[1];
        const parts = secondPara.fullText
          .split(/\t+|\s{2,}|\s*;\s*/)
          .map((s) => s.replace(/^[A-Ea-e][\.\)\-:]\s*/, '').trim())
          .filter(Boolean);
        if (parts.length >= 3 && parts.length <= 5) {
          const letters = ['A', 'B', 'C', 'D', 'E'];
          draft.questionLines = [sourceParas[0].fullText.trim()];
          draft.options = parts.map((pt, idx) => ({
            id: letters[idx] || 'E',
            text: pt,
            isRed: secondPara.hasRed && idx === 0,
          }));
        }
      }

      if (draft.options.length < 2 && optCount >= 2) {
        const stemParas = sourceParas.slice(0, totalParas - optCount);
        const optParas = sourceParas.slice(totalParas - optCount);
        const letters = ['A', 'B', 'C', 'D', 'E'];

        draft.questionLines = stemParas.map((p) => p.fullText.trim()).filter(Boolean);
        draft.questionImages = mergeUniqueImages(
          draft.questionImages,
          ...stemParas.map((p) => p.images)
        );
        draft.options = optParas.map((p, idx) => ({
          id: letters[idx] || 'E',
          text: p.fullText.replace(/^[•\-\*▪▫◦☐☑✓✔\d]+[\.\)\-:]?\s*/, '').trim(),
          isRed: p.hasRed,
          isBold: Boolean(p.isAllBold),
          isUnderline: Boolean(p.hasUnderline),
          isHighlight: Boolean(p.hasHighlight),
          images: p.images,
        }));
      }
    }
  }

  // 4. Sort options by letter (A, B, C, D, E) if all option IDs are distinct A..E (fixes 2-column A, D, B, E, C order!)
  if (draft.options.length >= 2) {
    const uniqueIds = new Set(draft.options.map((o) => o.id));
    if (uniqueIds.size === draft.options.length) {
      draft.options.sort((a, b) => a.id.localeCompare(b.id));
    }

    if (draft.questionLines.length === 0) {
      draft.questionLines = [
        draft.questionImages && draft.questionImages.length > 0
          ? 'Perhatikan gambar berikut untuk menjawab pertanyaan!'
          : draft.stimulusTable
          ? 'Perhatikan tabel berikut untuk menjawab pertanyaan!'
          : 'Pilihlah jawaban yang paling tepat!',
      ];
    }
    return draft;
  }

  // Case B: Explicitly numbered question (e.g. 1..35) or question with explicit statements/pairs/short-answers
  if (
    (draft.explicitStatements && draft.explicitStatements.length > 0) ||
    (draft.explicitMatchingPairs && draft.explicitMatchingPairs.length > 0) ||
    (draft.explicitPremises && draft.explicitPremises.length > 0) ||
    (draft.explicitTextAnswers && draft.explicitTextAnswers.length > 0) ||
    (draft.explicitNumber !== undefined &&
      (draft.questionLines.length > 0 || (draft.questionImages?.length ?? 0) > 0)) ||
    (draft.detectedType === 'isian_singkat' && draft.questionLines.length > 0)
  ) {
    const redParas = draft.unprefixedParagraphs.filter((p) => p.hasRed);
    if (
      redParas.length > 0 &&
      (!draft.explicitTextAnswers || draft.explicitTextAnswers.length === 0)
    ) {
      // If a subsequent line in the unprefixed paragraphs was colored red, treat it as the short answer key
      const nonStemRed = redParas.filter(
        (rp) => rp.fullText.trim() !== draft.questionLines[0]?.trim()
      );
      if (nonStemRed.length > 0) {
        draft.explicitTextAnswers = nonStemRed.map((rp) => rp.fullText.trim());
        const redSet = new Set(draft.explicitTextAnswers);
        draft.questionLines = draft.questionLines.filter(
          (l) => !redSet.has(l.trim())
        );
      }
    }
    if (!draft.detectedType && draft.options.length === 0) {
      draft.detectedType = 'isian_singkat';
    }
    return draft;
  }

  return null;
}

/**
 * Checks if a table is a Benar/Salah (or Sesuai/Tidak Sesuai, Ya/Tidak, Fakta/Opini, Setuju/Tidak Setuju, etc.)
 * statement table for a question. Supports both 1-row headers and 2-row merged headers.
 */
function tryExtractBenarSalahFromTable(
  table: ParsedTable
): { statements: StatementItem[]; trueLabel?: string; falseLabel?: string } | null {
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0)
  );
  if (rows.length < 2) return null;

  const isTrueHeader = (h: string) =>
    /^(?:benar|b|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true)$/.test(h);
  const isFalseHeader = (h: string) =>
    /^(?:salah|s|tidak\s+sesuai|tidak|opini|tidak\s+setuju|tidak\s+tepat|tidak\s+valid|tidak\s+mendukung|false)$/.test(
      h
    );

  let headerRowIdx = 0;
  let headers = rows[0].map((c) => c.fullText.replace(/\n+/g, ' ').trim().toLowerCase());
  let rawHeaders = rows[0].map((c) => c.fullText.replace(/\n+/g, ' ').trim());

  let benarCol = headers.findIndex(isTrueHeader);
  let salahCol = headers.findIndex(isFalseHeader);

  // Check 2-row merged header (e.g. Row 0: No | Pernyataan | Kategori, Row 1: "" | "" | Benar | Salah)
  if (benarCol === -1 && salahCol === -1 && rows.length >= 3) {
    const r1Headers = rows[1].map((c) =>
      c.fullText.replace(/\n+/g, ' ').trim().toLowerCase()
    );
    const r1Raw = rows[1].map((c) => c.fullText.replace(/\n+/g, ' ').trim());
    const r1Benar = r1Headers.findIndex(isTrueHeader);
    const r1Salah = r1Headers.findIndex(isFalseHeader);
    if (r1Benar !== -1 && r1Salah !== -1) {
      headerRowIdx = 1;
      headers = r1Headers.map((h, i) => h || headers[i] || '');
      rawHeaders = r1Raw.map((h, i) => h || rawHeaders[i] || '');
      benarCol = r1Benar;
      salahCol = r1Salah;
    }
  }

  const stmtCol = headers.findIndex(
    (h) =>
      h.includes('pernyataan') ||
      h.includes('statement') ||
      h.includes('kalimat') ||
      h.includes('uraian') ||
      h.includes('deskripsi') ||
      h.includes('kejadian') ||
      h.includes('peristiwa')
  );
  const keyCol = headers.findIndex(
    (h) =>
      h.includes('kunci') ||
      h.includes('jawaban') ||
      h === 'b/s' ||
      h === 'b - s' ||
      h === 'benar/salah' ||
      h === 'sesuai/tidak sesuai' ||
      h === 'ya/tidak' ||
      h === 'fakta/opini' ||
      h === 'status' ||
      h === 'kategori'
  );

  if (stmtCol === -1 && benarCol === -1 && keyCol === -1) {
    return null;
  }

  const effectiveStmtCol =
    stmtCol !== -1
      ? stmtCol
      : headers[0] === 'no' || headers[0] === 'no.' || headers[0] === 'nomor'
      ? 1
      : 0;

  if (benarCol === -1 && keyCol === -1) return null;

  let trueLabel: string | undefined;
  let falseLabel: string | undefined;
  if (benarCol !== -1 && salahCol !== -1) {
    const tRaw = rawHeaders[benarCol];
    const fRaw = rawHeaders[salahCol];
    if (tRaw && fRaw && !/^b$/i.test(tRaw) && !/^s$/i.test(fRaw)) {
      trueLabel = tRaw;
      falseLabel = fRaw;
    }
  } else if (keyCol !== -1) {
    const pairLbl = detectBenarSalahPairLabels(rawHeaders[keyCol] || '');
    if (pairLbl) {
      trueLabel = pairLbl.trueLabel;
      falseLabel = pairLbl.falseLabel;
    }
  }

  const strongCheckTokenRegex =
    /^(?:✓|✔|☑|✅|v|●|•|1|ya|benar|b|sesuai|fakta|setuju|tepat|valid|mendukung|true)$/i;
  const crossMarkTokenRegex = /^(?:✗|✘|x)$/i;
  const negativeTokenRegex =
    /^(?:salah|s|tidak\s*sesuai|tidak|opini|tidak\s*setuju|tidak\s*tepat|tidak\s*valid|tidak\s*mendukung|false|0|✗|✘|x)$/i;

  const statements: StatementItem[] = [];
  for (let rIdx = headerRowIdx + 1; rIdx < rows.length; rIdx++) {
    const r = rows[rIdx];
    const stmtCell = r[effectiveStmtCol];
    if (!stmtCell || (!stmtCell.fullText.trim() && !(stmtCell.images?.length ?? 0))) {
      continue;
    }

    let isBenar = stmtCell.hasRed;
    let decided = false;

    const bCell = benarCol !== -1 ? r[benarCol] : undefined;
    const sCell = salahCol !== -1 ? r[salahCol] : undefined;
    const bTxt = bCell ? bCell.fullText.trim().toLowerCase() : '';
    const sTxt = sCell ? sCell.fullText.trim().toLowerCase() : '';

    const bStrong = Boolean(
      bCell &&
        (bCell.hasRed || bCell.hasHighlight || strongCheckTokenRegex.test(bTxt))
    );
    const sStrong = Boolean(
      sCell &&
        (sCell.hasRed ||
          sCell.hasHighlight ||
          strongCheckTokenRegex.test(sTxt) ||
          (negativeTokenRegex.test(sTxt) && !crossMarkTokenRegex.test(sTxt)))
    );
    const bCross = Boolean(bCell && crossMarkTokenRegex.test(bTxt));
    const sCross = Boolean(sCell && crossMarkTokenRegex.test(sTxt));

    if (bStrong && !sStrong) {
      isBenar = true;
      decided = true;
    } else if (sStrong && !bStrong) {
      isBenar = false;
      decided = true;
    } else if (sCross && !bCross) {
      isBenar = false;
      decided = true;
    } else if (bCross && !sCross) {
      isBenar = true;
      decided = true;
    }

    if (!decided && keyCol !== -1 && r[keyCol]) {
      const kTxt = r[keyCol].fullText.trim().toLowerCase();
      if (strongCheckTokenRegex.test(kTxt)) {
        isBenar = true;
      } else if (negativeTokenRegex.test(kTxt)) {
        isBenar = false;
      }
    }

    statements.push({
      id: `st${statements.length + 1}`,
      statement:
        stmtCell.fullText.replace(/^\d+[\.\)\-:]\s*/, '').trim() ||
        `Pernyataan ${statements.length + 1}`,
      correctValue: isBenar ? 'Benar' : 'Salah',
      images: stmtCell.images,
    });
  }

  const isExplicitSingleRowBsTable =
    statements.length === 1 &&
    ((benarCol !== -1 && salahCol !== -1) ||
      stmtCol !== -1 ||
      (keyCol !== -1 &&
        /benar|salah|sesuai|ya\s*\/\s*tidak|fakta\s*\/\s*opini|^b\s*\/\s*s$/i.test(
          headers[keyCol] || ''
        )));

  return statements.length >= 2 || isExplicitSingleRowBsTable
    ? { statements, trueLabel, falseLabel }
    : null;
}

/**
 * Checks if a table is a Menjodohkan (Premis -> Respon) table for a question.
 * Supports 2-col (Premis | Respon), 3-col (No | Premis | Respon or Premis | Respon | Kunci),
 * 4-col (No | Premis | Kode | Respon or No | Premis | Respon | Kunci),
 * 5-col (No | Premis | Kode | Respon | Kunci), and extra distractor responses!
 */
function tryExtractMenjodohkanFromTable(
  table: ParsedTable,
  forceMenjodohkan: boolean = false
): {
  premises: MatchingPremise[];
  responses: MatchingResponse[];
  correctPairs: Record<string, string>;
  hasExplicitKeyCol: boolean;
} | null {
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0 || (c.images?.length ?? 0) > 0)
  );
  if (rows.length < 2) return null;

  const headers = rows[0].map((c) => c.fullText.replace(/\n+/g, ' ').trim().toLowerCase());
  let premCol = headers.findIndex(
    (h) =>
      h.includes('premis') ||
      h.includes('pernyataan') ||
      h.includes('kolom a') ||
      h.includes('kolom 1') ||
      h.includes('bagian a') ||
      h.includes('bagian 1') ||
      h.includes('kiri') ||
      h.includes('istilah') ||
      h.includes('organ') ||
      h.includes('tokoh') ||
      h.includes('konsep') ||
      h === 'soal'
  );
  let respCol = headers.findIndex(
    (h, idx) =>
      idx !== premCol &&
      (h.includes('respon') ||
        h.includes('pasangan') ||
        h.includes('kolom b') ||
        h.includes('kolom 2') ||
        h.includes('bagian b') ||
        h.includes('bagian 2') ||
        h.includes('kanan') ||
        h.includes('pengertian') ||
        h.includes('definisi') ||
        h.includes('fungsi') ||
        h.includes('peran') ||
        h.includes('penjelasan') ||
        h.includes('keterangan') ||
        (h.includes('jawaban') && !h.includes('kunci')))
  );
  let keyCol = headers.findIndex(
    (h, idx) =>
      idx !== premCol &&
      idx !== respCol &&
      (h.includes('kunci') || h === 'key' || h === 'kode kunci')
  );

  let startRow = 1;
  if (premCol === -1 || respCol === -1 || premCol === respCol) {
    if (!forceMenjodohkan) return null;
    const colCount = rows[0].length;
    if (colCount === 2) {
      premCol = 0;
      respCol = 1;
      const looksLikeHeader =
        /^(kolom|bagian|no|premis|soal|pernyataan|istilah|kiri|kanan|pasangan|jawaban)/i.test(
          headers[0]
        ) ||
        /^(kolom|bagian|respon|pasangan|jawaban|kanan|fungsi|pengertian)/i.test(
          headers[1]
        );
      startRow = looksLikeHeader ? 1 : 0;
    } else if (colCount === 3) {
      const col0IsNo =
        headers[0] === 'no' ||
        headers[0] === 'no.' ||
        headers[0] === 'nomor' ||
        /^\d+\.?$/.test(rows[1]?.[0]?.fullText.trim() || '');
      if (col0IsNo) {
        premCol = 1;
        respCol = 2;
        startRow = /^(no|no\.|nomor)$/i.test(headers[0]) ? 1 : 0;
      } else {
        premCol = 0;
        respCol = 1;
        keyCol = 2;
        startRow = 1;
      }
    } else if (colCount === 4) {
      // Detect: [No | Premis | Huruf/Kode | Respon] OR [No | Premis | Respon | Kunci]
      const col2IsLetterCode = rows
        .slice(1)
        .filter((r) => r[2]?.fullText.trim())
        .every((r) => /^[A-Ha-h][\.\)\-:]?$/.test(r[2].fullText.trim()));
      if (col2IsLetterCode) {
        premCol = 1;
        respCol = 3;
        startRow = /^(no|no\.|nomor|kolom|premis)/i.test(headers[0]) ? 1 : 0;
      } else {
        premCol = 1;
        respCol = 2;
        keyCol = 3;
        startRow = 1;
      }
    } else if (colCount === 5) {
      premCol = 1;
      respCol = 3;
      keyCol = 4;
      startRow = 1;
    } else {
      return null;
    }
  }

  const premises: MatchingPremise[] = [];
  const responses: MatchingResponse[] = [];
  const rowKeys: (string | null)[] = [];
  const respLetterToId: Record<string, string> = {};
  const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

  // Check if there is a separate response-code column immediately before respCol (e.g. col2 = 'A.', 'B.', 'C.')
  const respCodeCol =
    respCol >= 2 &&
    respCol - 1 !== premCol &&
    rows
      .slice(startRow)
      .some((r) => /^[A-Ha-h][\.\)\-:]?$/.test(r[respCol - 1]?.fullText.trim() || ''))
      ? respCol - 1
      : -1;

  for (let rIdx = startRow; rIdx < rows.length; rIdx++) {
    const r = rows[rIdx];
    const pCell = r[premCol];
    const rCell = r[respCol];
    const pRaw = pCell?.fullText.trim() || '';
    const rRaw = rCell?.fullText.trim() || '';

    const pText = pRaw.replace(/^\d+[\.\)\-:]\s*/, '').trim();
    const rLetterMatch = rRaw.match(/^([A-Ha-h])[\.\)\-:]\s*(.*)$/);
    const explicitRespCode =
      (respCodeCol !== -1
        ? r[respCodeCol]?.fullText.trim().match(/^([A-Ha-h])/)?.[1]
        : undefined) || rLetterMatch?.[1];
    const rText = rLetterMatch
      ? rLetterMatch[2].trim()
      : rRaw.replace(/^[A-Za-z0-9]+[\.\)\-:]\s*/, '').trim();

    const hasPrem = Boolean(pText || (pCell?.images?.length ?? 0) > 0);
    const hasResp = Boolean(rText || (rCell?.images?.length ?? 0) > 0);

    if (hasPrem) {
      const pId = `p${premises.length + 1}`;
      premises.push({
        id: pId,
        text: pText || `Premis ${premises.length + 1}`,
        ...(pCell?.images?.length ? { images: pCell.images } : {}),
      });
      const rawKey = keyCol !== -1 ? r[keyCol]?.fullText.trim() || '' : '';
      rowKeys.push(rawKey || null);
    }

    if (hasResp) {
      const rId = `r${responses.length + 1}`;
      const letterKey = (
        explicitRespCode ||
        letters[responses.length] ||
        String(responses.length + 1)
      ).toUpperCase();
      respLetterToId[letterKey] = rId;
      respLetterToId[String(responses.length + 1)] = rId;
      responses.push({
        id: rId,
        text: rText || `Pasangan ${responses.length + 1}`,
        ...(rCell?.images?.length ? { images: rCell.images } : {}),
      });
    }
  }

  if (premises.length < 2 || responses.length < 2) return null;

  const correctPairs: Record<string, string> = {};
  let hasExplicitKeyCol = false;

  premises.forEach((p, idx) => {
    const kRaw = rowKeys[idx];
    if (kRaw) {
      const codeMatch =
        kRaw.match(/(?:->|=>|[\-:=])\s*([A-Ha-h]|\d+)/i) ||
        kRaw.match(/^([A-Ha-h]|\d+)$/i);
      const code = codeMatch ? codeMatch[1].toUpperCase() : '';
      if (code && respLetterToId[code]) {
        correctPairs[p.id] = respLetterToId[code];
        hasExplicitKeyCol = true;
        return;
      }
      // Also allow matching by exact response text in key column
      const matchedByText = responses.find(
        (resp) => resp.text.toLowerCase() === kRaw.toLowerCase()
      );
      if (matchedByText) {
        correctPairs[p.id] = matchedByText.id;
        hasExplicitKeyCol = true;
        return;
      }
    }
    // Default 1-to-1 row alignment
    const fallbackResp = responses[idx] || responses[responses.length - 1];
    correctPairs[p.id] = fallbackResp.id;
  });

  return { premises, responses, correctPairs, hasExplicitKeyCol };
}

/**
 * Checks if a table is an Options Table (A, B, C, D, E) belonging to the preceding question paragraph.
 * Supports borderless 2-column option tables AND multi-column comparison option tables (with or without a header row).
 */
function tryExtractOptionsOnlyFromTable(
  table: ParsedTable
): {
  id: string;
  text: string;
  isRed: boolean;
  isBold?: boolean;
  isUnderline?: boolean;
  isHighlight?: boolean;
  images?: string[];
}[] | null {
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0 || (c.images?.length ?? 0) > 0)
  );
  if (rows.length === 0 || rows.length > 7) return null;

  const optionLabelOnlyRegex = /^(?:opsi\s*|pilihan\s*)?[\(\[]?([A-Ea-e])[\)\]]?[\.\)\-:]?$/i;

  // Check if Row 0 is a header row and Rows 1..N are options A, B, C, D(, E)
  let startRow = 0;
  let headers: string[] = [];
  if (
    rows.length >= 4 &&
    rows[0].length >= 2 &&
    !optionLabelOnlyRegex.test(rows[0][0].fullText.trim()) &&
    !OPTION_LINE_REGEX.test(rows[0][0].fullText.trim()) &&
    optionLabelOnlyRegex.test(rows[1][0].fullText.trim())
  ) {
    startRow = 1;
    headers = rows[0].map((c) => c.fullText.replace(/\n+/g, ' ').trim());
  }

  const extractedOptions: {
    id: string;
    text: string;
    isRed: boolean;
    isBold?: boolean;
    isUnderline?: boolean;
    isHighlight?: boolean;
    images?: string[];
  }[] = [];

  for (let rIdx = startRow; rIdx < rows.length; rIdx++) {
    const r = rows[rIdx];

    // Check 4-column / 6-column side-by-side (label, value) option grids: e.g. [A. | Mitokondria | C. | Lisosom]
    if (
      r.length >= 4 &&
      r.length % 2 === 0 &&
      optionLabelOnlyRegex.test(r[0].fullText.trim()) &&
      optionLabelOnlyRegex.test(r[2].fullText.trim())
    ) {
      let allPairsValid = true;
      const gridRowOpts: typeof extractedOptions = [];
      for (let c = 0; c < r.length; c += 2) {
        const lbl = r[c].fullText.trim();
        const valCell = r[c + 1];
        if (!lbl && !valCell.fullText.trim() && !valCell.images?.length) continue;
        const lm = lbl.match(optionLabelOnlyRegex);
        if (!lm) {
          allPairsValid = false;
          break;
        }
        const letter = lm[1].toUpperCase();
        const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
          valCell.fullText.replace(/\n+/g, ' ').trim()
        );
        gridRowOpts.push({
          id: letter,
          text: cleanedText || (valCell.images?.length ? '' : `Pilihan ${letter}`),
          isRed: r[c].hasRed || valCell.hasRed || isMarkedCorrect,
          isBold: Boolean(valCell.hasBold),
          isUnderline: Boolean(valCell.hasUnderline),
          isHighlight: Boolean(r[c].hasHighlight || valCell.hasHighlight),
          images: mergeUniqueImages(r[c].images, valCell.images),
        });
      }
      if (allPairsValid && gridRowOpts.length > 0) {
        extractedOptions.push(...gridRowOpts);
        continue;
      }
    }

    // Check if 2+ col label + text row: [A. | Col1 | Col2...]
    if (r.length >= 2 && optionLabelOnlyRegex.test(r[0].fullText.trim())) {
      const letter = r[0].fullText.trim().match(optionLabelOnlyRegex)![1].toUpperCase();
      const colTexts: string[] = [];
      for (let cIdx = 1; cIdx < r.length; cIdx++) {
        const val = r[cIdx].fullText.replace(/\n+/g, ' ').trim();
        if (!val) continue;
        if (headers[cIdx] && r.length >= 3) {
          colTexts.push(`${headers[cIdx]}: ${val}`);
        } else {
          colTexts.push(val);
        }
      }
      const rowImages = mergeUniqueImages(...r.slice(1).map((c) => c.images));
      const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
        colTexts.join(' — ')
      );
      const text = cleanedText || (rowImages ? '' : `Pilihan ${letter}`);
      extractedOptions.push({
        id: letter,
        text,
        isRed: r.some((cell) => cell.hasRed) || isMarkedCorrect,
        isBold: r.slice(1).some((cell) => cell.hasBold),
        isUnderline: r.slice(1).some((cell) => cell.hasUnderline),
        isHighlight: r.some((cell) => cell.hasHighlight),
        images: rowImages,
      });
      continue;
    }

    if (
      r.length >= 3 &&
      !r[0].fullText.trim() &&
      optionLabelOnlyRegex.test(r[1].fullText.trim())
    ) {
      const letter = r[1].fullText.trim().match(optionLabelOnlyRegex)![1].toUpperCase();
      const colTexts = r
        .slice(2)
        .map((c) => c.fullText.replace(/\n+/g, ' ').trim())
        .filter(Boolean);
      const rowImages = mergeUniqueImages(...r.slice(2).map((c) => c.images));
      const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
        colTexts.join(' — ')
      );
      const text = cleanedText || (rowImages ? '' : `Pilihan ${letter}`);
      extractedOptions.push({
        id: letter,
        text,
        isRed: r.some((cell) => cell.hasRed) || isMarkedCorrect,
        isBold: r.slice(2).some((cell) => cell.hasBold),
        isUnderline: r.slice(2).some((cell) => cell.hasUnderline),
        isHighlight: r.some((cell) => cell.hasHighlight),
        images: rowImages,
      });
      continue;
    }

    // Check if cells in the row are inline options like [A. Satu | D. Empat]
    let allCellsAreOptions = true;
    const rowOpts: typeof extractedOptions = [];
    for (const cell of r) {
      if (!cell.fullText.trim()) continue;
      const m = cell.fullText.trim().match(OPTION_LINE_REGEX);
      if (m) {
        const letter = (m[2] || m[3] || m[4] || 'A').toUpperCase();
        const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
          (m[6] || '').trim()
        );
        rowOpts.push({
          id: letter,
          text: cleanedText || (cell.images?.length ? '' : `Pilihan ${letter}`),
          isRed: cell.hasRed || Boolean(m[1] || m[5]) || isMarkedCorrect,
          isBold: Boolean(cell.hasBold),
          isUnderline: Boolean(cell.hasUnderline),
          isHighlight: Boolean(cell.hasHighlight),
          images: cell.images,
        });
      } else {
        allCellsAreOptions = false;
        break;
      }
    }
    if (allCellsAreOptions && rowOpts.length > 0) {
      extractedOptions.push(...rowOpts);
    } else {
      return null;
    }
  }

  if (extractedOptions.length >= 2 && extractedOptions.length <= 6) {
    extractedOptions.sort((a, b) => a.id.localeCompare(b.id));
    return extractedOptions;
  }
  return null;
}

/**
 * Checks if a table is a "Bank Soal Table" (questions formatted inside table rows/columns).
 */
function tryExtractQuestionsFromBankSoalTable(
  table: ParsedTable
): DraftQuestion[] | null {
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0)
  );
  if (rows.length === 0) return null;

  const firstRowTexts = rows[0].map((c) => c.fullText.trim().toLowerCase());

  // CASE 1: Horizontal Table (e.g. No | Tipe Soal | Pertanyaan/Soal | Opsi A..E | Kunci)
  const hasSoalHeader = firstRowTexts.some(
    (t) =>
      t.includes('soal') ||
      t.includes('pertanyaan') ||
      t.includes('butir') ||
      t.includes('pokok') ||
      t === 'question' ||
      t === 'stem'
  );
  const hasExplicitOptionHeaders =
    firstRowTexts.filter((t) =>
      /^(?:opsi\s+|pilihan\s+|jawaban\s+)[a-e]$/i.test(t)
    ).length >= 2;

  if ((hasSoalHeader && rows[0].length >= 2) || hasExplicitOptionHeaders) {
    const drafts: DraftQuestion[] = [];
    let typeCol = firstRowTexts.findIndex(
      (t) =>
        t.includes('tipe') ||
        t.includes('jenis') ||
        t === 'type' ||
        t === 'bentuk soal' ||
        t === 'bentuk'
    );
    let stimCol = firstRowTexts.findIndex(
      (t) =>
        t.includes('stimulus') ||
        t.includes('wacana') ||
        t.includes('bacaan') ||
        t.includes('narasi')
    );
    let catCol = firstRowTexts.findIndex(
      (t) =>
        t.includes('kategori') ||
        t.includes('materi') ||
        t.includes('topik') ||
        t.includes('kompetensi')
    );
    let expCol = firstRowTexts.findIndex(
      (t) =>
        t.includes('pembahasan') ||
        t.includes('penjelasan') ||
        t.includes('penyelesaian') ||
        t === 'explanation'
    );
    let ptsCol = firstRowTexts.findIndex(
      (t) =>
        t.includes('bobot') ||
        t.includes('skor') ||
        t.includes('poin') ||
        t === 'points'
    );
    let qCol = firstRowTexts.findIndex(
      (t, idx) =>
        idx !== typeCol &&
        idx !== stimCol &&
        idx !== expCol &&
        (t.includes('soal') ||
          t.includes('pertanyaan') ||
          t.includes('butir') ||
          t.includes('pokok') ||
          t === 'question' ||
          t === 'stem')
    );
    const optCols: { letter: string; idx: number }[] = [];
    const stmtCols: number[] = [];
    let keyCol = -1;

    firstRowTexts.forEach((t, idx) => {
      if (
        idx === qCol ||
        idx === typeCol ||
        idx === stimCol ||
        idx === catCol ||
        idx === expCol ||
        idx === ptsCol
      ) {
        return;
      }
      const m = t.match(/^(?:opsi\s*|pilihan\s*|jawaban\s*)?([a-e])$/i);
      if (m) {
        optCols.push({ letter: m[1].toUpperCase(), idx });
      } else if (/^(?:pernyataan|statement)\s*\d*$/i.test(t)) {
        stmtCols.push(idx);
      } else if (
        t.includes('kunci') ||
        t === 'jawaban benar' ||
        t === 'jawaban' ||
        t === 'key' ||
        t === 'answer'
      ) {
        keyCol = idx;
      }
    });

    if (qCol === -1) {
      qCol =
        firstRowTexts[0] === 'no' ||
        firstRowTexts[0] === 'no.' ||
        firstRowTexts[0] === 'nomor'
          ? 1
          : 0;
    }
    if (
      optCols.length < 2 &&
      stmtCols.length === 0 &&
      rows[0].length >= qCol + 4
    ) {
      const letters = ['A', 'B', 'C', 'D', 'E'];
      for (let c = qCol + 1; c < rows[0].length && optCols.length < 5; c++) {
        if (
          c === keyCol ||
          c === typeCol ||
          c === stimCol ||
          c === catCol ||
          c === expCol ||
          c === ptsCol
        ) {
          continue;
        }
        optCols.push({ letter: letters[optCols.length], idx: c });
      }
    }

    for (let rIdx = 1; rIdx < rows.length; rIdx++) {
      const r = rows[rIdx];
      const qCell = r[qCol];
      if (!qCell || (!qCell.fullText.trim() && !(qCell.images?.length ?? 0))) {
        continue;
      }

      const rawTypeStr =
        typeCol !== -1 && r[typeCol] ? r[typeCol].fullText.trim() : '';
      const inlineTag = extractInlineQuestionTypeTag(qCell.fullText);
      const rowDetectedType =
        detectQuestionTypeFromText(rawTypeStr) ||
        inlineTag.type ||
        detectQuestionTypeFromText(qCell.fullText) ||
        undefined;
      const bsPairLabels =
        detectBenarSalahPairLabels(rawTypeStr) ||
        detectBenarSalahPairLabels(qCell.fullText) ||
        undefined;

      const options: {
        id: string;
        text: string;
        isRed: boolean;
        isBold?: boolean;
        isUnderline?: boolean;
        isHighlight?: boolean;
        images?: string[];
      }[] = [];
      optCols.forEach(({ letter, idx }) => {
        const cell = r[idx];
        if (cell && (cell.fullText.trim() || (cell.images?.length ?? 0) > 0)) {
          const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
            cell.fullText.replace(/^[A-Ea-e][\.\)\-:]\s*/, '').trim()
          );
          options.push({
            id: letter,
            text: cleanedText,
            isRed: cell.hasRed || isMarkedCorrect,
            isBold: cell.hasBold,
            isUnderline: cell.hasUnderline,
            isHighlight: cell.hasHighlight,
            images: cell.images,
          });
        }
      });

      const explicitStatements: StatementItem[] = [];
      if (stmtCols.length > 0) {
        stmtCols.forEach((sIdx, i) => {
          const cell = r[sIdx];
          if (cell && (cell.fullText.trim() || (cell.images?.length ?? 0) > 0)) {
            const rawSt = cell.fullText.trim();
            const isBenar =
              cell.hasRed ||
              /\((?:benar|b|sesuai|ya|fakta|setuju)\)\s*$/i.test(rawSt) ||
              !/\((?:salah|s|tidak\s*sesuai|tidak|opini|tidak\s*setuju)\)\s*$/i.test(
                rawSt
              );
            explicitStatements.push({
              id: `st${i + 1}`,
              statement: rawSt
                .replace(
                  /\s*\((?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju)\)\s*$/i,
                  ''
                )
                .trim(),
              correctValue: isBenar ? 'Benar' : 'Salah',
              images: cell.images,
            });
          }
        });
      }

      const explicitKeys: string[] = [];
      const explicitTextAnswers: string[] = [];
      let explicitMatchingKeyMap: Record<number, string> | undefined;
      if (keyCol !== -1 && r[keyCol]?.fullText.trim()) {
        const rawKey = r[keyCol].fullText.trim();
        const matchKeyMap = parseMatchingKeyString(rawKey);
        const isSingleOrMultiOptionKey =
          /^[A-Ea-e](?:\s*(?:[,\/&]|dan)\s*[A-Ea-e])*$/i.test(rawKey) ||
          /^(?:opsi\s*)?[A-Ea-e]$/i.test(rawKey);
        const isBsSeries =
          /^(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju)(?:\s*[,\/\-]\s*(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju))+$/i.test(
            rawKey
          );
        if (matchKeyMap) {
          explicitMatchingKeyMap = matchKeyMap;
        } else if (isBsSeries) {
          const bsTokens = rawKey
            .split(/[,\/\-]/)
            .map((x) => x.trim().toLowerCase())
            .filter(Boolean);
          const isPos = (tok: string) =>
            /^(?:benar|b|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true)$/.test(
              tok
            );
          if (explicitStatements.length > 0) {
            bsTokens.forEach((tok, idx) => {
              if (explicitStatements[idx]) {
                explicitStatements[idx].correctValue = isPos(tok)
                  ? 'Benar'
                  : 'Salah';
              }
            });
          } else if (options.length > 0) {
            options.forEach((opt, idx) => {
              const tok = bsTokens[idx];
              if (tok) {
                opt.isRed = isPos(tok);
              }
            });
          }
          explicitKeys.push(...bsTokens.map((tok) => (isPos(tok) ? 'BENAR' : 'SALAH')));
        } else if (
          isSingleOrMultiOptionKey &&
          options.length >= 2 &&
          rowDetectedType !== 'benar_salah'
        ) {
          const kMatches = rawKey.toUpperCase().match(/[A-E]/g);
          if (kMatches) explicitKeys.push(...kMatches);
        } else if (
          rowDetectedType === 'benar_salah' &&
          /^(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju)$/i.test(
            rawKey
          )
        ) {
          const isPos = /^(?:benar|b|sesuai|ya|fakta|setuju|true)$/i.test(rawKey);
          explicitKeys.push(isPos ? 'BENAR' : 'SALAH');
        } else {
          explicitTextAnswers.push(
            ...rawKey
              .split(/\s*[\/|;]\s*/)
              .map((s) => s.trim())
              .filter(Boolean)
          );
          const kMatches = rawKey.toUpperCase().match(/^[A-E]$/);
          if (kMatches) explicitKeys.push(kMatches[0]);
        }
      }

      const stimulusTable =
        qCell.nestedTables.length > 0
          ? convertParsedTableToQuestionTableData(qCell.nestedTables[0])
          : undefined;
      const stimText =
        stimCol !== -1 && r[stimCol]?.fullText.trim()
          ? r[stimCol].fullText.trim()
          : undefined;
      const stimImages =
        stimCol !== -1 && r[stimCol]?.images?.length
          ? r[stimCol].images
          : undefined;
      const explicitCategory =
        catCol !== -1 && r[catCol]?.fullText.trim()
          ? r[catCol].fullText.trim()
          : undefined;
      const explicitExplanation =
        expCol !== -1 && r[expCol]?.fullText.trim()
          ? r[expCol].fullText.trim()
          : undefined;
      const ptsRaw =
        ptsCol !== -1 && r[ptsCol]?.fullText.trim()
          ? parseInt(r[ptsCol].fullText.trim().replace(/[^\d]/g, ''), 10)
          : NaN;
      const explicitPoints =
        !Number.isNaN(ptsRaw) && ptsRaw > 0 ? ptsRaw : undefined;

      if (
        options.length >= 2 ||
        explicitStatements.length > 0 ||
        explicitTextAnswers.length > 0 ||
        explicitMatchingKeyMap ||
        rowDetectedType === 'isian_singkat' ||
        qCell.fullText.trim().length > 5
      ) {
        drafts.push({
          explicitNumber: rIdx,
          detectedType:
            rowDetectedType ||
            (explicitStatements.length > 0
              ? 'benar_salah'
              : explicitMatchingKeyMap
              ? 'menjodohkan'
              : options.length === 0
              ? 'isian_singkat'
              : undefined),
          explicitCategory,
          explicitExplanation,
          explicitPoints,
          trueLabel: bsPairLabels?.trueLabel,
          falseLabel: bsPairLabels?.falseLabel,
          stimulusText: stimText,
          stimulusImages: stimImages,
          questionLines: [
            inlineTag.cleanedText.replace(/^\d+[\.\)\-:]\s*/, '').trim(),
          ],
          questionImages: qCell.images,
          unprefixedParagraphs: [],
          options,
          explicitKeys,
          explicitTextAnswers:
            explicitTextAnswers.length > 0 ? explicitTextAnswers : undefined,
          explicitStatements:
            explicitStatements.length > 0 ? explicitStatements : undefined,
          explicitMatchingKeyMap,
          stimulusTable,
        });
      }
    }

    if (drafts.length > 0) return drafts;
  }

  // CASE 2: Vertical Table or Multi-Row Question Table (including CBT template tables: Jenis | Soal | A..E | Kunci | Pembahasan)
  const optionLabelRegex = /^(?:opsi\s*|pilihan\s*)?([A-Ea-e])[\.\)\-:]?$/i;
  const questionLabelRegex = /^(?:no\.?\s*|soal\s*(?:no\.?)?\s*)?(\d+)[\.\)\-:]?$/i;

  let optionRowCount = 0;
  for (const r of rows) {
    if (r.length === 2 || r.length === 3) {
      const c0 = r[0].fullText.trim();
      const c1 = r[1].fullText.trim();
      if (
        (optionLabelRegex.test(c0) && r.length === 2) ||
        (r.length === 3 && !c0 && optionLabelRegex.test(c1)) ||
        (r.length === 3 && questionLabelRegex.test(c0) && optionLabelRegex.test(c1)) ||
        (r.length === 2 && /^(?:kunci|jawaban|tipe|jenis|soal|pertanyaan)$/i.test(c0))
      ) {
        optionRowCount++;
      }
    }
  }

  if (optionRowCount >= 2) {
    const drafts: DraftQuestion[] = [];
    let currentDraft: DraftQuestion | null = null;

    const flush = () => {
      const finalized = finalizeDraftQuestion(currentDraft);
      if (finalized) {
        drafts.push(finalized);
      }
      currentDraft = null;
    };

    const ensureDraft = (): DraftQuestion => {
      if (!currentDraft) {
        currentDraft = {
          questionLines: [],
          unprefixedParagraphs: [],
          options: [],
          explicitKeys: [],
        };
      }
      return currentDraft;
    };

    const applyKeyValueToDraft = (rawKey: string, target: DraftQuestion) => {
      const trimmedKey = rawKey.trim();
      if (!trimmedKey) return;
      const mPairs = parseMatchingKeyString(trimmedKey);
      if (mPairs) {
        target.detectedType = 'menjodohkan';
        target.explicitMatchingKeyMap = mPairs;
        return;
      }
      if (
        /^(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju)(?:\s*[,\/\-]\s*(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju))+$/i.test(
          trimmedKey
        )
      ) {
        target.detectedType = 'benar_salah';
        const bsTokens = trimmedKey
          .split(/[,\/\-]/)
          .map((x) => x.trim().toLowerCase())
          .filter(Boolean);
        target.explicitKeys.push(
          ...bsTokens.map((tok) =>
            /^(?:benar|b|sesuai|ya|fakta|setuju|true)$/.test(tok)
              ? 'BENAR'
              : 'SALAH'
          )
        );
        return;
      }
      if (
        /^[A-Ea-e](?:\s*(?:[,\/&]|dan)\s*[A-Ea-e])*$/i.test(trimmedKey) &&
        target.detectedType !== 'benar_salah' &&
        target.detectedType !== 'isian_singkat'
      ) {
        const kMatches = trimmedKey.toUpperCase().match(/[A-E]/g);
        if (kMatches) {
          target.explicitKeys.push(...kMatches);
          if (kMatches.length > 1) target.detectedType = 'pilihan_ganda_kompleks';
        }
        return;
      }
      if (!target.explicitTextAnswers) target.explicitTextAnswers = [];
      target.explicitTextAnswers.push(
        ...trimmedKey
          .split(/\s*[\/|;]\s*/)
          .map((s) => s.trim())
          .filter(Boolean)
      );
    };

    for (const r of rows) {
      // Handle 1-cell merged row (e.g. stimulus or question continuation)
      if (r.length === 1) {
        const txt = r[0].fullText.trim();
        if (!txt && !(r[0].images?.length ?? 0)) continue;
        const optM = txt.match(OPTION_LINE_REGEX);
        if (optM && currentDraft) {
          const letter = (optM[2] || optM[3] || optM[4] || 'A').toUpperCase();
          const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
            (optM[6] || '').trim()
          );
          if (
            letter === 'A' &&
            currentDraft.options.some((o) => o.id === 'A') &&
            currentDraft.options.length >= 2
          ) {
            flush();
            currentDraft = ensureDraft();
          }
          currentDraft.options.push({
            id: letter,
            text: cleanedText || (r[0].images?.length ? '' : `Pilihan ${letter}`),
            isRed: r[0].hasRed || Boolean(optM[1] || optM[5]) || isMarkedCorrect,
            isBold: r[0].hasBold,
            isUnderline: r[0].hasUnderline,
            isHighlight: r[0].hasHighlight,
            images: r[0].images,
          });
        } else {
          if (currentDraft && currentDraft.options.length >= 2) {
            flush();
          }
          const d = ensureDraft();
          if (txt) {
            d.questionLines.push(txt.replace(/^\d+[\.\)\-:]\s*/, '').trim());
          }
          if (r[0].images?.length) {
            d.questionImages = mergeUniqueImages(d.questionImages, r[0].images);
          }
          if (r[0].nestedTables.length > 0 && !d.stimulusTable) {
            d.stimulusTable = convertParsedTableToQuestionTableData(
              r[0].nestedTables[0]
            );
          }
        }
        continue;
      }

      const c0 = r[0].fullText.trim();
      const c1 = r[1].fullText.trim();
      const c2 = r.length >= 3 ? r[2].fullText.trim() : '';

      if (
        /^(no|no\.|nomor)$/i.test(c0) &&
        /^(soal|pertanyaan|butir|uraian)/i.test(c1)
      ) {
        continue;
      }

      // Metadata rows inside vertical table (Tipe/Jenis, Stimulus/Wacana, Pembahasan, Skor/Bobot, Kategori)
      if (/^(?:tipe|jenis|bentuk)(?:\s*soal)?$/i.test(c0) && c1) {
        if (currentDraft && (currentDraft.options.length >= 2 || currentDraft.questionLines.length > 0)) {
          flush();
        }
        const d = ensureDraft();
        const tDetected = detectQuestionTypeFromText(c1);
        if (tDetected) d.detectedType = tDetected;
        const pairLbl = detectBenarSalahPairLabels(c1);
        if (pairLbl) {
          d.trueLabel = pairLbl.trueLabel;
          d.falseLabel = pairLbl.falseLabel;
        }
        continue;
      }

      if (/^(?:stimulus|wacana|bacaan)$/i.test(c0) && (c1 || r[1].images?.length)) {
        const d = ensureDraft();
        if (c1) d.stimulusText = d.stimulusText ? `${d.stimulusText}\n\n${c1}` : c1;
        if (r[1].images?.length) {
          d.stimulusImages = mergeUniqueImages(d.stimulusImages, r[1].images);
        }
        continue;
      }

      if (/^(?:pembahasan|penjelasan|penyelesaian)$/i.test(c0) && c1) {
        const d = ensureDraft();
        d.explicitExplanation = c1;
        continue;
      }

      if (/^(?:bobot|skor|poin|nilai)$/i.test(c0) && c1) {
        const d = ensureDraft();
        const pts = parseInt(c1.replace(/[^\d]/g, ''), 10);
        if (!Number.isNaN(pts) && pts > 0) d.explicitPoints = pts;
        continue;
      }

      if (/^(?:kategori|materi|topik)$/i.test(c0) && c1) {
        const d = ensureDraft();
        d.explicitCategory = c1;
        continue;
      }

      const optMatchCol0 = c0.match(optionLabelRegex);
      const optMatchCol1 = r.length >= 3 ? c1.match(optionLabelRegex) : null;

      if (optMatchCol0) {
        const letter = optMatchCol0[1].toUpperCase();
        const optCell = r[1];
        const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
          optCell.fullText.trim()
        );
        const optText =
          cleanedText || (optCell.images?.length ? '' : `Pilihan ${letter}`);
        const isRed = r[0].hasRed || optCell.hasRed || isMarkedCorrect;
        if (
          currentDraft &&
          letter === 'A' &&
          currentDraft.options.some((o) => o.id === 'A') &&
          currentDraft.options.length >= 2
        ) {
          flush();
        }
        const d = ensureDraft();
        d.options.push({
          id: letter,
          text: optText,
          isRed,
          isBold: optCell.hasBold,
          isUnderline: optCell.hasUnderline,
          isHighlight: optCell.hasHighlight,
          images: optCell.images,
        });
        continue;
      }

      if (optMatchCol1 && r.length >= 3) {
        const letter = optMatchCol1[1].toUpperCase();
        const optCell = r[2];
        const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
          optCell.fullText.trim()
        );
        const optText =
          cleanedText || (optCell.images?.length ? '' : `Pilihan ${letter}`);
        const isRed = r[1].hasRed || optCell.hasRed || isMarkedCorrect;
        if (
          currentDraft &&
          letter === 'A' &&
          currentDraft.options.some((o) => o.id === 'A') &&
          currentDraft.options.length >= 2
        ) {
          flush();
        }
        const d = ensureDraft();
        d.options.push({
          id: letter,
          text: optText,
          isRed,
          isBold: optCell.hasBold,
          isUnderline: optCell.hasUnderline,
          isHighlight: optCell.hasHighlight,
          images: optCell.images,
        });
        continue;
      }

      // What if c1 in a 2-col row has "A. Pilihan A" directly?
      const inlineOptCol1 = !c0 ? c1.match(OPTION_LINE_REGEX) : null;
      if (inlineOptCol1 && currentDraft) {
        const letter = (
          inlineOptCol1[2] ||
          inlineOptCol1[3] ||
          inlineOptCol1[4] ||
          'A'
        ).toUpperCase();
        const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(
          (inlineOptCol1[6] || '').trim()
        );
        currentDraft.options.push({
          id: letter,
          text: cleanedText || (r[1].images?.length ? '' : `Pilihan ${letter}`),
          isRed:
            r[1].hasRed ||
            Boolean(inlineOptCol1[1] || inlineOptCol1[5]) ||
            isMarkedCorrect,
          isBold: r[1].hasBold,
          isUnderline: r[1].hasUnderline,
          isHighlight: r[1].hasHighlight,
          images: r[1].images,
        });
        continue;
      }

      if (/^(?:kunci|jawaban|kj|key|answer)/i.test(c0) && c1 && currentDraft) {
        applyKeyValueToDraft(c1, currentDraft);
        continue;
      }

      const numLabelMatch = c0.match(questionLabelRegex);
      const qLabelMatch = numLabelMatch || /^(?:soal|pertanyaan)/i.test(c0);
      const targetCell = qLabelMatch ? (c1 ? r[1] : r[2] || r[1]) : r[0];
      const questionCandidateText = qLabelMatch
        ? c1 || c2
        : `${c0} ${c1}`.trim();

      if (questionCandidateText || targetCell?.images?.length) {
        if (currentDraft && (currentDraft.options.length >= 2 || numLabelMatch)) {
          flush();
        }
        if (!currentDraft) {
          currentDraft = {
            explicitNumber: numLabelMatch ? parseInt(numLabelMatch[1], 10) : undefined,
            questionLines: [],
            unprefixedParagraphs: [],
            options: [],
            explicitKeys: [],
          };
        }
        // Check if targetCell contains both the question AND options paragraphs!
        if (targetCell && targetCell.paragraphs.length >= 3) {
          const cellBlocks: DocumentBlock[] = [];
          for (const p of targetCell.paragraphs) {
            cellBlocks.push({ kind: 'paragraph', paragraph: p });
          }
          for (const nt of targetCell.nestedTables) {
            cellBlocks.push({ kind: 'table', table: nt });
          }
          const innerDrafts = buildDraftsFromBlockSequence(cellBlocks);
          if (innerDrafts.length > 0) {
            currentDraft = null;
            drafts.push(...innerDrafts);
            continue;
          }
        }

        if (questionCandidateText) {
          const inlineTag = extractInlineQuestionTypeTag(questionCandidateText);
          if (inlineTag.type && !currentDraft.detectedType) {
            currentDraft.detectedType = inlineTag.type;
          }
          currentDraft.questionLines.push(
            inlineTag.cleanedText.replace(/^\d+[\.\)\-:]\s*/, '').trim()
          );
        }
        if (targetCell?.images?.length) {
          currentDraft.questionImages = mergeUniqueImages(
            currentDraft.questionImages,
            targetCell.images
          );
        }
        if (
          targetCell &&
          targetCell.nestedTables.length > 0 &&
          !currentDraft.stimulusTable
        ) {
          const bsNested = tryExtractBenarSalahFromTable(targetCell.nestedTables[0]);
          const matchNested = tryExtractMenjodohkanFromTable(
            targetCell.nestedTables[0],
            currentDraft.detectedType === 'menjodohkan'
          );
          if (bsNested) {
            currentDraft.detectedType = 'benar_salah';
            currentDraft.explicitStatements = bsNested.statements;
            if (bsNested.trueLabel) currentDraft.trueLabel = bsNested.trueLabel;
            if (bsNested.falseLabel) currentDraft.falseLabel = bsNested.falseLabel;
          } else if (matchNested) {
            currentDraft.detectedType = 'menjodohkan';
            currentDraft.explicitPremises = matchNested.premises;
            currentDraft.explicitResponses = matchNested.responses;
            currentDraft.explicitMatchingCorrectPairs = matchNested.correctPairs;
          } else {
            currentDraft.stimulusTable = convertParsedTableToQuestionTableData(
              targetCell.nestedTables[0]
            );
          }
        }
      }
    }

    flush();
    if (drafts.length > 0) return drafts;
  }

  // CASE 3: Table where rows/cells contain full questions with options (e.g. [1 | Pertanyaan + A..E])
  const cellBlocks: DocumentBlock[] = [];
  let inlineOptionLinesCount = 0;
  for (const r of rows) {
    for (const c of r) {
      for (const p of c.paragraphs) {
        const expanded = splitInlineOptionsIfPresent(p);
        for (const ep of expanded) {
          cellBlocks.push({ kind: 'paragraph', paragraph: ep });
          if (matchOptionLine(ep)) {
            inlineOptionLinesCount++;
          }
        }
      }
      for (const nt of c.nestedTables) {
        cellBlocks.push({ kind: 'table', table: nt });
      }
    }
  }

  if (inlineOptionLinesCount >= 2) {
    const drafts = buildDraftsFromBlockSequence(cellBlocks);
    if (drafts.length > 0) return drafts;
  }

  return null;
}

/**
 * Extracts question number -> answer key mappings from an Answer Key Table inside a KUNCI JAWABAN section
 * (e.g. | No | Kunci | or multi-column | No | Kunci | No | Kunci |).
 */
function tryExtractAnswerKeysFromTable(
  table: ParsedTable
): Record<number, string> {
  const keys: Record<number, string> = {};
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0)
  );
  if (rows.length === 0) return keys;

  for (const r of rows) {
    // Check paired columns (0&1, 2&3, 4&5, ...) where left cell is a question number and right cell is the key
    for (let c = 0; c + 1 < r.length; c += 2) {
      const left = r[c].fullText.trim();
      const right = r[c + 1].fullText.trim();
      const numM = left.match(/^(\d+)\.?$/);
      if (numM && right && !/^(?:kunci|jawaban|key|answer|skor|bobot)$/i.test(right)) {
        const qNum = parseInt(numM[1], 10);
        if (qNum >= 1 && qNum <= 300) {
          keys[qNum] = right;
        }
      }
    }
  }

  return keys;
}

interface CollectedStimulus {
  num?: number;
  title: string;
  paragraphs: string[];
  images: string[];
  table?: QuestionTableData;
  attachedCount: number;
}

/**
 * Extracts per-row Benar/Salah numbered questions from a table like:
 * No | Pernyataan Ilmiah & Studi Kasus Numerasi | Pilihan (B - S)
 */
function tryExtractBenarSalahRowQuestionsFromTable(
  table: ParsedTable,
  sectionInstruction?: string
): DraftQuestion[] | null {
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0)
  );
  if (rows.length < 2) return null;

  const headers = rows[0].map((c) => c.fullText.replace(/\n+/g, ' ').trim().toLowerCase());
  const noCol = headers.findIndex(
    (h) => h === 'no' || h === 'no.' || h === 'nomor'
  );
  const stmtCol = headers.findIndex(
    (h) =>
      h.includes('pernyataan') ||
      h.includes('statement') ||
      h.includes('kalimat') ||
      h.includes('uraian')
  );
  const pilihanCol = headers.findIndex(
    (h) =>
      h.includes('pilihan') ||
      h.includes('opsi') ||
      h === 'b / s' ||
      h === 'b - s' ||
      h === 'b/s'
  );

  if (noCol === -1 || stmtCol === -1 || pilihanCol === -1) {
    return null;
  }

  // Verify data rows have numbered col0 and "B - S" / "B / S" / "Benar - Salah" in pilihanCol
  const drafts: DraftQuestion[] = [];
  for (let rIdx = 1; rIdx < rows.length; rIdx++) {
    const r = rows[rIdx];
    const numRaw = r[noCol]?.fullText.trim() || '';
    const numMatch = numRaw.match(/^(\d+)\.?$/);
    const stmtText = r[stmtCol]?.fullText.replace(/\n+/g, ' ').trim() || '';
    const pilCell = r[pilihanCol];
    const pilText = pilCell?.fullText.trim() || '';

    if (
      !numMatch ||
      !stmtText ||
      !/^(?:b\s*[\-\/]\s*s|benar\s*[\-\/]\s*salah)$/i.test(pilText)
    ) {
      return null;
    }

    const qNum = parseInt(numMatch[1], 10);
    // Check red highlight inside pilihan cell segments ("B" red vs "S" red) or statement cell
    let detectedBenar: boolean | undefined = undefined;
    if (pilCell && pilCell.paragraphs.length > 0) {
      for (const p of pilCell.paragraphs) {
        for (const seg of p.segments) {
          if (!seg.isRed) continue;
          const t = seg.text.trim().toUpperCase();
          if (t === 'B' || t === 'BENAR') detectedBenar = true;
          else if (t === 'S' || t === 'SALAH') detectedBenar = false;
        }
      }
    }
    if (detectedBenar === undefined && (r[stmtCol]?.hasRed || pilCell?.hasRed)) {
      detectedBenar = true;
    }

    drafts.push({
      explicitNumber: qNum,
      detectedType: 'benar_salah',
      questionLines: [
        sectionInstruction ||
          'Analisislah setiap pernyataan ilmiah di bawah ini, kemudian pilihlah BENAR atau SALAH!',
      ],
      unprefixedParagraphs: [],
      options: [],
      explicitKeys:
        detectedBenar !== undefined ? [detectedBenar ? 'BENAR' : 'SALAH'] : [],
      explicitStatements: [
        {
          id: 'st1',
          statement: stmtText,
          correctValue: detectedBenar ? 'Benar' : 'Salah',
        },
      ],
    });
  }

  return drafts.length >= 1 ? drafts : null;
}

/**
 * Extracts points weights per section (e.g. "BAGIAN I: Pilihan Ganda | 15 Soal | 2 Point / nomor")
 * from an answer key/scoring rubric table.
 */
function tryParseRubricWeightsTable(
  table: ParsedTable
): Record<string, number> {
  const weights: Record<string, number> = {};
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0)
  );
  if (rows.length < 2) return weights;
  const headerJoined = rows[0].map((c) => c.fullText.toLowerCase()).join(' ');
  if (!headerJoined.includes('bobot') && !headerJoined.includes('skor')) {
    return weights;
  }
  for (let rIdx = 1; rIdx < rows.length; rIdx++) {
    const label = rows[rIdx][0]?.fullText.trim() || '';
    const weightCol = rows[rIdx]
      .slice(1)
      .map((c) => c.fullText.trim())
      .find((t) => /(\d+)\s*(?:point|poin|skor)/i.test(t));
    if (!label || !weightCol) continue;
    const ptsMatch = weightCol.match(/(\d+)/);
    const qType = detectQuestionTypeFromText(label);
    if (ptsMatch && qType) {
      weights[qType] = parseInt(ptsMatch[1], 10);
    }
  }
  return weights;
}

/**
 * Detects borderless / layout tables that teachers use to wrap messy exams
 * (e.g. 1-column exam wrapper tables, 2-column [No | Soal + Opsi] tables without a Bank Soal header,
 * or tables whose cells contain numbered questions and A..E options) and unwraps them into ParsedParagraphs.
 */
function tryUnwrapLayoutTableToParagraphs(
  table: ParsedTable
): ParsedParagraph[] | null {
  const rows = table.rows.filter((r) =>
    r.some((c) => c.fullText.trim().length > 0 || (c.images?.length ?? 0) > 0)
  );
  if (rows.length === 0) return null;

  const maxCols = Math.max(...rows.map((r) => r.length));
  if (maxCols > 3) return null;

  let optionLikeParas = 0;
  let numberedQCount = 0;
  const collected: ParsedParagraph[] = [];

  for (const row of rows) {
    // Handle [No. | Soal / Opsi] 2-column borderless layout row
    if (
      row.length === 2 &&
      /^(?:soal\s*|no\.?\s*)?\d{1,3}[\.\)\-:]?$/i.test(row[0].fullText.trim()) &&
      row[1].paragraphs.length > 0
    ) {
      const numOnly = row[0].fullText.trim().match(/(\d{1,3})/)?.[1];
      const firstBody = row[1].paragraphs[0];
      const firstBodyText = firstBody.fullText.trim();
      const alreadyNumbered = /^\d{1,3}\s*[\.\)\-:]/.test(firstBodyText);
      if (numOnly && !alreadyNumbered && firstBodyText) {
        numberedQCount++;
        collected.push({
          ...firstBody,
          fullText: `${numOnly}. ${firstBodyText}`,
          segments: [
            { text: `${numOnly}. `, isRed: false },
            ...firstBody.segments,
          ],
        });
        for (let k = 1; k < row[1].paragraphs.length; k++) {
          const p = row[1].paragraphs[k];
          if (matchOptionLine(p, 0)) optionLikeParas++;
          if (matchNumberedQuestionLine(p)) numberedQCount++;
          collected.push(p);
        }
        continue;
      }
    }

    for (const cell of row) {
      for (const p of cell.paragraphs) {
        const t = p.fullText.trim();
        if (!t && !(p.images && p.images.length > 0)) continue;
        if (matchOptionLine(p, 0)) optionLikeParas++;
        if (matchNumberedQuestionLine(p)) numberedQCount++;
        collected.push(p);
      }
    }
  }

  // Unwrap ONLY when the table clearly wraps questions/options rather than being a data/stimulus table!
  const isSingleColWrapper = maxCols === 1 && (optionLikeParas >= 2 || numberedQCount >= 2);
  const isMultiColQuestionWrapper =
    maxCols <= 3 &&
    ((optionLikeParas >= 3 && numberedQCount >= 1) ||
      (numberedQCount >= 2 && optionLikeParas >= 2));

  return isSingleColWrapper || isMultiColQuestionWrapper ? collected : null;
}

/**
 * Builds DraftQuestions from a sequence of DocumentBlocks (paragraphs and tables).
 */
function buildDraftsFromBlockSequence(blocks: DocumentBlock[]): DraftQuestion[] {
  const expandedBlocks: DocumentBlock[] = [];
  for (const b of blocks) {
    if (b.kind === 'paragraph') {
      const splitParas = splitInlineOptionsIfPresent(b.paragraph);
      for (const sp of splitParas) {
        const t = sp.fullText.trim();
        const hasImgs = Boolean(sp.images && sp.images.length > 0);
        if (!t && !hasImgs) continue;
        if (
          !hasImgs &&
          /^(soal\s+ujian|kumpulan\s+soal|latihan\s+soal|bank\s+soal|daftar\s+soal|template\s+soal|asesmen\s+.*|petunjuk\s+pengerjaan\s*:?\s*$)/i.test(
            t
          ) &&
          t.length < 110
        ) {
          continue;
        }
        expandedBlocks.push({ kind: 'paragraph', paragraph: sp });
      }
    } else {
      expandedBlocks.push(b);
    }
  }

  let currentDraft: DraftQuestion | null = null;
  let currentSectionType: QuestionType | undefined = undefined;
  let currentSectionInstruction: string | undefined = undefined;
  let inInternalNumberedList = false;
  let internalListCounter = 0;
  let inAnswerKeySection = false;
  const answerKeyByNumber: Record<number, string> = {};
  const rubricWeightsByType: Record<string, number> = {};
  const stimuliByNumber: Record<number, CollectedStimulus> = {};
  let activeStimulus: CollectedStimulus | undefined = undefined;
  let collectingStimulus = false;
  const drafts: DraftQuestion[] = [];

  const createEmptyDraft = (explicitNumber?: number): DraftQuestion => ({
    explicitNumber,
    detectedType: currentSectionType,
    questionLines: [],
    questionImages: [],
    unprefixedParagraphs: [],
    allParagraphs: [],
    options: [],
    explicitKeys: [],
  });

  const attachStimulusToDraft = (draft: DraftQuestion) => {
    const stemJoined = draft.questionLines.join(' ');
    const explicitStimRef = stemJoined.match(/\bstimulus\s+(\d+)\b/i);
    let chosenStimulus: CollectedStimulus | undefined = undefined;

    if (explicitStimRef) {
      const sNum = parseInt(explicitStimRef[1], 10);
      chosenStimulus = stimuliByNumber[sNum];
    } else if (activeStimulus) {
      const referencesPrevious =
        /\b(?:stimulus|wacana|teks|tabel|data|eksperimen|reaksi|grafik|bacaan|gambar|diagram)\s+(?:di\s*atas|tersebut|ini)\b/i.test(
          stemJoined
        );
      if (
        activeStimulus.attachedCount === 0 ||
        referencesPrevious ||
        draft.detectedType === 'pilihan_ganda'
      ) {
        chosenStimulus = activeStimulus;
      }
    }

    if (chosenStimulus) {
      draft.stimulusTitle = chosenStimulus.title;
      if (chosenStimulus.paragraphs.length > 0) {
        draft.stimulusText = chosenStimulus.paragraphs.join('\n\n');
      }
      if (chosenStimulus.images.length > 0) {
        draft.stimulusImages = mergeUniqueImages(
          draft.stimulusImages,
          chosenStimulus.images
        );
      }
      if (!draft.stimulusTable && chosenStimulus.table) {
        draft.stimulusTable = chosenStimulus.table;
      }
      chosenStimulus.attachedCount++;
    }
  };

  const flushDraft = () => {
    const finalized = finalizeDraftQuestion(currentDraft);
    if (finalized) {
      if (!finalized.stimulusTitle && !finalized.stimulusText) {
        attachStimulusToDraft(finalized);
      }
      drafts.push(finalized);
    }
    currentDraft = null;
    inInternalNumberedList = false;
    internalListCounter = 0;
  };

  // Helper to inspect upcoming blocks before the next top-level numbered question
  const inspectBeforeNextQuestion = (
    startIdx: number,
    expectedNextNum?: number
  ): { optionCount: number; firstOptionLetter: string | null } => {
    let optionCount = 0;
    let firstOptionLetter: string | null = null;
    for (let k = startIdx; k < expandedBlocks.length; k++) {
      const blk = expandedBlocks[k];
      if (blk.kind === 'paragraph') {
        const p = blk.paragraph;
        if (matchStimulusHeader(p.fullText)) break;
        const optM = matchOptionLine(p, optionCount);
        if (optM) {
          optionCount++;
          if (!firstOptionLetter) {
            firstOptionLetter = optM.letter;
          }
          continue;
        }
        const qM = matchNumberedQuestionLine(p);
        if (qM) {
          if (
            expectedNextNum === undefined ||
            qM.qNum === expectedNextNum ||
            optionCount >= 2
          ) {
            break;
          }
        }
      }
    }
    return { optionCount, firstOptionLetter };
  };

  for (let i = 0; i < expandedBlocks.length; i++) {
    const block = expandedBlocks[i];

    if (block.kind === 'table') {
      if (inAnswerKeySection) {
        const weights = tryParseRubricWeightsTable(block.table);
        Object.assign(rubricWeightsByType, weights);
        const tableKeys = tryExtractAnswerKeysFromTable(block.table);
        Object.assign(answerKeyByNumber, tableKeys);
        continue;
      }

      if (collectingStimulus && activeStimulus) {
        const tableData = convertParsedTableToQuestionTableData(block.table);
        if (tableData) {
          activeStimulus.table = tableData;
        }
        continue;
      }

      // Check BAGIAN III per-row numbered Benar/Salah statement table (No | Pernyataan ... | Pilihan: B - S)
      const bsRowDrafts = tryExtractBenarSalahRowQuestionsFromTable(
        block.table,
        currentSectionInstruction
      );
      if (bsRowDrafts && bsRowDrafts.length > 0) {
        flushDraft();
        drafts.push(...bsRowDrafts);
        continue;
      }

      const expectedNextNum =
        currentDraft?.explicitNumber !== undefined
          ? currentDraft.explicitNumber + 1
          : undefined;
      const upcoming = inspectBeforeNextQuestion(i + 1, expectedNextNum);

      // 0A. Check if this table is a Benar/Salah Statement Table for the current question!
      const bsTableResult = tryExtractBenarSalahFromTable(block.table);
      if (bsTableResult && bsTableResult.statements.length >= 1) {
        if (
          currentDraft &&
          ((currentDraft.explicitStatements && currentDraft.explicitStatements.length > 0) ||
            (currentDraft.explicitPremises && currentDraft.explicitPremises.length > 0) ||
            currentDraft.options.length >= 2)
        ) {
          flushDraft();
        }
        if (!currentDraft) {
          currentDraft = createEmptyDraft();
        }
        currentDraft.detectedType = 'benar_salah';
        currentDraft.explicitStatements = bsTableResult.statements;
        if (bsTableResult.trueLabel) currentDraft.trueLabel = bsTableResult.trueLabel;
        if (bsTableResult.falseLabel) currentDraft.falseLabel = bsTableResult.falseLabel;
        // Keep currentDraft open so any trailing "Kunci: B, S, B, S" or "Pembahasan:" attaches!
        continue;
      }

      // 0B. Check if this table is a Menjodohkan Table for the current question!
      const forceMenjodohkanTable =
        currentSectionType === 'menjodohkan' ||
        currentDraft?.detectedType === 'menjodohkan';
      const matchTableResult = tryExtractMenjodohkanFromTable(
        block.table,
        forceMenjodohkanTable
      );
      if (matchTableResult && matchTableResult.premises.length >= 2) {
        if (
          currentDraft &&
          ((currentDraft.explicitStatements && currentDraft.explicitStatements.length > 0) ||
            (currentDraft.explicitPremises && currentDraft.explicitPremises.length > 0) ||
            currentDraft.options.length >= 2)
        ) {
          flushDraft();
        }
        if (!currentDraft) {
          currentDraft = createEmptyDraft();
        }
        currentDraft.detectedType = 'menjodohkan';
        currentDraft.explicitPremises = matchTableResult.premises;
        currentDraft.explicitResponses = matchTableResult.responses;
        currentDraft.explicitMatchingCorrectPairs = matchTableResult.correctPairs;
        // Keep currentDraft open so any trailing "Kunci: 1-C, 2-A, 3-B" or "Pembahasan:" attaches!
        continue;
      }

      // If option paragraphs (A..E) already follow this table for the current question,
      // then this table is 100% a Stimulus/Data Table for the current question!
      if (
        currentDraft &&
        currentDraft.options.length === 0 &&
        upcoming.optionCount >= 2
      ) {
        const tableData = convertParsedTableToQuestionTableData(block.table);
        if (tableData) {
          currentDraft.stimulusTable = tableData;
        }
        continue;
      }

      // 1. Check if this table is an Options Table (A..E) for the current question!
      if (
        currentDraft &&
        currentDraft.questionLines.length > 0 &&
        currentDraft.options.length === 0
      ) {
        const tableOpts = tryExtractOptionsOnlyFromTable(block.table);
        if (tableOpts && tableOpts.length >= 2) {
          currentDraft.options.push(...tableOpts);
          if (block.table.rows.length > tableOpts.length) {
            currentDraft.stimulusTable = convertParsedTableToQuestionTableData(
              block.table
            );
          }
          continue;
        }
      }

      // 2. Check if this table is a Bank Soal Table containing full questions + options
      const tableQuestionDrafts = tryExtractQuestionsFromBankSoalTable(
        block.table
      );
      if (tableQuestionDrafts && tableQuestionDrafts.length > 0) {
        flushDraft();
        drafts.push(...tableQuestionDrafts);
        continue;
      }

      // 2B. Check if this table is a messy borderless layout table wrapping questions + options (e.g., 1-col or [No | Soal+Opsi])
      const unwrappedLayoutParas = tryUnwrapLayoutTableToParagraphs(block.table);
      if (unwrappedLayoutParas && unwrappedLayoutParas.length > 0) {
        const subBlocks: DocumentBlock[] = unwrappedLayoutParas.map((p) => ({
          kind: 'paragraph',
          paragraph: p,
        }));
        const layoutDrafts = buildDraftsFromBlockSequence(subBlocks);
        if (layoutDrafts.length > 0) {
          flushDraft();
          drafts.push(...layoutDrafts);
          continue;
        }
      }

      // 3. Otherwise, this table is a Data / Stimulus Table belonging to a question
      const tableData = convertParsedTableToQuestionTableData(block.table);
      if (tableData) {
        if (currentDraft && currentDraft.options.length >= 2) {
          flushDraft();
        }
        if (!currentDraft) {
          currentDraft = createEmptyDraft();
        }
        currentDraft.stimulusTable = tableData;
      }
      continue;
    }

    const para = block.paragraph;
    const text = para.fullText.trim();
    const paraImages = para.images && para.images.length > 0 ? para.images : undefined;

    // Handle standalone image-only paragraphs (e.g. embedded figure/diagram in Word or PDF)
    if (!text && paraImages) {
      if (inAnswerKeySection) continue;
      if (collectingStimulus && activeStimulus) {
        activeStimulus.images = mergeUniqueImages(activeStimulus.images, paraImages) || [];
        continue;
      }
      if (currentDraft) {
        if (currentDraft.options.length > 0) {
          const lastOpt = currentDraft.options[currentDraft.options.length - 1];
          const lastOptIsPlaceholder =
            !lastOpt.text ||
            lastOpt.text === '[Gambar]' ||
            /^Pilihan\s+[A-H]$/i.test(lastOpt.text);
          if (lastOptIsPlaceholder) {
            lastOpt.images = mergeUniqueImages(lastOpt.images, paraImages);
            if (lastOpt.text === '[Gambar]' || /^Pilihan\s+[A-H]$/i.test(lastOpt.text)) {
              lastOpt.text = '';
            }
            continue;
          }
          const expectedNext =
            currentDraft.explicitNumber !== undefined
              ? currentDraft.explicitNumber + 1
              : undefined;
          const upcoming = inspectBeforeNextQuestion(i + 1, expectedNext);
          if (upcoming.optionCount > 0 && currentDraft.options.length < 5) {
            lastOpt.images = mergeUniqueImages(lastOpt.images, paraImages);
            continue;
          }
          if (currentDraft.options.length >= 2) {
            flushDraft();
            currentDraft = createEmptyDraft();
            currentDraft.questionImages = mergeUniqueImages(
              currentDraft.questionImages,
              paraImages
            );
            continue;
          }
        }
        currentDraft.questionImages = mergeUniqueImages(
          currentDraft.questionImages,
          paraImages
        );
      } else {
        currentDraft = createEmptyDraft();
        currentDraft.questionImages = mergeUniqueImages(
          currentDraft.questionImages,
          paraImages
        );
      }
      continue;
    }

    // Check if we entered a document-end "KUNCI JAWABAN" section (either standalone header OR inline "KUNCI JAWABAN: 1B 2B 3C")
    let answerKeyText = text;
    const inlineAnswerKeyHeaderMatch = text.match(
      /^(?:(?:daftar|ringkasan)\s+)?kunci(?:\s+jawaban(?:\s+ujian|\s+soal|\s+dan\s+pembahasan)?)?\s*[:\-=]\s*(.+)$/i
    );
    const hasMultipleInlineNumberedKeys =
      inlineAnswerKeyHeaderMatch !== null &&
      Array.from(
        inlineAnswerKeyHeaderMatch[1].matchAll(
          /(?:^|[\s,;|])(?:no\.?\s*)?\d{1,3}\s*(?:[\.\):=]\s*|\s*-\s*|\s*)(?:Benar|Salah|Sesuai|Tidak\s+Sesuai|Ya|Tidak|[A-Ha-h])(?=\s|$|[,;|])/gi
        )
      ).length >= 2;

    if (
      /^(?:(?:daftar|ringkasan)\s+)?kunci\s+jawaban(?:\s+ujian|\s+soal|\s+dan\s+pembahasan.*)?\s*[:\-]?$/i.test(
        text
      )
    ) {
      flushDraft();
      collectingStimulus = false;
      inAnswerKeySection = true;
      continue;
    } else if (hasMultipleInlineNumberedKeys && inlineAnswerKeyHeaderMatch) {
      flushDraft();
      collectingStimulus = false;
      inAnswerKeySection = true;
      answerKeyText = inlineAnswerKeyHeaderMatch[1].trim();
    }

    if (inAnswerKeySection) {
      const akText = answerKeyText;
      if (
        /^(?:ringkasan\s+kunci\s+jawaban|bagian\s+[ivx]+|total\s+skor|bonus\s+penulisan)/i.test(
          akText
        )
      ) {
        continue;
      }

      // Parse single-question Menjodohkan key line FIRST so "12. 1-C, 2-A, 3-B" isn't split into Q1/Q2/Q3
      const matchingKeyLine = akText.match(
        /^(\d+)\s*[\.\):]\s*((?:\d+\s*(?:[\-=–—→>]+|->|=>)\s*[A-Ha-h](?:\s*[,;|]\s*|$)){2,})$/i
      );
      if (matchingKeyLine) {
        answerKeyByNumber[parseInt(matchingKeyLine[1], 10)] =
          matchingKeyLine[2].trim();
        continue;
      }

      // Parse PGK format: "16. Pernyataan 1, 2, 3 BENAR"
      const pgkKeyMatch = akText.match(
        /^(\d+)\s*[\.\)\-:]\s*(?:pernyataan|opsi|pilihan|nomor)?\s*([\d,\s]+)\s*(?:benar|ya|centang)?$/i
      );
      if (pgkKeyMatch) {
        const qNum = parseInt(pgkKeyMatch[1], 10);
        const nums = pgkKeyMatch[2].match(/\d+/g) || [];
        const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
        const mappedLetters = nums
          .map((n) => letters[parseInt(n, 10) - 1])
          .filter(Boolean);
        if (mappedLetters.length > 0) {
          answerKeyByNumber[qNum] = mappedLetters.join(', ');
          continue;
        }
      }

      // Parse inline pipe/space key pairs: "1. B | 2. B | 3. C", "1.B 2.A 3.C", "1B 2A 3C 4D", "1=B 2=A", "24. SALAH | 25. BENAR"
      // Use `.`, `)`, `:`, `=` or compact "1B 2A" (NOT `1-C` matching pairs when preceded by a question number!)
      const inlineKeyPairs = Array.from(
        akText.matchAll(
          /(?:^|[\s|;,])(?:no\.?\s*)?(\d{1,3})\s*(?:[\.\):=]\s*|\s*-\s*(?=[A-Ha-h](?:[\s|;,]|$)))(Benar|Salah|Sesuai|Tidak\s+Sesuai|Ya|Tidak|Fakta|Opini|[A-Ha-h](?:\s*,\s*[A-Ha-h])*)(?=\s*(?:[|;,]|$|(?:no\.?\s*)?\d{1,3}\s*[\.\):=\-]))/gi
        )
      );
      if (inlineKeyPairs.length >= 2) {
        inlineKeyPairs.forEach((m) => {
          answerKeyByNumber[parseInt(m[1], 10)] = m[2].trim();
        });
        continue;
      }

      // Also support super-compact keys like "1B 2A 3C 4D 5E" or "1.B 2.A 3.C"
      const compactKeyPairs = Array.from(
        akText.matchAll(/(?:^|[\s,;|])(\d{1,3})\s*\.?\s*([A-Ea-e])(?=\s|$|[,;|])/g)
      );
      if (compactKeyPairs.length >= 2) {
        compactKeyPairs.forEach((m) => {
          answerKeyByNumber[parseInt(m[1], 10)] = m[2].toUpperCase();
        });
        continue;
      }

      const singleKeyLine = akText.match(/^(?:no\.?\s*|soal\s*)?(\d{1,3})\s*[\.\)\-:=]\s*(.+)$/i);
      if (singleKeyLine) {
        let keyVal = singleKeyLine[2].trim();
        // If written as "1. B. Mitokondria" or "1. B) Mitokondria", extract the leading letter "B"
        const letterPlusText = keyVal.match(/^([A-Ha-h])\s*[\.\):]\s+\S+/);
        if (letterPlusText) {
          keyVal = letterPlusText[1].toUpperCase();
        }
        answerKeyByNumber[parseInt(singleKeyLine[1], 10)] = keyVal;
      }
      // Always stay inside inAnswerKeySection once entered!
      continue;
    }

    // Check if paragraph is a section header for a specific QuestionType
    const sectionHeaderType = matchSectionTypeHeader(text);
    if (sectionHeaderType) {
      flushDraft();
      collectingStimulus = false;
      activeStimulus = undefined;
      currentSectionType = sectionHeaderType;
      currentSectionInstruction = undefined;
      continue;
    }

    // Skip preamble metadata/header lines before the very first question begins
    if (
      !currentDraft &&
      drafts.length === 0 &&
      !collectingStimulus &&
      !paraImages &&
      !matchNumberedQuestionLine(para) &&
      !matchOptionLine(para, 0) &&
      !matchStimulusHeader(text) &&
      /^(?:mata\s+pelajaran|mapel|kelas|semester|tahun\s+(?:ajaran|pelajaran)|waktu|alokasi\s+waktu|nama\s+(?:siswa|peserta)|petunjuk(?:\s+umum)?|ujian\s+|penilaian\s+|sumatif\s+|ulangan\s+|evaluasi\s+|try\s*out\s+|simulasi\s+)/i.test(
        text
      ) &&
      text.length < 160
    ) {
      continue;
    }

    // Skip section-level "Petunjuk: ..." lines (do not turn them into fake questions)
    const petunjukMatch = text.match(/^petunjuk\s*[:\-]\s*(.+)$/i);
    if (petunjukMatch) {
      if (!currentDraft || currentDraft.questionLines.length === 0) {
        currentSectionInstruction = petunjukMatch[1].trim();
        continue;
      }
    }

    // Check STIMULUS header block
    const stimMatch = matchStimulusHeader(text);
    if (stimMatch) {
      flushDraft();
      collectingStimulus = true;
      const stimNum = stimMatch.num;
      activeStimulus = {
        num: stimNum,
        title: stimMatch.title,
        paragraphs: [],
        images: paraImages ? [...paraImages] : [],
        attachedCount: 0,
      };
      if (stimNum !== undefined) {
        stimuliByNumber[stimNum] = activeStimulus;
      }
      continue;
    }

    // Collect body paragraphs of the currently open Stimulus block until a numbered question begins
    if (collectingStimulus && activeStimulus) {
      const maybeQ = matchNumberedQuestionLine(para);
      const maybeOpt = matchOptionLine(para, 0);
      if (!maybeQ && !maybeOpt) {
        activeStimulus.paragraphs.push(text);
        if (paraImages) {
          activeStimulus.images = mergeUniqueImages(activeStimulus.images, paraImages) || [];
        }
        continue;
      }
      collectingStimulus = false;
    }

    // Handle standalone/orphan question number lines like "1", "1.", "(1)", "[1]", "No. 1", "Soal 1:"
    const orphanNumMatch = text.match(
      /^(?:(?:soal|pertanyaan)\s*(?:no\.?|nomor)?\s*|no\.?\s*|nomor\s*)?[\(\[]?(\d{1,3})[\)\]]?[\.\)\-:]?$/i
    );
    if (orphanNumMatch) {
      const numVal = parseInt(orphanNumMatch[1], 10);
      if (numVal >= 1 && numVal <= 200) {
        if (
          currentDraft &&
          (currentDraft.options.length >= 2 ||
            (currentDraft.explicitStatements && currentDraft.explicitStatements.length > 0) ||
            (currentDraft.explicitPremises && currentDraft.explicitPremises.length > 0) ||
            (currentDraft.allParagraphs && currentDraft.allParagraphs.length >= 3))
        ) {
          flushDraft();
        }
        if (!currentDraft) {
          currentDraft = createEmptyDraft(numVal);
        }
        if (paraImages) {
          currentDraft.questionImages = mergeUniqueImages(
            currentDraft.questionImages,
            paraImages
          );
        }
        continue;
      }
    }

    // 0. Check explicit per-question metadata directives (Tipe/Jenis, Pembahasan, Bobot/Skor, Kategori, Menjodohkan list markers)
    const tipeDirectiveMatch = text.match(
      /^(?:tipe|jenis|bentuk)(?:\s*soal)?\s*[:=]\s*(.+)$/i
    );
    if (tipeDirectiveMatch) {
      const detected = detectQuestionTypeFromText(tipeDirectiveMatch[1]);
      if (detected) {
        if (
          currentDraft &&
          (currentDraft.options.length >= 2 ||
            (currentDraft.explicitStatements && currentDraft.explicitStatements.length > 0) ||
            (currentDraft.explicitPremises && currentDraft.explicitPremises.length > 0))
        ) {
          flushDraft();
        }
        if (!currentDraft) {
          currentDraft = createEmptyDraft();
        }
        currentDraft.detectedType = detected;
        const pairLbl = detectBenarSalahPairLabels(tipeDirectiveMatch[1]);
        if (pairLbl) {
          currentDraft.trueLabel = pairLbl.trueLabel;
          currentDraft.falseLabel = pairLbl.falseLabel;
        }
        continue;
      }
    }

    const explanationMatch = text.match(
      /^(?:pembahasan|penjelasan|penyelesaian|keterangan\s+kunci)\s*[:=]\s*(.+)$/i
    );
    if (explanationMatch && currentDraft) {
      currentDraft.explicitExplanation = explanationMatch[1].trim();
      continue;
    }

    const pointsDirectiveMatch = text.match(
      /^(?:bobot|skor|poin|nilai)(?:\s*soal)?\s*[:=]\s*(\d+)/i
    );
    if (pointsDirectiveMatch && currentDraft) {
      const pts = parseInt(pointsDirectiveMatch[1], 10);
      if (!Number.isNaN(pts) && pts > 0) {
        currentDraft.explicitPoints = pts;
        continue;
      }
    }

    const categoryDirectiveMatch = text.match(
      /^(?:kategori|materi|topik|kompetensi)\s*[:=]\s*(.+)$/i
    );
    if (categoryDirectiveMatch && currentDraft) {
      currentDraft.explicitCategory = categoryDirectiveMatch[1].trim();
      continue;
    }

    // Ignore decorative separator lines (e.g. "-----" or "====" from archived Word files)
    if (/^[\-=*_~]{5,}$/.test(text) || /^ARSIP\s+BANK\s+SOAL\s+CBT\s*:/i.test(text) || /^Total\s+Soal\s*:\s*\d+\s+Butir/i.test(text)) {
      continue;
    }

    // Handle "[Pasangan Menjodohkan]:" marker from exported archives or teacher docs
    if (/^\[?\s*(?:pasangan\s+menjodohkan|daftar\s+pasangan)\s*\]?\s*[:\-]?$/i.test(text)) {
      if (!currentDraft) {
        currentDraft = createEmptyDraft();
      }
      currentDraft.detectedType = 'menjodohkan';
      continue;
    }

    // Handle two-list Menjodohkan headers: "Premis / Kolom A:" and "Respon / Kolom B:"
    if (
      currentDraft &&
      (currentDraft.detectedType === 'menjodohkan' ||
        currentSectionType === 'menjodohkan' ||
        /^(?:premis|kolom\s*[a1]|bagian\s*[a1])\s*[:\-]?$/i.test(text))
    ) {
      if (
        /^(?:premis|kolom\s*[a1]|bagian\s*[a1]|daftar\s+premis|pernyataan\s*\(kolom\s*[a1]\))\s*[:\-]?$/i.test(
          text
        )
      ) {
        currentDraft.detectedType = 'menjodohkan';
        currentDraft.matchingListMode = 'premise';
        continue;
      }
      if (
        /^(?:respon|pasangan|kolom\s*[b2]|bagian\s*[b2]|daftar\s+respon|pilihan\s+pasangan|jawaban\s*\(kolom\s*[b2]\))\s*[:\-]?$/i.test(
          text
        )
      ) {
        currentDraft.detectedType = 'menjodohkan';
        currentDraft.matchingListMode = 'response';
        continue;
      }
    }

    // 1. Check if line is an explicit "Kunci Jawaban: ..." line
    const keyMatch = text.match(EXPLICIT_KEY_LINE_REGEX);
    if (keyMatch && currentDraft) {
      const rawKeyVal = keyMatch[1].trim();
      const matchKeyMap = parseMatchingKeyString(rawKeyVal);
      const isBsSeries =
        /^(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju|tepat|tidak\s*tepat|valid|tidak\s*valid|true|false)(?:\s*[,\/\-]\s*(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju|tepat|tidak\s*tepat|valid|tidak\s*valid|true|false))+$/i.test(
          rawKeyVal
        );
      const isSingleBsWord =
        /^(?:benar|salah|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju|true|false)$/i.test(
          rawKeyVal
        ) ||
        ((currentDraft.detectedType === 'benar_salah' ||
          (currentDraft.explicitStatements &&
            currentDraft.explicitStatements.length > 0)) &&
          /^[bs]$/i.test(rawKeyVal));
      const isOptionLettersOnly =
        /^[A-Ha-h](?:\s*(?:[,\/&]|dan)\s*[A-Ha-h])*$/i.test(rawKeyVal) ||
        /^(?:opsi|pilihan)\s+[A-Ha-h](?:\s*(?:[,\/&]|dan)\s*[A-Ha-h])*$/i.test(
          rawKeyVal
        );
      const isNumericPgkKey =
        currentDraft.detectedType === 'pilihan_ganda_kompleks' &&
        /^(?:pernyataan|nomor|opsi)?\s*\d+(?:\s*(?:[,\/&]|dan)\s*\d+)+\s*(?:benar)?$/i.test(
          rawKeyVal
        );

      if (matchKeyMap) {
        currentDraft.detectedType = 'menjodohkan';
        currentDraft.explicitMatchingKeyMap = matchKeyMap;
      } else if (isBsSeries || isSingleBsWord) {
        currentDraft.detectedType = 'benar_salah';
        const bsVals = rawKeyVal
          .split(/[,\/\-]/)
          .map((v) => v.trim().toLowerCase())
          .filter(Boolean);
        const mapped = bsVals.map((v) =>
          /^(?:benar|b|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true)$/.test(v)
            ? 'BENAR'
            : 'SALAH'
        );
        currentDraft.explicitKeys.push(...mapped);
        if (currentDraft.explicitStatements && currentDraft.explicitStatements.length > 0) {
          currentDraft.explicitStatements.forEach((st, sIdx) => {
            const val = mapped[sIdx];
            if (val) {
              st.correctValue = val === 'BENAR' ? 'Benar' : 'Salah';
            }
          });
        }
      } else if (isNumericPgkKey) {
        const nums = rawKeyVal.match(/\d+/g) || [];
        const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
        const mappedLetters = nums
          .map((n) => letters[parseInt(n, 10) - 1])
          .filter(Boolean);
        if (mappedLetters.length > 0) {
          currentDraft.explicitKeys.push(...mappedLetters);
        }
      } else if (
        isOptionLettersOnly &&
        currentDraft.detectedType !== 'isian_singkat'
      ) {
        const keys = rawKeyVal.toUpperCase().match(/[A-H]/g) || [];
        currentDraft.explicitKeys.push(...keys);
        if (keys.length > 1) {
          currentDraft.detectedType = 'pilihan_ganda_kompleks';
        }
      } else {
        if (!currentDraft.explicitTextAnswers) {
          currentDraft.explicitTextAnswers = [];
        }
        currentDraft.explicitTextAnswers.push(
          ...rawKeyVal
            .split(/\s*[\/|;]\s*/)
            .map((s) => s.trim())
            .filter(Boolean)
        );
        const singleLetter = rawKeyVal.toUpperCase().match(/^[A-E]$/);
        if (singleLetter && currentDraft.options.length >= 2) {
          currentDraft.explicitKeys.push(singleLetter[0]);
        }
      }
      continue;
    }

    // 1B. If inside two-list Menjodohkan mode ("Premis:" / "Respon:"), collect premise/response lines directly!
    if (currentDraft && currentDraft.matchingListMode === 'premise') {
      const pMatch = text.match(/^(?:\d+[\.\)\-:]|[-•*▪▫])\s*(.+)$/);
      if (pMatch && pMatch[1].trim()) {
        if (!currentDraft.explicitPremises) currentDraft.explicitPremises = [];
        const pId = `p${currentDraft.explicitPremises.length + 1}`;
        currentDraft.explicitPremises.push({
          id: pId,
          text: pMatch[1].trim(),
          ...(paraImages ? { images: paraImages } : {}),
        });
        continue;
      }
    }
    if (currentDraft && currentDraft.matchingListMode === 'response') {
      const rOpt = matchOptionLine(para, currentDraft.explicitResponses?.length ?? 0);
      const rBullet = !rOpt ? text.match(/^(?:[A-Ha-h][\.\)\-:]|\d+[\.\)\-:]|[-•*▪▫])\s*(.+)$/) : null;
      if (rOpt || (rBullet && rBullet[1].trim())) {
        if (!currentDraft.explicitResponses) currentDraft.explicitResponses = [];
        const rId = `r${currentDraft.explicitResponses.length + 1}`;
        currentDraft.explicitResponses.push({
          id: rId,
          text: (rOpt ? rOpt.text : rBullet![1]).trim(),
          ...(paraImages ? { images: paraImages } : {}),
        });
        continue;
      } else {
        currentDraft.matchingListMode = undefined;
      }
    }

    // 2. Check if line is an Option (A..E or checkbox "[ ]" for PG Kompleks or auto-lettered option)
    const optMatch = matchOptionLine(para, currentDraft?.options.length ?? 0);
    if (optMatch) {
      const {
        letter: optLetter,
        text: optText,
        isRed,
        isBold,
        isUnderline,
        isHighlight,
        isCheckbox,
      } = optMatch;
      const cleanOptText =
        paraImages && /^Pilihan\s+[A-H]$/i.test(optText) ? '' : optText;

      if (
        currentDraft &&
        ((currentDraft.explicitStatements && currentDraft.explicitStatements.length > 0) ||
          (currentDraft.explicitPremises && currentDraft.explicitPremises.length > 0))
      ) {
        flushDraft();
      }
      if (!currentDraft) {
        currentDraft = createEmptyDraft();
      }
      if (isCheckbox) {
        currentDraft.detectedType = 'pilihan_ganda_kompleks';
      }

      // If we see 'A' again (non-checkbox) and we already collected >= 2 options for the current question:
      if (
        !isCheckbox &&
        optLetter === 'A' &&
        currentDraft.options.some((o) => o.id === 'A') &&
        currentDraft.options.length >= 2
      ) {
        const expectedNext =
          currentDraft.explicitNumber !== undefined
            ? currentDraft.explicitNumber + 1
            : undefined;
        const upcomingAfterThis = inspectBeforeNextQuestion(i + 1, expectedNext);
        if (
          currentDraft.explicitNumber !== undefined &&
          upcomingAfterThis.optionCount >= 2 &&
          currentDraft.options.length <= 4
        ) {
          for (const prevOpt of currentDraft.options) {
            currentDraft.questionLines.push(`${prevOpt.id}. ${prevOpt.text}`);
            if (prevOpt.images?.length) {
              currentDraft.questionImages = mergeUniqueImages(
                currentDraft.questionImages,
                prevOpt.images
              );
            }
          }
          currentDraft.options = [];
          if (currentDraft.allParagraphs) {
            currentDraft.allParagraphs.forEach((r) => {
              r.matchedOption = undefined;
            });
          }
        } else {
          flushDraft();
          currentDraft = createEmptyDraft();
        }
      }

      inInternalNumberedList = false;
      currentDraft.options.push({
        id: optLetter,
        text: cleanOptText,
        isRed,
        isBold,
        isUnderline,
        isHighlight,
        images: paraImages,
      });
      currentDraft.allParagraphs?.push({
        para,
        matchedOption: {
          letter: optLetter,
          text: cleanOptText,
          isRed,
          isBold,
          isUnderline,
          isHighlight,
          images: paraImages,
        },
      });
      continue;
    }

    // 3. Check if line is a Numbered Question (e.g., "1. Apa yang dimaksud..." or auto-numbered decimal)
    const qMatch = matchNumberedQuestionLine(para);
    if (qMatch) {
      const { qNum, qText: rawQText } = qMatch;
      const inlineTag = extractInlineQuestionTypeTag(rawQText);
      const qText = inlineTag.cleanedText || rawQText;
      const qPairLbl = detectBenarSalahPairLabels(rawQText);

      // If previous draft already completed a B/S or Menjodohkan table, flush it before starting a new numbered question!
      if (
        currentDraft &&
        ((currentDraft.explicitStatements && currentDraft.explicitStatements.length > 0) ||
          (currentDraft.explicitPremises && currentDraft.explicitPremises.length > 0))
      ) {
        flushDraft();
      }

      // If a standalone image or Tipe directive preceded this numbered question, reuse that draft so it stays attached!
      if (
        currentDraft &&
        currentDraft.questionLines.length === 0 &&
        currentDraft.options.length === 0 &&
        currentDraft.explicitNumber === undefined &&
        ((currentDraft.questionImages?.length ?? 0) > 0 || Boolean(currentDraft.detectedType))
      ) {
        currentDraft.explicitNumber = qNum;
        const inlineType = inlineTag.type || detectQuestionTypeFromText(qText);
        if (inlineType) currentDraft.detectedType = inlineType;
        if (qPairLbl) {
          currentDraft.trueLabel = qPairLbl.trueLabel;
          currentDraft.falseLabel = qPairLbl.falseLabel;
        }
        currentDraft.questionLines.push(qText);
        if (paraImages) {
          currentDraft.questionImages = mergeUniqueImages(
            currentDraft.questionImages,
            paraImages
          );
        }
        const cleanPara = { ...para, fullText: qText };
        currentDraft.unprefixedParagraphs.push(cleanPara);
        currentDraft.allParagraphs?.push({ para: cleanPara });
        continue;
      }

      if (!currentDraft) {
        currentDraft = createEmptyDraft(qNum);
        const inlineType = inlineTag.type || detectQuestionTypeFromText(qText);
        if (inlineType) currentDraft.detectedType = inlineType;
        if (qPairLbl) {
          currentDraft.trueLabel = qPairLbl.trueLabel;
          currentDraft.falseLabel = qPairLbl.falseLabel;
        }
        currentDraft.questionLines.push(qText);
        if (paraImages) {
          currentDraft.questionImages = mergeUniqueImages(
            currentDraft.questionImages,
            paraImages
          );
        }
        const cleanPara = { ...para, fullText: qText };
        currentDraft.unprefixedParagraphs.push(cleanPara);
        currentDraft.allParagraphs?.push({ para: cleanPara });
        continue;
      }

      // Determine if qNum is an internal numbered list item (1, 2, 3, 4) inside the current question stem
      // vs the start of the NEXT question (including messy copy-pasted docs where every question says "1.")!
      const expectedNextQNum: number =
        currentDraft.explicitNumber !== undefined
          ? currentDraft.explicitNumber + 1
          : drafts.length + 2;

      const prevBulletCount = currentDraft.questionLines.filter((l) =>
        /^[•\-\*▪▫◦○●]\s+\S/.test(l.trim())
      ).length;
      const prevEndsWithQuestionMark =
        currentDraft.questionLines.length > 0 &&
        currentDraft.questionLines.some((l) => /[?]$/.test(l.trim()));

      const prevLooksComplete =
        (currentDraft.explicitTextAnswers && currentDraft.explicitTextAnswers.length > 0) ||
        currentDraft.explicitKeys.length > 0 ||
        prevBulletCount >= 2 ||
        (prevEndsWithQuestionMark &&
          (/[?]$/.test(qText.trim()) ||
            inspectBeforeNextQuestion(i + 1, qNum + 1).optionCount >= 2));

      const isInternalListStart =
        !prevLooksComplete &&
        currentDraft.options.length === 0 &&
        qNum === 1 &&
        qNum !== expectedNextQNum &&
        (currentDraft.explicitNumber !== undefined || drafts.length > 0);

      const isInternalListContinuation =
        !prevLooksComplete &&
        inInternalNumberedList &&
        currentDraft.options.length === 0 &&
        qNum === internalListCounter + 1 &&
        qNum !== expectedNextQNum;

      const isSmallNumberInsideHigherQuestion =
        !prevLooksComplete &&
        currentDraft.options.length === 0 &&
        currentDraft.explicitNumber !== undefined &&
        currentDraft.explicitNumber >= 7 &&
        qNum <= 6 &&
        (currentDraft.allParagraphs?.length ?? 0) <= 6;

      if (
        isInternalListStart ||
        (isSmallNumberInsideHigherQuestion && !inInternalNumberedList)
      ) {
        inInternalNumberedList = true;
        internalListCounter = qNum;
        const lineWithNum = /^\d+/.test(text) ? text : `${qNum}. ${qText}`;
        currentDraft.questionLines.push(lineWithNum);
        if (paraImages) {
          currentDraft.questionImages = mergeUniqueImages(
            currentDraft.questionImages,
            paraImages
          );
        }
        currentDraft.unprefixedParagraphs.push(para);
        currentDraft.allParagraphs?.push({ para });
        continue;
      }

      if (isInternalListContinuation || isSmallNumberInsideHigherQuestion) {
        internalListCounter = qNum;
        const lineWithNum = /^\d+/.test(text) ? text : `${qNum}. ${qText}`;
        currentDraft.questionLines.push(lineWithNum);
        if (paraImages) {
          currentDraft.questionImages = mergeUniqueImages(
            currentDraft.questionImages,
            paraImages
          );
        }
        currentDraft.unprefixedParagraphs.push(para);
        currentDraft.allParagraphs?.push({ para });
        continue;
      }

      // Otherwise, this is a NEW question! Flush the previous question first!
      flushDraft();
      currentDraft = createEmptyDraft(qNum);
      const inlineType = inlineTag.type || detectQuestionTypeFromText(qText);
      if (inlineType) currentDraft.detectedType = inlineType;
      if (qPairLbl) {
        currentDraft.trueLabel = qPairLbl.trueLabel;
        currentDraft.falseLabel = qPairLbl.falseLabel;
      }
      currentDraft.questionLines.push(qText);
      if (paraImages) {
        currentDraft.questionImages = mergeUniqueImages(
          currentDraft.questionImages,
          paraImages
        );
      }
      const cleanPara = { ...para, fullText: qText };
      currentDraft.unprefixedParagraphs.push(cleanPara);
      currentDraft.allParagraphs?.push({ para: cleanPara });
      continue;
    }

    // 4. Non-option, non-numbered paragraph:
    const inlineTypeInPara = detectQuestionTypeFromText(text);

    // 4A. Merge orphan option text onto a bare option prefix (e.g. "A." on previous line, "Mitokondria" on this line!)
    if (currentDraft && currentDraft.options.length > 0) {
      const lastOpt = currentDraft.options[currentDraft.options.length - 1];
      const isPlaceholderOpt =
        (/^Pilihan\s+[A-H]$/i.test(lastOpt.text) || !lastOpt.text) &&
        !(lastOpt.images && lastOpt.images.length > 0);
      if (isPlaceholderOpt && text.length > 0) {
        const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(text);
        lastOpt.text = cleanedText || text;
        if (para.hasRed || isMarkedCorrect) lastOpt.isRed = true;
        if (para.isAllBold) lastOpt.isBold = true;
        if (para.hasUnderline) lastOpt.isUnderline = true;
        if (para.hasHighlight) lastOpt.isHighlight = true;
        if (paraImages) {
          lastOpt.images = mergeUniqueImages(lastOpt.images, paraImages);
        }
        const lastRec =
          currentDraft.allParagraphs?.[currentDraft.allParagraphs.length - 1];
        if (lastRec?.matchedOption) {
          lastRec.matchedOption.text = lastOpt.text;
          lastRec.matchedOption.isRed = lastOpt.isRed;
          lastRec.matchedOption.isBold = lastOpt.isBold;
          lastRec.matchedOption.isUnderline = lastOpt.isUnderline;
          lastRec.matchedOption.isHighlight = lastOpt.isHighlight;
          lastRec.matchedOption.images = lastOpt.images;
        }
        continue;
      }
    }

    // 4B. If the current draft ALREADY received its explicit answer/key (e.g. unnumbered Q&A pairs,
    // bullet-option question + Kunci, or completed matching/B-S table), a new non-option paragraph starts a NEW question!
    if (
      currentDraft &&
      ((currentDraft.explicitTextAnswers &&
        currentDraft.explicitTextAnswers.length > 0) ||
        (currentDraft.explicitMatchingKeyMap &&
          Object.keys(currentDraft.explicitMatchingKeyMap).length > 0) ||
        currentDraft.explicitKeys.length > 0)
    ) {
      flushDraft();
    }

    if (inlineTypeInPara && currentDraft && !currentDraft.detectedType) {
      currentDraft.detectedType = inlineTypeInPara;
    }

    if (currentDraft && currentDraft.options.length >= 1) {
      const expectedNext =
        currentDraft.explicitNumber !== undefined
          ? currentDraft.explicitNumber + 1
          : undefined;
      const upcoming = inspectBeforeNextQuestion(i + 1, expectedNext);

      if (
        upcoming.firstOptionLetter &&
        upcoming.firstOptionLetter !== 'A'
      ) {
        currentDraft.unprefixedParagraphs.push(para);
        currentDraft.allParagraphs?.push({ para });
        continue;
      }

      if (
        upcoming.firstOptionLetter === 'A' &&
        upcoming.optionCount >= 2 &&
        currentDraft.explicitNumber !== undefined
      ) {
        // Only treat prior options as sub-items in the stem if there were <= 3 items AND this line references them!
        // If currentDraft already collected 4-5 options (A..D/E), this is an UNNUMBERED next question -> flush first!
        const looksLikeContinuationOfStem =
          currentDraft.options.length <= 3 &&
          /^(?:berdasarkan|dari\s+(?:pernyataan|data|ciri|daftar)|manakah|yang\s+termasuk|pernyataan\s+(?:di\s*atas|tersebut|yang\s+benar))/i.test(
            text
          );
        if (looksLikeContinuationOfStem) {
          for (const prevOpt of currentDraft.options) {
            currentDraft.questionLines.push(`${prevOpt.id}. ${prevOpt.text}`);
          }
          currentDraft.options = [];
          if (currentDraft.allParagraphs) {
            currentDraft.allParagraphs.forEach((r) => {
              r.matchedOption = undefined;
            });
          }
          currentDraft.questionLines.push(text);
          if (paraImages) {
            currentDraft.questionImages = mergeUniqueImages(
              currentDraft.questionImages,
              paraImages
            );
          }
          currentDraft.unprefixedParagraphs.push(para);
          currentDraft.allParagraphs?.push({ para });
          continue;
        }
        flushDraft();
      } else if (
        upcoming.optionCount === 0 &&
        currentDraft.options.length < 4 &&
        currentDraft.explicitNumber !== undefined
      ) {
        currentDraft.unprefixedParagraphs.push(para);
        currentDraft.allParagraphs?.push({ para });
        continue;
      } else if (currentDraft.options.length >= 2) {
        flushDraft();
      }
    }

    if (!currentDraft) {
      currentDraft = createEmptyDraft();
      if (inlineTypeInPara) currentDraft.detectedType = inlineTypeInPara;
      currentDraft.questionLines.push(text);
      if (paraImages) {
        currentDraft.questionImages = mergeUniqueImages(
          currentDraft.questionImages,
          paraImages
        );
      }
      currentDraft.unprefixedParagraphs.push(para);
      currentDraft.allParagraphs?.push({ para });
    } else {
      currentDraft.questionLines.push(text);
      if (paraImages) {
        currentDraft.questionImages = mergeUniqueImages(
          currentDraft.questionImages,
          paraImages
        );
      }
      currentDraft.unprefixedParagraphs.push(para);
      currentDraft.allParagraphs?.push({ para });
    }
  }

  flushDraft();

  // Apply any keys found in a document-end KUNCI JAWABAN section & scoring rubric weights
  drafts.forEach((d, idx) => {
    const effectiveType = d.detectedType;
    if (effectiveType && rubricWeightsByType[effectiveType]) {
      d.explicitPoints = rubricWeightsByType[effectiveType];
    }

    const num = d.explicitNumber ?? idx + 1;
    const rawKey = answerKeyByNumber[num];
    if (!rawKey) return;

    const trimmedKey = rawKey.trim();
    const matchKeyMap = parseMatchingKeyString(trimmedKey);
    const isBsSeries =
      /^(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju|tepat|tidak\s*tepat|valid|tidak\s*valid|true|false)(?:\s*[,\/\-]\s*(?:benar|salah|b|s|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju|tepat|tidak\s*tepat|valid|tidak\s*valid|true|false))+$/i.test(
        trimmedKey
      );
    const isSingleBs =
      /^(?:benar|salah|sesuai|tidak\s*sesuai|ya|tidak|fakta|opini|setuju|tidak\s*setuju|true|false)$/i.test(
        trimmedKey
      ) ||
      ((d.detectedType === 'benar_salah' ||
        (d.explicitStatements && d.explicitStatements.length > 0)) &&
        /^[bs]$/i.test(trimmedKey));
    const isOptionLetters =
      /^[A-Ha-h](?:\s*(?:[,\/&]|dan)\s*[A-Ha-h])*$/i.test(trimmedKey);

    if (matchKeyMap) {
      d.detectedType = 'menjodohkan';
      d.explicitMatchingKeyMap = matchKeyMap;
    } else if (isBsSeries || isSingleBs) {
      d.detectedType = 'benar_salah';
      const bs = trimmedKey
        .split(/[,\/\-]/)
        .map((x) =>
          /^(?:benar|b|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true)$/i.test(
            x.trim()
          )
            ? 'BENAR'
            : 'SALAH'
        );
      d.explicitKeys = bs;
      if (d.explicitStatements && d.explicitStatements.length > 0) {
        d.explicitStatements.forEach((st, sIdx) => {
          const val = bs[sIdx] ?? bs[0];
          if (val) {
            st.correctValue = val === 'BENAR' ? 'Benar' : 'Salah';
          }
        });
      }
    } else if (isOptionLetters && d.detectedType !== 'isian_singkat') {
      const letters = trimmedKey.toUpperCase().match(/[A-H]/g) || [];
      d.explicitKeys = letters;
      if (letters.length > 1) {
        d.detectedType = 'pilihan_ganda_kompleks';
      }
    } else {
      d.explicitTextAnswers = trimmedKey
        .split(/\s*[\/|;]\s*/)
        .map((s) => s.trim())
        .filter(Boolean);
    }

    // Re-sync rubric weight if type was updated above
    if (d.detectedType && rubricWeightsByType[d.detectedType]) {
      d.explicitPoints = rubricWeightsByType[d.detectedType];
    }
  });

  return drafts;
}

/**
 * Helper to check if a draft represents a Menjodohkan (Matching) question from:
 * - Explicit premises/responses table or two-list format (with optional "Kunci: 1-C, 2-A, 3-B" remapping)
 * - Explicit pairs
 * - Arrow/connector lines ("- Mitokondria ===> Respirasi sel", "1. Kaktus -> Daun berduri", etc.)
 */
function tryExtractMatchingFromDraft(draft: DraftQuestion): {
  premises: MatchingPremise[];
  responses: MatchingResponse[];
  correctPairs: Record<string, string>;
  stemOnly: string;
} | null {
  const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

  const applyKeyMapToPremisesResponses = (
    premises: MatchingPremise[],
    responses: MatchingResponse[],
    basePairs?: Record<string, string>
  ): Record<string, string> => {
    const pairs: Record<string, string> = { ...(basePairs || {}) };
    if (draft.explicitMatchingKeyMap) {
      premises.forEach((p, pIdx) => {
        const mappedCode = draft.explicitMatchingKeyMap![pIdx + 1];
        if (!mappedCode) return;
        const letterIdx = letters.indexOf(mappedCode.toUpperCase());
        const numIdx = parseInt(mappedCode, 10) - 1;
        const targetResp =
          letterIdx >= 0
            ? responses[letterIdx]
            : !Number.isNaN(numIdx) && numIdx >= 0
            ? responses[numIdx]
            : undefined;
        if (targetResp) {
          pairs[p.id] = targetResp.id;
        }
      });
    }
    // Fill any unmapped premise with 1-to-1 fallback
    premises.forEach((p, idx) => {
      if (!pairs[p.id]) {
        const fallback = responses[idx] || responses[responses.length - 1];
        if (fallback) pairs[p.id] = fallback.id;
      }
    });
    return pairs;
  };

  // 1. Structured premises + responses (from Menjodohkan table OR two-list paragraph format)
  if (
    draft.explicitPremises &&
    draft.explicitPremises.length >= 2 &&
    draft.explicitResponses &&
    draft.explicitResponses.length >= 2
  ) {
    const correctPairs = applyKeyMapToPremisesResponses(
      draft.explicitPremises,
      draft.explicitResponses,
      draft.explicitMatchingCorrectPairs
    );
    const stemOnly =
      draft.questionLines.join(' ').trim() ||
      'Pasangkan pernyataan pada kolom Premis dengan jawaban yang sesuai pada kolom Respon!';
    return {
      premises: draft.explicitPremises,
      responses: draft.explicitResponses,
      correctPairs,
      stemOnly,
    };
  }

  // 1B. Two-list where Premis was numbered (1., 2., 3.) inside questionLines and Respon was A., B., C. inside options
  if (
    (draft.detectedType === 'menjodohkan' || Boolean(draft.explicitMatchingKeyMap)) &&
    draft.options.length >= 2
  ) {
    const numberedPremLines = draft.questionLines
      .slice(1)
      .filter((l) => /^\d+[\.\)\-:]\s*\S/.test(l.trim()));
    if (numberedPremLines.length >= 2) {
      const premises: MatchingPremise[] = numberedPremLines.map((l, idx) => ({
        id: `p${idx + 1}`,
        text: l.trim().replace(/^\d+[\.\)\-:]\s*/, '').trim(),
      }));
      const responses: MatchingResponse[] = draft.options.map((o, idx) => ({
        id: `r${idx + 1}`,
        text: o.text,
        ...(o.images?.length ? { images: o.images } : {}),
      }));
      const correctPairs = applyKeyMapToPremisesResponses(premises, responses);
      const stemOnly =
        draft.questionLines[0]?.trim() ||
        'Pasangkan pernyataan pada kolom Premis dengan jawaban yang sesuai pada kolom Respon!';
      return { premises, responses, correctPairs, stemOnly };
    }
  }

  // 2. Explicit 1-to-1 matching pairs
  if (draft.explicitMatchingPairs && draft.explicitMatchingPairs.length >= 2) {
    const premises: MatchingPremise[] = [];
    const responses: MatchingResponse[] = [];
    const correctPairs: Record<string, string> = {};
    draft.explicitMatchingPairs.forEach((pair, pIdx) => {
      const pId = `p${pIdx + 1}`;
      const rId = `r${pIdx + 1}`;
      premises.push({
        id: pId,
        text: pair.premise,
        ...(pair.premiseImages?.length ? { images: pair.premiseImages } : {}),
      });
      responses.push({
        id: rId,
        text: pair.response,
        ...(pair.responseImages?.length ? { images: pair.responseImages } : {}),
      });
      correctPairs[pId] = rId;
    });
    const stemOnly =
      draft.questionLines.join(' ').trim() ||
      'Pasangkan pernyataan pada kolom Premis dengan jawaban yang sesuai pada kolom Respon!';
    return { premises, responses, correctPairs, stemOnly };
  }

  // Never misclassify explicit PG / PGK / Benar-Salah / Isian questions (e.g. chemistry equations with "->") as Menjodohkan
  if (draft.detectedType && draft.detectedType !== 'menjodohkan') {
    return null;
  }

  const strongArrowRegex = /^(.+?)\s*(?:===>|==>|--->|->|=>|<->|↔)\s*(.+)$/;
  const softPairRegex = /^(.+?)\s*(?:===>|==>|--->|->|=>|<->|↔|—|--|=)\s*(.+)$/;

  const candidateStrings =
    draft.options.length >= 2
      ? draft.options.map((o) => o.text)
      : draft.questionLines.slice(1);

  // If options have single red answer or explicit A..E key (standard PG), do NOT hijack unless explicitly menjodohkan!
  if (
    draft.detectedType !== 'menjodohkan' &&
    draft.options.length >= 2 &&
    (draft.options.some((o) => o.isRed) || draft.explicitKeys.length > 0)
  ) {
    const allStrongArrows =
      candidateStrings.length >= 2 &&
      candidateStrings.every((line) =>
        strongArrowRegex.test(line.replace(/^(?:[-•*▪▫]|[A-Za-z0-9]+[\.\)\-:])\s*/, '').trim())
      );
    // Still skip chemistry reaction options when only 1 option is red (true PG)
    const redCount = draft.options.filter((o) => o.isRed).length;
    if (!allStrongArrows || redCount === 1 || draft.explicitKeys.length > 0) {
      return null;
    }
  }

  // Only allow "=" as a matching separator when the question is EXPLICITLY Menjodohkan
  // (otherwise math options like "A. x = 2, B. x = 3" or SPLDV "x + y = 5 / 2x - y = 4" get hijacked!)
  const activeRegex =
    draft.detectedType === 'menjodohkan' ? softPairRegex : strongArrowRegex;
  const pairs: { premise: string; response: string }[] = [];
  const remainingStemLines: string[] =
    draft.options.length >= 2 ? [...draft.questionLines] : [draft.questionLines[0] || ''];

  for (const line of candidateStrings) {
    const cleaned = line
      .replace(/^(?:[-•*▪▫]\s*|[A-Za-z0-9]+[\.\)\-:]\s*)/, '')
      .trim();
    // Skip lines that are pure $...$ math equations/implications when not explicitly Menjodohkan
    const isWrappedMathFormula =
      draft.detectedType !== 'menjodohkan' &&
      /^\$[^$]+\$$/.test(cleaned);
    const m = isWrappedMathFormula ? null : cleaned.match(activeRegex);
    if (m && m[1].trim() && m[2].trim()) {
      pairs.push({ premise: m[1].trim(), response: m[2].trim() });
    } else if (draft.options.length < 2 && line.trim()) {
      remainingStemLines.push(line.trim());
    }
  }

  if (
    pairs.length >= 2 &&
    (draft.detectedType === 'menjodohkan' ||
      pairs.length === candidateStrings.length)
  ) {
    const premises: MatchingPremise[] = pairs.map((p, idx) => ({
      id: `p${idx + 1}`,
      text: p.premise,
    }));
    const responses: MatchingResponse[] = pairs.map((p, idx) => ({
      id: `r${idx + 1}`,
      text: p.response,
    }));
    const correctPairs = applyKeyMapToPremisesResponses(premises, responses);
    const stemOnly =
      remainingStemLines.filter(Boolean).join(' ').trim() ||
      'Pasangkan pernyataan pada kolom Premis dengan jawaban yang sesuai pada kolom Respon!';
    return { premises, responses, correctPairs, stemOnly };
  }

  return null;
}

/**
 * Helper to check if a draft's options, statements, or inline "Pernyataan 1: ... [Kunci: Benar]" lines
 * represent a Benar/Salah (or Sesuai/Tidak Sesuai, Ya/Tidak, Fakta/Opini, etc.) question.
 */
function tryExtractBenarSalahFromDraft(
  draft: DraftQuestion
): {
  statements: StatementItem[];
  trueLabel?: string;
  falseLabel?: string;
  cleanedStem?: string;
} | null {
  if (draft.explicitStatements && draft.explicitStatements.length > 0) {
    return {
      statements: draft.explicitStatements,
      trueLabel: draft.trueLabel,
      falseLabel: draft.falseLabel,
    };
  }

  const stripRadioPrefix = (raw: string) =>
    raw.replace(/^(?:[oO○◯●•▪▫◦☐☑✓✔\-\*]|\[[xXvV✓✔\s]?\]|\(\s*\))\s+/, '').trim();

  const bsSuffixRegex =
    /^(.*?)[\s\-:]*[\(\[]\s*(?:kunci\s*:\s*)?(benar|salah|sesuai|tidak\s+sesuai|ya|tidak|fakta|opini|setuju|tidak\s+setuju|tepat|tidak\s+tepat|valid|tidak\s+valid|mendukung|tidak\s+mendukung|true|false|b|s)\s*[\)\]]\s*$/i;

  const isPositiveVal = (val: string) =>
    /^(?:benar|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true|b)$/i.test(
      val.trim()
    );

  // 0. Check inline statement lines inside questionLines (e.g. "Pernyataan 1: ... [Kunci: Benar]" from Archive or teacher docs!)
  if (draft.questionLines.length >= 2) {
    const matchedInline: StatementItem[] = [];
    const stemOnlyLines: string[] = [];
    for (let i = 0; i < draft.questionLines.length; i++) {
      const line = draft.questionLines[i].trim();
      const m = line.match(bsSuffixRegex);
      const isPernyataanLine = /^pernyataan\s*\d+\s*[:\.\-]\s*/i.test(line);
      if (m && (i > 0 || isPernyataanLine)) {
        const cleanedBody = m[1]
          .replace(/^(?:pernyataan\s*\d+\s*[:\.\-]\s*|[-•*▪▫]\s*|\d+[\.\)\-:]\s*)/i, '')
          .trim();
        matchedInline.push({
          id: `st${matchedInline.length + 1}`,
          statement: cleanedBody || `Pernyataan ${matchedInline.length + 1}`,
          correctValue: isPositiveVal(m[2]) ? 'Benar' : 'Salah',
        });
      } else {
        stemOnlyLines.push(line);
      }
    }
    if (
      matchedInline.length >= 2 ||
      (matchedInline.length === 1 &&
        (draft.detectedType === 'benar_salah' ||
          draft.questionLines.some((l) => /^pernyataan\s*\d+\s*[:\.\-]/i.test(l.trim()))))
    ) {
      return {
        statements: matchedInline,
        trueLabel: draft.trueLabel,
        falseLabel: draft.falseLabel,
        cleanedStem: stemOnlyLines.join(' ').trim() || undefined,
      };
    }
  }

  if (draft.options.length >= 2) {
    const matchedSuffixCount = draft.options.filter((o) =>
      bsSuffixRegex.test(o.text.trim())
    ).length;

    if (matchedSuffixCount >= 2) {
      return {
        statements: draft.options.map((o, idx) => {
          const m = o.text.trim().match(bsSuffixRegex);
          const stText = m ? m[1].trim() : o.text.trim();
          const valRaw = m ? m[2].toLowerCase() : '';
          const isBenar = valRaw ? isPositiveVal(valRaw) : o.isRed;
          return {
            id: `st${idx + 1}`,
            statement: stText,
            correctValue: isBenar ? 'Benar' : 'Salah',
            images: o.images,
          };
        }),
        trueLabel: draft.trueLabel,
        falseLabel: draft.falseLabel,
      };
    }

    // Check if the 2 options are literally polar pairs ("Benar"/"Salah", "Sesuai"/"Tidak Sesuai", "Ya"/"Tidak", "Fakta"/"Opini", etc.)
    const opt0Clean = stripRadioPrefix(draft.options[0].text.trim());
    const opt1Clean = stripRadioPrefix(draft.options[1].text.trim());
    const polarPairs: [RegExp, RegExp, string, string][] = [
      [/^(?:benar|true)$/i, /^(?:salah|false)$/i, 'Benar', 'Salah'],
      [/^sesuai$/i, /^tidak\s+sesuai$/i, 'Sesuai', 'Tidak Sesuai'],
      [/^ya$/i, /^tidak$/i, 'Ya', 'Tidak'],
      [/^fakta$/i, /^opini$/i, 'Fakta', 'Opini'],
      [/^setuju$/i, /^tidak\s+setuju$/i, 'Setuju', 'Tidak Setuju'],
      [/^tepat$/i, /^tidak\s+tepat$/i, 'Tepat', 'Tidak Tepat'],
      [/^valid$/i, /^tidak\s+valid$/i, 'Valid', 'Tidak Valid'],
      [/^mendukung$/i, /^tidak\s+mendukung$/i, 'Mendukung', 'Tidak Mendukung'],
    ];

    if (draft.options.length === 2) {
      for (const [tRe, fRe, tLbl, fLbl] of polarPairs) {
        if (tRe.test(opt0Clean) && fRe.test(opt1Clean)) {
          const isFirstCorrect =
            draft.options[0].isRed ||
            draft.options[0].isHighlight ||
            (draft.options[0].isBold && !draft.options[1].isBold) ||
            draft.explicitKeys.includes('A') ||
            draft.explicitKeys.includes('BENAR');
          const stemText =
            draft.questionLines.join(' ').trim() || 'Pernyataan soal';
          return {
            statements: [
              {
                id: 'st1',
                statement: stemText,
                correctValue: isFirstCorrect ? 'Benar' : 'Salah',
              },
            ],
            trueLabel: draft.trueLabel || tLbl,
            falseLabel: draft.falseLabel || fLbl,
          };
        }
      }
    }
  }

  if (draft.detectedType === 'benar_salah' && draft.options.length >= 2) {
    return {
      statements: draft.options.slice(0, 8).map((o, idx) => {
        const explicitVal = draft.explicitKeys[idx];
        const isBenar =
          explicitVal === 'BENAR'
            ? true
            : explicitVal === 'SALAH'
            ? false
            : o.isRed || Boolean(o.isHighlight);
        return {
          id: `st${idx + 1}`,
          statement: o.text,
          correctValue: isBenar ? 'Benar' : 'Salah',
          images: o.images,
        };
      }),
      trueLabel: draft.trueLabel,
      falseLabel: draft.falseLabel,
    };
  }

  // Single-statement Benar/Salah question with explicit B/S key (no table and no options)
  if (
    draft.detectedType === 'benar_salah' &&
    draft.options.length === 0 &&
    draft.questionLines.length >= 1
  ) {
    const stemText = draft.questionLines.join(' ').trim();
    const isBenar =
      draft.explicitKeys[0] === 'BENAR' ||
      (draft.explicitKeys[0] !== 'SALAH' &&
        draft.unprefixedParagraphs.some((p) => p.hasRed));
    return {
      statements: [
        {
          id: 'st1',
          statement: stemText,
          correctValue: isBenar ? 'Benar' : 'Salah',
        },
      ],
      trueLabel: draft.trueLabel,
      falseLabel: draft.falseLabel,
    };
  }

  return null;
}

/**
 * Converts extracted DocumentBlocks (paragraphs and tables with formatting metadata) into CBT Question objects.
 * Automatically recognizes all 5 question types (Pilihan Ganda, PG Kompleks, Benar/Salah, Menjodohkan, Isian Singkat)
 * directly from the uploaded file's structure, tags, tables, colors, highlights, bold/underline, or answer keys!
 */
function buildQuestionsFromBlocks(
  blocks: DocumentBlock[],
  _defaultQuestionType: QuestionType,
  startingNumber: number,
  defaultCategory: string
): Question[] {
  const drafts = buildDraftsFromBlockSequence(blocks);
  const questions: Question[] = [];
  const nowTs = Date.now();

  drafts.forEach((draft, idx) => {
    const qNum = startingNumber + idx;
    const rawQuestionText =
      draft.questionLines.join(' ').trim() ||
      (draft.questionImages && draft.questionImages.length > 0
        ? 'Perhatikan gambar berikut untuk menjawab pertanyaan!'
        : `Pertanyaan Soal No. ${qNum}`);
    const stemDetectedType =
      draft.detectedType || detectQuestionTypeFromText(rawQuestionText);
    const questionCategory = draft.explicitCategory || defaultCategory;
    const questionPoints = draft.explicitPoints || 10;
    const cleanStimulusImages =
      draft.stimulusImages && draft.stimulusImages.length > 0
        ? draft.stimulusImages
        : undefined;
    const cleanQuestionImages =
      draft.questionImages && draft.questionImages.length > 0
        ? draft.questionImages
        : undefined;

    // 1. Check Menjodohkan (Matching)
    const matchingResult = tryExtractMatchingFromDraft(draft);
    if (matchingResult && matchingResult.premises.length >= 2) {
      questions.push({
        id: `word_q_${nowTs}_${idx}`,
        number: qNum,
        type: 'menjodohkan',
        category: questionCategory,
        stimulusTitle: draft.stimulusTitle,
        stimulusText: draft.stimulusText,
        stimulusImages: cleanStimulusImages,
        questionText: matchingResult.stemOnly,
        questionImages: cleanQuestionImages,
        stimulusTable: draft.stimulusTable,
        instructionText:
          draft.explicitInstruction ||
          'Pasangkan setiap pernyataan di sebelah kiri dengan pasangan yang tepat di sebelah kanan!',
        premises: matchingResult.premises,
        responses: matchingResult.responses,
        correctPairs: matchingResult.correctPairs,
        points: questionPoints,
        explanation:
          draft.explicitExplanation ||
          'Pasangan jawaban yang benar telah diatur sesuai dokumen soal.',
      });
      return;
    }

    // 2. Check Benar / Salah (including Sesuai/Tidak Sesuai, Ya/Tidak, Fakta/Opini, etc.)
    const bsResult = tryExtractBenarSalahFromDraft(draft);
    if (bsResult && bsResult.statements.length >= 1) {
      const pairFromStem = detectBenarSalahPairLabels(rawQuestionText);
      const tLabel = bsResult.trueLabel || pairFromStem?.trueLabel || 'Benar';
      const fLabel = bsResult.falseLabel || pairFromStem?.falseLabel || 'Salah';
      questions.push({
        id: `word_q_${nowTs}_${idx}`,
        number: qNum,
        type: 'benar_salah',
        category: questionCategory,
        stimulusTitle: draft.stimulusTitle,
        stimulusText: draft.stimulusText,
        stimulusImages: cleanStimulusImages,
        questionText: bsResult.cleanedStem || rawQuestionText,
        questionImages: cleanQuestionImages,
        stimulusTable: draft.stimulusTable,
        instructionText:
          draft.explicitInstruction ||
          `Tentukan ${tLabel} atau ${fLabel} untuk setiap pernyataan!`,
        statements: bsResult.statements,
        trueLabel: tLabel,
        falseLabel: fLabel,
        points: questionPoints,
        explanation:
          draft.explicitExplanation ||
          `Kunci ${tLabel}/${fLabel}: ${bsResult.statements
            .map(
              (s, sIdx) =>
                `(${sIdx + 1}) ${s.correctValue === 'Benar' ? tLabel : fLabel}`
            )
            .join(', ')}.`,
      });
      return;
    }

    // 3. Check Isian Singkat / Uraian (when no options A..E exist or explicitly tagged as isian/uraian without options)
    if (
      draft.options.length < 2 ||
      (stemDetectedType === 'isian_singkat' && draft.options.length === 0)
    ) {
      let finalQuestionText = rawQuestionText;
      let shortAnswers =
        draft.explicitTextAnswers && draft.explicitTextAnswers.length > 0
          ? draft.explicitTextAnswers
          : draft.explicitKeys.length > 0
          ? draft.explicitKeys
          : [];

      // Support inline bracketed blank answer like "Ibukota Indonesia adalah [Jakarta]" when no explicit key was given
      if (shortAnswers.length === 0) {
        const inlineBlankMatch = finalQuestionText.match(
          /\[([^\[\]]{1,60})\]/
        );
        if (
          inlineBlankMatch &&
          !/^(?:gambar|tabel|stimulus|pg|pgk|isian|uraian|benar|salah)/i.test(
            inlineBlankMatch[1].trim()
          )
        ) {
          shortAnswers = inlineBlankMatch[1]
            .split(/\s*[\/|;]\s*/)
            .map((s) => s.trim())
            .filter(Boolean);
          finalQuestionText = finalQuestionText.replace(
            inlineBlankMatch[0],
            '________'
          );
        }
      }

      if (shortAnswers.length === 0) {
        shortAnswers = ['Sesuai Kunci Guru'];
      }

      questions.push({
        id: `word_q_${nowTs}_${idx}`,
        number: qNum,
        type: 'isian_singkat',
        category: questionCategory,
        stimulusTitle: draft.stimulusTitle,
        stimulusText: draft.stimulusText,
        stimulusImages: cleanStimulusImages,
        questionText: finalQuestionText,
        questionImages: cleanQuestionImages,
        stimulusTable: draft.stimulusTable,
        instructionText:
          draft.explicitInstruction ||
          'Ketiklah jawaban singkat atau uraian dengan tepat pada kolom yang tersedia!',
        correctShortAnswers: shortAnswers,
        placeholder: 'Ketik jawaban Anda di sini...',
        points: questionPoints,
        explanation:
          draft.explicitExplanation ||
          `Kunci jawaban: ${shortAnswers.join(' / ')}.`,
      });
      return;
    }

    // 4. Pilihan Ganda or Pilihan Ganda Kompleks
    const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const slicedOpts = draft.options.slice(0, 8);
    const normalizedOptions: OptionItem[] = slicedOpts.map((o, oIdx) => ({
      id: letters[oIdx] || o.id,
      text: o.text,
      ...(o.images?.length ? { images: o.images } : {}),
    }));

    const redOptionIds = slicedOpts
      .map((o, oIdx) => (o.isRed ? letters[oIdx] || o.id : null))
      .filter((id): id is string => Boolean(id));

    const validExplicitOptionKeys = draft.explicitKeys.filter((k) =>
      letters.includes(k)
    );

    // Also resolve text-based explicit keys (e.g. "Kunci: Mitokondria" matching Option B's text!)
    if (
      validExplicitOptionKeys.length === 0 &&
      draft.explicitTextAnswers &&
      draft.explicitTextAnswers.length > 0
    ) {
      const normText = (s: string) =>
        s
          .toLowerCase()
          .replace(/[^a-z0-9]/g, '')
          .trim();
      for (const ansText of draft.explicitTextAnswers) {
        const cleanAns = ansText.trim();
        const letterPrefixM = cleanAns.match(/^[\(\[]?([A-Ha-h])[\)\]]?[\.\):]\s*/);
        if (letterPrefixM && letters.includes(letterPrefixM[1].toUpperCase())) {
          const id = letterPrefixM[1].toUpperCase();
          if (
            normalizedOptions.some((o) => o.id === id) &&
            !validExplicitOptionKeys.includes(id)
          ) {
            validExplicitOptionKeys.push(id);
            continue;
          }
        }
        const ansNorm = normText(cleanAns);
        if (ansNorm.length < 2) continue;
        const matchedOpt = normalizedOptions.find((o) => {
          const optNorm = normText(o.text);
          if (!optNorm) return false;
          return (
            optNorm === ansNorm ||
            (ansNorm.length >= 4 && optNorm.includes(ansNorm)) ||
            (optNorm.length >= 4 && ansNorm.includes(optNorm))
          );
        });
        if (matchedOpt && !validExplicitOptionKeys.includes(matchedOpt.id)) {
          validExplicitOptionKeys.push(matchedOpt.id);
        }
      }
    }

    const highlightedOptionIds = slicedOpts
      .map((o, oIdx) => (o.isHighlight ? letters[oIdx] || o.id : null))
      .filter((id): id is string => Boolean(id));

    const underlinedOptionIds = slicedOpts
      .map((o, oIdx) => (o.isUnderline ? letters[oIdx] || o.id : null))
      .filter((id): id is string => Boolean(id));

    const boldOptionIds = slicedOpts
      .map((o, oIdx) => (o.isBold ? letters[oIdx] || o.id : null))
      .filter((id): id is string => Boolean(id));

    let effectiveCorrectIds: string[];
    let keySourceNote = 'kunci jawaban';

    if (redOptionIds.length > 0) {
      effectiveCorrectIds = redOptionIds;
      keySourceNote = 'teks warna merah / tanda kunci';
    } else if (validExplicitOptionKeys.length > 0) {
      effectiveCorrectIds = validExplicitOptionKeys;
      keySourceNote = 'kunci jawaban dokumen';
    } else if (
      highlightedOptionIds.length > 0 &&
      highlightedOptionIds.length < slicedOpts.length
    ) {
      effectiveCorrectIds = highlightedOptionIds;
      keySourceNote = 'stabilo / highlight dokumen';
    } else if (
      underlinedOptionIds.length > 0 &&
      underlinedOptionIds.length < slicedOpts.length
    ) {
      effectiveCorrectIds = underlinedOptionIds;
      keySourceNote = 'garis bawah dokumen';
    } else if (
      boldOptionIds.length > 0 &&
      boldOptionIds.length < slicedOpts.length
    ) {
      effectiveCorrectIds = boldOptionIds;
      keySourceNote = 'cetak tebal (bold) dokumen';
    } else {
      effectiveCorrectIds = ['A'];
      keySourceNote = 'default opsi A';
    }

    const isComplex =
      stemDetectedType === 'pilihan_ganda_kompleks' ||
      effectiveCorrectIds.length > 1;

    if (isComplex) {
      questions.push({
        id: `word_q_${nowTs}_${idx}`,
        number: qNum,
        type: 'pilihan_ganda_kompleks',
        category: questionCategory,
        stimulusTitle: draft.stimulusTitle,
        stimulusText: draft.stimulusText,
        stimulusImages: cleanStimulusImages,
        questionText: rawQuestionText,
        questionImages: cleanQuestionImages,
        stimulusTable: draft.stimulusTable,
        instructionText:
          draft.explicitInstruction ||
          'Pilihlah lebih dari satu jawaban yang benar!',
        options: normalizedOptions,
        correctOptionIds: effectiveCorrectIds,
        points: questionPoints,
        explanation:
          draft.explicitExplanation ||
          `Kunci jawaban yang benar (${keySourceNote}): ${effectiveCorrectIds.join(', ')}.`,
      });
    } else {
      const singleKey = effectiveCorrectIds[0] || 'A';
      questions.push({
        id: `word_q_${nowTs}_${idx}`,
        number: qNum,
        type: 'pilihan_ganda',
        category: questionCategory,
        stimulusTitle: draft.stimulusTitle,
        stimulusText: draft.stimulusText,
        stimulusImages: cleanStimulusImages,
        questionText: rawQuestionText,
        questionImages: cleanQuestionImages,
        stimulusTable: draft.stimulusTable,
        instructionText:
          draft.explicitInstruction || 'Pilih satu jawaban yang paling tepat!',
        options: normalizedOptions,
        correctOptionId: singleKey,
        points: questionPoints,
        explanation:
          draft.explicitExplanation ||
          `Kunci jawaban yang benar (${keySourceNote}) adalah opsi ${singleKey}.`,
      });
    }
  });

  return questions;
}

/**
 * Converts an Excel/CSV workbook into DocumentBlocks so any spreadsheet layout
 * (table bank soal, vertical list, or multi-sheet) is seamlessly parsed into CBT questions.
 */
function parseSpreadsheetBlocks(buffer: ArrayBuffer): DocumentBlock[] {
  const workbook = XLSX.read(buffer, { type: 'array' });
  const blocks: DocumentBlock[] = [];

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) continue;

    const sheetType = detectQuestionTypeFromText(sheetName);
    if (sheetType) {
      blocks.push({
        kind: 'paragraph',
        paragraph: {
          fullText: sheetName,
          hasRed: false,
          segments: [{ text: sheetName, isRed: false }],
        },
      });
    }

    const rawRows = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
      header: 1,
      defval: '',
    });

    const nonEmptyRows = rawRows.filter(
      (r) =>
        Array.isArray(r) &&
        r.some((cell) => String(cell ?? '').trim().length > 0)
    );
    if (nonEmptyRows.length === 0) continue;

    // Check if the sheet is a 1-column list of paragraphs or a multi-column table
    const maxNonEmptyCols = Math.max(
      ...nonEmptyRows.map(
        (r) => r.filter((c) => String(c ?? '').trim().length > 0).length
      )
    );

    if (maxNonEmptyCols <= 1) {
      nonEmptyRows.forEach((r) => {
        const txt = r
          .map((c) => String(c ?? '').trim())
          .find((s) => s.length > 0);
        if (txt) {
          blocks.push({
            kind: 'paragraph',
            paragraph: {
              fullText: txt,
              hasRed: false,
              segments: [{ text: txt, isRed: false }],
            },
          });
        }
      });
    } else {
      const parsedRows: ParsedTableCell[][] = nonEmptyRows.map((r) =>
        r.map((c) => {
          const txt = String(c ?? '').trim();
          const para: ParsedParagraph = {
            fullText: txt,
            hasRed: false,
            segments: txt ? [{ text: txt, isRed: false }] : [],
          };
          return {
            fullText: txt,
            hasRed: false,
            paragraphs: txt ? [para] : [],
            nestedTables: [],
          };
        })
      );
      blocks.push({ kind: 'table', table: { rows: parsedRows } });
    }
  }

  return blocks;
}

/**
 * Strips RTF control sequences while preserving line breaks and detecting red color entries in \colortbl.
 */
function parseRtfBlocks(rawRtf: string): DocumentBlock[] {
  const redCfIndices = new Set<number>();
  const colorTblMatch = rawRtf.match(/\{\\colortbl;([^}]*)\}/i);
  if (colorTblMatch) {
    const entries = colorTblMatch[1].split(';');
    entries.forEach((entry, idx) => {
      const rM = entry.match(/\\red(\d+)/i);
      const gM = entry.match(/\\green(\d+)/i);
      const bM = entry.match(/\\blue(\d+)/i);
      if (rM && gM && bM) {
        const r = parseInt(rM[1], 10);
        const g = parseInt(gM[1], 10);
        const b = parseInt(bM[1], 10);
        if (r >= 130 && g <= 100 && b <= 100) {
          redCfIndices.add(idx + 1);
        }
      }
    });
  }

  const normalized = rawRtf
    .replace(/\\par\b|\\line\b/gi, '\n')
    .replace(/\\tab\b/gi, '\t');

  const lines = normalized.split(/\r?\n/);
  const blocks: DocumentBlock[] = [];

  for (const rawLine of lines) {
    let hasRed = false;
    redCfIndices.forEach((cfIdx) => {
      if (new RegExp(`\\\\cf${cfIdx}\\b`).test(rawLine)) {
        hasRed = true;
      }
    });

    const cleaned = rawLine
      .replace(/\{\\(?:fonttbl|colortbl|stylesheet|info)[^}]*\}/gi, '')
      .replace(/\\'[0-9a-fA-F]{2}/g, (m) =>
        String.fromCharCode(parseInt(m.slice(2), 16))
      )
      .replace(/\\[a-zA-Z]+-?\d*\s?/g, '')
      .replace(/[{}]/g, '')
      .trim();

    if (cleaned) {
      blocks.push({
        kind: 'paragraph',
        paragraph: {
          fullText: cleaned,
          hasRed,
          segments: [{ text: cleaned, isRed: hasRed }],
        },
      });
    }
  }

  return blocks;
}

function multiplyPdfMatrices(m1: number[], m2: number[]): number[] {
  return [
    m1[0] * m2[0] + m1[2] * m2[1],
    m1[1] * m2[0] + m1[3] * m2[1],
    m1[0] * m2[2] + m1[2] * m2[3],
    m1[1] * m2[2] + m1[3] * m2[3],
    m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
    m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
  ];
}

function normalizePdfColorArg(args: unknown[]): string {
  if (!args || args.length === 0) return '#000000';
  if (typeof args[0] === 'string') return args[0];
  if (args.length >= 3) {
    const scale =
      Math.max(Number(args[0]), Number(args[1]), Number(args[2])) <= 1
        ? 255
        : 1;
    const r = Math.round(Number(args[0]) * scale);
    const g = Math.round(Number(args[1]) * scale);
    const b = Math.round(Number(args[2]) * scale);
    return `rgb(${r}, ${g}, ${b})`;
  }
  return '#000000';
}

function isPdfInlineOptionRow(
  spans: { x: number; endX: number; text: string }[]
): boolean {
  if (spans.length !== 2) return false;
  const optStart = /^(?:\(\s*[A-Ea-e]\s*\)|[A-Ea-e]\s*[\.\)\-:])\s+\S/;
  return optStart.test(spans[0].text.trim()) && optStart.test(spans[1].text.trim());
}

async function extractPdfImageObjectToDataUrl(
  rawImgObj: unknown,
  maxWidth: number = 920
): Promise<string | null> {
  if (!rawImgObj || typeof document === 'undefined') return null;
  const imgObj = rawImgObj as {
    width?: number;
    height?: number;
    data?: Uint8ClampedArray | Uint8Array;
    kind?: number;
    bitmap?: CanvasImageSource;
  };

  try {
    const srcW = Number(imgObj.width || 0);
    const srcH = Number(imgObj.height || 0);
    // Skip tiny spacer/bullet images or thin decorative lines
    if (srcW < 28 || srcH < 28) return null;

    const srcCanvas = document.createElement('canvas');
    srcCanvas.width = srcW;
    srcCanvas.height = srcH;
    const srcCtx = srcCanvas.getContext('2d');
    if (!srcCtx) return null;

    if (imgObj.bitmap) {
      srcCtx.fillStyle = '#ffffff';
      srcCtx.fillRect(0, 0, srcW, srcH);
      srcCtx.drawImage(imgObj.bitmap, 0, 0, srcW, srcH);
    } else if (imgObj.data && imgObj.data.length > 0) {
      const rgba = new Uint8ClampedArray(srcW * srcH * 4);
      const data = imgObj.data;
      const pixelCount = srcW * srcH;

      if (data.length >= pixelCount * 4) {
        rgba.set(data.subarray(0, pixelCount * 4));
      } else if (data.length >= pixelCount * 3) {
        for (let p = 0, s = 0, d = 0; p < pixelCount; p++, s += 3, d += 4) {
          rgba[d] = data[s];
          rgba[d + 1] = data[s + 1];
          rgba[d + 2] = data[s + 2];
          rgba[d + 3] = 255;
        }
      } else if (data.length >= pixelCount) {
        for (let p = 0, d = 0; p < pixelCount; p++, d += 4) {
          const g = data[p];
          rgba[d] = g;
          rgba[d + 1] = g;
          rgba[d + 2] = g;
          rgba[d + 3] = 255;
        }
      } else {
        // 1-bit monochrome mask
        const rowBytes = Math.ceil(srcW / 8);
        for (let y = 0; y < srcH; y++) {
          for (let x = 0; x < srcW; x++) {
            const byte = data[y * rowBytes + (x >> 3)] ?? 255;
            const bit = (byte >> (7 - (x & 7))) & 1;
            const v = bit ? 255 : 0;
            const d = (y * srcW + x) * 4;
            rgba[d] = v;
            rgba[d + 1] = v;
            rgba[d + 2] = v;
            rgba[d + 3] = 255;
          }
        }
      }

      const imageData = srcCtx.createImageData(srcW, srcH);
      imageData.data.set(rgba);
      srcCtx.putImageData(imageData, 0, 0);
    } else {
      return null;
    }

    const scale = srcW > maxWidth ? maxWidth / srcW : 1;
    const outW = Math.max(1, Math.round(srcW * scale));
    const outH = Math.max(1, Math.round(srcH * scale));
    const outCanvas = document.createElement('canvas');
    outCanvas.width = outW;
    outCanvas.height = outH;
    const outCtx = outCanvas.getContext('2d');
    if (!outCtx) return null;
    outCtx.fillStyle = '#ffffff';
    outCtx.fillRect(0, 0, outW, outH);
    outCtx.drawImage(srcCanvas, 0, 0, outW, outH);

    const jpegDataUrl = outCanvas.toDataURL('image/jpeg', 0.82);
    return isSafeImageDataUrl(jpegDataUrl) ? jpegDataUrl : null;
  } catch {
    return null;
  }
}

/**
 * Parses a .pdf question file into DocumentBlocks using pdfjs-dist, preserving:
 * - Red text color metadata from PDF graphics operator lists (for PG/PGK/B-S keys)
 * - Embedded raster images & diagrams extracted via PDF graphics operators
 * - Superscripts and subscripts converted cleanly to Unicode (H₂O, 10⁻³¹, S²⁻)
 * - Multi-column tables reconstructed via X-interval projection & cross-page merging
 * - Multi-line wrapped paragraphs and checkbox/option lines
 */
export async function parsePdfDocumentBlocks(
  bytes: Uint8Array
): Promise<DocumentBlock[]> {
  const pdfjsLib = await loadPdfJs();

  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(bytes),
    verbosity: 0,
  });
  const pdfDoc = await loadingTask.promise;

  interface PdfRawItem {
    str: string;
    x: number;
    y: number;
    w: number;
    h: number;
    isRed: boolean;
  }

  interface PdfVisualSpan {
    x: number;
    endX: number;
    text: string;
    hasRed: boolean;
    segments: TextSegment[];
  }

  interface PdfVisualRow {
    baseY: number;
    minX: number;
    maxX: number;
    spans: PdfVisualSpan[];
    hasRed: boolean;
    fullText: string;
    images?: string[];
  }

  const allBlocks: DocumentBlock[] = [];

  for (let pageNum = 1; pageNum <= pdfDoc.numPages; pageNum++) {
    const page = await pdfDoc.getPage(pageNum);

    // 1. Collect red-colored text draw coordinates AND embedded images from page operator list
    const redDraws: { x: number; y: number; text: string }[] = [];
    const pendingImages: {
      x: number;
      y: number;
      width: number;
      name?: string;
      inlineObj?: unknown;
    }[] = [];
    try {
      const opList = await page.getOperatorList();
      const { OPS } = pdfjsLib;
      let ctm = [1, 0, 0, 1, 0, 0];
      let tm = [1, 0, 0, 1, 0, 0];
      let tlm = [1, 0, 0, 1, 0, 0];
      let leading = 0;
      let fillColor = '#000000';
      const stack: { ctm: number[]; fillColor: string }[] = [];

      for (let i = 0; i < opList.fnArray.length; i++) {
        const fn = opList.fnArray[i];
        const args = opList.argsArray[i] || [];

        if (fn === OPS.save) {
          stack.push({ ctm: [...ctm], fillColor });
        } else if (fn === OPS.restore) {
          const prev = stack.pop();
          if (prev) {
            ctm = prev.ctm;
            fillColor = prev.fillColor;
          }
        } else if (fn === OPS.transform) {
          ctm = multiplyPdfMatrices(ctm, args as number[]);
        } else if (fn === OPS.setFillRGBColor) {
          fillColor = normalizePdfColorArg(args);
        } else if (fn === OPS.setFillGray) {
          fillColor = '#000000';
        } else if (fn === OPS.setFillCMYKColor && args.length >= 4) {
          const c = Number(args[0]);
          const m = Number(args[1]);
          const y = Number(args[2]);
          const k = Number(args[3]);
          const r = Math.round(255 * (1 - c) * (1 - k));
          const g = Math.round(255 * (1 - m) * (1 - k));
          const b = Math.round(255 * (1 - y) * (1 - k));
          fillColor = `rgb(${r}, ${g}, ${b})`;
        } else if (
          fn === OPS.paintImageXObject ||
          fn === (OPS as Record<string, number>).paintJpegXObject ||
          fn === OPS.paintImageXObjectRepeat
        ) {
          const dispW = Math.hypot(ctm[0], ctm[1]);
          const dispH = Math.hypot(ctm[2], ctm[3]);
          if (dispW >= 24 && dispH >= 24 && typeof args[0] === 'string') {
            pendingImages.push({
              x: ctm[4],
              y: ctm[5] + Math.abs(ctm[3]) * 0.5,
              width: dispW,
              name: args[0],
            });
          }
        } else if (fn === OPS.paintInlineImageXObject) {
          const dispW = Math.hypot(ctm[0], ctm[1]);
          const dispH = Math.hypot(ctm[2], ctm[3]);
          if (dispW >= 24 && dispH >= 24 && args[0]) {
            pendingImages.push({
              x: ctm[4],
              y: ctm[5] + Math.abs(ctm[3]) * 0.5,
              width: dispW,
              inlineObj: args[0],
            });
          }
        } else if (fn === OPS.beginText) {
          tm = [1, 0, 0, 1, 0, 0];
          tlm = [1, 0, 0, 1, 0, 0];
        } else if (fn === OPS.setTextMatrix && args[0]) {
          const m = args[0] as Record<number, number>;
          const arr = Array.isArray(m)
            ? m
            : [m[0], m[1], m[2], m[3], m[4], m[5]];
          tm = [...arr];
          tlm = [...arr];
        } else if (fn === OPS.moveText) {
          tlm = multiplyPdfMatrices(tlm, [
            1,
            0,
            0,
            1,
            Number(args[0]) || 0,
            Number(args[1]) || 0,
          ]);
          tm = [...tlm];
        } else if (fn === OPS.setLeading) {
          leading = Number(args[0]) || 0;
        } else if (fn === OPS.setLeadingMoveText) {
          leading = -(Number(args[1]) || 0);
          tlm = multiplyPdfMatrices(tlm, [
            1,
            0,
            0,
            1,
            Number(args[0]) || 0,
            Number(args[1]) || 0,
          ]);
          tm = [...tlm];
        } else if (fn === OPS.nextLine) {
          tlm = multiplyPdfMatrices(tlm, [1, 0, 0, 1, 0, -leading]);
          tm = [...tlm];
        } else if (
          fn === OPS.showText ||
          fn === OPS.showSpacedText ||
          fn === OPS.nextLineShowText ||
          fn === OPS.nextLineSetSpacingShowText
        ) {
          if (
            fn === OPS.nextLineShowText ||
            fn === OPS.nextLineSetSpacingShowText
          ) {
            tlm = multiplyPdfMatrices(tlm, [1, 0, 0, 1, 0, -leading]);
            tm = [...tlm];
          }
          const glyphs = Array.isArray(args[0]) ? args[0] : [];
          const runStr = glyphs
            .map((g: unknown) =>
              g && typeof g === 'object' && 'unicode' in g
                ? String((g as { unicode: string }).unicode)
                : ''
            )
            .join('')
            .trim();
          if (runStr && isRedColorValue(fillColor)) {
            const tr = multiplyPdfMatrices(ctm, tm);
            redDraws.push({ x: tr[4], y: tr[5], text: runStr });
          }
        }
      }
    } catch {
      // If operator list inspection fails on a malformed PDF stream, proceed with text extraction
    }

    // Resolve embedded PDF images to compressed data URLs
    const resolvedPdfImages: { x: number; y: number; width: number; dataUrl: string }[] = [];
    if (pendingImages.length > 0 && typeof document !== 'undefined') {
      const resolvePdfObj = (name: string): Promise<unknown> =>
        new Promise((resolve) => {
          let settled = false;
          const finish = (val: unknown) => {
            if (!settled) {
              settled = true;
              resolve(val);
            }
          };
          const timer = setTimeout(() => finish(null), 1200);
          try {
            if (page.objs.has(name)) {
              clearTimeout(timer);
              finish(page.objs.get(name));
              return;
            }
            if (page.commonObjs.has(name)) {
              clearTimeout(timer);
              finish(page.commonObjs.get(name));
              return;
            }
            page.objs.get(name, (obj: unknown) => {
              clearTimeout(timer);
              finish(obj);
            });
          } catch {
            clearTimeout(timer);
            finish(null);
          }
        });

      const imgCache: Record<string, string | null> = {};
      for (const pImg of pendingImages) {
        let dataUrl: string | null = null;
        if (pImg.inlineObj) {
          dataUrl = await extractPdfImageObjectToDataUrl(pImg.inlineObj);
        } else if (pImg.name) {
          if (!(pImg.name in imgCache)) {
            const obj = await resolvePdfObj(pImg.name);
            imgCache[pImg.name] = await extractPdfImageObjectToDataUrl(obj);
          }
          dataUrl = imgCache[pImg.name];
        }
        if (dataUrl) {
          resolvedPdfImages.push({
            x: pImg.x,
            y: pImg.y,
            width: pImg.width,
            dataUrl,
          });
        }
      }
    }

    // 2. Extract positioned text items
    const tc = await page.getTextContent();
    const normalItems: PdfRawItem[] = [];
    const scriptItems: PdfRawItem[] = [];

    for (const raw of tc.items) {
      if (!('str' in raw)) continue;
      const str = normalizeMathUnicodeChars(raw.str);
      if (!str || str.length === 0) continue;
      const x = raw.transform[4];
      const y = raw.transform[5];
      const w = Math.max(0, raw.width || 0);
      const h =
        raw.height && raw.height > 0
          ? raw.height
          : Math.hypot(raw.transform[2], raw.transform[3]);

      const isRed =
        str.trim().length > 0 &&
        redDraws.some(
          (rd) => Math.abs(rd.x - x) <= 6 && Math.abs(rd.y - y) <= 4.5
        );

      const itemObj: PdfRawItem = { str, x, y, w, h, isRed };
      if (
        h > 0 &&
        h < 7.2 &&
        str.trim().length > 0 &&
        str.trim().length <= 12 &&
        /^[0-9a-zA-Z+\-−().,]+$/.test(str.trim())
      ) {
        scriptItems.push(itemObj);
      } else {
        normalItems.push(itemObj);
      }
    }

    // 3. Group non-whitespace normal items into visual baseline rows
    interface RawRowBucket {
      baseY: number;
      items: (PdfRawItem & { scriptKind?: 'sup' | 'sub' })[];
    }
    const rowBuckets: RawRowBucket[] = [];
    const whitespaceItems: PdfRawItem[] = [];

    for (const it of normalItems) {
      if (!it.str.trim()) {
        if (it.w > 0) whitespaceItems.push(it);
        continue;
      }
      const found = rowBuckets.find((r) => Math.abs(r.baseY - it.y) <= 2.4);
      if (found) {
        found.items.push(it);
      } else {
        rowBuckets.push({ baseY: it.y, items: [it] });
      }
    }

    // Attach pure-whitespace items ONLY to existing baseline rows (never create empty buckets at script Y!)
    for (const ws of whitespaceItems) {
      let bestRow: RawRowBucket | undefined;
      let bestDist = 4.5;
      for (const r of rowBuckets) {
        const d = Math.abs(r.baseY - ws.y);
        if (d < bestDist) {
          bestDist = d;
          bestRow = r;
        }
      }
      if (bestRow) {
        bestRow.items.push(ws);
      }
    }

    // Attach small sub/superscript items cleanly to closest baseline row
    for (const sc of scriptItems) {
      let bestRow: RawRowBucket | undefined;
      let bestDist = 8.0;
      for (const r of rowBuckets) {
        const d = Math.abs(r.baseY - sc.y);
        if (d < bestDist) {
          bestDist = d;
          bestRow = r;
        }
      }
      if (bestRow) {
        const scriptKind = sc.y >= bestRow.baseY + 0.8 ? 'sup' : 'sub';
        bestRow.items.push({ ...sc, scriptKind });
      } else {
        rowBuckets.push({ baseY: sc.y, items: [sc] });
      }
    }

    rowBuckets.sort((a, b) => b.baseY - a.baseY);

    // 4. Build horizontal column spans per row (splitting on gap >= 8pt or wide space item)
    const visualRows: PdfVisualRow[] = [];
    for (const rb of rowBuckets) {
      rb.items.sort((a, b) => a.x - b.x);

      const spans: PdfVisualSpan[] = [];
      let curSegs: TextSegment[] = [];
      let curStartX = 0;
      let curEndX = 0;
      let hasCurrent = false;
      let pendingSpace = false;

      const pushSeg = (txt: string, red: boolean) => {
        if (!txt) return;
        const last = curSegs[curSegs.length - 1];
        if (last && last.isRed === red) {
          last.text += txt;
        } else {
          curSegs.push({ text: txt, isRed: red });
        }
      };

      const finalizeSpan = () => {
        if (!hasCurrent) return;
        const txt = curSegs.map((s) => s.text).join('').trim();
        if (txt) {
          spans.push({
            x: curStartX,
            endX: Math.max(curEndX, curStartX + 4),
            text: txt,
            hasRed: curSegs.some((s) => s.isRed && s.text.trim().length > 0),
            segments: curSegs,
          });
        }
        curSegs = [];
        hasCurrent = false;
        pendingSpace = false;
      };

      for (const it of rb.items) {
        const isWhitespace = it.str.trim().length === 0;
        if (isWhitespace) {
          if (it.w >= 10) {
            finalizeSpan();
          } else if (hasCurrent) {
            pendingSpace = true;
          }
          continue;
        }

        const displayText = it.scriptKind
          ? /^[0-9+\-ni().,]+$/i.test(it.str.trim())
            ? convertToUnicodeScript(it.str.trim(), it.scriptKind)
            : it.scriptKind === 'sup'
            ? `^{${it.str.trim()}}`
            : `_{${it.str.trim()}}`
          : it.str;

        if (!hasCurrent) {
          curStartX = it.x;
          curEndX = it.x + it.w;
          hasCurrent = true;
          pushSeg(displayText, it.isRed);
        } else {
          const gap = it.x - curEndX;
          if (gap >= 8.0) {
            finalizeSpan();
            curStartX = it.x;
            curEndX = it.x + it.w;
            hasCurrent = true;
            pushSeg(displayText, it.isRed);
          } else {
            const needSpace =
              !it.scriptKind &&
              (pendingSpace || gap >= 1.8) &&
              !/\s$/.test(curSegs[curSegs.length - 1]?.text || '') &&
              !/^\s/.test(displayText);
            if (needSpace) {
              pushSeg(' ', it.isRed);
            }
            pushSeg(displayText, it.isRed);
            curEndX = Math.max(curEndX, it.x + it.w);
          }
        }
        pendingSpace = false;
      }
      finalizeSpan();

      if (spans.length === 0) continue;
      const fullText = spans.map((s) => s.text).join(' ').trim();
      // Skip bare page number footers like "1" or "Halaman 1 dari 11" at bottom margin
      if (
        rb.baseY < 45 &&
        /^(?:-\s*\d+\s*-|\d+|(?:hal(?:aman)?|page)\s+\d+(?:\s*(?:dari|\/|of)\s*\d+)?)$/i.test(
          fullText
        )
      ) {
        continue;
      }

      visualRows.push({
        baseY: rb.baseY,
        minX: spans[0].x,
        maxX: spans[spans.length - 1].endX,
        spans,
        hasRed: spans.some((s) => s.hasRed),
        fullText,
      });
    }

    // Insert extracted PDF images into visualRows in vertical reading order (top to bottom)
    if (resolvedPdfImages.length > 0) {
      for (const imgEntry of resolvedPdfImages) {
        visualRows.push({
          baseY: imgEntry.y,
          minX: imgEntry.x,
          maxX: imgEntry.x + imgEntry.width,
          spans: [],
          hasRed: false,
          fullText: '',
          images: [imgEntry.dataUrl],
        });
      }
      visualRows.sort((a, b) => b.baseY - a.baseY);
    }

    // 5. Partition visualRows into Table Regions vs Paragraph Regions
    const isTableBreakHeading = (txt: string) =>
      Boolean(matchStimulusHeader(txt)) ||
      Boolean(matchSectionTypeHeader(txt)) ||
      /^petunjuk\s*[:\-]/i.test(txt) ||
      /^(?:(?:daftar|ringkasan)\s+)?kunci\s+jawaban/i.test(txt) ||
      CHECKBOX_OPTION_REGEX.test(txt);

    const rowIsMultiCol = (r: PdfVisualRow) =>
      !r.images?.length &&
      r.spans.length >= 2 &&
      !isPdfInlineOptionRow(r.spans) &&
      !isTableBreakHeading(r.fullText);

    const isRowTableContinuation = (
      prevTableRow: PdfVisualRow,
      cand: PdfVisualRow
    ) => {
      if (cand.images?.length) return false;
      if (cand.spans.length >= 2) return rowIsMultiCol(cand);
      if (isTableBreakHeading(cand.fullText)) return false;
      if (NUMBERED_QUESTION_REGEX.test(cand.fullText)) return false;
      const dy = prevTableRow.baseY - cand.baseY;
      return dy <= 17.5;
    };

    const emitParagraphRun = (paraRows: PdfVisualRow[]) => {
      let curLines: PdfVisualRow[] = [];

      const flushPara = () => {
        if (curLines.length === 0) return;
        const segments: TextSegment[] = [];
        curLines.forEach((lr, idx) => {
          lr.spans.forEach((sp, sIdx) => {
            if (idx > 0 || sIdx > 0) {
              segments.push({ text: ' ', isRed: false });
            }
            sp.segments.forEach((seg) => segments.push(seg));
          });
        });
        const fullText = segments
          .map((s) => s.text)
          .join('')
          .replace(/\s+/g, ' ')
          .trim();
        if (fullText) {
          allBlocks.push({
            kind: 'paragraph',
            paragraph: {
              fullText,
              hasRed: segments.some((s) => s.isRed && s.text.trim().length > 0),
              segments,
            },
          });
        }
        curLines = [];
      };

      for (const r of paraRows) {
        if (r.images && r.images.length > 0 && !r.fullText) {
          flushPara();
          allBlocks.push({
            kind: 'paragraph',
            paragraph: {
              fullText: '',
              hasRed: false,
              segments: [],
              images: [...r.images],
            },
          });
          continue;
        }
        if (curLines.length === 0) {
          curLines.push(r);
          continue;
        }
        const prev = curLines[curLines.length - 1];
        const prevTextJoined = curLines.map((l) => l.fullText).join(' ').trim();
        const dy = prev.baseY - r.baseY;
        const rNumMatch = r.fullText.match(NUMBERED_QUESTION_REGEX);
        const rNumVal = rNumMatch ? parseInt(rNumMatch[1], 10) : 0;
        const startsWithStruct =
          Boolean(matchStimulusHeader(r.fullText)) ||
          Boolean(matchSectionTypeHeader(r.fullText)) ||
          /^petunjuk\s*[:\-]/i.test(r.fullText) ||
          /^(?:(?:daftar|ringkasan)\s+)?kunci\s+jawaban/i.test(r.fullText) ||
          /^(?:ringkasan\s+kunci|bagian\s+[ivx]+\s*\(|total\s+skor)/i.test(
            r.fullText
          ) ||
          CHECKBOX_OPTION_REGEX.test(r.fullText) ||
          /^(?:\([A-Ea-e]\)|[A-Ea-e][\.\)\-:])\s+/.test(r.fullText) ||
          (rNumVal >= 1 &&
            rNumVal <= 200 &&
            !/\|\s*\d+\s*\.$/.test(prevTextJoined));

        if (dy > 16.5 || startsWithStruct) {
          flushPara();
        }
        curLines.push(r);
      }
      flushPara();
    };

    const emitTableRun = (tableRows: PdfVisualRow[]) => {
      // Cluster columns via X-interval projection across all spans in tableRows
      const intervals: { start: number; end: number }[] = [];
      for (const r of tableRows) {
        for (const sp of r.spans) {
          intervals.push({ start: sp.x, end: sp.endX });
        }
      }
      intervals.sort((a, b) => a.start - b.start);
      const colIntervals: { start: number; end: number }[] = [];
      for (const iv of intervals) {
        const last = colIntervals[colIntervals.length - 1];
        if (!last || iv.start > last.end + 4) {
          colIntervals.push({ ...iv });
        } else {
          last.end = Math.max(last.end, iv.end);
        }
      }

      if (colIntervals.length < 2) {
        emitParagraphRun(tableRows);
        return;
      }

      const mapSpanToCol = (sp: PdfVisualSpan): number => {
        let bestCol = 0;
        let bestScore = -Infinity;
        const spMid = (sp.x + sp.endX) / 2;
        colIntervals.forEach((ci, cIdx) => {
          const overlap =
            Math.min(sp.endX, ci.end) - Math.max(sp.x, ci.start);
          const ciMid = (ci.start + ci.end) / 2;
          const score =
            overlap > 0 ? 1000 + overlap : -Math.abs(spMid - ciMid);
          if (score > bestScore) {
            bestScore = score;
            bestCol = cIdx;
          }
        });
        return bestCol;
      };

      // Merge wrapped visual lines into logical table rows
      interface LogicalCellAccum {
        segments: TextSegment[];
      }
      const logicalRows: {
        cells: LogicalCellAccum[];
        lastY: number;
        populatedCount: number;
        hasCol0: boolean;
      }[] = [];

      for (const r of tableRows) {
        const assignedCols = new Set<number>();
        const colSpans: { col: number; sp: PdfVisualSpan }[] = r.spans.map(
          (sp) => {
            const c = mapSpanToCol(sp);
            assignedCols.add(c);
            return { col: c, sp };
          }
        );

        const prevRow = logicalRows[logicalRows.length - 1];
        const dy = prevRow ? prevRow.lastY - r.baseY : 999;
        const rHasCol0 = assignedCols.has(0);
        const isPartialWrapWithPrev =
          prevRow &&
          dy <= 15.0 &&
          prevRow.populatedCount >= 3 &&
          assignedCols.size < prevRow.populatedCount;
        const rIsNewMultiColRecord =
          prevRow &&
          rHasCol0 &&
          assignedCols.size >= 2 &&
          prevRow.populatedCount >= 2 &&
          !isPartialWrapWithPrev;

        const canMergeIntoPrev =
          prevRow && dy <= 17.5 && !rIsNewMultiColRecord;

        if (canMergeIntoPrev) {
          for (const { col, sp } of colSpans) {
            const cell = prevRow.cells[col];
            if (cell.segments.length > 0) {
              cell.segments.push({ text: ' ', isRed: false });
            }
            sp.segments.forEach((s) => cell.segments.push(s));
          }
          prevRow.lastY = r.baseY;
          prevRow.populatedCount = prevRow.cells.filter(
            (c) => c.segments.length > 0
          ).length;
        } else {
          const cells: LogicalCellAccum[] = colIntervals.map(() => ({
            segments: [],
          }));
          for (const { col, sp } of colSpans) {
            const cell = cells[col];
            if (cell.segments.length > 0) {
              cell.segments.push({ text: ' ', isRed: false });
            }
            sp.segments.forEach((s) => cell.segments.push(s));
          }
          logicalRows.push({
            cells,
            lastY: r.baseY,
            populatedCount: assignedCols.size,
            hasCol0: rHasCol0,
          });
        }
      }

      const parsedRows: ParsedTableCell[][] = logicalRows.map((lr) =>
        lr.cells.map((cell) => {
          const fullText = cell.segments
            .map((s) => s.text)
            .join('')
            .replace(/\s+/g, ' ')
            .trim();
          const hasRed = cell.segments.some(
            (s) => s.isRed && s.text.trim().length > 0
          );
          const para: ParsedParagraph = {
            fullText,
            hasRed,
            segments: cell.segments,
          };
          return {
            fullText,
            hasRed,
            paragraphs: fullText ? [para] : [],
            nestedTables: [],
          };
        })
      );

      if (parsedRows.length > 0) {
        allBlocks.push({ kind: 'table', table: { rows: parsedRows } });
      }
    };

    let idx = 0;
    const pendingParaRows: PdfVisualRow[] = [];
    const flushPendingParas = () => {
      if (pendingParaRows.length > 0) {
        emitParagraphRun(pendingParaRows);
        pendingParaRows.length = 0;
      }
    };

    while (idx < visualRows.length) {
      const r = visualRows[idx];
      if (rowIsMultiCol(r)) {
        const tblRows: PdfVisualRow[] = [r];
        let j = idx + 1;
        while (
          j < visualRows.length &&
          isRowTableContinuation(tblRows[tblRows.length - 1], visualRows[j])
        ) {
          tblRows.push(visualRows[j]);
          j++;
        }
        const multiColCount = tblRows.filter((tr) => rowIsMultiCol(tr)).length;
        if (multiColCount >= 2 || (tblRows.length === 1 && idx === visualRows.length - 1)) {
          flushPendingParas();
          emitTableRun(tblRows);
          idx = j;
          continue;
        }
      }
      pendingParaRows.push(r);
      idx++;
    }
    flushPendingParas();
  }

  // 6. Merge tables split directly across a page boundary when column counts match
  const mergedBlocks: DocumentBlock[] = [];
  for (const blk of allBlocks) {
    const prev = mergedBlocks[mergedBlocks.length - 1];
    if (
      blk.kind === 'table' &&
      prev?.kind === 'table' &&
      prev.table.rows.length >= 1 &&
      blk.table.rows.length >= 1 &&
      prev.table.rows[0].length === blk.table.rows[0].length
    ) {
      prev.table.rows.push(...blk.table.rows);
      continue;
    }
    mergedBlocks.push(blk);
  }

  return mergedBlocks;
}

function countTotalQuestionImages(questions: Question[]): number {
  let count = 0;
  for (const q of questions) {
    count += q.stimulusImages?.length ?? 0;
    count += q.questionImages?.length ?? 0;
    if (q.options) {
      for (const o of q.options) count += o.images?.length ?? 0;
    }
    if (q.statements) {
      for (const s of q.statements) count += s.images?.length ?? 0;
    }
    if (q.premises) {
      for (const p of q.premises) count += p.images?.length ?? 0;
    }
    if (q.responses) {
      for (const r of q.responses) count += r.images?.length ?? 0;
    }
  }
  return count;
}

/**
 * Extracts the WordDocument stream from a legacy Microsoft Word 97-2003 OLE2 Compound Binary File (.doc)
 * and converts extracted text & binary table markers (\x07) into DocumentBlocks.
 */
function extractOle2WordDocumentStream(bytes: Uint8Array): Uint8Array | null {
  try {
    if (bytes.length < 512) return null;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const sectorShift = view.getUint16(30, true);
    const sectorSize = 1 << sectorShift;
    if (sectorSize !== 512 && sectorSize !== 4096) return null;

    const firstDirSector = view.getUint32(48, true);
    const firstDifatSector = view.getUint32(68, true);
    const numDifatSectors = view.getUint32(72, true);
    const maxSectors = Math.floor((bytes.length - 512) / sectorSize);

    const getSectorOffset = (secId: number): number => 512 + secId * sectorSize;

    // 1. Gather FAT sector IDs from header DIFAT (109 entries) + extra DIFAT chain
    const fatSectorIds: number[] = [];
    for (let i = 0; i < 109; i++) {
      const id = view.getUint32(76 + i * 4, true);
      if (id === 0xffffffff || id === 0xfffffffe) break;
      if (id < maxSectors) fatSectorIds.push(id);
    }
    let difatSec = firstDifatSector;
    let difatSafety = 0;
    while (
      difatSec !== 0xfffffffe &&
      difatSec !== 0xffffffff &&
      difatSec < maxSectors &&
      difatSafety < Math.min(numDifatSectors + 2, 64)
    ) {
      difatSafety++;
      const off = getSectorOffset(difatSec);
      const count = sectorSize / 4 - 1;
      for (let i = 0; i < count; i++) {
        const id = view.getUint32(off + i * 4, true);
        if (id === 0xffffffff || id === 0xfffffffe) break;
        if (id < maxSectors) fatSectorIds.push(id);
      }
      difatSec = view.getUint32(off + count * 4, true);
    }

    // 2. Build FAT table
    const entriesPerSector = sectorSize / 4;
    const fat: number[] = [];
    for (const fatSecId of fatSectorIds) {
      const off = getSectorOffset(fatSecId);
      if (off + sectorSize > bytes.length) continue;
      for (let i = 0; i < entriesPerSector; i++) {
        fat.push(view.getUint32(off + i * 4, true));
      }
    }

    const readStreamByChain = (startSec: number, maxBytes: number): Uint8Array => {
      const chunks: Uint8Array[] = [];
      let total = 0;
      let sec = startSec;
      const visited = new Set<number>();
      while (
        sec !== 0xfffffffe &&
        sec !== 0xffffffff &&
        sec < maxSectors &&
        !visited.has(sec) &&
        total < maxBytes
      ) {
        visited.add(sec);
        const off = getSectorOffset(sec);
        if (off + sectorSize > bytes.length) break;
        const take = Math.min(sectorSize, maxBytes - total);
        chunks.push(bytes.subarray(off, off + take));
        total += take;
        sec = sec < fat.length ? fat[sec] : 0xfffffffe;
      }
      const out = new Uint8Array(total);
      let pos = 0;
      for (const ch of chunks) {
        out.set(ch, pos);
        pos += ch.length;
      }
      return out;
    };

    // 3. Read Directory stream and find "WordDocument"
    const dirBytes = readStreamByChain(firstDirSector, 1024 * 1024);
    const dirView = new DataView(
      dirBytes.buffer,
      dirBytes.byteOffset,
      dirBytes.byteLength
    );
    for (let off = 0; off + 128 <= dirBytes.length; off += 128) {
      const nameByteLen = dirView.getUint16(off + 64, true);
      if (nameByteLen < 2 || nameByteLen > 64) continue;
      let name = '';
      for (let i = 0; i < nameByteLen - 2; i += 2) {
        name += String.fromCharCode(dirView.getUint16(off + i, true));
      }
      if (name === 'WordDocument') {
        const startSec = dirView.getUint32(off + 116, true);
        const streamSize = dirView.getUint32(off + 120, true);
        if (streamSize > 0 && streamSize <= bytes.length) {
          return readStreamByChain(startSec, streamSize);
        }
      }
    }
    return null;
  } catch {
    return null;
  }
}

function parseBinaryDocBlocks(bytes: Uint8Array): DocumentBlock[] {
  const stream = extractOle2WordDocumentStream(bytes) || bytes;

  const isReadableChar = (code: number): boolean =>
    code === 0x09 ||
    code === 0x0a ||
    code === 0x0d ||
    code === 0x07 ||
    (code >= 0x20 && code <= 0x7e) ||
    (code >= 0xa0 && code <= 0x024f) ||
    (code >= 0x2010 && code <= 0x203a) ||
    (code >= 0x2190 && code <= 0x22ff) ||
    (code >= 0x25a0 && code <= 0x27bf);

  // Try extracting UTF-16LE runs first (Word 97-2003 Unicode documents)
  const extractUtf16Chunks = (buf: Uint8Array): string[] => {
    const chunks: string[] = [];
    let cur = '';
    for (let i = 0; i + 1 < buf.length; i += 2) {
      const code = buf[i] | (buf[i + 1] << 8);
      if (isReadableChar(code)) {
        cur += String.fromCharCode(code);
      } else {
        if (cur.trim().length >= 8) {
          chunks.push(cur);
        }
        cur = '';
      }
    }
    if (cur.trim().length >= 8) chunks.push(cur);
    return chunks;
  };

  // Also extract single-byte Windows-1252/ASCII runs (Word compressed text)
  const extractLatinChunks = (buf: Uint8Array): string[] => {
    const chunks: string[] = [];
    let cur = '';
    for (let i = 0; i < buf.length; i++) {
      const b = buf[i];
      if (
        b === 0x09 ||
        b === 0x0a ||
        b === 0x0d ||
        b === 0x07 ||
        (b >= 0x20 && b <= 0x7e) ||
        b >= 0xc0
      ) {
        cur += String.fromCharCode(b);
      } else {
        if (cur.trim().length >= 12) {
          chunks.push(cur);
        }
        cur = '';
      }
    }
    if (cur.trim().length >= 12) chunks.push(cur);
    return chunks;
  };

  const filterNoiseChunk = (chunk: string): boolean => {
    const trimmed = chunk.trim();
    if (trimmed.length < 2) return false;
    if (
      /^(?:Normal|Default Paragraph Font|Table Normal|No List|Heading \d|Times New Roman|Calibri|Cambria|Arial|Tahoma|Verdana|Symbol|Wingdings|Microsoft Word|Root Entry|WordDocument|1Table|0Table|SummaryInformation|DocumentSummaryInformation|CompObj|bjbj|HYPERLINK|PAGEREF|TOC\s)/i.test(
        trimmed
      )
    ) {
      return false;
    }
    // Require reasonable ratio of Indonesian/English word characters
    const letters = (trimmed.match(/[A-Za-z0-9]/g) || []).length;
    return letters / Math.max(trimmed.length, 1) >= 0.45;
  };

  const utf16Raw = extractUtf16Chunks(stream).filter(filterNoiseChunk);
  const latinRaw = extractLatinChunks(stream).filter(filterNoiseChunk);

  const utf16Total = utf16Raw.reduce((a, s) => a + s.length, 0);
  const latinTotal = latinRaw.reduce((a, s) => a + s.length, 0);

  // Pick whichever encoding holds the actual document body (or combine if both carry substantial question text)
  const chosenChunks =
    utf16Total >= latinTotal * 0.5 && utf16Total >= 80
      ? utf16Raw
      : latinTotal >= 80
      ? latinRaw
      : [...utf16Raw, ...latinRaw];

  const blocks: DocumentBlock[] = [];
  let pendingTableRows: ParsedTableCell[][] = [];

  const flushTable = () => {
    if (pendingTableRows.length >= 2) {
      blocks.push({ kind: 'table', table: { rows: pendingTableRows } });
    } else if (pendingTableRows.length === 1) {
      const joined = pendingTableRows[0]
        .map((c) => c.fullText)
        .filter(Boolean)
        .join(' ');
      if (joined) {
        blocks.push({
          kind: 'paragraph',
          paragraph: {
            fullText: joined,
            hasRed: false,
            segments: [{ text: joined, isRed: false }],
          },
        });
      }
    }
    pendingTableRows = [];
  };

  for (const chunk of chosenChunks) {
    // Strip Word field codes (\x13...\x14display\x15)
    const cleaned = chunk
      .replace(/\x13[^\x14\x15]*\x14([^\x15]*)\x15/g, '$1')
      .replace(/[\x13\x14\x15]/g, '')
      .replace(/\r\n/g, '\r')
      .replace(/\n/g, '\r');

    // Split into logical lines; Word binary tables delimit cells with \x07 and end rows with \x07\x07
    const segments = cleaned.split(/\r/);
    for (const seg of segments) {
      if (seg.includes('\x07')) {
        const rawCells = seg
          .split('\x07')
          .map((c) => c.replace(/\s+/g, ' ').trim());
        const nonEmptyTrailingTrim = rawCells.filter(
          (c, idx) => c.length > 0 || idx < rawCells.length - 1
        );
        if (nonEmptyTrailingTrim.length >= 2) {
          const parsedRow: ParsedTableCell[] = nonEmptyTrailingTrim.map((c) => ({
            fullText: c,
            hasRed: false,
            paragraphs: c
              ? [
                  {
                    fullText: c,
                    hasRed: false,
                    segments: [{ text: c, isRed: false }],
                  },
                ]
              : [],
            nestedTables: [],
          }));
          pendingTableRows.push(parsedRow);
          continue;
        }
      }

      flushTable();
      const line = seg.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, ' ').replace(/\s+/g, ' ').trim();
      if (!line || !filterNoiseChunk(line)) continue;
      blocks.push({
        kind: 'paragraph',
        paragraph: {
          fullText: line,
          hasRed: false,
          segments: [{ text: line, isRed: false }],
        },
      });
    }
  }
  flushTable();

  return blocks;
}

/**
 * Main entry point to parse any uploaded question file (.docx, .doc, .pdf, .xlsx, .xls, .csv, .txt, .rtf, .json, .html)
 * into CBT Question items, automatically recognizing each question's type and embedded images according to the file content.
 */
export async function parseWordQuestions(
  file: File,
  defaultQuestionType: QuestionType,
  startingNumber: number,
  defaultCategory: string = 'Sumatif Akhir Semester'
): Promise<{
  questions: Question[];
  redDetectedCount: number;
  tableCount: number;
  imageCount: number;
  typeBreakdown: Record<string, number>;
}> {
  const fileNameLower = file.name.trim().toLowerCase();
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);

  // 1. Handle JSON file directly if uploaded
  if (fileNameLower.endsWith('.json')) {
    const rawJson = new TextDecoder('utf-8').decode(bytes);
    const parsed = JSON.parse(rawJson);
    const arr = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed?.questions)
      ? parsed.questions
      : [];
    if (arr.length > 0) {
      const nowTs = Date.now();
      const questions: Question[] = arr.map((item: Partial<Question>, idx: number) => ({
        id: `word_q_${nowTs}_${idx}`,
        number: startingNumber + idx,
        type: item.type || 'pilihan_ganda',
        category: item.category || defaultCategory,
        stimulusTitle: item.stimulusTitle,
        stimulusText: item.stimulusText,
        stimulusImages: Array.isArray(item.stimulusImages)
          ? item.stimulusImages.filter((src) => isSafeImageDataUrl(src))
          : undefined,
        questionText: item.questionText || `Pertanyaan No. ${startingNumber + idx}`,
        questionImages: Array.isArray(item.questionImages)
          ? item.questionImages.filter((src) => isSafeImageDataUrl(src))
          : undefined,
        instructionText: item.instructionText || 'Pilih jawaban yang tepat!',
        options: item.options,
        correctOptionId: item.correctOptionId,
        correctOptionIds: item.correctOptionIds,
        statements: item.statements,
        trueLabel: item.trueLabel || 'Benar',
        falseLabel: item.falseLabel || 'Salah',
        premises: item.premises,
        responses: item.responses,
        correctPairs: item.correctPairs,
        correctShortAnswers: item.correctShortAnswers,
        stimulusTable: item.stimulusTable,
        points: item.points || 10,
        explanation: item.explanation || 'Sesuai kunci jawaban pada file.',
      }));
      const typeBreakdown: Record<string, number> = {};
      questions.forEach((q) => {
        typeBreakdown[q.type] = (typeBreakdown[q.type] || 0) + 1;
      });
      return {
        questions,
        redDetectedCount: questions.length,
        tableCount: questions.filter((q) => Boolean(q.stimulusTable)).length,
        imageCount: countTotalQuestionImages(questions),
        typeBreakdown,
      };
    }
  }

  const isPdfContainer =
    fileNameLower.endsWith('.pdf') ||
    (bytes.length >= 5 &&
      bytes[0] === 0x25 &&
      bytes[1] === 0x50 &&
      bytes[2] === 0x44 &&
      bytes[3] === 0x46 &&
      bytes[4] === 0x2d);

  const isZipContainer =
    bytes.length > 4 &&
    bytes[0] === 0x50 &&
    bytes[1] === 0x4b &&
    bytes[2] === 0x03 &&
    bytes[3] === 0x04;

  const isOle2Container =
    bytes.length >= 8 &&
    bytes[0] === 0xd0 &&
    bytes[1] === 0xcf &&
    bytes[2] === 0x11 &&
    bytes[3] === 0xe0 &&
    bytes[4] === 0xa1 &&
    bytes[5] === 0xb1 &&
    bytes[6] === 0x1a &&
    bytes[7] === 0xe1;

  const isSpreadsheetExt =
    fileNameLower.endsWith('.xlsx') ||
    fileNameLower.endsWith('.xls') ||
    fileNameLower.endsWith('.csv');

  let blocks: DocumentBlock[] = [];

  if (isPdfContainer) {
    blocks = await parsePdfDocumentBlocks(bytes);
  } else if (isZipContainer && !isSpreadsheetExt) {
    const { textFiles, binaryFiles } = await extractZipFiles(buffer);
    const documentXml = textFiles['word/document.xml'];
    if (documentXml) {
      const relImageMap = await buildDocxRelImageMap(
        textFiles['word/_rels/document.xml.rels'],
        binaryFiles
      );
      blocks = parseDocxDocumentBlocks(
        documentXml,
        textFiles['word/numbering.xml'],
        textFiles['word/styles.xml'],
        relImageMap
      );
    } else {
      // ZIP container without word/document.xml (e.g. .xlsx renamed or spreadsheet)
      blocks = parseSpreadsheetBlocks(buffer);
    }
  } else if (isSpreadsheetExt) {
    blocks = parseSpreadsheetBlocks(buffer);
  } else if (isOle2Container) {
    // Legacy Word 97-2003 binary .doc file (OLE2 Compound File)
    blocks = parseBinaryDocBlocks(bytes);
  } else {
    const textDecoder = new TextDecoder('utf-8');
    const rawText = textDecoder.decode(bytes);
    if (fileNameLower.endsWith('.rtf') || rawText.trimStart().startsWith('{\\rtf')) {
      blocks = parseRtfBlocks(rawText);
    } else {
      blocks = parseHtmlOrTextDocBlocks(rawText);
    }
  }

  // Also check if the filename itself hints at a specific question type (e.g. "Soal_Benar_Salah.docx")
  const fileNameTypeHint = detectQuestionTypeFromText(file.name);
  if (fileNameTypeHint && blocks.length > 0) {
    blocks.unshift({
      kind: 'paragraph',
      paragraph: {
        fullText: file.name.replace(/\.[^.]+$/, ''),
        hasRed: false,
        segments: [{ text: file.name, isRed: false }],
      },
    });
  }

/**
 * Multi-pass emergency recovery parser for extremely messy / chaotic / unformatted Word files
 * (e.g., all questions jammed into one paragraph, broken tables, missing question numbers,
 * bullet-only options, or raw Q&A prose) when the primary structured pass yields 0 or severely under-extracted questions.
 */
function rescueQuestionsFromMessyBlocks(
  blocks: DocumentBlock[],
  defaultQuestionType: QuestionType,
  startingNumber: number,
  defaultCategory: string
): Question[] {
  // Pass R1: Flatten ALL blocks (including every table cell & nested table) into raw paragraphs,
  // aggressively split inline run-on questions & inline options, and run buildQuestionsFromBlocks again.
  const flatParagraphs: ParsedParagraph[] = [];

  const collectTableCellsAsParagraphs = (tbl: ParsedTable) => {
    for (const row of tbl.rows) {
      // If a row is [No | Text], combine so numbering stays attached
      if (
        row.length >= 2 &&
        /^\d{1,3}[\.\)\-:]?$/.test(row[0].fullText.trim()) &&
        row[1].fullText.trim()
      ) {
        const num = row[0].fullText.trim().replace(/[^\d]/g, '');
        const restCells = row.slice(1);
        let attached = false;
        for (const c of restCells) {
          for (const p of c.paragraphs) {
            const clean = sanitizeParsedParagraph(p);
            if (!clean.fullText && !(clean.images?.length)) continue;
            if (!attached && clean.fullText && !/^\d{1,3}[\.\)\-:]/.test(clean.fullText)) {
              flatParagraphs.push({
                ...clean,
                fullText: `${num}. ${clean.fullText}`,
                segments: [{ text: `${num}. `, isRed: false }, ...clean.segments],
              });
              attached = true;
            } else {
              flatParagraphs.push(clean);
            }
          }
          for (const nt of c.nestedTables) collectTableCellsAsParagraphs(nt);
        }
        continue;
      }

      for (const cell of row) {
        for (const p of cell.paragraphs) {
          const clean = sanitizeParsedParagraph(p);
          if (clean.fullText || clean.images?.length) {
            flatParagraphs.push(clean);
          }
        }
        for (const nt of cell.nestedTables) {
          collectTableCellsAsParagraphs(nt);
        }
      }
    }
  };

  for (const b of blocks) {
    if (b.kind === 'paragraph') {
      const clean = sanitizeParsedParagraph(b.paragraph);
      if (clean.fullText || clean.images?.length) {
        flatParagraphs.push(clean);
      }
    } else {
      collectTableCellsAsParagraphs(b.table);
    }
  }

  // Aggressively split any giant merged paragraph on inline "1. ... 2. ..." or "Soal 1 ... Soal 2 ..." boundaries
  const aggressiveBlocks: DocumentBlock[] = [];
  for (const para of flatParagraphs) {
    const raw = para.fullText;
    // Try splitting on explicit "Soal 1", "No. 2", or inline " 2. " after "?" / "..." / option text
    const parts = raw
      .split(
        /(?<=[?…\.!\)])\s+(?=(?:(?:soal|pertanyaan)\s*(?:no\.?|nomor)?\s*|no\.?\s*)?\d{1,3}\s*[\.\):]\s*[A-Za-z"'(“])/gi
      )
      .map((s) => s.trim())
      .filter(Boolean);

    if (parts.length > 1) {
      parts.forEach((pt, idx) => {
        const subPara: ParsedParagraph = {
          fullText: pt,
          hasRed: para.hasRed,
          hasBold: para.hasBold,
          hasUnderline: para.hasUnderline,
          hasHighlight: para.hasHighlight,
          isAllBold: para.isAllBold,
          segments: [{ text: pt, isRed: para.hasRed, isBold: para.isAllBold, isUnderline: para.hasUnderline, isHighlight: para.hasHighlight }],
          images: idx === 0 ? para.images : undefined,
        };
        splitInlineOptionsIfPresent(subPara).forEach((sp) =>
          aggressiveBlocks.push({ kind: 'paragraph', paragraph: sp })
        );
      });
    } else {
      splitInlineOptionsIfPresent(para).forEach((sp) =>
        aggressiveBlocks.push({ kind: 'paragraph', paragraph: sp })
      );
    }
  }

  const r1Questions = buildQuestionsFromBlocks(
    aggressiveBlocks,
    defaultQuestionType,
    startingNumber,
    defaultCategory
  );
  if (r1Questions.length >= 2) {
    return r1Questions;
  }

  // Pass R2: Unstructured Q&A / Bullet-Option / Free-form Prompt Recovery
  // Handles messy docs that have NO numbering and NO A..E prefixes (just prompt + bullet choices OR prompt + Jawaban:)
  const nowTs = Date.now();
  const r2Questions: Question[] = [];
  const cleanParas = aggressiveBlocks
    .filter((b): b is { kind: 'paragraph'; paragraph: ParsedParagraph } => b.kind === 'paragraph')
    .map((b) => b.paragraph)
    .filter((p) => {
      const t = p.fullText.trim();
      if (!t && !(p.images?.length)) return false;
      if (
        t.length < 100 &&
        /^(?:mata\s+pelajaran|mapel|kelas|semester|tahun\s+ajaran|waktu|nama|petunjuk|ujian|penilaian|sumatif|ulangan|kumpulan\s+soal|bank\s+soal|latihan\s+soal)/i.test(
          t
        )
      ) {
        return false;
      }
      return true;
    });

  const isBulletLine = (t: string) => /^[•\-\*▪▫◦○●□☐☑✓✔>]\s+/.test(t);
  const looksLikePrompt = (t: string) =>
    /[?]$/.test(t) ||
    /\.{3,}|_{3,}|…$/.test(t) ||
    /^(?:apa|siapa|kapan|dimana|di\s+mana|mengapa|kenapa|bagaimana|berapa|jelaskan|sebutkan|tuliskan|hitunglah|tentukan|analisislah|uraikan|bandingkan|perhatikan|berdasarkan|manakah|berikut\s+ini|soal|pertanyaan|tanya)\b/i.test(
      t
    );

  let idx = 0;
  while (idx < cleanParas.length) {
    const cur = cleanParas[idx];
    const t = cur.fullText.trim();
    if (!t) {
      idx++;
      continue;
    }

    // Check if followed by 2..5 bullet lines -> Pilihan Ganda!
    if (!isBulletLine(t) && idx + 2 < cleanParas.length && isBulletLine(cleanParas[idx + 1].fullText.trim())) {
      const bulletChoices: ParsedParagraph[] = [];
      let j = idx + 1;
      while (j < cleanParas.length && isBulletLine(cleanParas[j].fullText.trim()) && bulletChoices.length < 6) {
        bulletChoices.push(cleanParas[j]);
        j++;
      }
      if (bulletChoices.length >= 2) {
        const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
        const opts: OptionItem[] = [];
        const markedIds: string[] = [];
        bulletChoices.forEach((bp, bIdx) => {
          const letter = letters[bIdx] || String.fromCharCode(65 + bIdx);
          const stripped = bp.fullText.trim().replace(/^[•\-\*▪▫◦○●□☐☑✓✔>]\s+/, '').trim();
          const { cleanedText, isMarkedCorrect } = extractTrailingCorrectMarker(stripped);
          if (bp.hasRed || isMarkedCorrect || bp.hasHighlight || bp.hasUnderline) {
            markedIds.push(letter);
          }
          opts.push({
            id: letter,
            text: cleanedText || stripped,
            ...(bp.images?.length ? { images: bp.images } : {}),
          });
        });

        // Check optional trailing Kunci: line
        let explicitKeyStr = '';
        if (j < cleanParas.length && EXPLICIT_KEY_LINE_REGEX.test(cleanParas[j].fullText.trim())) {
          explicitKeyStr = cleanParas[j].fullText.trim().match(EXPLICIT_KEY_LINE_REGEX)?.[1]?.trim() || '';
          j++;
        }

        let correctIds = markedIds;
        if (correctIds.length === 0 && explicitKeyStr) {
          const letterKeys = explicitKeyStr.toUpperCase().match(/\b[A-F]\b/g);
          if (letterKeys && letterKeys.length > 0) {
            correctIds = letterKeys;
          } else {
            const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
            const matched = opts.find((o) => norm(o.text) === norm(explicitKeyStr) || norm(o.text).includes(norm(explicitKeyStr)));
            if (matched) correctIds = [matched.id];
          }
        }
        const isComplex = correctIds.length > 1;
        const qNum = startingNumber + r2Questions.length;
        const cleanPrompt = t.replace(/^(?:(?:soal|pertanyaan|tanya)\s*(?:no\.?)?\s*\d*\s*[:\.\-]\s*|\d{1,3}\s*[\.\)\-:]\s*)/i, '').trim();
        r2Questions.push({
          id: `word_q_${nowTs}_r_${r2Questions.length}`,
          number: qNum,
          type: isComplex ? 'pilihan_ganda_kompleks' : 'pilihan_ganda',
          category: defaultCategory,
          questionText: cleanPrompt || t,
          questionImages: cur.images,
          instructionText: isComplex
            ? 'Pilihlah lebih dari satu jawaban yang benar!'
            : 'Pilih satu jawaban yang paling tepat!',
          options: opts,
          ...(isComplex
            ? { correctOptionIds: correctIds }
            : { correctOptionId: correctIds[0] || 'A' }),
          points: 10,
          explanation:
            correctIds.length > 0
              ? `Kunci jawaban yang benar: ${correctIds.join(', ')}.`
              : 'Kunci jawaban yang benar (default opsi A) adalah opsi A.',
        });
        idx = j;
        continue;
      }
    }

    // Check Q&A pair or standalone question prompt -> Isian Singkat
    const nextPara = cleanParas[idx + 1];
    const nextIsKey = Boolean(
      nextPara && EXPLICIT_KEY_LINE_REGEX.test(nextPara.fullText.trim())
    );
    if (nextIsKey || (looksLikePrompt(t) && t.length >= 12)) {
      const cleanPrompt = t
        .replace(/^(?:(?:soal|pertanyaan|tanya)\s*(?:no\.?)?\s*\d*\s*[:\.\-]\s*|\d{1,3}\s*[\.\)\-:]\s*)/i, '')
        .trim();
      let shortAnswers: string[] = [];
      if (nextIsKey && nextPara) {
        const rawAns = nextPara.fullText.trim().match(EXPLICIT_KEY_LINE_REGEX)?.[1]?.trim() || '';
        shortAnswers = rawAns
          .split(/\s*[\/|;]\s*/)
          .map((s) => s.trim())
          .filter(Boolean);
        idx += 2;
      } else {
        idx += 1;
      }
      if (shortAnswers.length === 0) {
        shortAnswers = ['Sesuai Kunci Guru'];
      }
      const qNum = startingNumber + r2Questions.length;
      r2Questions.push({
        id: `word_q_${nowTs}_r_${r2Questions.length}`,
        number: qNum,
        type: 'isian_singkat',
        category: defaultCategory,
        questionText: cleanPrompt || t,
        questionImages: cur.images,
        instructionText:
          'Ketiklah jawaban singkat atau uraian dengan tepat pada kolom yang tersedia!',
        correctShortAnswers: shortAnswers,
        placeholder: 'Ketik jawaban Anda di sini...',
        points: 10,
        explanation: `Kunci jawaban: ${shortAnswers.join(' / ')}.`,
      });
      continue;
    }

    idx++;
  }

  if (r2Questions.length > r1Questions.length) {
    return r2Questions;
  }
  return r1Questions;
}

  let questions = buildQuestionsFromBlocks(
    blocks,
    defaultQuestionType,
    startingNumber,
    defaultCategory
  );

  // If the file format was too messy and yielded 0 questions (or collapsed a huge multi-question file into 1 bloated item),
  // automatically run the multi-pass messy-document rescue engine and keep whichever pass recovered more questions!
  const looksCollapsedMessyDoc =
    questions.length === 0 ||
    (questions.length === 1 &&
      (questions[0].questionText.length > 500 ||
        (blocks.length >= 8 &&
          questions[0].type === 'isian_singkat' &&
          !questions[0].stimulusTable)));

  if (looksCollapsedMessyDoc && blocks.length > 0) {
    const rescued = rescueQuestionsFromMessyBlocks(
      blocks,
      defaultQuestionType,
      startingNumber,
      defaultCategory
    );
    if (rescued.length > questions.length) {
      questions = rescued;
    }
  }

  const redDetectedCount = questions.filter((q) => {
    if (q.explanation.includes('default opsi A')) return false;
    if (
      q.type === 'isian_singkat' &&
      (!q.correctShortAnswers ||
        q.correctShortAnswers.length === 0 ||
        q.correctShortAnswers.every((a) => a === 'Sesuai Kunci Guru'))
    ) {
      return false;
    }
    return true;
  }).length;

  const tableCount = questions.filter((q) => Boolean(q.stimulusTable)).length;
  const imageCount = countTotalQuestionImages(questions);

  const typeBreakdown: Record<string, number> = {};
  questions.forEach((q) => {
    typeBreakdown[q.type] = (typeBreakdown[q.type] || 0) + 1;
  });

  return { questions, redDetectedCount, tableCount, imageCount, typeBreakdown };
}

/**
 * Computes CRC-32 for building a valid .docx ZIP archive in memory.
 */
function crc32(data: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

/**
 * Builds an uncompressed ZIP archive (Uint8Array) from a map of filenames -> UTF-8 string content.
 */
function createUncompressedZip(files: Record<string, string>): Uint8Array {
  const encoder = new TextEncoder();
  const entries = Object.entries(files).map(([name, content]) => {
    const nameBytes = encoder.encode(name);
    const dataBytes = encoder.encode(content);
    const crc = crc32(dataBytes);
    return { nameBytes, dataBytes, crc };
  });

  const localHeaders: Uint8Array[] = [];
  const centralHeaders: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const { nameBytes, dataBytes, crc } = entry;
    const localHeader = new Uint8Array(30 + nameBytes.length + dataBytes.length);
    const lv = new DataView(localHeader.buffer);

    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0, true);
    lv.setUint16(8, 0, true);
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, dataBytes.length, true);
    lv.setUint32(22, dataBytes.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);
    localHeader.set(dataBytes, 30 + nameBytes.length);
    localHeaders.push(localHeader);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, dataBytes.length, true);
    cv.setUint32(24, dataBytes.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);
    centralHeaders.push(centralHeader);

    offset += localHeader.length;
  }

  const cdSize = centralHeaders.reduce((acc, c) => acc + c.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, cdSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + cdSize + eocd.length;
  const output = new Uint8Array(totalSize);
  let pos = 0;
  for (const lh of localHeaders) {
    output.set(lh, pos);
    pos += lh.length;
  }
  for (const ch of centralHeaders) {
    output.set(ch, pos);
    pos += ch.length;
  }
  output.set(eocd, pos);
  return output;
}

/**
 * Generates and downloads a ready-to-use .docx template file demonstrating ALL 5 CBT question types
 * (Pilihan Ganda, PG + Tabel, PG Kompleks, Benar/Salah, Menjodohkan, and Isian Singkat + Stimulus).
 */
export function downloadWordQuestionTemplate(subjectTitle: string = 'Mata Pelajaran'): void {
  const cleanSubject = subjectTitle
    .replace(/^Simulasi TKA\s*-\s*/i, '')
    .replace(/\s*\(SMA\/MA\/SMK\)/i, '')
    .trim();

  const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`;

  const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const makePara = (text: string, isRed: boolean = false, isBold: boolean = false) => {
    const escaped = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    const rPrParts: string[] = [];
    if (isBold) rPrParts.push('<w:b/>');
    if (isRed) rPrParts.push('<w:color w:val="FF0000"/>');
    const rPrXml = rPrParts.length > 0 ? `<w:rPr>${rPrParts.join('')}</w:rPr>` : '';
    return `<w:p><w:r>${rPrXml}<w:t xml:space="preserve">${escaped}</w:t></w:r></w:p>`;
  };

  const makeTableXml = (headers: string[], rows: string[][]) => {
    const makeRow = (cells: string[], isHeader: boolean) =>
      `<w:tr>${cells
        .map((c) => `<w:tc>${makePara(c, false, isHeader)}</w:tc>`)
        .join('')}</w:tr>`;
    return `<w:tbl>${makeRow(headers, true)}${rows.map((r) => makeRow(r, false)).join('')}</w:tbl>`;
  };

  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${makePara(`TEMPLATE BANK SOAL WORD CBT — ${cleanSubject.toUpperCase()}`, false, true)}
    ${makePara('Petunjuk: Tandai jawaban benar dengan warna merah (atau highlight/bold/garis bawah/tuliskan baris Kunci:). Semua 5 tipe soal otomatis terbaca saat diunggah.')}
    ${makePara('')}
    ${makePara(`1. [PG] Organel sel yang berfungsi sebagai tempat berlangsungnya respirasi seluler untuk menghasilkan energi (ATP) pada mata pelajaran ${cleanSubject} adalah...`, false, true)}
    ${makePara('A. Ribosom')}
    ${makePara('B. Mitokondria', true)}
    ${makePara('C. Lisosom')}
    ${makePara('D. Badan Golgi')}
    ${makePara('E. Retikulum Endoplasma')}
    ${makePara('')}
    ${makePara('2. [PG] Perhatikan tabel hasil pengamatan kerja enzim katalase berikut!', false, true)}
    ${makeTableXml(
      ['No', 'Perlakuan Suhu / pH', 'Gelembung Gas', 'Nyala Bara Api'],
      [
        ['1', 'Ekstrak Hati + H2O2 (Suhu 37°C, pH 7)', '+++ (Banyak)', 'Menyala Terang'],
        ['2', 'Ekstrak Hati + H2O2 (Suhu 60°C, pH 7)', '- (Tidak Ada)', 'Padam'],
        ['3', 'Ekstrak Hati + H2O2 (Suhu 37°C, pH 2)', '+ (Sedikit)', 'Redup']
      ]
    )}
    ${makePara('Berdasarkan tabel di atas, enzim katalase bekerja secara optimal pada kondisi...')}
    ${makePara('A. Suhu 37°C dan pH netral (7)', true)}
    ${makePara('B. Suhu tinggi 60°C dan pH netral (7)')}
    ${makePara('C. Suhu 37°C dan suasana asam (pH 2)')}
    ${makePara('D. Semua kondisi suhu dan derajat keasaman')}
    ${makePara('E. Suhu di atas 60°C tanpa H2O2')}
    ${makePara('')}
    ${makePara('3. [PGK] Pilihlah lebih dari satu pernyataan yang BENAR mengenai sifat-sifat enzim berikut!', false, true)}
    ${makePara('A. Bekerja secara spesifik pada substrat tertentu', true)}
    ${makePara('B. Tidak ikut bereaksi dan dapat digunakan kembali', true)}
    ${makePara('C. Hanya dapat bekerja pada suhu di atas 90°C')}
    ${makePara('D. Menurunkan energi aktivasi reaksi kimia', true)}
    ${makePara('E. Terdiri atas lemak murni tanpa komponen protein')}
    ${makePara('')}
    ${makePara('4. [BENAR/SALAH] Tentukan kebenaran setiap pernyataan berikut mengenai proses fotosintesis!', false, true)}
    ${makeTableXml(
      ['No', 'Pernyataan', 'Benar', 'Salah'],
      [
        ['1', 'Reaksi terang berlangsung di membran tilakoid (grana) kloroplas.', '✓', ''],
        ['2', 'Oksigen (O2) yang dihasilkan berasal dari pemecahan molekul CO2.', '', '✓'],
        ['3', 'Siklus Calvin (reaksi gelap) berlangsung di stroma kloroplas.', '✓', '']
      ]
    )}
    ${makePara('')}
    ${makePara('5. [MENJODOHKAN] Jodohkan organ pencernaan pada kolom kiri dengan enzim yang dihasilkannya pada kolom kanan!', false, true)}
    ${makeTableXml(
      ['Premis / Organ', 'Pasangan / Enzim'],
      [
        ['Mulut (kelenjar ludah)', 'Ptialin (Amilase ludah)'],
        ['Lambung', 'Pepsin dan Renin'],
        ['Pankreas', 'Tripsin dan Lipase']
      ]
    )}
    ${makePara('')}
    ${makePara('[STIMULUS: Metabolisme Sel]', false, true)}
    ${makePara('Respirasi aerob merupakan proses pemecahan glukosa secara sempurna menggunakan oksigen bebas. Tahapan pertamanya adalah glikolisis yang terjadi di sitoplasma dan mengubah 1 molekul glukosa menjadi 2 molekul asam piruvat.')}
    ${makePara('6. [ISIAN SINGKAT] Tuliskan nama tahapan pertama respirasi aerob yang berlangsung di sitoplasma dan menghasilkan asam piruvat!', false, true)}
    ${makePara('Kunci: Glikolisis / glikolisis', true, true)}
  </w:body>
</w:document>`;

  const zipBytes = createUncompressedZip({
    '[Content_Types].xml': contentTypesXml,
    '_rels/.rels': relsXml,
    'word/document.xml': documentXml,
  });

  const blob = new Blob([zipBytes as unknown as BlobPart], {
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const safeName = cleanSubject.replace(/[^a-zA-Z0-9_-]/g, '_') || 'Mapel';
  link.href = url;
  link.download = `Template_Soal_Word_${safeName}.docx`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Generates and downloads an archival .docx document containing ALL current questions in the selected exam package.
 * Uses explicit type tags, red answer markers, and clean tables so re-uploading the archive restores all 5 types with 100% fidelity.
 */
export function downloadWordQuestionArchive(
  pkg: { title: string; code?: string; questions: Question[] },
  filterType: string = 'Semua Tipe Soal'
): void {
  const cleanSubject = (pkg.title || 'Mata Pelajaran')
    .replace(/^Simulasi TKA\s*-\s*/i, '')
    .replace(/\s*\(SMA\/MA\/SMK\)/i, '')
    .trim();

  const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`;

  const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const makePara = (
    text: string,
    isRed: boolean = false,
    isBold: boolean = false,
    isItalic: boolean = false
  ) => {
    const escaped = (text || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    const rPrParts: string[] = [];
    if (isBold) rPrParts.push('<w:b/>');
    if (isItalic) rPrParts.push('<w:i/>');
    if (isRed) rPrParts.push('<w:color w:val="FF0000"/>');
    const rPrXml = rPrParts.length > 0 ? `<w:rPr>${rPrParts.join('')}</w:rPr>` : '';
    return `<w:p><w:r>${rPrXml}<w:t xml:space="preserve">${escaped}</w:t></w:r></w:p>`;
  };

  const makeTableXml = (headers: string[], rows: string[][]) => {
    const makeRow = (cells: string[], isHeader: boolean) =>
      `<w:tr>${cells
        .map((c) => `<w:tc>${makePara(c, false, isHeader)}</w:tc>`)
        .join('')}</w:tr>`;
    return `<w:tbl>${makeRow(headers, true)}${rows.map((r) => makeRow(r, false)).join('')}</w:tbl>`;
  };

  const TYPE_TAG_MAP: Record<QuestionType, string> = {
    pilihan_ganda: '[PG]',
    pilihan_ganda_kompleks: '[PGK]',
    benar_salah: '[BENAR/SALAH]',
    menjodohkan: '[MENJODOHKAN]',
    isian_singkat: '[ISIAN SINGKAT]',
  };

  const filteredQuestions = pkg.questions.filter((q) => {
    if (!filterType || filterType === 'Semua Tipe Soal') return true;
    return q.type === filterType;
  });

  const questionElements: string[] = [];

  // Header Title
  questionElements.push(
    makePara(
      `ARSIP BANK SOAL CBT: ${cleanSubject.toUpperCase()} (${pkg.code || 'SAS2026'})`,
      false,
      true
    )
  );
  questionElements.push(
    makePara(
      `Total Soal: ${filteredQuestions.length} Butir | Filter: ${filterType} | Tanggal Unduh: ${new Date().toLocaleDateString('id-ID')}`,
      false,
      false,
      true
    )
  );
  questionElements.push(makePara('------------------------------------------------------------'));

  filteredQuestions.forEach((q, idx) => {
    const qNum = idx + 1;
    const typeTag = TYPE_TAG_MAP[q.type] || '[PG]';

    // Stimulus (jika ada)
    if (q.stimulusTitle || q.stimulusText) {
      questionElements.push(
        makePara(
          `[STIMULUS: ${q.stimulusTitle || `Wacana Soal ${qNum}`}]`,
          false,
          true
        )
      );
      if (q.stimulusText) {
        const paras = q.stimulusText.split(/\n{2,}/);
        paras.forEach((p) => {
          const t = p.trim();
          if (t) questionElements.push(makePara(t));
        });
      }
    }

    // Nomor, Tag Tipe & Pertanyaan Soal
    questionElements.push(
      makePara(`${qNum}. ${typeTag} ${q.questionText || ''}`, false, true)
    );

    if (q.stimulusTable && q.stimulusTable.headers?.length > 0) {
      questionElements.push(
        makeTableXml(q.stimulusTable.headers, q.stimulusTable.rows || [])
      );
    }

    // Render Opsi Berdasarkan Tipe Soal
    if (q.type === 'pilihan_ganda' || q.type === 'pilihan_ganda_kompleks') {
      const opts = q.options || [];
      const correctOptionId = q.correctOptionId || '';
      const correctOptionIds = new Set(q.correctOptionIds || []);

      opts.forEach((opt) => {
        const isCorrect =
          q.type === 'pilihan_ganda'
            ? opt.id.toUpperCase() === correctOptionId.toUpperCase()
            : correctOptionIds.has(opt.id) ||
              correctOptionIds.has(opt.id.toUpperCase()) ||
              correctOptionIds.has(opt.id.toLowerCase());

        questionElements.push(
          makePara(`${opt.id}. ${opt.text}`, isCorrect, isCorrect)
        );
      });
    } else if (q.type === 'benar_salah') {
      const tLabel = q.trueLabel || 'Benar';
      const fLabel = q.falseLabel || 'Salah';
      const statements = q.statements || [];
      if (statements.length > 0) {
        questionElements.push(
          makeTableXml(
            ['No', 'Pernyataan', tLabel, fLabel],
            statements.map((st, sIdx) => {
              const isTrue = (st.correctValue || 'Benar') === 'Benar';
              return [
                String(sIdx + 1),
                st.statement,
                isTrue ? '✓' : '',
                isTrue ? '' : '✓',
              ];
            })
          )
        );
      }
    } else if (q.type === 'menjodohkan') {
      const pairs = q.correctPairs || {};
      const premises = q.premises || [];
      const responses = q.responses || [];
      const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

      const hasExtraDistractors = responses.length > premises.length;
      if (hasExtraDistractors && responses.length > 0) {
        const rowCount = Math.max(premises.length, responses.length);
        const respIdToLetter = new Map<string, string>();
        responses.forEach((r, rIdx) => {
          respIdToLetter.set(r.id, letters[rIdx] || String(rIdx + 1));
        });
        const tableRows: string[][] = [];
        for (let r = 0; r < rowCount; r++) {
          const pr = premises[r];
          const resp = responses[r];
          const keyLetter = pr ? respIdToLetter.get(pairs[pr.id] || '') || '' : '';
          tableRows.push([
            pr ? pr.text : '',
            resp ? letters[r] || String(r + 1) : '',
            resp ? resp.text : '',
            keyLetter,
          ]);
        }
        questionElements.push(
          makeTableXml(['Premis / Pernyataan', 'Kode', 'Pilihan Respon', 'Kunci'], tableRows)
        );
      } else if (premises.length > 0) {
        questionElements.push(
          makeTableXml(
            ['Premis / Pernyataan', 'Pasangan / Respon'],
            premises.map((pr) => {
              const targetRespId = pairs[pr.id];
              const matchedResp = responses.find((r) => r.id === targetRespId);
              return [pr.text, matchedResp ? matchedResp.text : targetRespId || '-'];
            })
          )
        );
      }
    } else if (q.type === 'isian_singkat') {
      const keys = q.correctShortAnswers || [];
      questionElements.push(
        makePara(
          `[Kunci Jawaban Singkat]: ${keys.join(' / ') || '(Tidak ditentukan)'}`,
          true,
          true
        )
      );
    }

    if (q.points && q.points !== 10) {
      questionElements.push(makePara(`Bobot: ${q.points}`, false, false, true));
    }

    if (q.explanation) {
      questionElements.push(
        makePara(`Pembahasan: ${q.explanation}`, false, false, true)
      );
    }

    questionElements.push(makePara('')); // Baris kosong antar soal
  });

  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${questionElements.join('\n    ')}
  </w:body>
</w:document>`;

  const zipBytes = createUncompressedZip({
    '[Content_Types].xml': contentTypesXml,
    '_rels/.rels': relsXml,
    'word/document.xml': documentXml,
  });

  const blob = new Blob([zipBytes as unknown as BlobPart], {
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const safeName = cleanSubject.replace(/[^a-zA-Z0-9_-]/g, '_') || 'Mapel';
  const filterSuffix = filterType && filterType !== 'Semua Tipe Soal' ? `_${filterType}` : '';
  link.href = url;
  link.download = `Arsip_Soal_${safeName}${filterSuffix}.docx`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
