import React, { useState, useMemo, useEffect } from 'react';
import {
  Eye,
  EyeOff,
  ShieldAlert,
  Lock,
  UserCog,
  ArrowLeft,
  Home,
  ClipboardList,
  User,
  ClipboardCheck,
  RotateCcw,
  UserCheck,
  Users,
  FileCheck2,
  ChevronsLeft,
  ChevronsRight,
  Search,
  RefreshCw,
  Plus,
  Trash2,
  LogOut,
  CheckCircle2,
  ArrowUpDown,
  KeyRound,
  BookOpen,
  Printer,
  Calendar,
  Clock,
  Settings,
  Save,
  ShieldCheck,
  Download,
  Sliders,
  GraduationCap,
  FolderTree,
  Layers,
  Upload,
  FileSpreadsheet,
  FileText,
  Archive,
  AlertCircle,
  Edit,
  X,
  Check,
  Image as ImageIcon,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { TutWuriLogo } from './PusmendikHeader';
import { QuestionImageGallery } from './QuestionImageGallery';
import { MathText } from './MathText';
import {
  AdminScheduleItem,
  ExamPackage,
  ExamResultSummary,
  Question,
  QuestionType,
} from '../types/cbt';
import {
  getQuestionTypeLabel,
  isDefaultSampleQuestion,
  stripDemoSampleIfUploadedPresent,
} from '../data/cbtData';
import {
  ProctorParticipantRow,
  DEFAULT_EXAM_ROOMS,
  resolveParticipantRuang,
  doesKelasMatch,
  getParticipantNameKelasKey,
  isDefaultDemoParticipantRow,
  isDefaultDemoParticipantsList,
  isParticipantLockedByViolation,
  isParticipantStatusActive,
  sanitizeParticipantRows,
  buildResetParticipantRowPatch,
} from './ProctorDashboardView';
import { generateProctorCardsPDF } from '../utils/pdfProctorCard';
import { generateParticipantCardsPDF } from '../utils/pdfParticipantCard';
import {
  generateExamReportPDF,
  resolveResultClass,
} from '../utils/pdfExamReport';
import {
  parseWordQuestions,
  downloadWordQuestionTemplate,
  downloadWordQuestionArchive,
} from '../utils/wordQuestionParser';
import {
  authenticateWithServer,
  saveVercelStorage,
} from '../utils/vercelStorage';

interface AdminLoginViewProps {
  onAdminLoginSuccess: (adminUsername: string) => void;
  onBackToStudentLogin: () => void;
  onGoToProctorLogin: () => void;
  adminSettings?: Record<string, any>;
  onRefreshAdminSettings?: () => Promise<Record<string, any> | null | undefined>;
}

const BUILTIN_DEFAULT_ADMINS = [
  {
    id: 'adm_1',
    adminId: 'K05060108-KB6K',
    namaLengkap: 'SHAHRUR ROBBY, S.Pd.',
    email: 'shahrurrobby17@gmail.com',
    status: 'Aktif',
    password: 'SAS2026',
  },
  {
    id: 'adm_2',
    adminId: 'ADMIN_SMADIP',
    namaLengkap: 'TIM TEKNIS CBT SMA ISLAM DIPONEGORO',
    email: 'admin.cbt@smadiponegorowagir.sch.id',
    status: 'Aktif',
    password: 'SAS2026',
  },
];

function resolveAdminAccountFromSettings(
  settingsObj: Record<string, any> | null | undefined,
  cleanInputUpper: string
): Record<string, any> | undefined {
  if (!cleanInputUpper) return undefined;

  let effectiveSettings: Record<string, any> | null =
    settingsObj && typeof settingsObj === 'object' ? settingsObj : null;
  if (!effectiveSettings) {
    try {
      const saved = localStorage.getItem('cbt_admin_settings');
      if (saved) {
        effectiveSettings = JSON.parse(saved);
      }
    } catch {
      // ignore storage error
    }
  }

  const storedList = Array.isArray(effectiveSettings?.adminList)
    ? (effectiveSettings!.adminList as Record<string, any>[])
    : [];
  const adminList =
    storedList.length > 0 ? storedList : BUILTIN_DEFAULT_ADMINS;

  // 1. Direct match by adminId, username, namaLengkap, or email in adminList
  const directMatch = adminList.find((adm) => {
    if (!adm || typeof adm !== 'object') return false;
    const uName = String(adm.username || '').trim().toUpperCase();
    const fullName = String(adm.namaLengkap || '').trim().toUpperCase();
    const aId = String(adm.adminId || '').trim().toUpperCase();
    const email = String(adm.email || '').trim().toUpperCase();
    return (
      (uName && uName === cleanInputUpper) ||
      (fullName && fullName === cleanInputUpper) ||
      (aId && aId === cleanInputUpper) ||
      (email && email === cleanInputUpper)
    );
  });
  if (directMatch) return directMatch;

  // 2. Legacy aliases resolve to primary admin record in adminList so status & password changes apply to aliases too
  const primaryAdminId =
    typeof effectiveSettings?.adminId === 'string' &&
    effectiveSettings.adminId.trim()
      ? effectiveSettings.adminId.trim().toUpperCase()
      : 'K05060108-KB6K';

  const validPrimaryUsernames = new Set([
    'SHAHRUR ROBBY, S.PD.',
    'SHAHRUR ROBBY, S.PD',
    'SHAHRUR ROBBY',
    'SHAHRUR',
    'ROBBY',
    'SHAHRURROBBY17',
    'SHAHRURROBBY17@GMAIL.COM',
    'ADMIN',
    'ADMINISTRATOR',
    'ADMIN_CBT',
    'ADMINCBT',
    'SMADIP',
    'SMADIPONEGORO',
    'K05060108',
    'K05060108-KB6K',
    primaryAdminId,
    typeof effectiveSettings?.adminUsername === 'string'
      ? effectiveSettings.adminUsername.trim().toUpperCase()
      : '',
    typeof effectiveSettings?.adminNama === 'string'
      ? effectiveSettings.adminNama.trim().toUpperCase()
      : '',
  ]);

  if (validPrimaryUsernames.has(cleanInputUpper)) {
    return (
      adminList.find(
        (adm) =>
          String(adm?.adminId || '').trim().toUpperCase() === primaryAdminId ||
          adm?.id === 'adm_1'
      ) ||
      (storedList.length === 0 ? BUILTIN_DEFAULT_ADMINS[0] : undefined)
    );
  }

  // 3. Technical admin aliases resolve to ADMIN_SMADIP entry in adminList
  const validTechUsernames = new Set([
    'TIM_TEKNIS',
    'TIM TEKNIS',
    'ADMIN_TEKNIS',
    'ADMIN_SMADIP',
    'ADMINSMADIP',
    'TIM TEKNIS CBT SMA ISLAM DIPONEGORO',
  ]);

  if (validTechUsernames.has(cleanInputUpper)) {
    return (
      adminList.find(
        (adm) =>
          String(adm?.adminId || '').trim().toUpperCase() === 'ADMIN_SMADIP' ||
          adm?.id === 'adm_2'
      ) ||
      (storedList.length === 0 ? BUILTIN_DEFAULT_ADMINS[1] : undefined)
    );
  }

  return undefined;
}

export const AdminLoginView: React.FC<AdminLoginViewProps> = ({
  onAdminLoginSuccess,
  onBackToStudentLogin,
  onGoToProctorLogin,
  adminSettings,
}) => {
  const [usernameInput, setUsernameInput] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isCheckingLogin, setIsCheckingLogin] = useState(false);

  // Resolve ID Administrator secara otomatis ketika Username dimasukkan dengan benar
  const resolvedAdminAccount = useMemo(() => {
    const clean = usernameInput.trim().toUpperCase();
    return resolveAdminAccountFromSettings(adminSettings, clean);
  }, [usernameInput, adminSettings]);

  const resolvedAdminId = resolvedAdminAccount?.adminId
    ? String(resolvedAdminAccount.adminId).trim().toUpperCase()
    : '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isCheckingLogin) return;
    const cleanUsername = usernameInput.trim();
    const cleanUpper = cleanUsername.toUpperCase();
    const cleanPass = password.trim();

    if (!cleanUsername) {
      setErrorMsg('Username Administrator wajib diisi terlebih dahulu.');
      return;
    }

    if (!cleanPass) {
      setErrorMsg('Password wajib diisi.');
      return;
    }

    const matchedAccount = resolveAdminAccountFromSettings(adminSettings, cleanUpper);
    let serverAuthPassed = false;
    let serverAdminId = '';

    setIsCheckingLogin(true);
    try {
      const authRes = await authenticateWithServer({
        role: 'admin',
        username: cleanUpper,
        password: cleanPass,
      });
      if (authRes.ok) {
        serverAuthPassed = true;
        serverAdminId = String(
          authRes.account?.adminId || matchedAccount?.adminId || cleanUpper
        )
          .trim()
          .toUpperCase();
      } else if (authRes.networkError) {
        setErrorMsg(
          'Gagal terhubung ke server CBT untuk verifikasi sesi Administrator. Periksa koneksi internet lalu coba login kembali.'
        );
        return;
      } else {
        setErrorMsg(
          authRes.error ||
            'Login Administrator ditolak. Periksa Username, Password, dan status akun Anda.'
        );
        return;
      }
    } finally {
      setIsCheckingLogin(false);
    }

    if (!serverAuthPassed) {
      setErrorMsg(
        'Verifikasi sesi Administrator ke server gagal. Silakan coba login kembali.'
      );
      return;
    }

    setErrorMsg('');

    onAdminLoginSuccess(
      String(serverAdminId || matchedAccount?.adminId || cleanUpper)
        .trim()
        .toUpperCase()
    );
  };

  return (
    <main className="flex-1 flex flex-col items-center justify-center px-4 py-10 min-h-[calc(100vh-10rem)]">
      <div className="w-full max-w-[440px] bg-white rounded-[14px] px-9 sm:px-11 py-10 shadow-[0_24px_60px_-12px_rgba(15,23,42,0.16)] border border-slate-100/80 animate-cbt-slide-up">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-[18px] font-bold text-[#1e293b] tracking-tight">
            Login Administrator
          </h1>
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#0066ff]">
            <ShieldAlert className="w-4 h-4" />
            <span>Admin Server</span>
          </span>
        </div>

        <p className="mt-1.5 text-[13.5px] leading-[1.55] text-[#475569]">
          Masukkan Username dan kata sandi Anda untuk mengakses dashboard pengelolaan ujian.
        </p>

        {errorMsg && (
          <div className="mt-4 px-3.5 py-2.5 rounded-lg bg-rose-50 border border-rose-200 text-xs font-medium text-rose-700">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-7 space-y-5">
          {/* Username Administrator */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-600">
              Username
            </label>
            <div className="flex items-center gap-3 px-3.5 py-2.5 rounded-lg border border-slate-200 focus-within:border-[#0066ff] bg-slate-50/50">
              <User className="w-4 h-4 text-slate-500 shrink-0" />
              <input
                type="text"
                value={usernameInput}
                onChange={(e) => {
                  setUsernameInput(e.target.value);
                  if (errorMsg) setErrorMsg('');
                }}
                placeholder="Masukkan Username"
                aria-label="Username Administrator"
                autoComplete="off"
                className="w-full text-sm text-slate-800 placeholder:text-slate-400 bg-transparent focus:outline-none"
              />
            </div>
          </div>

          {/* ID Administrator (Muncul Otomatis & Tidak Bisa Diedit) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-slate-600">
                ID Administrator
              </label>
              <span className="text-[11px] font-medium text-slate-400">
                Otomatis (Terkunci)
              </span>
            </div>
            <div
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg border transition-colors ${
                resolvedAdminId
                  ? 'border-emerald-300 bg-emerald-50/60'
                  : 'border-slate-200 bg-slate-100/80'
              }`}
            >
              <UserCog
                className={`w-4 h-4 shrink-0 ${
                  resolvedAdminId ? 'text-emerald-600' : 'text-slate-400'
                }`}
              />
              <input
                type="text"
                value={resolvedAdminId}
                readOnly
                disabled
                tabIndex={-1}
                placeholder="Muncul otomatis saat Username benar"
                aria-label="ID Administrator"
                className={`w-full text-sm font-mono font-bold bg-transparent focus:outline-none cursor-not-allowed select-none ${
                  resolvedAdminId
                    ? 'text-slate-900'
                    : 'text-slate-400 placeholder:font-sans placeholder:font-normal placeholder:text-slate-400'
                }`}
              />
              {resolvedAdminId && (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              )}
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-600">
              Password
            </label>
            <div className="relative flex items-center gap-3 px-3.5 py-2.5 rounded-lg border border-slate-200 focus-within:border-[#0066ff] bg-slate-50/50">
              <Lock className="w-4 h-4 text-slate-500 shrink-0" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Masukkan password"
                aria-label="Password"
                className="w-full pr-7 text-sm text-slate-800 placeholder:text-slate-400 bg-transparent focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="absolute right-3 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                aria-label={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 space-y-2.5">
            <button
              type="submit"
              disabled={isCheckingLogin}
              className="w-full py-2.5 px-6 rounded-lg bg-[#0088ff] hover:bg-[#006fd6] active:scale-[0.99] text-white text-[14px] font-semibold shadow-[0_6px_16px_rgba(0,136,255,0.28)] transition-all cursor-pointer disabled:opacity-70"
            >
              {isCheckingLogin ? 'Memeriksa Akun...' : 'Sign-In Administrator'}
            </button>

            <button
              type="button"
              onClick={onGoToProctorLogin}
              className="w-full py-2 px-4 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              Beralih ke Login Proktor
            </button>

            <button
              type="button"
              onClick={onBackToStudentLogin}
              className="w-full py-2 px-4 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Kembali ke Halaman Login Peserta</span>
            </button>
          </div>
        </form>
      </div>
    </main>
  );
};

const KELAS_OPTIONS = ['X', 'XI IPA', 'XI IPS', 'XII IPA', 'XII IPS'] as const;

export const INITIAL_ADMIN_PARTICIPANTS: ProctorParticipantRow[] = [
  {
    id: 'ap1',
    selected: false,
    status: 'Non Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20264821',
    password: 'SMADIP1547*',
    namaPeserta: 'ANDRIAN FAJARICO PRASETYA',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'X',
    loginState: 'Belum Login',
    requestReset: false,
  },
  {
    id: 'ap2',
    selected: false,
    status: 'Non Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20267394',
    password: 'SMADIP1556*',
    namaPeserta: 'AHMAD RIZKI NOVANSYAH',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'XI IPA',
    loginState: 'Belum Login',
    requestReset: false,
  },
  {
    id: 'ap3',
    selected: false,
    status: 'Non Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20262918',
    password: 'SMADIP1565*',
    namaPeserta: 'ARYA RESTU KUSUMA',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'XI IPS',
    loginState: 'Belum Login',
    requestReset: false,
  },
  {
    id: 'ap4',
    selected: false,
    status: 'Non Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20268563',
    password: 'SMADIP1574*',
    namaPeserta: 'AUREL RIZKY ADI PRATAMA',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'XII IPA',
    loginState: 'Belum Login',
    requestReset: false,
  },
  {
    id: 'ap5',
    selected: false,
    status: 'Non Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20265147',
    password: 'SMADIP1583*',
    namaPeserta: 'AHMAD DENY FIKRUDIN',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'XII IPS',
    loginState: 'Belum Login',
    requestReset: false,
  },
  {
    id: 'ap6',
    selected: false,
    status: 'Non Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20269302',
    password: 'SMADIP1592*',
    namaPeserta: 'ALDISA FRANDIKA LIAN PRATAMA',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'X',
    loginState: 'Belum Login',
    requestReset: false,
  },
  {
    id: 'p7',
    selected: false,
    status: 'Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20266475',
    password: 'ANBKTKA26*',
    namaPeserta: 'NADIA PUTRI PRATAMA',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'XI IPA',
    loginState: 'Belum Login',
    requestReset: false,
  },
  {
    id: 'p8',
    selected: false,
    status: 'Active',
    kodeTes: 'SAS26SMADIP1',
    username: 'SA20261839',
    password: 'SAINSTKA*',
    namaPeserta: 'BAGAS ADITYA NUGRAHA',
    kelompok: 'Ruang 1',
    ruang: 'Ruang 1',
    kelas: 'XII IPA',
    loginState: 'Belum Login',
    requestReset: false,
  },
];

export interface AdminProctorItem {
  id: string;
  proctorId: string;
  fullName: string;
  roomName: string;
  rombel: string;
  encryptionCode: string;
  password: string;
  status: 'Active' | 'Non Active';
}

export const INITIAL_ADMIN_PROCTORS: AdminProctorItem[] = [
  {
    id: 'pr1',
    proctorId: 'K05060108-KB6K',
    fullName: 'DRS. H. AHMAD FAUZI, M.PD.',
    roomName: 'LAB KOMPUTER 1 (UTAMA)',
    rombel: 'Kelas X & XI IPA',
    encryptionCode: 'GLDTKASMA',
    password: 'SMADIP2026*',
    status: 'Active',
  },
  {
    id: 'pr2',
    proctorId: 'K05060108-KB7L',
    fullName: 'SITI NURHALIZA, S.KOM.',
    roomName: 'LAB KOMPUTER 2',
    rombel: 'Kelas XI IPS & XII IPA',
    encryptionCode: 'ENC-8842-WGR',
    password: 'PROKTOR02*',
    status: 'Active',
  },
  {
    id: 'pr3',
    proctorId: 'K05060108-KB8M',
    fullName: 'MOCHAMAD RIZALDI, S.PD.',
    roomName: 'LAB MULTIMEDIA 3',
    rombel: 'Kelas XII IPS',
    encryptionCode: 'ENC-9910-WGR',
    password: 'PROKTOR03*',
    status: 'Non Active',
  },
];

export const INITIAL_ADMIN_SCHEDULES: AdminScheduleItem[] = [
  {
    id: 'sch1',
    hariTanggal: 'Senin, 07 Desember 2026',
    kelas: 'X',
    mapel: 'Bahasa Indonesia & Literasi Membaca',
    waktuMulai: '07:30 WIB',
    durasi: '90 Menit',
    isActive: false,
  },
  {
    id: 'sch2',
    hariTanggal: 'Senin, 07 Desember 2026',
    kelas: 'XI IPA',
    mapel: 'Matematika & Fisika Dasar',
    waktuMulai: '07:30 WIB',
    durasi: '120 Menit',
    isActive: false,
  },
  {
    id: 'sch3',
    hariTanggal: 'Selasa, 08 Desember 2026',
    kelas: 'XI IPS',
    mapel: 'Ekonomi & Sosiologi',
    waktuMulai: '07:30 WIB',
    durasi: '90 Menit',
    isActive: false,
  },
  {
    id: 'sch4',
    hariTanggal: 'Rabu, 09 Desember 2026',
    kelas: 'XII IPA',
    mapel: 'Biologi & Kimia Terapan',
    waktuMulai: '09:30 WIB',
    durasi: '120 Menit',
    isActive: false,
  },
  {
    id: 'sch5',
    hariTanggal: 'Kamis, 10 Desember 2026',
    kelas: 'XII IPS',
    mapel: 'Geografi & Sejarah Indonesia',
    waktuMulai: '09:30 WIB',
    durasi: '90 Menit',
    isActive: false,
  },
];

type AdminSidebarMenuId =
  | 'beranda'
  | 'daftar_proktor'
  | 'status_peserta'
  | 'daftar_peserta'
  | 'jadwal'
  | 'status_tes'
  | 'request_reset'
  | 'daftar_login'
  | 'kelompok_tes'
  | 'laporan_pengolahan'
  | 'pengaturan';

interface AdminDashboardViewProps {
  adminUsername: string;
  activeToken: string;
  tokenSecondsLeft: number;
  tokenDurationSeconds?: number;
  onUpdateToken: (newToken: string) => void;
  schedules: AdminScheduleItem[];
  onUpdateSchedules: (nextSchedules: AdminScheduleItem[]) => void;
  participants?: ProctorParticipantRow[];
  onUpdateParticipants?: React.Dispatch<
    React.SetStateAction<ProctorParticipantRow[]>
  >;
  proctors?: AdminProctorItem[];
  onUpdateProctors?: React.Dispatch<React.SetStateAction<AdminProctorItem[]>>;
  packages: ExamPackage[];
  onUpdatePackages: (
    updater:
      | ExamPackage[]
      | ((prevPackages: ExamPackage[]) => ExamPackage[])
  ) => void;
  onResetDefaultPackages: () => void;
  resultsHistory: ExamResultSummary[];
  onClearHistory: () => void;
  adminSettings?: Record<string, any>;
  onUpdateAdminSettings?: (nextCfg: Record<string, any>) => void;
  storageEngine?: 'vercel-kv' | 'vercel-serverless' | 'local';
  ephemeralStorageWarning?: boolean;
  lastSyncedLabel?: string;
  onForceSyncStorage?: () => void;
  onPullStorage?: (
    targetUrl?: string,
    sourceToken?: string
  ) => Promise<{ ok: boolean; message: string }>;
  onLogoutAdmin: () => void;
}

export const STATUS_TES_CLASS_GROUPS = [
  'Kelas X',
  'Kelas XI IPA',
  'Kelas XI IPS',
  'Kelas XII IPA',
  'Kelas XII IPS',
] as const;

export function getTargetClassFromMapel(mapel?: {
  tingkat?: string | number | null;
  kategori?: string | number | null;
  nama?: string | number | null;
  kode?: string | number | null;
} | null): string {
  if (!mapel || typeof mapel !== 'object') return 'Kelas X';
  const rawTingkat = String(mapel.tingkat ?? '').trim();
  const tingkatUpper = rawTingkat.toUpperCase();
  const katUpper = String(mapel.kategori ?? '').toUpperCase();
  const namaUpper = String(mapel.nama ?? '').toUpperCase();
  const kodeUpper = String(mapel.kode ?? '').toUpperCase();

  if (tingkatUpper === 'KELAS XII IPA' || tingkatUpper === 'XII IPA' || tingkatUpper === 'XII-IPA') {
    return 'Kelas XII IPA';
  }
  if (tingkatUpper === 'KELAS XII IPS' || tingkatUpper === 'XII IPS' || tingkatUpper === 'XII-IPS') {
    return 'Kelas XII IPS';
  }
  if (tingkatUpper === 'KELAS XI IPA' || tingkatUpper === 'XI IPA' || tingkatUpper === 'XI-IPA') {
    return 'Kelas XI IPA';
  }
  if (tingkatUpper === 'KELAS XI IPS' || tingkatUpper === 'XI IPS' || tingkatUpper === 'XI-IPS') {
    return 'Kelas XI IPS';
  }
  if (
    tingkatUpper === 'KELAS X' ||
    tingkatUpper === 'X' ||
    tingkatUpper === 'X-1' ||
    tingkatUpper === 'X-2' ||
    tingkatUpper === 'KELAS X (FASE E)'
  ) {
    return 'Kelas X';
  }

  const isGenericMultiLevel =
    tingkatUpper.includes('SEMUA') || tingkatUpper.includes('XI & XII');

  if (!isGenericMultiLevel) {
    if (/\bKELAS XII\b/.test(tingkatUpper)) {
      if (
        katUpper.includes('IPS') ||
        namaUpper.includes('SEJARAH') ||
        namaUpper.includes('GEOGRAFI') ||
        namaUpper.includes('SOSIOLOGI') ||
        namaUpper.includes('EKONOMI')
      ) {
        return 'Kelas XII IPS';
      }
      return 'Kelas XII IPA';
    }
    if (/\bKELAS XI\b/.test(tingkatUpper)) {
      if (
        katUpper.includes('IPS') ||
        namaUpper.includes('EKONOMI') ||
        namaUpper.includes('SOSIOLOGI') ||
        namaUpper.includes('GEOGRAFI')
      ) {
        return 'Kelas XI IPS';
      }
      return 'Kelas XI IPA';
    }
    if (/\bKELAS X\b/.test(tingkatUpper) || tingkatUpper.includes('FASE E')) {
      return 'Kelas X';
    }
  }

  if (
    kodeUpper.includes('BIN') ||
    namaUpper.includes('INDONESIA') ||
    kodeUpper.includes('PAI') ||
    namaUpper.includes('AGAMA') ||
    kodeUpper.includes('PKN') ||
    namaUpper.includes('PANCASILA')
  ) {
    return 'Kelas X';
  }
  if (
    kodeUpper.includes('BIO') ||
    kodeUpper.includes('SAINS') ||
    namaUpper.includes('BIOLOGI') ||
    namaUpper.includes('PENALARAN SAINS')
  ) {
    return 'Kelas XI IPA';
  }
  if (
    kodeUpper.includes('EKO') ||
    kodeUpper.includes('MAT') ||
    namaUpper.includes('EKONOMI') ||
    namaUpper.includes('MATEMATIKA WAJIB')
  ) {
    return 'Kelas XI IPS';
  }
  if (
    kodeUpper.includes('BIG') ||
    kodeUpper.includes('FIS') ||
    namaUpper.includes('INGGRIS') ||
    namaUpper.includes('FISIKA')
  ) {
    return 'Kelas XII IPA';
  }
  if (
    kodeUpper.includes('SEJ') ||
    kodeUpper.includes('GEO') ||
    namaUpper.includes('SEJARAH') ||
    namaUpper.includes('GEOGRAFI') ||
    namaUpper.includes('SOSIOLOGI KONTEMPORER')
  ) {
    return 'Kelas XII IPS';
  }

  if (katUpper.includes('MIPA')) return 'Kelas XI IPA';
  if (katUpper.includes('IPS')) return 'Kelas XI IPS';

  return 'Kelas X';
}

export const getPkgClass = (pkg?: ExamPackage | null): string => {
  if (!pkg || typeof pkg !== 'object') return 'Kelas X';
  const rawTargetClass = String(pkg.targetClass ?? '').trim();
  if (
    rawTargetClass &&
    rawTargetClass !== 'Semua Kelas' &&
    !rawTargetClass.toUpperCase().includes('SEMUA')
  ) {
    return rawTargetClass;
  }
  return getTargetClassFromMapel({
    tingkat: rawTargetClass,
    kategori: pkg.subtest,
    nama: pkg.title,
    kode: pkg.code,
  });
};

export const DEFAULT_MAPEL_LIST = [
  {
    kode: 'BIN-SAS',
    nama: 'Bahasa Indonesia & Literasi Membaca',
    tingkat: 'Kelas X',
    kategori: 'Wajib Umum',
    alokasiMenit: 90,
    kkm: 75,
    status: 'Aktif',
  },
  {
    kode: 'PAI-SAS',
    nama: 'Pendidikan Agama Islam & Budi Pekerti',
    tingkat: 'Kelas X',
    kategori: 'Pendidikan Agama',
    alokasiMenit: 60,
    kkm: 80,
    status: 'Aktif',
  },
  {
    kode: 'BIO-SAS',
    nama: 'Biologi & Kimia Terapan',
    tingkat: 'Kelas XI IPA',
    kategori: 'Peminatan MIPA',
    alokasiMenit: 90,
    kkm: 78,
    status: 'Aktif',
  },
  {
    kode: 'TKA-SAINS-02',
    nama: 'Matematika Lanjut & Penalaran Sains',
    tingkat: 'Kelas XI IPA',
    kategori: 'Peminatan MIPA',
    alokasiMenit: 90,
    kkm: 78,
    status: 'Aktif',
  },
  {
    kode: 'MAT-SAS',
    nama: 'Matematika Wajib & Numerasi',
    tingkat: 'Kelas XI IPS',
    kategori: 'Wajib Umum',
    alokasiMenit: 90,
    kkm: 75,
    status: 'Aktif',
  },
  {
    kode: 'EKO-SAS',
    nama: 'Ekonomi & Sosiologi Terapan',
    tingkat: 'Kelas XI IPS',
    kategori: 'Peminatan IPS',
    alokasiMenit: 90,
    kkm: 75,
    status: 'Aktif',
  },
  {
    kode: 'BIG-SAS',
    nama: 'Bahasa Inggris & Literasi Digital',
    tingkat: 'Kelas XII IPA',
    kategori: 'Wajib Umum',
    alokasiMenit: 90,
    kkm: 75,
    status: 'Aktif',
  },
  {
    kode: 'FIS-SAS',
    nama: 'Fisika & Kimia Analisis Lanjut',
    tingkat: 'Kelas XII IPA',
    kategori: 'Peminatan MIPA',
    alokasiMenit: 90,
    kkm: 78,
    status: 'Aktif',
  },
  {
    kode: 'SEJ-SAS',
    nama: 'Sejarah Indonesia & Kebangsaan',
    tingkat: 'Kelas XII IPS',
    kategori: 'Wajib Umum',
    alokasiMenit: 60,
    kkm: 75,
    status: 'Aktif',
  },
  {
    kode: 'GEO-SAS',
    nama: 'Geografi & Sosiologi Kontemporer',
    tingkat: 'Kelas XII IPS',
    kategori: 'Peminatan IPS',
    alokasiMenit: 90,
    kkm: 75,
    status: 'Aktif',
  },
];

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  adminUsername,
  activeToken,
  tokenSecondsLeft,
  tokenDurationSeconds = 600,
  onUpdateToken,
  schedules,
  onUpdateSchedules,
  participants: externalParticipants,
  onUpdateParticipants,
  proctors: externalProctors,
  onUpdateProctors,
  packages,
  onUpdatePackages,
  onResetDefaultPackages,
  resultsHistory,
  onClearHistory,
  adminSettings: externalAdminSettings,
  onUpdateAdminSettings,
  storageEngine = 'vercel-serverless',
  ephemeralStorageWarning = false,
  lastSyncedLabel = 'Tersimpan Otomatis',
  onForceSyncStorage,
  onPullStorage,
  onLogoutAdmin,
}) => {
  // Default view is 'kelompok_tes' to match the user's attached screenshot 100%
  const [activeMenu, setActiveMenu] = useState<AdminSidebarMenuId>('kelompok_tes');
  const [pullStorageUrl, setPullStorageUrl] = useState<string>(() => {
    try {
      return localStorage.getItem('cbt_pull_storage_url') || '/api/storage';
    } catch {
      return '/api/storage';
    }
  });
  const [pullStorageToken, setPullStorageToken] = useState<string>(() => {
    try {
      return localStorage.getItem('cbt_pull_storage_token') || '';
    } catch {
      return '';
    }
  });
  const [isPullingStorage, setIsPullingStorage] = useState<boolean>(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth < 768 : false
  );
  const [localParticipants, setLocalParticipants] = useState<
    ProctorParticipantRow[]
  >(INITIAL_ADMIN_PARTICIPANTS);
  const [localProctors, setLocalProctors] = useState<AdminProctorItem[]>(
    INITIAL_ADMIN_PROCTORS
  );
  const rawParticipants = Array.isArray(externalParticipants)
    ? externalParticipants
    : localParticipants;
  const participants = useMemo(
    () => sanitizeParticipantRows(rawParticipants),
    [rawParticipants]
  );
  const setParticipants = onUpdateParticipants ?? setLocalParticipants;
  const proctors = useMemo(
    () =>
      (Array.isArray(externalProctors) ? externalProctors : localProctors).filter(
        (pr) => Boolean(pr && typeof pr === 'object')
      ),
    [externalProctors, localProctors]
  );
  const setProctors = onUpdateProctors ?? setLocalProctors;
  const safeSchedules = useMemo(
    () => (Array.isArray(schedules) ? schedules : []),
    [schedules]
  );
  const safePackages = useMemo(
    () => (Array.isArray(packages) ? packages : []),
    [packages]
  );
  const safeResultsHistory = useMemo(
    () =>
      (Array.isArray(resultsHistory) ? resultsHistory : []).filter(
        (r) => Boolean(r && typeof r === 'object')
      ),
    [resultsHistory]
  );

  // Add New Proctor Form States
  const [newProctorName, setNewProctorName] = useState('');
  const [newProctorRoom, setNewProctorRoom] = useState('LAB KOMPUTER 1');
  const [newProctorRombel, setNewProctorRombel] = useState('Kelas X');
  const [newProctorPass] = useState('SMADIP2026*');
  const [proctorSearch, setProctorSearch] = useState('');

  // Filter controls (1: Status, 2: Kode Tes, 3: Ruang Ujian, 4: Apply)
  const [filterStatus, setFilterStatus] = useState<string>('Semua Status');
  const [filterKodeTes, setFilterKodeTes] = useState<string>('SEMUA');
  const [filterKelompok, setFilterKelompok] = useState<string>('SEMUA');
  const [targetMoveRuang, setTargetMoveRuang] = useState<string>('Ruang 2');

  const [appliedStatus, setAppliedStatus] = useState<string>('Semua Status');
  const [appliedKodeTes, setAppliedKodeTes] = useState<string>('SEMUA');
  const [appliedKelompok, setAppliedKelompok] = useState<string>('SEMUA');

  const availableExamRooms = useMemo(() => {
    const roomSet = new Set<string>(DEFAULT_EXAM_ROOMS);
    proctors.forEach((pr) => {
      const rn = String(pr?.roomName ?? '').trim();
      if (rn) {
        roomSet.add(rn);
      }
    });
    participants.forEach((p) => {
      const r = resolveParticipantRuang(p);
      if (r) roomSet.add(r);
    });
    return Array.from(roomSet);
  }, [proctors, participants]);

  const availableKodeTesList = useMemo(() => {
    const kodeSet = new Set<string>(['SAS26SMADIP1']);
    participants.forEach((p) => {
      const kt = String(p?.kodeTes || '').trim();
      if (kt) kodeSet.add(kt);
    });
    return Array.from(kodeSet);
  }, [participants]);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [toastMsg, setToastMsg] = useState<string>('');
  const [showLogoutConfirmModal, setShowLogoutConfirmModal] = useState<boolean>(false);

  // Question Bank & Token states
  const [selectedPkgId, setSelectedPkgId] = useState(safePackages[0]?.id || '');
  const [statusTesKelas, setStatusTesKelas] = useState('Semua Kelas');
  const [statusTesTipeSoal, setStatusTesTipeSoal] = useState('Semua Tipe Soal');
  const [appendUploadMode, setAppendUploadMode] = useState(false);
  const [showQuestionPreviewModal, setShowQuestionPreviewModal] = useState(false);
  const [previewQuestionIdx, setPreviewQuestionIdx] = useState(0);
  const [confirmClearPkgId, setConfirmClearPkgId] = useState<string | null>(null);
  const [customTokenInput, setCustomTokenInput] = useState(activeToken);

  useEffect(() => {
    setCustomTokenInput(activeToken);
  }, [activeToken]);

  const effectiveTokenDurationSecs = Math.max(60, tokenDurationSeconds || 600);
  const tokenIntervalMinutes = Math.round(effectiveTokenDurationSecs / 60);
  const tokenMinutes = String(Math.floor(tokenSecondsLeft / 60)).padStart(2, '0');
  const tokenSeconds = String(tokenSecondsLeft % 60).padStart(2, '0');
  const tokenCountdownLabel = `${tokenMinutes}:${tokenSeconds}`;
  const tokenProgressPct = Math.max(
    0,
    Math.min(100, (tokenSecondsLeft / effectiveTokenDurationSecs) * 100)
  );
  const [newQuestionType, setNewQuestionType] = useState<QuestionType>('pilihan_ganda');
  const [newCategory, setNewCategory] = useState('Literasi & Numerasi');
  const [newStimulusTitle, setNewStimulusTitle] = useState('');
  const [newStimulusText, setNewStimulusText] = useState('');
  const [newQuestionText, setNewQuestionText] = useState('');
  const [optA, setOptA] = useState('');
  const [optB, setOptB] = useState('');
  const [optC, setOptC] = useState('');
  const [optD, setOptD] = useState('');
  const [optE, setOptE] = useState('');
  const [correctOpt, setCorrectOpt] = useState('A');
  const [complexCorrectOpts, setComplexCorrectOpts] = useState<string[]>(['A', 'C']);
  const [statement1, setStatement1] = useState('Pernyataan 1 terkait materi ujian');
  const [statement1Val, setStatement1Val] = useState<'Benar' | 'Salah'>('Benar');
  const [statement2, setStatement2] = useState('Pernyataan 2 terkait materi ujian');
  const [statement2Val, setStatement2Val] = useState<'Benar' | 'Salah'>('Salah');
  const [statement3, setStatement3] = useState('Pernyataan 3 terkait materi ujian');
  const [statement3Val, setStatement3Val] = useState<'Benar' | 'Salah'>('Benar');
  const [matchPremise1, setMatchPremise1] = useState('');
  const [matchResponse1, setMatchResponse1] = useState('');
  const [matchPremise2, setMatchPremise2] = useState('');
  const [matchResponse2, setMatchResponse2] = useState('');
  const [matchPremise3, setMatchPremise3] = useState('');
  const [matchResponse3, setMatchResponse3] = useState('');
  const [shortAnswerKeyInput, setShortAnswerKeyInput] = useState('');

  // Add New Participant form in Daftar Peserta (only requires Name; Username & Password auto-filled)
  const [newParticipantName, setNewParticipantName] = useState('');
  const [newParticipantKelas, setNewParticipantKelas] = useState<string>('X');
  const [participantSearchQuery, setParticipantSearchQuery] = useState('');
  const excelInputRef = React.useRef<HTMLInputElement | null>(null);
  const mapelExcelInputRef = React.useRef<HTMLInputElement | null>(null);
  const [uploadedExcelInfo, setUploadedExcelInfo] = useState<{
    fileName: string;
    count: number;
    uploadedAt: string;
  } | null>(() => {
    try {
      const savedInfo = localStorage.getItem('pusmendik_cbt_excel_info_v1');
      return savedInfo ? JSON.parse(savedInfo) : null;
    } catch {
      return null;
    }
  });

  // Jadwal Ujian form state in menu Jadwal
  const [newHariTanggal, setNewHariTanggal] = useState('');
  const [newJadwalKelas, setNewJadwalKelas] = useState<string>('X');
  const [newJadwalMapel, setNewJadwalMapel] = useState('');
  const [newWaktuMulai, setNewWaktuMulai] = useState('07:30 WIB');
  const [newDurasi, setNewDurasi] = useState('90 Menit');

  const activeSchedules = useMemo(
    () => safeSchedules.filter((s) => s?.isActive),
    [safeSchedules]
  );
  const isAnyScheduleActive = activeSchedules.length > 0;

  // Auto-generated Username (SA2026 + Angka Acak) & Password for next participant in Daftar Peserta
  const nextAutoSequence = useMemo(() => {
    const usedUsernames = new Set(
      participants.map((p) => String(p?.username || '').trim().toUpperCase())
    );
    const seed = (participants.length + 1) * 379 + 1423;
    let candidate = 1000 + (seed % 9000);
    while (usedUsernames.has(`SA2026${candidate}`)) {
      candidate = 1000 + ((candidate + 437) % 9000);
    }
    return candidate;
  }, [participants]);
  const autoGeneratedUsername = `SA2026${nextAutoSequence}`;
  const autoGeneratedPassword = `SMADIP${nextAutoSequence}*`;

  // Auto-generated ID / Username Proktor & Kode Enkripsi in Daftar Proktor
  const nextProctorNumber = 6 + proctors.length;
  const nextProctorSuffixLetter = String.fromCharCode(
    65 + ((10 + proctors.length) % 26)
  );
  const autoGeneratedProctorId = `K05060108-KB${nextProctorNumber}${nextProctorSuffixLetter}`;
  const autoGeneratedProctorEnc = `ENC-${8104 + proctors.length * 319}-WGR`;

  // Pengaturan State
  const defaultKelasList = [
    { kode: 'X-1', tingkat: 'Kelas X', jurusan: 'Fase E (Umum)', ruang: 'LAB KOMPUTER 1', sesi: 'Sesi 1', status: 'Aktif' },
    { kode: 'X-2', tingkat: 'Kelas X', jurusan: 'Fase E (Umum)', ruang: 'LAB KOMPUTER 1', sesi: 'Sesi 2', status: 'Aktif' },
    { kode: 'XI-IPA', tingkat: 'Kelas XI', jurusan: 'MIPA (Fase F)', ruang: 'LAB KOMPUTER 2', sesi: 'Sesi 1', status: 'Aktif' },
    { kode: 'XI-IPS', tingkat: 'Kelas XI', jurusan: 'IPS (Fase F)', ruang: 'LAB KOMPUTER 2', sesi: 'Sesi 2', status: 'Aktif' },
    { kode: 'XII-IPA', tingkat: 'Kelas XII', jurusan: 'MIPA', ruang: 'LAB KOMPUTER 3', sesi: 'Sesi 1', status: 'Aktif' },
    { kode: 'XII-IPS', tingkat: 'Kelas XII', jurusan: 'IPS', ruang: 'LAB KOMPUTER 3', sesi: 'Sesi 2', status: 'Aktif' },
  ];

  const defaultMapelList = DEFAULT_MAPEL_LIST;

  const defaultAdminList = [
    {
      id: 'adm_1',
      adminId: 'K05060108-KB6K',
      namaLengkap: 'SHAHRUR ROBBY, S.Pd.',
      nip: '-',
      email: 'shahrurrobby17@gmail.com',
      noHp: '0812-3456-7890',
      role: 'Penanggung Jawab / Super Admin',
      status: 'Aktif',
      password: 'SAS2026',
    },
    {
      id: 'adm_2',
      adminId: 'ADMIN_SMADIP',
      namaLengkap: 'TIM TEKNIS CBT SMA ISLAM DIPONEGORO',
      nip: '-',
      email: 'admin.cbt@smadiponegorowagir.sch.id',
      noHp: '0857-1122-3344',
      role: 'Administrator Server & Database',
      status: 'Aktif',
      password: 'SAS2026',
    },
  ];

  const defaultAdminConfig = {
    namaSekolah: 'SMA Islam Diponegoro Wagir',
    namaKepalaSekolah: 'ROMEO GALISTRA, S.Pd.',
    logoKartuPeserta: '',
    npsn: '20517890',
    namaUjian: 'SUMATIF AKHIR SEMESTER (SAS)',
    semester: 'Genap 2025/2026',
    modaPelaksanaan: 'Daring (Online)',
    ruangDefault: 'LAB KOMPUTER',
    tingkatKelas: 'Semua Tingkat (Kelas X, XI, XII)',
    daftarKelas: 'X-1, X-2, XI-IPA, XI-IPS, XII-IPA, XII-IPS',
    namaProktor: 'DRS. H. AHMAD FAUZI, M.PD.',
    adminNama: 'SHAHRUR ROBBY, S.Pd.',
    adminId: 'K05060108-KB6K',
    adminNip: '-',
    adminEmail: 'shahrurrobby17@gmail.com',
    adminNoHp: '0812-3456-7890',
    adminRole: 'Super Administrator CBT',
    adminList: defaultAdminList,
    kelasList: defaultKelasList,
    mapelList: defaultMapelList,
    customMapelConfigured: false,
    deletedMapelCodes: [] as string[],
    deletedMapelNames: [] as string[],
    durasiDefault: 90,
    minMinutesBeforeFinish: 45,
    enforceMinFinishTime: false,
    acakSoal: true,
    acakOpsi: true,
    wajibFullscreen: true,
    kunciKeluarSistem: true,
    tampilkanNilaiPeserta: false,
    tokenIntervalMenit: 10,
    pesanPelanggaran:
      'Anda terdeteksi keluar dari layar CBT! Harap lapor ke Proktor / Pengawas untuk reset login.',
    updatedAt: 0,
  };

  const normalizeAdminConfig = (
    sourceObj: any,
    fallbackPrev?: typeof defaultAdminConfig
  ): typeof defaultAdminConfig => {
    const base = fallbackPrev || defaultAdminConfig;
    if (!sourceObj || typeof sourceObj !== 'object') {
      return {
        ...base,
        logoKartuPeserta:
          base.logoKartuPeserta ||
          (() => {
            try {
              return localStorage.getItem('cbt_kartu_peserta_logo') || '';
            } catch {
              return '';
            }
          })(),
      };
    }

    const parsed = sourceObj;
    const isCustomMapelConfigured = Boolean(parsed.customMapelConfigured);
    const deletedCodesSet = new Set<string>(
      Array.isArray(parsed.deletedMapelCodes)
        ? parsed.deletedMapelCodes.map((c: any) =>
            String(c || '').trim().toUpperCase()
          )
        : []
    );
    const deletedNamesSet = new Set<string>(
      Array.isArray(parsed.deletedMapelNames)
        ? parsed.deletedMapelNames.map((n: any) =>
            String(n || '').trim().toLowerCase()
          )
        : []
    );

    const rawMapelList = Array.isArray(parsed.mapelList)
      ? parsed.mapelList
      : Array.isArray(base.mapelList)
      ? base.mapelList
      : defaultMapelList;

    const normalizedMapelList = rawMapelList
      .filter((m: any) => m && typeof m === 'object')
      .map((m: any) => ({
        ...m,
        tingkat: getTargetClassFromMapel(m),
      }))
      .filter((m: any) => {
        const mKode = String(m.kode || '').trim().toUpperCase();
        const mNama = String(m.nama || '').trim().toLowerCase();
        if (mKode && deletedCodesSet.has(mKode)) return false;
        if (mNama && deletedNamesSet.has(mNama)) return false;
        return true;
      });

    if (
      !isCustomMapelConfigured &&
      deletedCodesSet.size === 0 &&
      deletedNamesSet.size === 0 &&
      normalizedMapelList.length < 10
    ) {
      const existingCodes = new Set(
        normalizedMapelList.map((m: any) => String(m.kode || '').trim().toUpperCase())
      );
      defaultMapelList.forEach((defM: any) => {
        const defCode = String(defM.kode || '').trim().toUpperCase();
        if (defCode && !existingCodes.has(defCode)) {
          normalizedMapelList.push({
            ...defM,
            tingkat: getTargetClassFromMapel(defM),
          });
          existingCodes.add(defCode);
        }
      });
    }

    const migratedAdminNama =
      !parsed.adminNama || parsed.adminNama === 'ROMEO GALISTRA, S.Pd.'
        ? 'SHAHRUR ROBBY, S.Pd.'
        : String(parsed.adminNama);

    const rawAdminList = Array.isArray(parsed.adminList) && parsed.adminList.length > 0
      ? parsed.adminList
      : Array.isArray(base.adminList) && base.adminList.length > 0
      ? base.adminList
      : defaultAdminList;

    const migratedAdminList = rawAdminList
      .filter((adm: any) => adm && typeof adm === 'object')
      .map((adm: any) =>
        adm.adminId === 'K05060108-KB6K' &&
        adm.namaLengkap === 'ROMEO GALISTRA, S.Pd.'
          ? {
              ...adm,
              namaLengkap: 'SHAHRUR ROBBY, S.Pd.',
              email: 'shahrurrobby17@gmail.com',
              password: adm.password || 'SAS2026',
            }
          : {
              ...adm,
              adminId: String(adm.adminId || 'ADMIN_SMADIP'),
              namaLengkap: String(adm.namaLengkap || 'Administrator CBT'),
              password: adm.password || 'SAS2026',
            }
      );

    const normalizedInterval =
      !parsed.updatedAt && parsed.tokenIntervalMenit === 15
        ? 10
        : Number(parsed.tokenIntervalMenit) || 10;

    let savedLogo = '';
    try {
      savedLogo = localStorage.getItem('cbt_kartu_peserta_logo') || '';
    } catch {
      savedLogo = '';
    }

    return {
      ...base,
      ...parsed,
      tokenIntervalMenit: normalizedInterval,
      enforceMinFinishTime: Boolean(parsed.enforceMinFinishTime),
      logoKartuPeserta:
        typeof parsed.logoKartuPeserta === 'string'
          ? parsed.logoKartuPeserta || savedLogo
          : savedLogo,
      namaProktor: String(parsed.namaProktor || base.namaProktor || 'DRS. H. AHMAD FAUZI, M.PD.'),
      adminNama: migratedAdminNama,
      adminList: migratedAdminList.length > 0 ? migratedAdminList : defaultAdminList,
      kelasList:
        Array.isArray(parsed.kelasList) && parsed.kelasList.length > 0
          ? parsed.kelasList
          : Array.isArray(base.kelasList) && base.kelasList.length > 0
          ? base.kelasList
          : defaultKelasList,
      mapelList: normalizedMapelList,
      deletedMapelCodes: Array.from(deletedCodesSet),
      deletedMapelNames: Array.from(deletedNamesSet),
    };
  };

  const [appConfig, setAppConfig] = useState<typeof defaultAdminConfig>(() => {
    try {
      const sourceObj =
        externalAdminSettings && typeof externalAdminSettings === 'object'
          ? externalAdminSettings
          : (() => {
              const saved = localStorage.getItem('cbt_admin_settings');
              return saved ? JSON.parse(saved) : null;
            })();
      return normalizeAdminConfig(sourceObj, defaultAdminConfig);
    } catch {
      return normalizeAdminConfig(null, defaultAdminConfig);
    }
  });

  useEffect(() => {
    if (!externalAdminSettings || typeof externalAdminSettings !== 'object') {
      return;
    }
    const remoteTs =
      typeof externalAdminSettings.updatedAt === 'number'
        ? externalAdminSettings.updatedAt
        : 0;
    const localTs =
      typeof appConfig.updatedAt === 'number' ? appConfig.updatedAt : 0;
    const hasNewAdminList =
      Array.isArray(externalAdminSettings.adminList) &&
      externalAdminSettings.adminList.length > 0 &&
      remoteTs >= localTs;
    if (remoteTs > localTs || hasNewAdminList) {
      setAppConfig((prev) => {
        try {
          return normalizeAdminConfig(externalAdminSettings, prev);
        } catch {
          return prev;
        }
      });
    }
  }, [externalAdminSettings, appConfig.updatedAt]);

  const persistAdminConfig = (
    nextCfg: typeof defaultAdminConfig,
    options?: { syncCloud?: boolean }
  ) => {
    const stamped = {
      ...nextCfg,
      updatedAt: Date.now(),
    };
    setAppConfig(stamped);
    try {
      localStorage.setItem('cbt_admin_settings', JSON.stringify(stamped));
    } catch {
      // ignore
    }
    if (onUpdateAdminSettings) {
      onUpdateAdminSettings(stamped);
    } else if (options?.syncCloud) {
      saveVercelStorage({ adminSettings: stamped });
    }
    return stamped;
  };

  const logoKartuInputRef = React.useRef<HTMLInputElement | null>(null);

  const handleUploadLogoKartuPeserta = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showNotice('Format file harus berupa gambar (.png, .jpg, .jpeg, .webp, atau .svg)!');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const rawDataUrl = reader.result as string;
      const img = new Image();
      img.onload = () => {
        let finalDataUrl = rawDataUrl;
        try {
          const canvas = document.createElement('canvas');
          const maxSize = 240;
          let width = img.width || maxSize;
          let height = img.height || maxSize;
          if (width > maxSize || height > maxSize) {
            if (width > height) {
              height = Math.round((height * maxSize) / width);
              width = maxSize;
            } else {
              width = Math.round((width * maxSize) / height);
              height = maxSize;
            }
          }
          canvas.width = Math.max(1, width);
          canvas.height = Math.max(1, height);
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            finalDataUrl = canvas.toDataURL('image/png');
          }
        } catch {
          finalDataUrl = rawDataUrl;
        }
        try {
          localStorage.setItem('cbt_kartu_peserta_logo', finalDataUrl);
        } catch {
          // ignore storage quota warning
        }
        persistAdminConfig(
          { ...appConfig, logoKartuPeserta: finalDataUrl },
          { syncCloud: true }
        );
        showNotice('Logo Kop Kartu Peserta berhasil diunggah dan disinkronkan!');
      };
      img.onerror = () => {
        showNotice('Gagal membaca file gambar logo. Silakan pilih file gambar lain.');
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRemoveLogoKartuPeserta = () => {
    try {
      localStorage.removeItem('cbt_kartu_peserta_logo');
    } catch {
      // ignore
    }
    persistAdminConfig(
      { ...appConfig, logoKartuPeserta: '' },
      { syncCloud: true }
    );
    showNotice('Logo Kop Kartu Peserta berhasil dihapus dan disinkronkan.');
  };

  const [editingProctor, setEditingProctor] = useState<AdminProctorItem | null>(null);
  const [editingProctorForm, setEditingProctorForm] = useState<AdminProctorItem | null>(null);

  // State untuk form Tambah Data Administrator Baru di menu Pengaturan
  const [showAdminForm, setShowAdminForm] = useState(false);
  const [newAdminId, setNewAdminId] = useState('');
  const [newAdminNama, setNewAdminNama] = useState('');
  const [newAdminNip, setNewAdminNip] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminNoHp, setNewAdminNoHp] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('SAS2026');
  const [newAdminRole, setNewAdminRole] = useState('Administrator Server & Database');
  const [editingAdminPassId, setEditingAdminPassId] = useState<string | null>(null);
  const [editingAdminPassValue, setEditingAdminPassValue] = useState('');

  // State untuk tambah kolom kelas baru di menu Pengaturan
  const [newPengaturanKelasKode, setNewPengaturanKelasKode] = useState('');
  const [newPengaturanKelasTingkat, setNewPengaturanKelasTingkat] = useState('Kelas X');
  const [newPengaturanKelasJurusan, setNewPengaturanKelasJurusan] = useState('Fase E (Umum)');
  const [newPengaturanKelasRuang, setNewPengaturanKelasRuang] = useState('LAB KOMPUTER 1');
  const [newPengaturanKelasSesi, setNewPengaturanKelasSesi] = useState('Sesi 1');

  // State & form untuk Input Mata Pelajaran di menu Pengaturan
  const [showMapelForm, setShowMapelForm] = useState(false);
  const [newMapelKode, setNewMapelKode] = useState('');
  const [newMapelNama, setNewMapelNama] = useState('');
  const [newMapelTingkat, setNewMapelTingkat] = useState('Kelas X');
  const [newMapelKategori, setNewMapelKategori] = useState('Wajib Umum');
  const [newMapelAlokasi, setNewMapelAlokasi] = useState(90);
  const [newMapelKKM, setNewMapelKKM] = useState(75);

  const handleAddMapelToSettings = (presetData?: {
    nama: string;
    kode?: string;
    tingkat?: string;
    kategori?: string;
    alokasi?: number;
    kkm?: number;
  }) => {
    const rawNama = presetData ? presetData.nama : newMapelNama;
    const rawKode = presetData ? (presetData.kode || '') : newMapelKode;
    const rawTingkat = presetData ? (presetData.tingkat || newMapelTingkat) : newMapelTingkat;
    const rawKategori = presetData ? (presetData.kategori || newMapelKategori) : newMapelKategori;
    const rawAlokasi = presetData ? (presetData.alokasi || newMapelAlokasi) : newMapelAlokasi;
    const rawKKM = presetData ? (presetData.kkm || newMapelKKM) : newMapelKKM;

    if (!rawNama.trim()) {
      showNotice('Harap masukkan nama mata pelajaran.');
      return;
    }
    const cleanNama = rawNama.trim();

    const currentList = Array.isArray(appConfig.mapelList)
      ? [...appConfig.mapelList]
      : [...defaultMapelList];

    let cleanKode = rawKode.trim().toUpperCase();
    if (!cleanKode) {
      const basePrefix =
        cleanNama
          .replace(/[^a-zA-Z0-9]/g, '')
          .slice(0, 3)
          .toUpperCase() || 'MPL';
      cleanKode = `${basePrefix}-SAS`;
      let counter = 2;
      while (currentList.some((m: { kode: string }) => m.kode.toUpperCase() === cleanKode)) {
        cleanKode = `${basePrefix}-${String(counter).padStart(2, '0')}-SAS`;
        counter++;
      }
    } else {
      if (currentList.some((m: { kode: string }) => m.kode.toUpperCase() === cleanKode)) {
        let counter = 2;
        let candidate = `${cleanKode}-${counter}`;
        while (currentList.some((m: { kode: string }) => m.kode.toUpperCase() === candidate)) {
          counter++;
          candidate = `${cleanKode}-${counter}`;
        }
        cleanKode = candidate;
      }
    }

    const newEntry = {
      kode: cleanKode,
      nama: cleanNama,
      tingkat: rawTingkat,
      kategori: rawKategori,
      alokasiMenit: Number(rawAlokasi) || 90,
      kkm: Number(rawKKM) || 75,
      status: 'Aktif',
      simulasiWhitelistedV4: true,
    };

    const updatedList = [...currentList, newEntry];
    const nextDeletedCodes = (appConfig.deletedMapelCodes || []).filter(
      (c) => c.trim().toUpperCase() !== cleanKode.toUpperCase()
    );
    const nextDeletedNames = (appConfig.deletedMapelNames || []).filter(
      (n) => n.trim().toLowerCase() !== cleanNama.toLowerCase()
    );
    const updatedConfig = {
      ...appConfig,
      mapelList: updatedList,
      customMapelConfigured: true,
      deletedMapelCodes: nextDeletedCodes,
      deletedMapelNames: nextDeletedNames,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });

    // Daftarkan juga secara otomatis ke paket soal CBT agar langsung muncul di Status Tes
    const newPkgId = 'mapel_pkg_' + cleanKode.toLowerCase().replace(/[^a-z0-9]/g, '_');
    const targetClass = getTargetClassFromMapel({
      kode: cleanKode,
      nama: cleanNama,
      tingkat: rawTingkat,
      kategori: rawKategori,
    });
    onUpdatePackages((prevPackages) => {
      const baseList = Array.isArray(prevPackages) ? prevPackages : packages;
      const already = baseList.some(
        (p) =>
          p.id === newPkgId ||
          p.code.toUpperCase() === cleanKode ||
          (p.title.trim().toLowerCase() === cleanNama.toLowerCase() &&
            getPkgClass(p) === targetClass)
      );
      if (already) return baseList;
      return [
        ...baseList,
        {
          id: newPkgId,
          code: cleanKode,
          title: cleanNama,
          level: 'SMA / MA / SMK / Sederajat',
          subtest: rawKategori,
          durationMinutes: Number(rawAlokasi) || 90,
          targetClass: rawTingkat,
          questions: [],
          simulasiWhitelistedV4: true,
        },
      ];
    });

    setNewMapelKode('');
    setNewMapelNama('');
    setNewMapelAlokasi(90);
    setNewMapelKKM(75);
    setShowMapelForm(true);
    showNotice(`Mata pelajaran "${cleanNama}" (${cleanKode}) untuk ${rawTingkat} berhasil ditambahkan!`);
  };

  const handleUploadMapelExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result;
        if (!buffer) return;

        const workbook = XLSX.read(buffer, { type: 'array' });
        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          showNotice('File Excel kosong atau tidak memiliki lembar kerja.');
          return;
        }

        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        if (!worksheet) {
          showNotice('Lembar kerja Excel tidak dapat dibaca.');
          return;
        }

        const rawRows = XLSX.utils.sheet_to_json<any[]>(worksheet, {
          header: 1,
          defval: '',
        });

        const nonEmptyRows = rawRows.filter(
          (row) =>
            Array.isArray(row) &&
            row.some((cell) => String(cell ?? '').trim() !== '')
        );

        if (nonEmptyRows.length === 0) {
          showNotice('File Excel tidak memiliki baris data.');
          return;
        }

        // Cari baris header untuk kolom: Nama mapel, tingkat/fase, kategori, durasi, KKM
        let headerRowIdx = -1;
        let namaColIdx = -1;
        let tingkatColIdx = -1;
        let kategoriColIdx = -1;
        let durasiColIdx = -1;
        let kkmColIdx = -1;
        let kodeColIdx = -1;

        for (let r = 0; r < Math.min(nonEmptyRows.length, 5); r++) {
          const cells = nonEmptyRows[r].map((c) =>
            String(c ?? '').trim().toLowerCase()
          );

          const nIdx = cells.findIndex(
            (c) =>
              c.includes('nama mapel') ||
              c.includes('nama mata pelajaran') ||
              c === 'mapel' ||
              c === 'mata pelajaran' ||
              c === 'nama' ||
              c === 'subject'
          );

          if (nIdx !== -1) {
            headerRowIdx = r;
            namaColIdx = nIdx;
            tingkatColIdx = cells.findIndex(
              (c) =>
                c.includes('tingkat') ||
                c.includes('fase') ||
                c.includes('kelas') ||
                c === 'grade' ||
                c === 'level'
            );
            kategoriColIdx = cells.findIndex(
              (c) =>
                c.includes('kategori') ||
                c.includes('jurusan') ||
                c.includes('peminatan') ||
                c === 'category'
            );
            durasiColIdx = cells.findIndex(
              (c) =>
                c.includes('durasi') ||
                c.includes('waktu') ||
                c.includes('alokasi') ||
                c.includes('menit') ||
                c === 'duration'
            );
            kkmColIdx = cells.findIndex(
              (c) =>
                c.includes('kkm') ||
                c.includes('passing grade') ||
                c.includes('kkm minimal')
            );
            kodeColIdx = cells.findIndex(
              (c) =>
                c === 'kode' ||
                c.includes('kode mapel') ||
                c.includes('kode ujian') ||
                c === 'code'
            );
            break;
          }
        }

        let startDataRow = 0;
        if (headerRowIdx !== -1) {
          startDataRow = headerRowIdx + 1;
        } else {
          // Fallback urutan kolom standar: 0=Nama, 1=Tingkat/Fase, 2=Kategori, 3=Durasi, 4=KKM
          const firstRowStr = nonEmptyRows[0].map((c) => String(c ?? '').toLowerCase());
          if (
            firstRowStr.some(
              (c) =>
                isNaN(Number(c)) &&
                (c.includes('nama') || c.includes('tingkat') || c.includes('kategori'))
            )
          ) {
            startDataRow = 1;
          }
          namaColIdx = 0;
          tingkatColIdx = 1;
          kategoriColIdx = 2;
          durasiColIdx = 3;
          kkmColIdx = 4;
        }

        const dataRows = nonEmptyRows.slice(startDataRow);
        if (dataRows.length === 0) {
          showNotice('Tidak ada baris data mata pelajaran yang ditemukan di file Excel.');
          return;
        }

        const currentList = Array.isArray(appConfig.mapelList)
          ? [...appConfig.mapelList]
          : [...defaultMapelList];

        const existingCodes = new Set(
          currentList.map((m: any) => (m.kode || '').trim().toUpperCase())
        );
        const existingNames = new Set(
          currentList.map((m: any) => (m.nama || '').trim().toLowerCase())
        );

        const newMapels: any[] = [];
        const newPackagesToAdd: ExamPackage[] = [];

        dataRows.forEach((row) => {
          const rawNama = String(row[namaColIdx] ?? '').trim();
          if (!rawNama) return;

          // Normalisasi tingkat / fase
          let rawTingkat = tingkatColIdx !== -1 ? String(row[tingkatColIdx] ?? '').trim() : '';
          let normalizedTingkat = 'Kelas X';
          const tUpper = rawTingkat.toUpperCase();
          if (tUpper.includes('XII') || tUpper.includes('12')) {
            if (tUpper.includes('IPS') || tUpper.includes('SOSIAL')) {
              normalizedTingkat = 'Kelas XII IPS';
            } else {
              normalizedTingkat = 'Kelas XII IPA';
            }
          } else if (tUpper.includes('XI') || tUpper.includes('11')) {
            if (tUpper.includes('IPS') || tUpper.includes('SOSIAL')) {
              normalizedTingkat = 'Kelas XI IPS';
            } else {
              normalizedTingkat = 'Kelas XI IPA';
            }
          } else if (tUpper.includes('X') || tUpper.includes('10') || tUpper.includes('FASE E')) {
            normalizedTingkat = 'Kelas X';
          } else if (rawTingkat) {
            normalizedTingkat = rawTingkat;
          } else {
            normalizedTingkat = getTargetClassFromMapel({ nama: rawNama });
          }

          // Normalisasi Kategori
          let rawKategori = kategoriColIdx !== -1 ? String(row[kategoriColIdx] ?? '').trim() : '';
          if (!rawKategori) {
            if (normalizedTingkat.includes('IPA')) rawKategori = 'Peminatan MIPA';
            else if (normalizedTingkat.includes('IPS')) rawKategori = 'Peminatan IPS';
            else rawKategori = 'Wajib Umum';
          }

          // Durasi & KKM
          const rawDurasi = durasiColIdx !== -1 ? Number(row[durasiColIdx]) : 90;
          const durasiVal = !isNaN(rawDurasi) && rawDurasi > 0 ? rawDurasi : 90;

          const rawKKM = kkmColIdx !== -1 ? Number(row[kkmColIdx]) : 75;
          const kkmVal = !isNaN(rawKKM) && rawKKM >= 0 ? rawKKM : 75;

          // Kode Mapel unik
          let rawKode = kodeColIdx !== -1 ? String(row[kodeColIdx] ?? '').trim().toUpperCase() : '';
          let finalKode = rawKode;
          if (!finalKode) {
            const prefix =
              rawNama
                .replace(/[^a-zA-Z0-9]/g, '')
                .slice(0, 3)
                .toUpperCase() || 'MPL';
            finalKode = `${prefix}-SAS`;
            let counter = 2;
            while (existingCodes.has(finalKode)) {
              finalKode = `${prefix}-${String(counter).padStart(2, '0')}-SAS`;
              counter++;
            }
          } else if (existingCodes.has(finalKode)) {
            let counter = 2;
            let candidate = `${finalKode}-${counter}`;
            while (existingCodes.has(candidate)) {
              counter++;
              candidate = `${finalKode}-${counter}`;
            }
            finalKode = candidate;
          }

          existingCodes.add(finalKode);
          existingNames.add(rawNama.toLowerCase());

          const mapelEntry = {
            kode: finalKode,
            nama: rawNama,
            tingkat: normalizedTingkat,
            kategori: rawKategori,
            alokasiMenit: durasiVal,
            kkm: kkmVal,
            status: 'Aktif',
            simulasiWhitelistedV4: true,
          };
          newMapels.push(mapelEntry);

          const newPkgId = 'mapel_pkg_' + finalKode.toLowerCase().replace(/[^a-z0-9]/g, '_');
          newPackagesToAdd.push({
            id: newPkgId,
            code: finalKode,
            title: rawNama,
            level: 'SMA / MA / SMK / Sederajat',
            subtest: rawKategori,
            durationMinutes: durasiVal,
            targetClass: normalizedTingkat,
            questions: [],
            simulasiWhitelistedV4: true,
          });
        });

        if (newMapels.length === 0) {
          showNotice('Tidak ada baris mata pelajaran valid yang dapat diimpor.');
          return;
        }

        const addedCodesUpper = new Set(
          newMapels.map((m) => String(m.kode || '').trim().toUpperCase())
        );
        const addedNamesLower = new Set(
          newMapels.map((m) => String(m.nama || '').trim().toLowerCase())
        );
        const nextDeletedCodes = (appConfig.deletedMapelCodes || []).filter(
          (c) => !addedCodesUpper.has(c.trim().toUpperCase())
        );
        const nextDeletedNames = (appConfig.deletedMapelNames || []).filter(
          (n) => !addedNamesLower.has(n.trim().toLowerCase())
        );
        const updatedList = [...currentList, ...newMapels];
        const updatedConfig = {
          ...appConfig,
          mapelList: updatedList,
          customMapelConfigured: true,
          deletedMapelCodes: nextDeletedCodes,
          deletedMapelNames: nextDeletedNames,
        };
        persistAdminConfig(updatedConfig, { syncCloud: true });

        // Daftarkan ke paket CBT agar langsung muncul di Status Tes
        onUpdatePackages((prevPackages) => {
          const baseList = Array.isArray(prevPackages) ? prevPackages : packages;
          const merged = [...baseList];
          newPackagesToAdd.forEach((newPkg) => {
            const already = merged.some(
              (p) =>
                p.id === newPkg.id ||
                p.code.toUpperCase() === newPkg.code.toUpperCase()
            );
            if (!already) {
              merged.push(newPkg);
            }
          });
          return merged;
        });

        showNotice(
          `Berhasil mengimpor ${newMapels.length} mata pelajaran dari file Excel "${file.name}"!`
        );
      } catch (err: any) {
        showNotice(`Gagal membaca file Excel: ${err?.message || 'Format tidak valid'}`);
      } finally {
        if (e.target) e.target.value = '';
      }
    };

    reader.readAsArrayBuffer(file);
  };

  const handleDownloadMapelTemplateExcel = () => {
    try {
      const headers = ['Nama Mapel', 'Tingkat/Fase', 'Kategori', 'Durasi', 'KKM'];
      const sampleData = [
        ['Bahasa Indonesia & Literasi Membaca', 'Kelas X', 'Wajib Umum', 90, 75],
        ['Pendidikan Agama Islam & Budi Pekerti', 'Kelas X', 'Pendidikan Agama', 60, 80],
        ['Biologi & Kimia Terapan', 'Kelas XI IPA', 'Peminatan MIPA', 90, 78],
        ['Matematika Lanjut & Penalaran Sains', 'Kelas XI IPA', 'Peminatan MIPA', 90, 78],
        ['Matematika Wajib & Numerasi', 'Kelas XI IPS', 'Wajib Umum', 90, 75],
        ['Ekonomi & Sosiologi Terapan', 'Kelas XI IPS', 'Peminatan IPS', 90, 75],
        ['Bahasa Inggris & Literasi Digital', 'Kelas XII IPA', 'Wajib Umum', 90, 75],
        ['Fisika & Kimia Analisis Lanjut', 'Kelas XII IPA', 'Peminatan MIPA', 90, 78],
        ['Sejarah Indonesia & Kebangsaan', 'Kelas XII IPS', 'Wajib Umum', 60, 75],
        ['Geografi & Sosiologi Kontemporer', 'Kelas XII IPS', 'Peminatan IPS', 90, 75],
      ];

      const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData]);
      ws['!cols'] = [
        { wch: 40 }, // Nama Mapel
        { wch: 18 }, // Tingkat/Fase
        { wch: 20 }, // Kategori
        { wch: 12 }, // Durasi
        { wch: 10 }, // KKM
      ];

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Template Mapel');
      XLSX.writeFile(wb, 'Format_Excel_Mata_Pelajaran_CBT.xlsx');
      showNotice('Format template Excel Mata Pelajaran berhasil diunduh.');
    } catch {
      showNotice('Gagal mengunduh template Excel.');
    }
  };

  const handleExportMapelToExcel = () => {
    try {
      const currentList =
        Array.isArray(appConfig.mapelList) && appConfig.mapelList.length > 0
          ? appConfig.mapelList
          : defaultMapelList;

      if (!currentList || currentList.length === 0) {
        showNotice('Belum ada data mata pelajaran untuk diunduh.');
        return;
      }

      const headers = [
        'No',
        'Kode Mapel',
        'Nama Mata Pelajaran',
        'Tingkat / Fase',
        'Kategori',
        'Durasi (Menit)',
        'KKM',
        'Status',
      ];

      const rows = currentList.map((m: any, idx: number) => [
        idx + 1,
        m.kode || '-',
        m.nama || '-',
        m.tingkat || '-',
        m.kategori || '-',
        m.alokasiMenit || 90,
        m.kkm || 75,
        m.status || 'Aktif',
      ]);

      const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
      ws['!cols'] = [
        { wch: 6 },  // No
        { wch: 16 }, // Kode Mapel
        { wch: 42 }, // Nama Mapel
        { wch: 18 }, // Tingkat/Fase
        { wch: 22 }, // Kategori
        { wch: 15 }, // Durasi
        { wch: 10 }, // KKM
        { wch: 12 }, // Status
      ];

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Daftar Mapel SAS');
      const dateStr = new Date().toISOString().slice(0, 10);
      XLSX.writeFile(wb, `Daftar_Mata_Pelajaran_SAS_${dateStr}.xlsx`);
      showNotice(`Berhasil mengunduh ${currentList.length} data mata pelajaran ke Excel!`);
    } catch (err: any) {
      showNotice(`Gagal mengunduh Excel: ${err?.message || 'Terjadi kesalahan'}`);
    }
  };

  const handleDeleteMapelFromSettings = (kodeToDelete: string) => {
    const currentList = Array.isArray(appConfig.mapelList)
      ? appConfig.mapelList
      : defaultMapelList;
    const itemToDelete = currentList.find((m: any) => m.kode === kodeToDelete);
    const cleanTargetKode = (kodeToDelete || '').trim().toUpperCase();
    const cleanTargetNama = (itemToDelete?.nama || '')
      .replace(/^Simulasi TKA\s*-\s*/i, '')
      .trim()
      .toLowerCase();
    const targetClass = itemToDelete ? getTargetClassFromMapel(itemToDelete) : '';

    const updatedList = currentList.filter(
      (m: { kode: string }) => m.kode !== kodeToDelete
    );
    const nextDeletedCodes = Array.from(
      new Set([
        ...(Array.isArray(appConfig.deletedMapelCodes)
          ? appConfig.deletedMapelCodes
          : []),
        ...(cleanTargetKode ? [cleanTargetKode] : []),
      ])
    );
    // Only track deletedMapelNames when no other remaining class still uses this subject name
    const stillUsedInOtherClass = updatedList.some(
      (m: any) =>
        String(m?.nama || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase() === cleanTargetNama
    );
    const nextDeletedNames = Array.from(
      new Set([
        ...(Array.isArray(appConfig.deletedMapelNames)
          ? appConfig.deletedMapelNames
          : []),
        ...(!stillUsedInOtherClass && cleanTargetNama ? [cleanTargetNama] : []),
      ])
    );

    const updatedConfig = {
      ...appConfig,
      mapelList: updatedList,
      customMapelConfigured: true,
      deletedMapelCodes: nextDeletedCodes,
      deletedMapelNames: nextDeletedNames,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });

    // Juga hapus dari daftar paket soal CBT agar sinkron di status tes (tanpa menghapus kelas lain)
    onUpdatePackages((prevPackages) => {
      const baseList = Array.isArray(prevPackages) ? prevPackages : safePackages;
      return baseList.filter((p) => {
        const pCode = (p.code || '').trim().toUpperCase();
        const pTitle = (p.title || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        if (cleanTargetKode && pCode === cleanTargetKode) return false;
        if (
          cleanTargetNama &&
          pTitle === cleanTargetNama &&
          (!targetClass || getPkgClass(p) === targetClass)
        ) {
          return false;
        }
        return true;
      });
    });

    // Juga hapus jadwal ujian yang memakai mata pelajaran & kelas yang dihapus agar tidak tetap tampil di siswa
    if (cleanTargetNama) {
      const remainingSchedules = safeSchedules.filter((sch) => {
        const schTitle = String(sch?.mapel || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        if (schTitle !== cleanTargetNama) return true;
        if (!targetClass) return false;
        return !(
          doesKelasMatch(targetClass, sch.kelas) ||
          doesKelasMatch(sch.kelas, targetClass)
        );
      });
      if (remainingSchedules.length !== safeSchedules.length) {
        onUpdateSchedules(remainingSchedules);
      }
    }

    showNotice(`Mata pelajaran ${itemToDelete?.nama || kodeToDelete} berhasil dihapus dari pengaturan & jadwal ujian.`);
  };

  const handleToggleMapelStatus = (kodeToToggle: string) => {
    const currentList = Array.isArray(appConfig.mapelList)
      ? appConfig.mapelList
      : defaultMapelList;
    let toggledItem: any = null;
    let nextStatus = 'Aktif';
    const updatedList = currentList.map((m: any) => {
      if (m.kode === kodeToToggle) {
        toggledItem = m;
        nextStatus = m.status === 'Aktif' ? 'Non Aktif' : 'Aktif';
        return { ...m, status: nextStatus };
      }
      return m;
    });
    const updatedConfig = {
      ...appConfig,
      mapelList: updatedList,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });

    if (toggledItem && nextStatus === 'Non Aktif') {
      const cleanTargetNama = String(toggledItem.nama || '')
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
      const targetClass = getTargetClassFromMapel(toggledItem);
      const nowTs = Date.now();
      let changed = false;
      const nextSchedules = safeSchedules.map((sch) => {
        const schTitle = String(sch?.mapel || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        if (
          sch.isActive &&
          schTitle === cleanTargetNama &&
          (!targetClass ||
            doesKelasMatch(targetClass, sch.kelas) ||
            doesKelasMatch(sch.kelas, targetClass))
        ) {
          changed = true;
          return { ...sch, isActive: false, updatedAt: nowTs };
        }
        return sch;
      });
      if (changed) {
        onUpdateSchedules(nextSchedules);
      }
    }
  };

  const handleAddAdminToSettings = () => {
    if (!newAdminId.trim() || !newAdminNama.trim()) {
      showNotice('Harap lengkapi ID Administrator dan Nama Lengkap.');
      return;
    }
    const cleanId = newAdminId.trim().toUpperCase();
    const currentList = Array.isArray(appConfig.adminList) ? appConfig.adminList : defaultAdminList;
    if (currentList.some((a: any) => a.adminId.toUpperCase() === cleanId)) {
      showNotice(`Administrator dengan ID ${cleanId} sudah terdaftar.`);
      return;
    }
    const finalPassword = newAdminPassword.trim() || 'SAS2026';
    const newEntry = {
      id: `adm_${Date.now()}`,
      adminId: cleanId,
      namaLengkap: newAdminNama.trim(),
      nip: newAdminNip.trim() || '-',
      email: newAdminEmail.trim() || 'admin.cbt@smadiponegorowagir.sch.id',
      noHp: newAdminNoHp.trim() || '-',
      role: newAdminRole,
      status: 'Aktif',
      password: finalPassword,
    };
    const updatedList = [...currentList, newEntry];
    const updatedConfig = {
      ...appConfig,
      adminList: updatedList,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });
    setNewAdminId('');
    setNewAdminNama('');
    setNewAdminNip('');
    setNewAdminEmail('');
    setNewAdminNoHp('');
    setNewAdminPassword('SAS2026');
    setShowAdminForm(false);
    showNotice(`Administrator ${newEntry.namaLengkap} (${cleanId}) berhasil ditambahkan dan disinkronkan!`);
  };

  const handleToggleAdminStatusInSettings = (adminIdToToggle: string) => {
    const currentList = Array.isArray(appConfig.adminList) ? appConfig.adminList : defaultAdminList;
    const targetAdmin = currentList.find((a: any) => a.adminId === adminIdToToggle);
    const activeCount = currentList.filter((a: any) => (a.status || 'Aktif') === 'Aktif').length;
    if (targetAdmin && (targetAdmin.status || 'Aktif') === 'Aktif' && activeCount <= 1) {
      showNotice('Minimal harus terdapat 1 akun administrator dengan status Aktif.');
      return;
    }
    const updatedList = currentList.map((a: any) =>
      a.adminId === adminIdToToggle
        ? { ...a, status: a.status === 'Aktif' ? 'Non Aktif' : 'Aktif' }
        : a
    );
    const updatedConfig = {
      ...appConfig,
      adminList: updatedList,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });
    showNotice(`Status aktif administrator ${adminIdToToggle} berhasil diperbarui dan disinkronkan.`);
  };

  const handleSaveAdminPassword = (adminIdToUpdate: string) => {
    const cleanNewPass = editingAdminPassValue.trim();
    if (!cleanNewPass || cleanNewPass.length < 4) {
      showNotice('Password Administrator minimal 4 karakter.');
      return;
    }
    const currentList = Array.isArray(appConfig.adminList) ? appConfig.adminList : defaultAdminList;
    const updatedList = currentList.map((a: any) =>
      a.adminId === adminIdToUpdate ? { ...a, password: cleanNewPass } : a
    );
    const updatedConfig = {
      ...appConfig,
      adminList: updatedList,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });
    setEditingAdminPassId(null);
    setEditingAdminPassValue('');
    showNotice(`Password administrator ${adminIdToUpdate} berhasil diperbarui dan disinkronkan.`);
  };

  const handleDeleteAdminFromSettings = (adminIdToDelete: string) => {
    const currentList = Array.isArray(appConfig.adminList) ? appConfig.adminList : defaultAdminList;
    if (currentList.length <= 1) {
      showNotice('Minimal harus terdapat 1 akun administrator utama aktif.');
      return;
    }
    const remaining = currentList.filter((a: any) => a.adminId !== adminIdToDelete);
    if (!remaining.some((a: any) => (a.status || 'Aktif') === 'Aktif')) {
      showNotice('Tidak dapat menghapus: minimal 1 administrator aktif harus tersisa.');
      return;
    }
    const updatedConfig = {
      ...appConfig,
      adminList: remaining,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });
    showNotice(`Administrator ${adminIdToDelete} berhasil dihapus dan disinkronkan.`);
  };

  const handleAddKelasToSettings = () => {
    if (!newPengaturanKelasKode.trim()) {
      showNotice('Harap ketik kode/nama kelas terlebih dahulu.');
      return;
    }
    const cleanKode = newPengaturanKelasKode.trim().toUpperCase();
    const currentList = Array.isArray(appConfig.kelasList) ? appConfig.kelasList : defaultKelasList;
    if (currentList.some((k: { kode: string }) => k.kode.toUpperCase() === cleanKode)) {
      showNotice(`Kelas ${cleanKode} sudah ada dalam daftar.`);
      return;
    }
    const newEntry = {
      kode: cleanKode,
      tingkat: newPengaturanKelasTingkat,
      jurusan: newPengaturanKelasJurusan,
      ruang: newPengaturanKelasRuang,
      sesi: newPengaturanKelasSesi,
      status: 'Aktif',
    };
    const updatedList = [...currentList, newEntry];
    const updatedDaftar = updatedList.map((k: { kode: string }) => k.kode).join(', ');
    persistAdminConfig(
      {
        ...appConfig,
        kelasList: updatedList,
        daftarKelas: updatedDaftar,
      },
      { syncCloud: true }
    );
    setNewPengaturanKelasKode('');
    showNotice(`Kolom kelas ${cleanKode} berhasil ditambahkan dan disinkronkan!`);
  };

  const handleDeleteKelasFromSettings = (kodeToDelete: string) => {
    const currentList = Array.isArray(appConfig.kelasList) ? appConfig.kelasList : defaultKelasList;
    const updatedList = currentList.filter((k: { kode: string }) => k.kode !== kodeToDelete);
    const updatedDaftar = updatedList.map((k: { kode: string }) => k.kode).join(', ');
    persistAdminConfig(
      {
        ...appConfig,
        kelasList: updatedList,
        daftarKelas: updatedDaftar,
      },
      { syncCloud: true }
    );
    showNotice(`Kelas ${kodeToDelete} berhasil dihapus dari pengaturan dan disinkronkan.`);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    persistAdminConfig(appConfig, { syncCloud: true });
    try {
      if (appConfig.namaProktor && proctors.length > 0) {
        setProctors((prev) =>
          prev.map((pr, idx) =>
            idx === 0 ? { ...pr, fullName: (appConfig.namaProktor || '').toUpperCase() } : pr
          )
        );
      }
    } catch {
      // ignore
    }
    showNotice('Pengaturan sistem ujian SAS berhasil disimpan dan diterapkan!');
  };

  const handleExportSettings = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(appConfig, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `pengaturan_sas_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showNotice('File backup pengaturan berhasil diunduh.');
  };

  const handleResetSettings = () => {
    persistAdminConfig(defaultAdminConfig, { syncCloud: true });
    showNotice('Pengaturan dikembalikan ke konfigurasi standar.');
  };

  const showNotice = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 2600);
  };

  const filteredRows = useMemo(() => {
    return participants
      .filter((row) => {
        const isAktif = isParticipantStatusActive(row.status);
        if (appliedStatus === 'Non Aktif' && isAktif) {
          return false;
        }
        if (appliedStatus === 'Aktif' && !isAktif) {
          return false;
        }
        if (appliedKodeTes !== 'SEMUA' && row.kodeTes && row.kodeTes !== appliedKodeTes) {
          return false;
        }
        if (
          appliedKelompok !== 'SEMUA' &&
          resolveParticipantRuang(row) !== appliedKelompok
        ) {
          return false;
        }
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchUser = String(row.username ?? '').toLowerCase().includes(q);
          const matchName = String(row.namaPeserta ?? '').toLowerCase().includes(q);
          const matchRuang = resolveParticipantRuang(row).toLowerCase().includes(q);
          if (!matchUser && !matchName && !matchRuang) return false;
        }
        return true;
      })
      .sort((a, b) =>
        resolveParticipantRuang(a).localeCompare(resolveParticipantRuang(b), 'id', {
          numeric: true,
        })
      );
  }, [
    participants,
    appliedStatus,
    appliedKodeTes,
    appliedKelompok,
    searchQuery,
  ]);

  const [selectedParticipantIds, setSelectedParticipantIds] = useState<
    Set<string>
  >(() => new Set());

  const allVisibleSelected =
    filteredRows.length > 0 &&
    filteredRows.every((r) => selectedParticipantIds.has(r.id));

  const selectedVisibleCount = useMemo(
    () => participants.filter((r) => selectedParticipantIds.has(r.id)).length,
    [participants, selectedParticipantIds]
  );

  const handleApplyFilter = () => {
    setAppliedStatus(filterStatus);
    setAppliedKodeTes(filterKodeTes);
    setAppliedKelompok(filterKelompok);
    showNotice('Filter Ruang Ujian pada Kelompok Tes berhasil diterapkan.');
  };

  const handleMoveSelectedToRuang = (explicitRuang?: string) => {
    const selectedRows = participants.filter((r) =>
      selectedParticipantIds.has(r.id)
    );
    if (selectedRows.length === 0) {
      showNotice(
        'Klik tombol centang biru untuk memilih minimal satu siswa terlebih dahulu.'
      );
      return;
    }
    const destinationRuang =
      explicitRuang && explicitRuang !== 'SEMUA'
        ? explicitRuang
        : targetMoveRuang || 'Ruang 2';

    const selectedIdSet = new Set(selectedRows.map((r) => r.id));
    const nowTs = Date.now();
    setParticipants((prev) =>
      prev.map((r) =>
        selectedIdSet.has(r.id)
          ? {
              ...r,
              ruang: destinationRuang,
              kelompok: destinationRuang,
              selected: false,
              metaUpdatedAt: nowTs,
            }
          : r
      )
    );
    setSelectedParticipantIds((prev) => {
      const next = new Set(prev);
      selectedIdSet.forEach((id) => next.delete(id));
      return next;
    });
    showNotice(
      `${selectedRows.length} siswa berhasil dipindahkan ke ${destinationRuang} (juga diperbarui pada Kartu Login Peserta).`
    );
  };

  const handleToggleSelectAll = () => {
    const targetVal = !allVisibleSelected;
    setSelectedParticipantIds((prev) => {
      const next = new Set(prev);
      filteredRows.forEach((r) => {
        if (targetVal) {
          next.add(r.id);
        } else {
          next.delete(r.id);
        }
      });
      return next;
    });
  };

  const handleToggleRow = (id: string) => {
    setSelectedParticipantIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleAssignSelected = () => {
    const visibleSelectedIds = new Set(
      filteredRows.filter((r) => selectedParticipantIds.has(r.id)).map((r) => r.id)
    );
    const selectedCount = visibleSelectedIds.size;
    if (selectedCount === 0) {
      showNotice('Centang minimal satu peserta terlebih dahulu.');
      return;
    }
    const nowTs = Date.now();
    setParticipants((prev) =>
      prev.map((r) =>
        visibleSelectedIds.has(r.id)
          ? {
              ...r,
              status: 'Active',
              metaUpdatedAt: Math.max((r.metaUpdatedAt || 0) + 1, nowTs),
            }
          : r
      )
    );
    setFilterStatus('Semua Status');
    setAppliedStatus('Semua Status');
    showNotice(`${selectedCount} peserta berhasil di-Assign (Status: Active).`);
  };

  const handleUnassignSelected = () => {
    const visibleSelectedIds = new Set(
      filteredRows.filter((r) => selectedParticipantIds.has(r.id)).map((r) => r.id)
    );
    const selectedCount = visibleSelectedIds.size;
    if (selectedCount === 0) {
      showNotice('Centang minimal satu peserta terlebih dahulu.');
      return;
    }
    const nowTs = Date.now();
    setParticipants((prev) =>
      prev.map((r) =>
        visibleSelectedIds.has(r.id)
          ? {
              ...r,
              status: 'Non Active',
              metaUpdatedAt: Math.max((r.metaUpdatedAt || 0) + 1, nowTs),
            }
          : r
      )
    );
    setFilterStatus('Semua Status');
    setAppliedStatus('Semua Status');
    showNotice(`${selectedCount} peserta diubah menjadi Non Active.`);
  };

  const handleResetAll = () => {
    setFilterStatus('Semua Status');
    setFilterKodeTes('SEMUA');
    setFilterKelompok('SEMUA');
    setAppliedStatus('Semua Status');
    setAppliedKodeTes('SEMUA');
    setAppliedKelompok('SEMUA');
    setSearchQuery('');
    showNotice('Filter telah di-reset ke Semua Status dan Semua Kelompok.');
  };

  const handleAddParticipant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newParticipantName.trim()) return;
    const nowTs = Date.now();
    const newRow: ProctorParticipantRow = {
      id: `ap_${nowTs}`,
      selected: false,
      status: 'Non Active',
      kodeTes: 'SAS26SMADIP1',
      username: autoGeneratedUsername,
      password: autoGeneratedPassword,
      namaPeserta: newParticipantName.trim().toUpperCase(),
      kelompok: '1',
      kelas: newParticipantKelas,
      loginState: 'Belum Login',
      metaUpdatedAt: nowTs,
    };
    setParticipants((prev) => [...prev, newRow]);
    setSelectedParticipantIds((prev) => {
      const next = new Set(prev);
      next.add(newRow.id);
      return next;
    });
    setNewParticipantName('');
    showNotice(
      `Peserta ${newRow.namaPeserta} (Kelas ${newRow.kelas}) berhasil ditambahkan (Username: ${newRow.username} | Password: ${newRow.password}).`
    );
  };

  const handleDownloadTemplateExcel = () => {
    const sampleRows = [
      { 'Nama Siswa': 'M. REIHAN ALFARIZI', Kelas: 'X' },
      { 'Nama Siswa': 'SITI AISYAH PUTRI', Kelas: 'X' },
      { 'Nama Siswa': 'BAGAS ADITYA NUGRAHA', Kelas: 'XI IPA' },
      { 'Nama Siswa': 'PUTRI AYU NINGTYAS', Kelas: 'XI IPS' },
      { 'Nama Siswa': 'AUREL RIZKY ADI PRATAMA', Kelas: 'XII IPA' },
      { 'Nama Siswa': 'AHMAD DENY FIKRUDIN', Kelas: 'XII IPS' },
    ];
    const worksheet = XLSX.utils.json_to_sheet(sampleRows);
    worksheet['!cols'] = [{ wch: 34 }, { wch: 16 }];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Daftar Peserta');
    XLSX.writeFile(workbook, 'Format_Upload_Daftar_Peserta_SAS.xlsx');
    showNotice('Format Template Excel (Nama Siswa & Kelas) berhasil diunduh.');
  };

  const handleUploadParticipantExcel = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result;
        if (!buffer) return;

        const workbook = XLSX.read(buffer, { type: 'array' });
        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          showNotice('File Excel kosong atau tidak memiliki lembar kerja.');
          return;
        }

        const parsedEntries: Array<{ namaPeserta: string; kelas: string }> = [];

        workbook.SheetNames.forEach((sheetName) => {
          const worksheet = workbook.Sheets[sheetName];
          if (!worksheet) return;

          const rawRows = XLSX.utils.sheet_to_json<any[]>(worksheet, {
            header: 1,
            defval: '',
          });

          const nonEmptyRows = rawRows.filter(
            (row) =>
              Array.isArray(row) &&
              row.some((cell) => String(cell ?? '').trim() !== '')
          );

          if (nonEmptyRows.length === 0) return;

          // Deteksi baris header jika ada kolom bertuliskan "Nama" / "Nama Siswa" dan "Kelas"
          let startRowIdx = 0;
          let namaColIdx = 0;
          let kelasColIdx = 1;

          const firstRowCells = nonEmptyRows[0].map((c) =>
            String(c ?? '')
              .trim()
              .toLowerCase()
          );

          const detectedNamaIdx = firstRowCells.findIndex(
            (c) =>
              c.includes('nama') ||
              c.includes('siswa') ||
              c.includes('peserta') ||
              c === 'student' ||
              c === 'name'
          );
          const detectedKelasIdx = firstRowCells.findIndex(
            (c) =>
              c.includes('kelas') ||
              c.includes('rombel') ||
              c.includes('tingkat') ||
              c === 'class'
          );

          if (detectedNamaIdx !== -1 || detectedKelasIdx !== -1) {
            startRowIdx = 1;
            if (detectedNamaIdx !== -1) {
              namaColIdx = detectedNamaIdx;
            } else {
              namaColIdx = detectedKelasIdx === 0 ? 1 : 0;
            }
            if (detectedKelasIdx !== -1) {
              kelasColIdx = detectedKelasIdx;
            } else {
              kelasColIdx = namaColIdx === 0 ? 1 : 0;
            }
          } else if (
            firstRowCells.length >= 3 &&
            (firstRowCells[0] === 'no' ||
              firstRowCells[0] === 'no.' ||
              firstRowCells[0] === 'nomor')
          ) {
            startRowIdx = 1;
            namaColIdx = 1;
            kelasColIdx = 2;
          }

          const dataRows = nonEmptyRows.slice(startRowIdx);

          dataRows.forEach((row) => {
            let rawNama = String(row[namaColIdx] ?? '').trim();
            let rawKelas = String(row[kelasColIdx] ?? '').trim();

            // Jika baris memiliki kolom nomor di paling kiri tanpa header
            if (
              detectedNamaIdx === -1 &&
              row.length >= 3 &&
              /^\d+$/.test(rawNama) &&
              String(row[1] ?? '').trim() !== ''
            ) {
              rawNama = String(row[1] ?? '').trim();
              rawKelas = String(row[2] ?? '').trim();
            }

            if (!rawNama) return;

            // Normalisasi penulisan kelas (mis. "Kelas X" -> "X", "Kelas XII IPA" -> "XII IPA")
            let cleanKelas = rawKelas
              .replace(/^kelas\s+/i, '')
              .trim()
              .toUpperCase();
            if (!cleanKelas) {
              const sheetKelasFallback = sheetName
                .replace(/^(daftar\s+peserta|sheet\d*|data|siswa|kelas)\s*/i, '')
                .trim()
                .toUpperCase();
              cleanKelas = sheetKelasFallback || newParticipantKelas || 'X';
            }

            parsedEntries.push({
              namaPeserta: rawNama.toUpperCase(),
              kelas: cleanKelas,
            });
          });
        });

        if (parsedEntries.length === 0) {
          showNotice(
            'Tidak ada baris Nama Siswa & Kelas yang valid pada file Excel tersebut.'
          );
          return;
        }

        // Jika daftar peserta saat ini masih murni data contoh awal (bawaan sistem),
        // maka upload pertama menggantikan data contoh awal.
        // Namun jika sudah ada data kelas hasil upload / tambah sebelumnya,
        // upload kelas berikutnya otomatis melanjutkan di bawah kelas sebelumnya (tidak menimpa).
        const isStillInitialDefaultOnly =
          isDefaultDemoParticipantsList(participants);

        const baseParticipants = isStillInitialDefaultOnly
          ? []
          : participants.filter((p) => !isDefaultDemoParticipantRow(p));

        // Hasilkan angka acak unik untuk format username SA2026(ANGKA ACAK)
        const usedUsernames = new Set<string>(
          baseParticipants.map((p) => p.username.trim().toUpperCase())
        );
        const existingKeys = new Set<string>();
        baseParticipants.forEach((p) => {
          const nk = getParticipantNameKelasKey(p);
          if (nk) existingKeys.add(nk);
        });

        // Cek cadangan lokal jika ada riwayat peserta sebelumnya agar username/password tetap konsisten saat upload ulang
        const backupByNameKelas = new Map<string, ProctorParticipantRow>();
        try {
          const backupRaw = localStorage.getItem(
            'pusmendik_cbt_participants_backup_v1'
          );
          if (backupRaw) {
            const backupParsed = JSON.parse(backupRaw);
            if (Array.isArray(backupParsed)) {
              backupParsed.forEach((bp: ProctorParticipantRow) => {
                const nk = getParticipantNameKelasKey(bp);
                if (nk && !isDefaultDemoParticipantRow(bp)) {
                  backupByNameKelas.set(nk, bp);
                }
              });
            }
          }
        } catch {
          // ignore
        }

        const nowTs = Date.now();
        const appendedParticipants: ProctorParticipantRow[] = [];

        parsedEntries.forEach((entry, idx) => {
          const compositeKey = getParticipantNameKelasKey({
            namaPeserta: entry.namaPeserta,
            kelas: entry.kelas,
          });
          if (compositeKey && existingKeys.has(compositeKey)) {
            return;
          }
          if (compositeKey) {
            existingKeys.add(compositeKey);
          }

          const backupMatch = compositeKey
            ? backupByNameKelas.get(compositeKey)
            : undefined;
          let newUsername = '';
          let newPassword = '';
          let newId = `excel_${nowTs}_${idx}`;

          if (
            backupMatch &&
            backupMatch.username &&
            !usedUsernames.has(backupMatch.username.trim().toUpperCase())
          ) {
            newUsername = backupMatch.username.trim().toUpperCase();
            const codeDigits = newUsername.replace(/^SA2026/, '') || '4821';
            newPassword = backupMatch.password || `SMADIP${codeDigits}*`;
            newId = backupMatch.id || newId;
            usedUsernames.add(newUsername);
          } else {
            let randCode = Math.floor(1000 + Math.random() * 9000);
            while (usedUsernames.has(`SA2026${randCode}`)) {
              randCode = 1000 + ((randCode + 317) % 9000);
            }
            newUsername = `SA2026${randCode}`;
            newPassword = `SMADIP${randCode}*`;
            usedUsernames.add(newUsername);
          }

          appendedParticipants.push({
            id: newId,
            selected: true,
            status: backupMatch?.status || 'Non Active',
            kodeTes: 'SAS26SMADIP1',
            username: newUsername,
            password: newPassword,
            namaPeserta: entry.namaPeserta,
            kelompok: backupMatch?.kelompok || '1',
            ruang: backupMatch?.ruang,
            kelas: entry.kelas,
            loginState: backupMatch?.loginState || 'Belum Login',
            metaUpdatedAt: nowTs,
          });
        });

        const combinedParticipants = sanitizeParticipantRows([
          ...baseParticipants,
          ...appendedParticipants,
        ]);

        setParticipants(combinedParticipants);
        setFilterStatus('Semua Status');
        setAppliedStatus('Semua Status');

        const uploadedClasses = Array.from(
          new Set(parsedEntries.map((item) => item.kelas))
        ).join(', ');

        const info = {
          fileName: file.name,
          count: combinedParticipants.length,
          uploadedAt: new Date().toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
          }),
        };
        setUploadedExcelInfo(info);
        try {
          localStorage.setItem(
            'pusmendik_cbt_excel_info_v1',
            JSON.stringify(info)
          );
        } catch {
          // ignore storage error
        }

        if (baseParticipants.length > 0 && appendedParticipants.length > 0) {
          showNotice(
            `Berhasil menambahkan ${appendedParticipants.length} siswa (Kelas ${uploadedClasses}) di bawah daftar sebelumnya. Total: ${combinedParticipants.length} peserta.`
          );
        } else if (
          baseParticipants.length > 0 &&
          appendedParticipants.length === 0
        ) {
          showNotice(
            `Data siswa pada "${file.name}" (Kelas ${uploadedClasses}) sudah ada dalam daftar peserta.`
          );
        } else {
          showNotice(
            `Berhasil mengunggah "${file.name}": ${appendedParticipants.length} siswa (Kelas ${uploadedClasses}) telah dimuat ke Daftar Peserta!`
          );
        }
      } catch {
        showNotice(
          'Gagal membaca file Excel. Pastikan file berformat .xlsx, .xls, atau .csv dengan kolom Nama Siswa dan Kelas.'
        );
      } finally {
        if (excelInputRef.current) {
          excelInputRef.current.value = '';
        }
      }
    };

    reader.readAsArrayBuffer(file);
  };

  const displayPackages = useMemo(() => {
    const currentMapelList = Array.isArray(appConfig.mapelList)
      ? appConfig.mapelList
      : defaultMapelList;
    const deletedCodesSet = new Set<string>(
      Array.isArray(appConfig.deletedMapelCodes)
        ? appConfig.deletedMapelCodes.map((c) => String(c ?? '').trim().toUpperCase())
        : []
    );
    const deletedNamesSet = new Set<string>(
      Array.isArray(appConfig.deletedMapelNames)
        ? appConfig.deletedMapelNames.map((n) => String(n ?? '').trim().toLowerCase())
        : []
    );

    const result: ExamPackage[] = [];
    const processedPkgIds = new Set<string>();

    currentMapelList.forEach((mapel: any) => {
      if (!mapel || typeof mapel !== 'object') return;
      const cleanKode = String(mapel.kode ?? '').trim().toUpperCase();
      const cleanNama = String(mapel.nama ?? '')
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
      if (cleanKode && deletedCodesSet.has(cleanKode)) return;
      if (cleanNama && deletedNamesSet.has(cleanNama)) return;

      const newPkgId = 'mapel_pkg_' + cleanKode.toLowerCase().replace(/[^a-z0-9]/g, '_');

      const targetClass = getTargetClassFromMapel(mapel);

      const existing = safePackages.find((p) => {
        if (!p || typeof p !== 'object' || processedPkgIds.has(p.id)) return false;
        if (p.id === newPkgId) return true;
        const pCode = String(p.code ?? '').trim().toUpperCase();
        const pTitle = String(p.title ?? '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        if (cleanKode.length > 0 && pCode === cleanKode) return true;
        if (
          cleanNama.length > 0 &&
          pTitle === cleanNama &&
          getPkgClass(p) === targetClass
        ) {
          return true;
        }
        return false;
      });

      if (existing && !processedPkgIds.has(existing.id)) {
        processedPkgIds.add(existing.id);
        const cleanedQuestions = stripDemoSampleIfUploadedPresent(
          existing.questions
        );
        result.push({
          ...existing,
          code: String(mapel.kode ?? existing.code ?? ''),
          title: String(mapel.nama ?? existing.title ?? ''),
          durationMinutes: Number(mapel.alokasiMenit) || existing.durationMinutes || 90,
          subtest: String(mapel.kategori ?? existing.subtest ?? 'Wajib Umum'),
          targetClass: targetClass,
          questions: cleanedQuestions,
        });
      } else if (!processedPkgIds.has(newPkgId)) {
        processedPkgIds.add(newPkgId);
        result.push({
          id: newPkgId,
          code: String(mapel.kode ?? 'MAPEL-01'),
          title: String(mapel.nama ?? 'Mata Pelajaran Ujian'),
          level: 'SMA / MA / SMK / Sederajat',
          subtest: String(mapel.kategori ?? 'Wajib Umum'),
          durationMinutes: Number(mapel.alokasiMenit) || 90,
          targetClass: targetClass,
          questions: [],
        });
      }
    });

    safePackages.forEach((pkg) => {
      if (!pkg || typeof pkg !== 'object') return;
      if (!processedPkgIds.has(pkg.id)) {
        const pCode = String(pkg.code ?? '').trim().toUpperCase();
        const pTitle = String(pkg.title ?? '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        if (pCode && deletedCodesSet.has(pCode)) return;
        if (pTitle && deletedNamesSet.has(pTitle)) return;

        processedPkgIds.add(pkg.id);
        const cleanedQuestions = stripDemoSampleIfUploadedPresent(
          pkg.questions
        );
        result.push({
          ...pkg,
          questions: cleanedQuestions,
        });
      }
    });

    return result;
  }, [
    appConfig.mapelList,
    appConfig.deletedMapelCodes,
    appConfig.deletedMapelNames,
    safePackages,
  ]);

  const visiblePackagesForKelas = useMemo(() => {
    if (statusTesKelas === 'Semua Kelas') return displayPackages;
    return displayPackages.filter((p) => getPkgClass(p) === statusTesKelas);
  }, [displayPackages, statusTesKelas]);

  const fallbackEmptyPackage: ExamPackage = useMemo(
    () => ({
      id: 'pkg_empty_fallback',
      code: 'MAPEL-00',
      title: 'Belum Ada Mata Pelajaran',
      level: 'SMA / MA / SMK / Sederajat',
      subtest: 'Wajib Umum',
      durationMinutes: 90,
      targetClass: statusTesKelas !== 'Semua Kelas' ? statusTesKelas : 'Kelas X',
      questions: [],
    }),
    [statusTesKelas]
  );

  const selectedPackage: ExamPackage =
    visiblePackagesForKelas.find((p) => p.id === selectedPkgId) ||
    visiblePackagesForKelas[0] ||
    fallbackEmptyPackage;

  const [lastUploadedWordFile, setLastUploadedWordFile] = useState<string>('');

  const syncSelectedPackageQuestions = (nextQuestions: Question[]) => {
    if (!selectedPackage || selectedPackage.id === 'pkg_empty_fallback') return;
    const renumbered = nextQuestions.map((q, idx) => ({
      ...q,
      number: idx + 1,
    }));
    const preservedClass = getPkgClass(selectedPackage);
    const updatedSelectedPackage: ExamPackage = {
      ...selectedPackage,
      targetClass: preservedClass,
      questions: renumbered,
      questionsUpdatedAt: Date.now(),
    };
    const cleanSelectedKode = (selectedPackage.code || '').trim().toUpperCase();
    const cleanSelectedNama = (selectedPackage.title || '')
      .replace(/^Simulasi TKA\s*-\s*/i, '')
      .trim()
      .toLowerCase();

    onUpdatePackages((prevPackages) => {
      const baseList = Array.isArray(prevPackages) ? prevPackages : packages;
      let matched = false;
      const nextList: ExamPackage[] = [];

      baseList.forEach((pkg) => {
        const pCode = (pkg.code || '').trim().toUpperCase();
        const pTitle = (pkg.title || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        const isExactMatch =
          !matched &&
          (pkg.id === selectedPackage.id ||
            (cleanSelectedKode.length > 0 && pCode === cleanSelectedKode) ||
            (cleanSelectedNama.length > 0 &&
              pTitle === cleanSelectedNama &&
              getPkgClass(pkg) === preservedClass));

        if (isExactMatch) {
          matched = true;
          nextList.push({
            ...updatedSelectedPackage,
            id: pkg.id,
            targetClass: preservedClass,
          });
        } else {
          nextList.push(pkg);
        }
      });

      if (!matched) {
        nextList.push(updatedSelectedPackage);
      }
      return nextList;
    });
  };

  const handleDeleteQuestion = (
    qId: string,
    qNumber?: number,
    targetQuestion?: Question
  ) => {
    if (!selectedPackage) return;
    let deletedOne = false;
    const filtered = selectedPackage.questions.filter((item) => {
      if (deletedOne) return true;
      if (targetQuestion && item === targetQuestion) {
        deletedOne = true;
        return false;
      }
      if (qId && item.id === qId) {
        deletedOne = true;
        return false;
      }
      if (qNumber !== undefined && item.number === qNumber) {
        deletedOne = true;
        return false;
      }
      return true;
    });
    syncSelectedPackageQuestions(filtered);
    if (filtered.length === 0) {
      setLastUploadedWordFile('');
    }
    showNotice('Butir soal berhasil dihapus.');
  };

  const handleDeleteAllQuestions = () => {
    if (!selectedPackage || selectedPackage.questions.length === 0) return;
    if (statusTesTipeSoal === 'Semua Tipe Soal') {
      syncSelectedPackageQuestions([]);
      setLastUploadedWordFile('');
      showNotice(
        `Seluruh butir soal pada mata pelajaran ${selectedPackage.title} berhasil dihapus.`
      );
    } else {
      const remaining = selectedPackage.questions.filter(
        (q) => q.type !== statusTesTipeSoal
      );
      syncSelectedPackageQuestions(remaining);
      if (remaining.length === 0) {
        setLastUploadedWordFile('');
      }
      showNotice(
        `Seluruh soal tipe ${getQuestionTypeLabel(statusTesTipeSoal as QuestionType)} berhasil dihapus.`
      );
    }
  };

  const handleDeletePackageQuestions = (targetPkg: ExamPackage) => {
    if (!targetPkg || targetPkg.id === 'pkg_empty_fallback') return;
    const preservedClass = getPkgClass(targetPkg);
    const cleanTargetKode = (targetPkg.code || '').trim().toUpperCase();
    const cleanTargetNama = (targetPkg.title || '')
      .replace(/^Simulasi TKA\s*-\s*/i, '')
      .trim()
      .toLowerCase();
    const displayTitle = (targetPkg.title || '')
      .replace(/^Simulasi TKA\s*-\s*/i, '')
      .replace(/\s*\(SMA\/MA\/SMK\)/i, '');

    onUpdatePackages((prevPackages) => {
      const baseList = Array.isArray(prevPackages) ? prevPackages : safePackages;
      return baseList.map((pkg) => {
        const pCode = (pkg.code || '').trim().toUpperCase();
        const pTitle = (pkg.title || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        const isTarget =
          pkg.id === targetPkg.id ||
          (cleanTargetKode.length > 0 && pCode === cleanTargetKode) ||
          (cleanTargetNama.length > 0 &&
            pTitle === cleanTargetNama &&
            getPkgClass(pkg) === preservedClass);
        if (!isTarget) return pkg;
        return {
          ...pkg,
          targetClass: preservedClass,
          questions: [],
          questionsUpdatedAt: Date.now(),
        };
      });
    });

    if (selectedPackage?.id === targetPkg.id) {
      setLastUploadedWordFile('');
      setShowQuestionPreviewModal(false);
    }
    showNotice(
      `Seluruh butir soal pada mata pelajaran ${displayTitle} berhasil dihapus.`
    );
  };

  const handleDeleteMapelPackage = (pkgToDelete: ExamPackage) => {
    const pkgTitle = (pkgToDelete.title || '')
      .replace(/^Simulasi TKA\s*-\s*/i, '')
      .replace(/\s*\(SMA\/MA\/SMK\)/i, '');
    const cleanTargetKode = (pkgToDelete.code || '').trim().toUpperCase();
    const cleanTargetNama = (pkgToDelete.title || '')
      .replace(/^Simulasi TKA\s*-\s*/i, '')
      .trim()
      .toLowerCase();
    const targetClass = getPkgClass(pkgToDelete);

    // 1. Hapus terlebih dahulu dari appConfig.mapelList & sinkronkan agar onUpdatePackages membaca snapshot terbaru
    const currentMapelList = Array.isArray(appConfig.mapelList)
      ? appConfig.mapelList
      : defaultMapelList;
    const updatedMapelList = currentMapelList.filter((m: any) => {
      const mKode = String(m?.kode || '').trim().toUpperCase();
      const mNama = String(m?.nama || '')
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
      if (cleanTargetKode && mKode === cleanTargetKode) return false;
      if (
        cleanTargetNama &&
        mNama === cleanTargetNama &&
        getTargetClassFromMapel(m) === targetClass
      ) {
        return false;
      }
      return true;
    });

    const nextDeletedCodes = Array.from(
      new Set([
        ...(Array.isArray(appConfig.deletedMapelCodes)
          ? appConfig.deletedMapelCodes
          : []),
        ...(cleanTargetKode ? [cleanTargetKode] : []),
      ])
    );
    const stillUsedInOtherClass = updatedMapelList.some(
      (m: any) =>
        String(m?.nama || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase() === cleanTargetNama
    );
    const nextDeletedNames = Array.from(
      new Set([
        ...(Array.isArray(appConfig.deletedMapelNames)
          ? appConfig.deletedMapelNames
          : []),
        ...(!stillUsedInOtherClass && cleanTargetNama ? [cleanTargetNama] : []),
      ])
    );

    const updatedConfig = {
      ...appConfig,
      mapelList: updatedMapelList,
      customMapelConfigured: true,
      deletedMapelCodes: nextDeletedCodes,
      deletedMapelNames: nextDeletedNames,
    };
    persistAdminConfig(updatedConfig, { syncCloud: true });

    // 2. Hapus dari packages (hanya untuk mapel & kelas yang cocok)
    onUpdatePackages((prevPackages) => {
      const baseList = Array.isArray(prevPackages) ? prevPackages : safePackages;
      return baseList.filter((p) => {
        if (p.id === pkgToDelete.id) return false;
        const pCode = (p.code || '').trim().toUpperCase();
        const pTitle = (p.title || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        if (cleanTargetKode && pCode === cleanTargetKode) return false;
        if (
          cleanTargetNama &&
          pTitle === cleanTargetNama &&
          getPkgClass(p) === targetClass
        ) {
          return false;
        }
        return true;
      });
    });

    // 3. Hapus juga jadwal ujian terkait mapel & kelas ini agar tidak tetap tampil di Konfirmasi Data Peserta
    if (cleanTargetNama) {
      const remainingSchedules = safeSchedules.filter((sch) => {
        const schTitle = String(sch?.mapel || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
        if (schTitle !== cleanTargetNama) return true;
        if (!targetClass) return false;
        return !(
          doesKelasMatch(targetClass, sch.kelas) ||
          doesKelasMatch(sch.kelas, targetClass)
        );
      });
      if (remainingSchedules.length !== safeSchedules.length) {
        onUpdateSchedules(remainingSchedules);
      }
    }

    // 4. Update selectedPkgId jika yang dihapus sedang dipilih
    const remainingVisible = displayPackages.filter((p) => p.id !== pkgToDelete.id);
    if (selectedPkgId === pkgToDelete.id) {
      setSelectedPkgId(
        remainingVisible.length > 0 ? remainingVisible[0].id : 'pkg_empty_fallback'
      );
    }

    showNotice(`Mata pelajaran "${pkgTitle}" (${pkgToDelete.code}) beserta jadwal terkait berhasil dihapus dan disinkronkan.`);
  };

  const handleAddQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPackage) {
      return;
    }
    if (!newQuestionText.trim()) {
      if (
        lastUploadedWordFile ||
        selectedPackage.questions.some((q) => q.id.startsWith('word_q_'))
      ) {
        showNotice(
          'Data soal dan jawaban dari file Word sudah tersimpan otomatis di Bank Soal (kolom pertanyaan & jawaban manual tidak perlu diisi).'
        );
      } else {
        showNotice(
          'Silakan klik tombol "Upload Word" untuk mengunggah soal, atau ketik pertanyaan soal jika ingin menambah manual.'
        );
      }
      return;
    }

    const baseQuestions = selectedPackage.questions.filter(
      (q) => !isDefaultSampleQuestion(q)
    );
    const nextNumber = baseQuestions.length + 1;
    const stimulusFields = {
      ...(newStimulusTitle.trim()
        ? { stimulusTitle: newStimulusTitle.trim() }
        : {}),
      ...(newStimulusText.trim()
        ? { stimulusText: newStimulusText.trim() }
        : {}),
    };
    let newQuestion: Question;

    if (newQuestionType === 'pilihan_ganda') {
      newQuestion = {
        id: `admin_q_${Date.now()}`,
        number: nextNumber,
        type: 'pilihan_ganda',
        category: newCategory.trim() || 'Sumatif Akhir Semester',
        ...stimulusFields,
        questionText: newQuestionText.trim(),
        instructionText: 'Pilih satu jawaban yang paling tepat!',
        options: [
          { id: 'A', text: optA.trim() || 'Pilihan A' },
          { id: 'B', text: optB.trim() || 'Pilihan B' },
          { id: 'C', text: optC.trim() || 'Pilihan C' },
          { id: 'D', text: optD.trim() || 'Pilihan D' },
          { id: 'E', text: optE.trim() || 'Pilihan E' },
        ],
        correctOptionId: correctOpt,
        points: 10,
        explanation: `Kunci jawaban yang benar adalah opsi ${correctOpt}.`,
      };
    } else if (newQuestionType === 'pilihan_ganda_kompleks') {
      const finalCorrectIds =
        complexCorrectOpts.length > 0 ? complexCorrectOpts : ['A'];
      newQuestion = {
        id: `admin_q_${Date.now()}`,
        number: nextNumber,
        type: 'pilihan_ganda_kompleks',
        category: newCategory.trim() || 'Sumatif Akhir Semester',
        ...stimulusFields,
        questionText: newQuestionText.trim(),
        instructionText: 'Pilihlah lebih dari satu jawaban yang benar!',
        options: [
          { id: 'A', text: optA.trim() || 'Pilihan A' },
          { id: 'B', text: optB.trim() || 'Pilihan B' },
          { id: 'C', text: optC.trim() || 'Pilihan C' },
          { id: 'D', text: optD.trim() || 'Pilihan D' },
          { id: 'E', text: optE.trim() || 'Pilihan E' },
        ],
        correctOptionIds: finalCorrectIds,
        points: 10,
        explanation: `Kunci jawaban yang benar adalah opsi: ${finalCorrectIds.join(', ')}.`,
      };
    } else if (newQuestionType === 'menjodohkan') {
      const rawPairs = [
        { p: matchPremise1.trim(), r: matchResponse1.trim() },
        { p: matchPremise2.trim(), r: matchResponse2.trim() },
        { p: matchPremise3.trim(), r: matchResponse3.trim() },
      ].filter((pair) => pair.p || pair.r);
      const effectivePairs =
        rawPairs.length > 0
          ? rawPairs
          : [
              { p: 'Premis 1', r: 'Pasangan 1' },
              { p: 'Premis 2', r: 'Pasangan 2' },
              { p: 'Premis 3', r: 'Pasangan 3' },
            ];
      const premises = effectivePairs.map((pair, idx) => ({
        id: `p${idx + 1}`,
        text: pair.p || `Premis ${idx + 1}`,
      }));
      const responses = effectivePairs.map((pair, idx) => ({
        id: `r${idx + 1}`,
        text: pair.r || `Pasangan ${idx + 1}`,
      }));
      const correctPairs: Record<string, string> = {};
      effectivePairs.forEach((_, idx) => {
        correctPairs[`p${idx + 1}`] = `r${idx + 1}`;
      });
      newQuestion = {
        id: `admin_q_${Date.now()}`,
        number: nextNumber,
        type: 'menjodohkan',
        category: newCategory.trim() || 'Sumatif Akhir Semester',
        ...stimulusFields,
        questionText: newQuestionText.trim(),
        instructionText: 'Pasangkan setiap premis di sisi kiri dengan jawaban yang tepat di sisi kanan!',
        premises,
        responses,
        correctPairs,
        points: 10,
        explanation: 'Kunci jawaban ditentukan berdasarkan pasangan premis dan respons yang sesuai.',
      };
    } else if (newQuestionType === 'isian_singkat') {
      const parsedKeys = shortAnswerKeyInput
        .split(/[,;\n]+/)
        .map((k) => k.trim())
        .filter(Boolean);
      const finalKeys = parsedKeys.length > 0 ? parsedKeys : ['Jawaban'];
      newQuestion = {
        id: `admin_q_${Date.now()}`,
        number: nextNumber,
        type: 'isian_singkat',
        category: newCategory.trim() || 'Sumatif Akhir Semester',
        ...stimulusFields,
        questionText: newQuestionText.trim(),
        instructionText: 'Ketik jawaban singkat yang paling tepat pada kolom isian!',
        correctShortAnswers: finalKeys,
        placeholder: 'Ketik jawaban Anda di sini...',
        points: 10,
        explanation: `Kunci jawaban yang diterima: ${finalKeys.join(' / ')}.`,
      };
    } else {
      // benar_salah
      newQuestion = {
        id: `admin_q_${Date.now()}`,
        number: nextNumber,
        type: 'benar_salah',
        category: newCategory.trim() || 'Sumatif Akhir Semester',
        ...stimulusFields,
        questionText: newQuestionText.trim(),
        instructionText: 'Tentukan Benar atau Salah untuk setiap pernyataan!',
        statements: [
          { id: 'st1', statement: statement1.trim() || 'Pernyataan 1', correctValue: statement1Val },
          { id: 'st2', statement: statement2.trim() || 'Pernyataan 2', correctValue: statement2Val },
          { id: 'st3', statement: statement3.trim() || 'Pernyataan 3', correctValue: statement3Val },
        ],
        trueLabel: 'Benar',
        falseLabel: 'Salah',
        points: 10,
        explanation: 'Kunci jawaban ditentukan berdasarkan kesesuaian pernyataan dengan teks.',
      };
    }

    syncSelectedPackageQuestions([...baseQuestions, newQuestion]);
    setNewStimulusTitle('');
    setNewStimulusText('');
    setNewQuestionText('');
    setOptA('');
    setOptB('');
    setOptC('');
    setOptD('');
    setOptE('');
    setMatchPremise1('');
    setMatchResponse1('');
    setMatchPremise2('');
    setMatchResponse2('');
    setMatchPremise3('');
    setMatchResponse3('');
    setShortAnswerKeyInput('');
    showNotice(`Soal (${getQuestionTypeLabel(newQuestionType)}) No. ${nextNumber} berhasil ditambahkan ke bank soal.`);
  };

  const wordQuestionInputRef = React.useRef<HTMLInputElement | null>(null);

  const ensureFullscreenMode = () => {
    try {
      const isMobileDevice =
        window.innerWidth < 768 ||
        Boolean(window.matchMedia?.('(pointer: coarse)').matches) ||
        /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
      if (!isMobileDevice) return;

      const doc = document as Document & {
        webkitFullscreenElement?: Element | null;
        msFullscreenElement?: Element | null;
      };
      const docEl = document.documentElement as HTMLElement & {
        webkitRequestFullscreen?: (options?: FullscreenOptions) => Promise<void>;
      };
      if (!doc.fullscreenElement && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
        if (docEl.requestFullscreen) {
          docEl.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
        } else if (docEl.webkitRequestFullscreen) {
          docEl.webkitRequestFullscreen();
        }
      }
    } catch {
      // Ignore
    }
  };

  const triggerUploadWordFile = () => {
    ensureFullscreenMode();

    // Ketika jendela file eksplorer ditutup (baik via Open/OK maupun Cancel), kembalikan fullscreen saat window kembali fokus
    const handleReturnFocus = () => {
      window.removeEventListener('focus', handleReturnFocus);
      setTimeout(() => {
        ensureFullscreenMode();
      }, 100);
      setTimeout(() => {
        ensureFullscreenMode();
      }, 500);
    };
    window.addEventListener('focus', handleReturnFocus, { once: true });

    if (wordQuestionInputRef.current) {
      wordQuestionInputRef.current.value = '';
      if (typeof wordQuestionInputRef.current.showPicker === 'function') {
        try {
          wordQuestionInputRef.current.showPicker();
          return;
        } catch {
          // Fallback to click()
        }
      }
      wordQuestionInputRef.current.click();
    }
  };

  const handleUploadWordQuestions = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    // Pastikan fullscreen kembali aktif seketika setelah pengguna memilih file dan klik Open/OK
    ensureFullscreenMode();
    setTimeout(() => {
      ensureFullscreenMode();
    }, 150);
    setTimeout(() => {
      ensureFullscreenMode();
    }, 450);

    const file = e.target.files?.[0];
    if (!file || !selectedPackage) return;

    try {
      const existingRealQuestions = appendUploadMode
        ? selectedPackage.questions.filter((q) => !isDefaultSampleQuestion(q))
        : [];
      const startNum = existingRealQuestions.length + 1;
      const defaultCat =
        selectedPackage.subtest || newCategory.trim() || 'Sumatif Akhir Semester';
      const {
        questions: importedQuestions,
        redDetectedCount,
        tableCount,
        imageCount,
        typeBreakdown,
      } = await parseWordQuestions(file, newQuestionType, startNum, defaultCat);

      if (importedQuestions.length === 0) {
        showNotice(
          'Tidak ditemukan butir soal yang valid pada file yang diunggah. Pastikan file berisi daftar pertanyaan atau tabel soal.'
        );
        return;
      }

      const combinedQuestions = [
        ...existingRealQuestions,
        ...importedQuestions,
      ];

      syncSelectedPackageQuestions(combinedQuestions);
      setLastUploadedWordFile(file.name);
      setStatusTesTipeSoal('Semua Tipe Soal');

      const detectedTypes = Object.keys(typeBreakdown) as QuestionType[];
      if (detectedTypes.length === 1) {
        setNewQuestionType(detectedTypes[0]);
      }

      setNewQuestionText('');
      setOptA('');
      setOptB('');
      setOptC('');
      setOptD('');
      setOptE('');

      const breakdownSummary = detectedTypes
        .map((t) => `${typeBreakdown[t]} ${getQuestionTypeLabel(t)}`)
        .join(', ');
      const tableInfo =
        tableCount > 0 ? `, ${tableCount} tabel` : '';
      const imageInfo =
        imageCount > 0 ? `, ${imageCount} gambar` : '';
      showNotice(
        `Berhasil mengunggah "${file.name}": ${importedQuestions.length} soal dikenali otomatis (${breakdownSummary}; ${redDetectedCount} kunci jawaban${tableInfo}${imageInfo}).`
      );
    } catch {
      showNotice(
        'Gagal membaca file soal. Pastikan file berformat .docx, .doc, .pdf, .xlsx, .xls, .csv, .txt, .rtf, atau .json yang valid.'
      );
    } finally {
      if (wordQuestionInputRef.current) {
        wordQuestionInputRef.current.value = '';
      }
      ensureFullscreenMode();
      setTimeout(() => {
        ensureFullscreenMode();
      }, 200);
    }
  };

  const handleAddProctor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProctorName.trim()) return;
    const item: AdminProctorItem = {
      id: `pr_${Date.now()}`,
      proctorId: autoGeneratedProctorId,
      fullName: newProctorName.trim().toUpperCase(),
      roomName: newProctorRoom.trim().toUpperCase() || 'LAB KOMPUTER',
      rombel: newProctorRombel.trim() || 'Kelas X',
      encryptionCode: autoGeneratedProctorEnc,
      password: newProctorPass.trim() || 'SMADIP2026*',
      status: 'Active',
    };
    setProctors((prev) => [item, ...prev]);
    setNewProctorName('');
    showNotice(`Proktor ${item.fullName} (${item.proctorId}) berhasil ditambahkan.`);
  };

  const handleToggleProctorStatus = (id: string) => {
    setProctors((prev) =>
      prev.map((pr) =>
        pr.id === id
          ? { ...pr, status: pr.status === 'Active' ? 'Non Active' : 'Active' }
          : pr
      )
    );
    showNotice('Status aktif proktor berhasil diperbarui.');
  };

  const handleDeleteProctor = (id: string) => {
    setProctors((prev) => prev.filter((pr) => pr.id !== id));
    showNotice('Data proktor berhasil dihapus.');
  };

  const handleSaveEditingProctor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProctorForm) return;
    const updatedName = editingProctorForm.fullName.trim().toUpperCase();
    if (!updatedName) {
      showNotice('Nama proktor tidak boleh kosong!');
      return;
    }
    const updatedRoom = editingProctorForm.roomName.trim().toUpperCase() || 'LAB KOMPUTER';
    const updatedRombel = editingProctorForm.rombel.trim() || 'Kelas X';
    const updatedPassword = editingProctorForm.password.trim() || 'SMADIP2026*';

    setProctors((prev) =>
      prev.map((pr) =>
        pr.id === editingProctorForm.id
          ? {
              ...pr,
              fullName: updatedName,
              roomName: updatedRoom,
              rombel: updatedRombel,
              password: updatedPassword,
              status: editingProctorForm.status,
            }
          : pr
      )
    );

    // Keep appConfig in sync if this matches the first proctor
    if (proctors[0]?.id === editingProctorForm.id) {
      persistAdminConfig(
        { ...appConfig, namaProktor: updatedName },
        { syncCloud: true }
      );
    }

    // Keep active proctor session in sync in localStorage
    try {
      const rawSession = localStorage.getItem('cbt_proctor_session');
      if (rawSession) {
        const parsed = JSON.parse(rawSession);
        if (parsed) {
          parsed.name = updatedName;
          localStorage.setItem('cbt_proctor_session', JSON.stringify(parsed));
        }
      }
    } catch {
      // ignore
    }

    setEditingProctor(null);
    setEditingProctorForm(null);
    showNotice(`Data Proktor ${updatedName} berhasil diperbarui dan disimpan.`);
  };

  const scheduleExcelInputRef = React.useRef<HTMLInputElement | null>(null);

  const handleDownloadScheduleTemplateExcel = () => {
    const sampleData = [
      ['Hari dan Tanggal', 'Kelas', 'Mapel', 'Waktu Mulai', 'Durasi'],
      ['Senin, 07 Desember 2026', 'X', 'Matematika Wajib', '07:30 WIB', '90 Menit'],
      ['Senin, 07 Desember 2026', 'X', 'Bahasa Indonesia', '09:30 WIB', '90 Menit'],
      ['Senin, 07 Desember 2026', 'XI IPA', 'Kimia', '07:30 WIB', '90 Menit'],
      ['Selasa, 08 Desember 2026', 'XI IPS', 'Ekonomi', '07:30 WIB', '90 Menit'],
      ['Selasa, 08 Desember 2026', 'XII IPA', 'Fisika', '07:30 WIB', '90 Menit'],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(sampleData);
    worksheet['!cols'] = [
      { wch: 28 },
      { wch: 14 },
      { wch: 28 },
      { wch: 16 },
      { wch: 14 },
    ];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Jadwal Ujian');
    XLSX.writeFile(workbook, 'Format_Upload_Jadwal_SAS.xlsx');
    showNotice(
      'Template Excel jadwal berhasil diunduh (Format: Hari dan Tanggal, Kelas, Mapel, Waktu Mulai, Durasi).'
    );
  };

  const handleUploadScheduleExcel = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });

      const cleanCell = (val: unknown) =>
        String(val ?? '')
          .replace(/\r?\n/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();

      const normalizeHeader = (val: unknown) =>
        cleanCell(val)
          .toLowerCase()
          .replace(/[^a-z0-9\s/]/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();

      const normalizeKelas = (raw: string) => {
        const cleaned = raw
          .replace(/^(kelas|kls)\s*[:.-]?\s*/i, '')
          .replace(/\s+/g, ' ')
          .trim()
          .toUpperCase();
        return cleaned;
      };

      const normalizeDurasi = (raw: string) => {
        const cleaned = raw.trim();
        if (!cleaned) return '90 Menit';
        if (/^\d+$/.test(cleaned)) return `${cleaned} Menit`;
        return cleaned;
      };

      const makeScheduleKey = (item: {
        hariTanggal: string;
        kelas: string;
        mapel: string;
        waktuMulai: string;
      }) =>
        `${item.hariTanggal.toLowerCase()}|${item.kelas.toLowerCase()}|${item.mapel.toLowerCase()}|${item.waktuMulai.toLowerCase()}`;

      const existingKeys = new Set(schedules.map((s) => makeScheduleKey(s)));
      const importedItems: AdminScheduleItem[] = [];
      let skippedDuplicates = 0;
      const nowTs = Date.now();

      for (const sheetName of workbook.SheetNames) {
        const worksheet = workbook.Sheets[sheetName];
        if (!worksheet) continue;

        const rows = XLSX.utils.sheet_to_json<unknown[]>(worksheet, {
          header: 1,
          defval: '',
          raw: false,
        });
        if (!rows.length) continue;

        let headerRowIdx = -1;
        let hariTanggalCol = -1;
        let hariOnlyCol = -1;
        let tanggalOnlyCol = -1;
        let kelasCol = -1;
        let mapelCol = -1;
        let waktuCol = -1;
        let durasiCol = -1;

        const scanLimit = Math.min(rows.length, 15);
        for (let r = 0; r < scanLimit; r++) {
          const row = Array.isArray(rows[r]) ? rows[r] : [];
          let foundHariTgl = -1;
          let foundHari = -1;
          let foundTgl = -1;
          let foundKelas = -1;
          let foundMapel = -1;
          let foundWaktu = -1;
          let foundDurasi = -1;

          row.forEach((cell, idx) => {
            const h = normalizeHeader(cell);
            if (!h) return;

            if (
              foundHariTgl === -1 &&
              ((h.includes('hari') && (h.includes('tanggal') || h.includes('tgl'))) ||
                h === 'hari dan tanggal' ||
                h === 'hari/tanggal')
            ) {
              foundHariTgl = idx;
            } else if (foundHari === -1 && (h === 'hari' || h.startsWith('hari '))) {
              foundHari = idx;
            } else if (
              foundTgl === -1 &&
              (h === 'tanggal' || h === 'tgl' || h.startsWith('tanggal ') || h.startsWith('tgl '))
            ) {
              foundTgl = idx;
            } else if (
              foundKelas === -1 &&
              (h.includes('kelas') || h === 'kls' || h.includes('rombel') || h.includes('tingkat'))
            ) {
              foundKelas = idx;
            } else if (
              foundMapel === -1 &&
              (h.includes('mapel') || h.includes('mata pelajaran') || h.includes('pelajaran'))
            ) {
              foundMapel = idx;
            } else if (
              foundWaktu === -1 &&
              (h.includes('waktu') || h.includes('mulai') || h.includes('jam') || h.includes('pukul'))
            ) {
              foundWaktu = idx;
            } else if (
              foundDurasi === -1 &&
              (h.includes('durasi') || h.includes('alokasi') || h.includes('lama') || h.includes('menit'))
            ) {
              foundDurasi = idx;
            }
          });

          const matchedCount = [
            foundHariTgl !== -1 || foundHari !== -1 || foundTgl !== -1,
            foundKelas !== -1,
            foundMapel !== -1,
            foundWaktu !== -1,
            foundDurasi !== -1,
          ].filter(Boolean).length;

          if (matchedCount >= 2 && foundMapel !== -1) {
            headerRowIdx = r;
            hariTanggalCol = foundHariTgl;
            hariOnlyCol = foundHari;
            tanggalOnlyCol = foundTgl;
            kelasCol = foundKelas;
            mapelCol = foundMapel;
            waktuCol = foundWaktu;
            durasiCol = foundDurasi;
            break;
          }
        }

        const startRow = headerRowIdx !== -1 ? headerRowIdx + 1 : 0;
        let lastHariTanggal = '';
        let lastKelas = '';

        for (let r = startRow; r < rows.length; r++) {
          const row = Array.isArray(rows[r]) ? rows[r] : [];
          if (!row.some((c) => cleanCell(c) !== '')) continue;

          let rawHariTanggal = '';
          let rawKelas = '';
          let rawMapel = '';
          let rawWaktu = '';
          let rawDurasi = '';

          if (headerRowIdx !== -1) {
            if (hariTanggalCol !== -1) {
              rawHariTanggal = cleanCell(row[hariTanggalCol]);
            } else {
              const hPart = hariOnlyCol !== -1 ? cleanCell(row[hariOnlyCol]) : '';
              const tPart = tanggalOnlyCol !== -1 ? cleanCell(row[tanggalOnlyCol]) : '';
              if (hPart && tPart) {
                rawHariTanggal = `${hPart}, ${tPart}`;
              } else {
                rawHariTanggal = hPart || tPart;
              }
            }
            rawKelas = kelasCol !== -1 ? cleanCell(row[kelasCol]) : '';
            rawMapel = mapelCol !== -1 ? cleanCell(row[mapelCol]) : '';
            rawWaktu = waktuCol !== -1 ? cleanCell(row[waktuCol]) : '';
            rawDurasi = durasiCol !== -1 ? cleanCell(row[durasiCol]) : '';
          } else {
            const c0 = cleanCell(row[0]);
            const offset = /^\d+[.)]?$/.test(c0) && row.length >= 6 ? 1 : 0;
            rawHariTanggal = cleanCell(row[offset]);
            rawKelas = cleanCell(row[offset + 1]);
            rawMapel = cleanCell(row[offset + 2]);
            rawWaktu = cleanCell(row[offset + 3]);
            rawDurasi = cleanCell(row[offset + 4]);
          }

          const mapelLower = normalizeHeader(rawMapel);
          if (
            !rawMapel ||
            mapelLower === 'mapel' ||
            mapelLower === 'mata pelajaran' ||
            mapelLower === 'pelajaran'
          ) {
            continue;
          }

          if (rawHariTanggal) {
            lastHariTanggal = rawHariTanggal;
          }
          const resolvedHariTanggal = rawHariTanggal || lastHariTanggal;
          if (!resolvedHariTanggal) continue;

          const normalizedKelas = normalizeKelas(rawKelas);
          if (normalizedKelas) {
            lastKelas = normalizedKelas;
          }
          const resolvedKelas = normalizedKelas || lastKelas || KELAS_OPTIONS[0] || 'X';
          const resolvedWaktu = rawWaktu || '07:30 WIB';
          const resolvedDurasi = normalizeDurasi(rawDurasi);

          const key = makeScheduleKey({
            hariTanggal: resolvedHariTanggal,
            kelas: resolvedKelas,
            mapel: rawMapel,
            waktuMulai: resolvedWaktu,
          });

          if (existingKeys.has(key)) {
            skippedDuplicates += 1;
            continue;
          }
          existingKeys.add(key);

          importedItems.push({
            id: `sch_xls_${nowTs}_${importedItems.length}`,
            hariTanggal: resolvedHariTanggal,
            kelas: resolvedKelas,
            mapel: rawMapel,
            waktuMulai: resolvedWaktu,
            durasi: resolvedDurasi,
            isActive: false,
            updatedAt: nowTs,
            simulasiWhitelistedV4: true,
          });
        }
      }

      if (importedItems.length === 0) {
        if (skippedDuplicates > 0) {
          showNotice(
            `Semua ${skippedDuplicates} jadwal pada file "${file.name}" sudah ada di daftar jadwal.`
          );
        } else {
          showNotice(
            `Tidak ditemukan baris jadwal valid pada file "${file.name}". Pastikan kolom berisi: Hari dan Tanggal, Kelas, Mapel, Waktu Mulai, Durasi.`
          );
        }
        return;
      }

      const addedSlots = ensureBankSoalForSchedules(importedItems);
      onUpdateSchedules([...schedules, ...importedItems]);
      const dupText =
        skippedDuplicates > 0
          ? ` (${skippedDuplicates} duplikat dilewati)`
          : '';
      const slotText =
        addedSlots > 0
          ? ` ${addedSlots} slot Bank Soal baru otomatis dibuat pada menu Status Tes.`
          : '';
      showNotice(
        `Berhasil mengunggah ${importedItems.length} jadwal ujian dari "${file.name}"${dupText}.${slotText} Klik "Aktifkan Mapel" untuk menampilkan token di Proktor & Siswa.`
      );
    } catch (err) {
      console.error('Upload jadwal Excel error:', err);
      showNotice(
        'Gagal membaca file Excel jadwal. Pastikan format file .xlsx, .xls, atau .csv valid.'
      );
    } finally {
      e.target.value = '';
    }
  };

  const ensureBankSoalForSchedules = (newItems: AdminScheduleItem[]): number => {
    if (!Array.isArray(newItems) || newItems.length === 0) return 0;

    const currentMapelList: any[] = Array.isArray(appConfig.mapelList)
      ? [...appConfig.mapelList]
      : [...defaultMapelList];
    const usedCodes = new Set<string>(
      [
        ...currentMapelList.map((m) => String(m?.kode || '').trim().toUpperCase()),
        ...packages.map((p) => String(p?.code || '').trim().toUpperCase()),
      ].filter(Boolean)
    );

    const existingPkgSlotKeys = new Set<string>();
    const existingMapelSlotKeys = new Set<string>();
    const makeSlotKey = (name?: string, targetClass?: string) => {
      const cleanName = String(name || '')
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
      const cleanCls = String(targetClass || '').trim().toUpperCase();
      return cleanName && cleanCls ? `${cleanCls}::${cleanName}` : '';
    };

    packages.forEach((p) => {
      const k = makeSlotKey(p.title, getPkgClass(p));
      if (k) existingPkgSlotKeys.add(k);
    });
    currentMapelList.forEach((m) => {
      const k = makeSlotKey(m?.nama, getTargetClassFromMapel(m || {}));
      if (k) existingMapelSlotKeys.add(k);
    });

    const addedMapels: any[] = [];
    const addedPackages: ExamPackage[] = [];
    const reactivatedNames = new Set<string>();
    const reactivatedCodes = new Set<string>();
    const nowTs = Date.now();

    newItems.forEach((item, idx) => {
      const mapelName = String(item.mapel || '').trim();
      if (!mapelName) return;
      const cleanMapelLower = mapelName
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
      const targetClass = getTargetClassFromMapel({
        tingkat: item.kelas,
        nama: mapelName,
      });
      const slotKey = `${targetClass.toUpperCase()}::${cleanMapelLower}`;
      reactivatedNames.add(cleanMapelLower);

      const hasPkgSlot = existingPkgSlotKeys.has(slotKey);
      const hasMapelSlot = existingMapelSlotKeys.has(slotKey);
      if (hasPkgSlot && hasMapelSlot) return;

      const durMatch = String(item.durasi || '').match(/\d+/);
      const durationMinutes = durMatch
        ? Math.max(10, parseInt(durMatch[0], 10) || 90)
        : 90;

      const existingMapelMatch = currentMapelList.find(
        (m) =>
          makeSlotKey(m?.nama, getTargetClassFromMapel(m || {})) === slotKey
      );
      const existingPkgMatch = packages.find(
        (p) => makeSlotKey(p.title, getPkgClass(p)) === slotKey
      );

      let codeCandidate = String(
        existingMapelMatch?.kode || existingPkgMatch?.code || ''
      )
        .trim()
        .toUpperCase();
      if (!codeCandidate) {
        const kelasSlug = targetClass
          .replace(/^Kelas\s+/i, '')
          .replace(/[^a-zA-Z0-9]+/g, '')
          .toUpperCase()
          .slice(0, 6);
        const mapelSlug = mapelName
          .replace(/[^a-zA-Z0-9]+/g, '')
          .toUpperCase()
          .slice(0, 6);
        codeCandidate = `${mapelSlug || 'MPL'}-${kelasSlug || 'X'}`;
        let suffix = 2;
        while (usedCodes.has(codeCandidate)) {
          codeCandidate = `${mapelSlug || 'MPL'}-${kelasSlug || 'X'}${suffix}`;
          suffix += 1;
        }
      }
      usedCodes.add(codeCandidate);
      reactivatedCodes.add(codeCandidate);

      const kategori = targetClass.includes('IPS')
        ? 'Peminatan IPS'
        : targetClass.includes('IPA')
        ? 'Peminatan IPA'
        : 'Wajib Umum';
      const pkgId =
        'mapel_pkg_' + codeCandidate.toLowerCase().replace(/[^a-z0-9]/g, '_');

      if (!hasMapelSlot) {
        existingMapelSlotKeys.add(slotKey);
        addedMapels.push({
          id: `mp_sch_${nowTs}_${idx}`,
          kode: codeCandidate,
          nama: mapelName,
          kategori,
          tingkat: targetClass,
          alokasiMenit: durationMinutes,
          jumlahSoal: 0,
          simulasiWhitelistedV4: true,
        });
      }

      if (!hasPkgSlot) {
        existingPkgSlotKeys.add(slotKey);
        addedPackages.push({
          id: pkgId,
          code: codeCandidate,
          title: mapelName,
          level: 'SMA / MA / SMK / Sederajat',
          subtest: kategori,
          durationMinutes,
          targetClass,
          questions: [],
          simulasiWhitelistedV4: true,
        });
      }
    });

    const reactivatedSlotKeys = new Set<string>();
    newItems.forEach((item) => {
      const mapelName = String(item.mapel || '').trim();
      if (!mapelName) return;
      const targetClass = getTargetClassFromMapel({
        tingkat: item.kelas,
        nama: mapelName,
      });
      const k = makeSlotKey(mapelName, targetClass);
      if (k) reactivatedSlotKeys.add(k);
    });

    let hasReactivatedInactiveMapel = false;
    const updatedCurrentMapelList = currentMapelList.map((m) => {
      if (!m || typeof m !== 'object') return m;
      const mKey = makeSlotKey(m.nama, getTargetClassFromMapel(m));
      const mNamaClean = String(m.nama || '')
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
      if (
        (mKey && reactivatedSlotKeys.has(mKey)) ||
        (mNamaClean && reactivatedNames.has(mNamaClean))
      ) {
        if (String(m.status || '').trim().toLowerCase() === 'non aktif') {
          hasReactivatedInactiveMapel = true;
          return { ...m, status: 'Aktif' };
        }
      }
      return m;
    });

    if (
      addedMapels.length === 0 &&
      addedPackages.length === 0 &&
      !hasReactivatedInactiveMapel &&
      reactivatedNames.size === 0
    ) {
      return 0;
    }

    const nextDeletedNames = (
      Array.isArray(appConfig.deletedMapelNames)
        ? appConfig.deletedMapelNames
        : []
    ).filter(
      (n) => !reactivatedNames.has(String(n || '').trim().toLowerCase())
    );
    const nextDeletedCodes = (
      Array.isArray(appConfig.deletedMapelCodes)
        ? appConfig.deletedMapelCodes
        : []
    ).filter((c) => !reactivatedCodes.has(String(c || '').trim().toUpperCase()));

    const deletedNamesChanged =
      nextDeletedNames.length !==
      (Array.isArray(appConfig.deletedMapelNames)
        ? appConfig.deletedMapelNames.length
        : 0);
    const deletedCodesChanged =
      nextDeletedCodes.length !==
      (Array.isArray(appConfig.deletedMapelCodes)
        ? appConfig.deletedMapelCodes.length
        : 0);

    if (
      addedMapels.length > 0 ||
      hasReactivatedInactiveMapel ||
      deletedNamesChanged ||
      deletedCodesChanged
    ) {
      persistAdminConfig(
        {
          ...appConfig,
          mapelList: [...updatedCurrentMapelList, ...addedMapels],
          customMapelConfigured: true,
          deletedMapelNames: nextDeletedNames,
          deletedMapelCodes: nextDeletedCodes,
        },
        { syncCloud: true }
      );
    }

    if (addedPackages.length > 0) {
      onUpdatePackages((prevPackages) => {
        const base = Array.isArray(prevPackages) ? prevPackages : packages;
        const existingIds = new Set(base.map((p) => p.id));
        const toAppend = addedPackages.filter((p) => !existingIds.has(p.id));
        return [...base, ...toAppend];
      });
    }

    return Math.max(addedMapels.length, addedPackages.length);
  };

  const handleAddSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHariTanggal.trim() || !newJadwalMapel.trim()) return;
    const nowTs = Date.now();
    const item: AdminScheduleItem = {
      id: `sch_${nowTs}`,
      hariTanggal: newHariTanggal.trim(),
      kelas: newJadwalKelas,
      mapel: newJadwalMapel.trim(),
      waktuMulai: newWaktuMulai.trim() || '07:30 WIB',
      durasi: newDurasi.trim() || '90 Menit',
      isActive: false,
      updatedAt: nowTs,
      simulasiWhitelistedV4: true,
    };
    const addedSlots = ensureBankSoalForSchedules([item]);
    onUpdateSchedules([...schedules, item]);
    setNewHariTanggal('');
    setNewJadwalMapel('');
    const slotText =
      addedSlots > 0
        ? ' Slot Bank Soal otomatis disiapkan di menu Status Tes.'
        : '';
    showNotice(
      `Jadwal ${item.mapel} (Kelas ${item.kelas}) ditambahkan.${slotText} Klik "Aktifkan Mapel" agar token keluar di Proktor & Siswa.`
    );
  };

  const handleToggleScheduleActive = (id: string) => {
    const target = schedules.find((s) => s.id === id);
    if (!target) return;
    const nextState = !target.isActive;
    if (nextState) {
      ensureBankSoalForSchedules([target]);
    }
    const nowTs = Date.now();
    const nextList = schedules.map((s) =>
      s.id === id ? { ...s, isActive: nextState, updatedAt: nowTs } : s
    );
    onUpdateSchedules(nextList);
    if (nextState) {
      showNotice(
        `Mapel "${target.mapel}" (Kelas ${target.kelas}) DIAKTIFKAN! Token ujian kini keluar di halaman Proktor dan Siswa dapat mengerjakan.`
      );
    } else {
      showNotice(
        `Mapel "${target.mapel}" (Kelas ${target.kelas}) dinonaktifkan.`
      );
    }
  };

  const handleDeleteSchedule = (id: string) => {
    onUpdateSchedules(schedules.filter((s) => s.id !== id));
    showNotice('Data jadwal ujian berhasil dihapus.');
  };

  const SIDEBAR_MENUS: {
    id: AdminSidebarMenuId;
    label: string;
    breadcrumb: string;
    icon: React.FC<{ className?: string }>;
  }[] = [
    { id: 'beranda', label: 'Beranda', breadcrumb: 'Beranda Administrator', icon: Home },
    { id: 'daftar_proktor', label: 'Daftar Proktor', breadcrumb: 'List Daftar Proktor', icon: UserCog },
    { id: 'status_peserta', label: 'Status Peserta', breadcrumb: 'List Status Peserta', icon: ClipboardList },
    { id: 'daftar_peserta', label: 'Daftar Peserta', breadcrumb: 'Manajemen Daftar Peserta', icon: User },
    { id: 'jadwal', label: 'Jadwal', breadcrumb: 'Jadwal Ujian Sumatif Akhir Semester', icon: Calendar },
    { id: 'status_tes', label: 'Status Tes', breadcrumb: 'Manajemen Bank Soal', icon: ClipboardCheck },
    { id: 'request_reset', label: 'Request Reset Login', breadcrumb: 'Request Reset Login', icon: RotateCcw },
    { id: 'daftar_login', label: 'Daftar Login', breadcrumb: 'Daftar Login Peserta', icon: UserCheck },
    { id: 'kelompok_tes', label: 'Kelompok Tes', breadcrumb: 'List Kelompok Test', icon: Users },
    { id: 'laporan_pengolahan', label: 'Laporan Pengolahan', breadcrumb: 'Laporan Pengolahan Nilai', icon: FileCheck2 },
    { id: 'pengaturan', label: 'Pengaturan', breadcrumb: 'Pengaturan Sistem Ujian SAS', icon: Settings },
  ];

  const currentMenuMeta =
    SIDEBAR_MENUS.find((m) => m.id === activeMenu) || SIDEBAR_MENUS[8];

  return (
    <div className="h-dvh min-h-[100vh] overflow-hidden flex bg-[#f4f6fa] text-slate-800">
      {/* LEFT SIDEBAR (Exact Deep Cobalt Navy & Geometric Facets matching reference screenshot) */}
      <aside
        className={`${
          sidebarCollapsed ? 'w-20' : 'w-64'
        } h-dvh min-h-[100vh] relative overflow-hidden shrink-0 bg-[#001a6e] text-white flex flex-col transition-all duration-200 select-none shadow-xl z-20`}
      >
        {/* Exact Geometric Facet Overlay from ANBK Reference Screenshot */}
        <svg
          className="pointer-events-none absolute inset-0 w-full h-full"
          viewBox="0 0 260 900"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <rect width="260" height="900" fill="#001a6e" />
          <polygon points="0,380 260,220 260,640 0,520" fill="#001e7d" />
          <polygon points="260,470 75,900 260,900" fill="#002596" />
          <polygon points="0,510 175,900 0,900" fill="#00155a" />
        </svg>

        {/* Top Brand inside Sidebar */}
        <div className="relative z-10 h-16 shrink-0 px-4 bg-[#001147] flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 overflow-hidden min-w-0">
            <TutWuriLogo className="w-8 h-8 shrink-0" />
            {!sidebarCollapsed && (
              <span className="text-[13px] font-extrabold tracking-tight text-white whitespace-nowrap truncate">
                ADMINISTRATOR SAS
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={() => setSidebarCollapsed((prev) => !prev)}
            className="p-1.5 rounded-lg text-[#2563eb] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title={sidebarCollapsed ? 'Perlebar Menu' : 'Ciutkan Menu'}
          >
            {sidebarCollapsed ? (
              <ChevronsRight className="w-5 h-5" />
            ) : (
              <ChevronsLeft className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Scrollable Navigation Menu Items (Fixed height items so nothing shifts on click) */}
        <nav className="relative z-10 flex-1 overflow-y-auto overscroll-contain py-3 space-y-0.5">
          {SIDEBAR_MENUS.map((item) => {
            const IconComponent = item.icon;
            const isActive = activeMenu === item.id;
            const resetCount =
              item.id === 'request_reset'
                ? participants.filter((p) => isParticipantLockedByViolation(p))
                    .length
                : 0;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveMenu(item.id)}
                className={`w-full h-12 shrink-0 flex items-center justify-between gap-2 px-6 text-left text-[13.5px] font-semibold leading-none transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-[#020c36] text-white'
                    : 'text-white hover:bg-[#020c36]/55'
                }`}
                title={item.label}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <IconComponent className="w-[18px] h-[18px] shrink-0 text-white" />
                  {!sidebarCollapsed && (
                    <span className="truncate">{item.label}</span>
                  )}
                </div>
                {!sidebarCollapsed && resetCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold">
                    {resetCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Logout Administrator Button */}
        <div className="relative z-10 shrink-0 p-4 border-t border-white/10 bg-[#00155a]/90">
          <button
            type="button"
            onClick={() => setShowLogoutConfirmModal(true)}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#020c36] hover:bg-rose-600 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            {!sidebarCollapsed && <span>Keluar Administrator</span>}
          </button>
        </div>
      </aside>

      {/* RIGHT MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0 h-dvh min-h-[100vh] overflow-hidden">
        {/* Top White Header Bar matching reference image */}
        <header className="shrink-0 bg-white px-7 py-3.5 flex items-center justify-between gap-4 border-b border-slate-200/80">
          <div>
            <h1 className="text-sm sm:text-[15px] font-bold tracking-wide text-slate-700 uppercase">
              SUMATIF AKHIR SEMESTER
            </h1>
          </div>

          <div className="flex items-center gap-4">
            {(() => {
              const cleanInput = String(adminUsername ?? '').trim().toUpperCase();
              const adminList = Array.isArray(appConfig?.adminList)
                ? appConfig.adminList
                : [];
              const matchedAdmin = adminList.find(
                (adm: any) =>
                  String(adm?.adminId || '').trim().toUpperCase() === cleanInput ||
                  String(adm?.username || '').trim().toUpperCase() === cleanInput ||
                  String(adm?.namaLengkap || '').trim().toUpperCase() === cleanInput
              );
              const displayAdminName = String(
                matchedAdmin?.namaLengkap ||
                  appConfig?.adminNama ||
                  'SHAHRUR ROBBY, S.Pd.'
              );
              const displayAdminId = String(
                matchedAdmin?.adminId ||
                  appConfig?.adminId ||
                  adminUsername ||
                  'K05060108-KB6K'
              );

              return (
                <div className="flex items-center gap-3 text-right">
                  <div className="leading-tight">
                    <div className="text-xs font-bold text-slate-800">
                      {displayAdminName}
                    </div>
                    <div className="text-[11px] font-mono font-semibold text-slate-500">
                      {displayAdminId}
                    </div>
                  </div>
                  <div className="w-9 h-9 rounded-lg bg-[#0095ff] text-white font-bold text-sm flex items-center justify-center shadow-xs">
                    {(displayAdminName.charAt(0) || 'A').toUpperCase()}
                  </div>
                </div>
              );
            })()}

            <button
              type="button"
              onClick={() => setShowLogoutConfirmModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold transition-colors cursor-pointer"
              title="Keluar dari sesi Administrator"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-600" />
              <span className="hidden sm:inline">Keluar</span>
            </button>
          </div>
        </header>

        {/* Sub-Header Breadcrumb Bar matching screenshot */}
        <div className="bg-white px-7 py-2.5 border-b border-slate-200/70 shadow-2xs flex items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2.5 text-slate-600">
            <span className="font-semibold text-slate-700">
              {currentMenuMeta.label === 'Kelompok Tes'
                ? 'Kelompok Test'
                : currentMenuMeta.label}
            </span>
            <span className="text-slate-300">|</span>
            <Home className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">•</span>
            <span className="text-slate-400">{currentMenuMeta.breadcrumb}</span>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Token Aktif:</span>
            {isAnyScheduleActive ? (
              <span className="font-mono font-black text-red-600 underline decoration-2 underline-offset-2 bg-red-50 px-2.5 py-0.5 rounded border border-red-200">
                {activeToken}
              </span>
            ) : (
              <span className="font-mono font-bold text-slate-400 bg-slate-100 px-2.5 py-0.5 rounded border border-slate-200">
                BELUM KELUAR (Mapel Belum Aktif)
              </span>
            )}
          </div>
        </div>

        {/* MAIN BODY */}
        <main className="flex-1 p-6 sm:p-7 overflow-y-auto space-y-6">
          {ephemeralStorageWarning && storageEngine !== 'vercel-kv' && (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 flex items-start gap-3 text-amber-900 shadow-2xs">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed space-y-1">
                <div className="font-bold text-amber-950">
                  Peringatan Penyimpanan Produksi: Database Redis (Vercel KV / Upstash) Belum Terhubung
                </div>
                <p>
                  Aplikasi sedang berjalan pada memori serverless sementara sehingga data peserta, bank soal, dan status sesi dapat terpecah antar perangkat saat ujian serentak. Hubungkan database <strong>Upstash Redis</strong> di tab <strong>Storage</strong> dashboard Vercel (mengisi <code className="font-mono bg-amber-100 px-1 rounded">KV_REST_API_URL</code> / <code className="font-mono bg-amber-100 px-1 rounded">UPSTASH_REDIS_REST_URL</code> dan token-nya), lalu Redeploy.
                </p>
              </div>
            </div>
          )}
          {/* 1. KELOMPOK TES (Exact Match to Attached Image) */}
          {activeMenu === 'kelompok_tes' && (
            <div className="space-y-6">
              {/* Filter Section */}
              <div className="space-y-3">
                <h2 className="text-[15px] font-semibold text-slate-700">
                  Filter
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-4 items-end">
                  {/* 1. Status Dropdown */}
                  <div className="lg:col-span-3 space-y-1.5">
                    <label className="block text-xs font-medium text-slate-500">
                      Status
                    </label>
                    <select
                      value={filterStatus}
                      onChange={(e) => {
                        const val = e.target.value;
                        setFilterStatus(val);
                        setAppliedStatus(val);
                      }}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm text-slate-700 bg-white border border-slate-200 rounded-lg shadow-2xs focus:outline-none focus:border-[#0095ff]"
                    >
                      <option value="Semua Status">Semua Status</option>
                      <option value="Aktif">Aktif</option>
                      <option value="Non Aktif">Non Aktif</option>
                    </select>
                  </div>

                  {/* 2. Kode Tes Dropdown */}
                  <div className="lg:col-span-3 space-y-1.5">
                    <label className="block text-xs font-medium text-slate-500">
                      Kode Tes
                    </label>
                    <select
                      value={filterKodeTes}
                      onChange={(e) => {
                        const val = e.target.value;
                        setFilterKodeTes(val);
                        setAppliedKodeTes(val);
                      }}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm text-slate-700 bg-white border border-slate-200 rounded-lg shadow-2xs focus:outline-none focus:border-[#0095ff]"
                    >
                      <option value="SEMUA">Semua Kode Tes</option>
                      {availableKodeTesList.map((kt) => (
                        <option key={kt} value={kt}>
                          {kt}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 3. Ruang Ujian Dropdown */}
                  <div className="lg:col-span-3 space-y-1.5">
                    <label className="block text-xs font-medium text-slate-500">
                      Ruang Ujian
                    </label>
                    <select
                      value={filterKelompok}
                      onChange={(e) => {
                        const val = e.target.value;
                        setFilterKelompok(val);
                        setAppliedKelompok(val);
                        if (val !== 'SEMUA') {
                          setTargetMoveRuang(val);
                        }
                      }}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm text-slate-700 bg-white border border-slate-200 rounded-lg shadow-2xs focus:outline-none focus:border-[#0095ff]"
                    >
                      <option value="SEMUA">Semua Ruang Ujian</option>
                      {availableExamRooms.map((room) => (
                        <option key={room} value={room}>
                          {room}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 4. Apply Button */}
                  <div className="lg:col-span-3 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={handleApplyFilter}
                      className="px-6 py-2.5 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs sm:text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                    >
                      Apply
                    </button>
                  </div>
                </div>

                {/* Tab Pengelompokan Siswa per Ruang Ujian */}
                <div className="pt-2 flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setFilterKelompok('SEMUA');
                      setAppliedKelompok('SEMUA');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                      appliedKelompok === 'SEMUA'
                        ? 'bg-[#001a6e] text-white border-[#001a6e] shadow-2xs'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Semua Ruang ({participants.length})
                  </button>
                  {availableExamRooms.map((room) => {
                    const countInRoom = participants.filter(
                      (p) => resolveParticipantRuang(p) === room
                    ).length;
                    const isSelectedRoom = appliedKelompok === room;
                    return (
                      <button
                        key={room}
                        type="button"
                        onClick={() => {
                          setFilterKelompok(room);
                          setAppliedKelompok(room);
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer flex items-center gap-1.5 ${
                          isSelectedRoom
                            ? 'bg-[#0095ff] text-white border-[#0095ff] shadow-2xs'
                            : countInRoom > 0
                            ? 'bg-blue-50/70 text-[#001a6e] border-blue-200 hover:bg-blue-100/70'
                            : 'bg-white text-slate-400 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span>{room}</span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            isSelectedRoom
                              ? 'bg-white/20 text-white'
                              : countInRoom > 0
                              ? 'bg-[#0095ff] text-white'
                              : 'bg-slate-100 text-slate-400'
                          }`}
                        >
                          {countInRoom > 0 ? `${countInRoom} Siswa` : 'Kosong'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Table Card */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-100 overflow-hidden">
                {/* Search & Move Room / Unassign / Assign Toolbar */}
                <div className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Search Input & Selected Counter */}
                  <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
                    <div className="relative w-full sm:w-72">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search Username, Nama, atau Ruang..."
                        className="w-full pl-10 pr-4 py-2 text-xs text-slate-700 placeholder:text-slate-400 bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-[#0095ff]"
                      />
                    </div>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 border border-blue-200 text-[#0095ff] text-xs font-bold">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>{selectedVisibleCount} Siswa Terpilih</span>
                    </span>
                  </div>

                  {/* Action Buttons: Pindahkan Ruang Ujian | Unassign | Assign */}
                  <div className="flex flex-wrap items-center gap-2.5">
                    <div className="inline-flex items-center gap-1.5 bg-blue-50/60 border border-blue-200 rounded-lg p-1">
                      <span className="text-[11px] font-bold text-[#001a6e] pl-2">
                        Pindahkan ke:
                      </span>
                      <select
                        value={targetMoveRuang}
                        onChange={(e) => setTargetMoveRuang(e.target.value)}
                        aria-label="Pilih Ruang Ujian Tujuan"
                        className="px-2.5 py-1 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-md focus:outline-none focus:border-[#0095ff]"
                      >
                        {availableExamRooms.map((room) => (
                          <option key={room} value={room}>
                            {room}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={() => handleMoveSelectedToRuang(targetMoveRuang)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold transition-colors cursor-pointer shadow-2xs"
                      >
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Pindahkan Ruang</span>
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={handleUnassignSelected}
                      className="px-4 py-2 rounded-lg border border-[#93c5fd] bg-blue-50/50 hover:bg-blue-100/70 text-[#3b82f6] text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Unassign
                    </button>
                    <button
                      type="button"
                      onClick={handleAssignSelected}
                      className="px-5 py-2 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                    >
                      Assign
                    </button>
                  </div>
                </div>

                {/* Participant Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-[#f8f9fc] border-y border-slate-100 text-[12px] font-bold text-slate-600">
                        <th className="py-3.5 px-5 w-14">
                          <button
                            type="button"
                            onClick={handleToggleSelectAll}
                            aria-label="Pilih Semua Peserta"
                            title="Pilih / Batal Pilih Semua Siswa"
                            className={`w-5 h-5 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                              allVisibleSelected
                                ? 'bg-[#0095ff] border-2 border-[#0095ff] text-white shadow-2xs ring-2 ring-blue-100'
                                : 'bg-blue-50/50 hover:bg-blue-100/80 border-2 border-[#0095ff]/60 text-[#0095ff]/40 hover:text-[#0095ff]'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </button>
                        </th>
                        <th className="py-3.5 px-4">
                          <div className="inline-flex items-center gap-1.5">
                            <span>Status</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3.5 px-4">
                          <div className="inline-flex items-center gap-1.5">
                            <span>Kode Test</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3.5 px-4">
                          <div className="inline-flex items-center gap-1.5">
                            <span>Ruang Ujian</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3.5 px-4">
                          <div className="inline-flex items-center gap-1.5">
                            <span>Username</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3.5 px-4">
                          <div className="inline-flex items-center gap-1.5">
                            <span>Nama Peserta</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {appliedKelompok !== 'SEMUA' ? (
                        filteredRows.length === 0 ? (
                          <tr>
                            <td
                              colSpan={6}
                              className="py-12 text-center text-slate-500 space-y-2"
                            >
                              <div className="text-sm font-bold text-slate-700">
                                Tidak ada data
                              </div>
                              <p className="text-xs text-slate-500">
                                Belum ada peserta yang ditempatkan pada{' '}
                                <strong>{appliedKelompok}</strong>. Pilih siswa
                                dengan tombol centang biru lalu klik{' '}
                                <strong>Pindahkan Ruang</strong>.
                              </p>
                              <button
                                type="button"
                                onClick={() => {
                                  setFilterStatus('Semua Status');
                                  setAppliedStatus('Semua Status');
                                  setFilterKodeTes('SEMUA');
                                  setAppliedKodeTes('SEMUA');
                                  setFilterKelompok('SEMUA');
                                  setAppliedKelompok('SEMUA');
                                  setSearchQuery('');
                                }}
                                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0095ff] text-xs font-semibold cursor-pointer"
                              >
                                Tampilkan Semua Ruang Ujian
                              </button>
                            </td>
                          </tr>
                        ) : (
                          filteredRows.map((row) => {
                            const isRowSelected = selectedParticipantIds.has(row.id);
                            return (
                            <tr
                              key={row.id}
                              onClick={() => handleToggleRow(row.id)}
                              className={`transition-colors cursor-pointer ${
                                isRowSelected
                                  ? 'bg-blue-50/35 hover:bg-blue-50/60'
                                  : 'hover:bg-slate-50/90'
                              }`}
                            >
                              <td
                                className="py-4 px-5"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <button
                                  type="button"
                                  onClick={() => handleToggleRow(row.id)}
                                  aria-label={`Pilih ${row.namaPeserta}`}
                                  title={
                                    isRowSelected
                                      ? `Batal pilih ${row.namaPeserta}`
                                      : `Pilih ${row.namaPeserta}`
                                  }
                                  className={`w-5 h-5 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                                    isRowSelected
                                      ? 'bg-[#0095ff] border-2 border-[#0095ff] text-white shadow-2xs ring-2 ring-blue-100'
                                      : 'bg-blue-50/50 hover:bg-blue-100/80 border-2 border-[#0095ff]/60 text-[#0095ff]/35 hover:text-[#0095ff]'
                                  }`}
                                >
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                </button>
                              </td>
                              <td className="py-4 px-4">
                                {isParticipantStatusActive(row.status) ? (
                                  <span className="inline-block min-w-[110px] text-center px-3 py-1 rounded-md bg-emerald-100 text-emerald-700 font-semibold text-[11.5px]">
                                    Active
                                  </span>
                                ) : (
                                  <span className="inline-block min-w-[110px] text-center px-3 py-1 rounded-md bg-[#ffe4e6] text-[#f43f5e] font-semibold text-[11.5px]">
                                    Non Active
                                  </span>
                                )}
                              </td>
                              <td className="py-4 px-4 font-medium text-slate-600">
                                {row.kodeTes}
                              </td>
                              <td className="py-4 px-4">
                                <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-blue-50 text-[#001a6e] border border-blue-200 font-bold text-[11px]">
                                  {resolveParticipantRuang(row)}
                                </span>
                              </td>
                              <td className="py-4 px-4 font-mono text-slate-600">
                                {row.username}
                              </td>
                              <td className="py-4 px-4 font-medium text-slate-700">
                                {row.namaPeserta}
                              </td>
                            </tr>
                            );
                          })
                        )
                      ) : (
                        availableExamRooms.map((room) => {
                          const roomRows = filteredRows.filter(
                            (r) => resolveParticipantRuang(r) === room
                          );
                          return (
                            <React.Fragment key={room}>
                              <tr className="bg-slate-100/85 border-y border-slate-200">
                                <td
                                  colSpan={6}
                                  className="py-2.5 px-5 font-extrabold text-xs text-[#001a6e]"
                                >
                                  <div className="flex items-center justify-between">
                                    <span>KELOMPOK RUANG UJIAN: {room}</span>
                                    <span
                                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                                        roomRows.length > 0
                                          ? 'bg-blue-100 text-[#001a6e]'
                                          : 'bg-slate-200 text-slate-600'
                                      }`}
                                    >
                                      {roomRows.length > 0
                                        ? `${roomRows.length} Peserta`
                                        : 'Tidak ada data (0 Peserta)'}
                                    </span>
                                  </div>
                                </td>
                              </tr>
                              {roomRows.length === 0 ? (
                                <tr>
                                  <td
                                    colSpan={6}
                                    className="py-4 px-5 text-center text-slate-400 italic bg-slate-50/40"
                                  >
                                    Tidak ada data peserta pada {room}.
                                  </td>
                                </tr>
                              ) : (
                                roomRows.map((row) => {
                                  const isRowSelected = selectedParticipantIds.has(row.id);
                                  return (
                                  <tr
                                    key={row.id}
                                    onClick={() => handleToggleRow(row.id)}
                                    className={`transition-colors cursor-pointer ${
                                      isRowSelected
                                        ? 'bg-blue-50/35 hover:bg-blue-50/60'
                                        : 'hover:bg-slate-50/90'
                                    }`}
                                  >
                                    <td
                                      className="py-4 px-5"
                                      onClick={(e) => e.stopPropagation()}
                                    >
                                      <button
                                        type="button"
                                        onClick={() => handleToggleRow(row.id)}
                                        aria-label={`Pilih ${row.namaPeserta}`}
                                        title={
                                          isRowSelected
                                            ? `Batal pilih ${row.namaPeserta}`
                                            : `Pilih ${row.namaPeserta}`
                                        }
                                        className={`w-5 h-5 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                                          isRowSelected
                                            ? 'bg-[#0095ff] border-2 border-[#0095ff] text-white shadow-2xs ring-2 ring-blue-100'
                                            : 'bg-blue-50/50 hover:bg-blue-100/80 border-2 border-[#0095ff]/60 text-[#0095ff]/35 hover:text-[#0095ff]'
                                        }`}
                                      >
                                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                                      </button>
                                    </td>
                                    <td className="py-4 px-4">
                                      {isParticipantStatusActive(row.status) ? (
                                        <span className="inline-block min-w-[110px] text-center px-3 py-1 rounded-md bg-emerald-100 text-emerald-700 font-semibold text-[11.5px]">
                                          Active
                                        </span>
                                      ) : (
                                        <span className="inline-block min-w-[110px] text-center px-3 py-1 rounded-md bg-[#ffe4e6] text-[#f43f5e] font-semibold text-[11.5px]">
                                          Non Active
                                        </span>
                                      )}
                                    </td>
                                    <td className="py-4 px-4 font-medium text-slate-600">
                                      {row.kodeTes}
                                    </td>
                                    <td className="py-4 px-4">
                                      <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-blue-50 text-[#001a6e] border border-blue-200 font-bold text-[11px]">
                                        {resolveParticipantRuang(row)}
                                      </span>
                                    </td>
                                    <td className="py-4 px-4 font-mono text-slate-600">
                                      {row.username}
                                    </td>
                                    <td className="py-4 px-4 font-medium text-slate-700">
                                      {row.namaPeserta}
                                    </td>
                                  </tr>
                                  );
                                })
                              )}
                            </React.Fragment>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 2. BERANDA */}
          {activeMenu === 'beranda' && (
            <div className="space-y-6">
              {/* Kartu Token Ujian Aktif (Otomatis Berganti Setiap 10 Menit jika Mapel di Jadwal Aktif) */}
              <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-2xs space-y-4">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500">
                      <KeyRound className="w-4 h-4 text-[#0095ff]" />
                      <span>Kartu Token Ujian Aktif</span>
                    </div>

                    {isAnyScheduleActive ? (
                      <div className="pt-1 flex flex-col items-start gap-3">
                        <div className="font-mono text-4xl sm:text-5xl font-black tracking-[0.25em] text-red-600 underline decoration-red-600 decoration-4 underline-offset-8 [text-shadow:0_0_1px_currentColor]">
                          {activeToken}
                        </div>
                        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700">
                          <span className="text-slate-500">
                            Berganti otomatis dalam:
                          </span>
                          <span className="font-mono font-black text-red-600 text-sm">
                            {tokenCountdownLabel}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="pt-1 flex flex-col items-start gap-3">
                        <div className="font-mono text-4xl sm:text-5xl font-black tracking-[0.2em] text-slate-400 underline decoration-slate-300 decoration-4 underline-offset-8 [text-shadow:0_0_1px_currentColor]">
                          BELUM KELUAR
                        </div>
                        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-400">
                          <span>Berganti otomatis dalam: --:--</span>
                        </div>
                        <div className="flex flex-wrap items-center gap-3">
                          <button
                            type="button"
                            onClick={() => setActiveMenu('jadwal')}
                            className="px-3.5 py-1.5 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold cursor-pointer"
                          >
                            Buka Menu Jadwal & Aktifkan Mapel →
                          </button>
                          <p className="text-xs text-slate-500 font-medium">
                            Mata pelajaran pada menu <strong>Jadwal</strong> belum diaktifkan oleh Administrator.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      type="button"
                      disabled={!isAnyScheduleActive}
                      onClick={() => {
                        onUpdateToken(activeToken);
                        showNotice(
                          `Token aktif (${activeToken}) berhasil disimpan & durasi ${tokenIntervalMinutes} menit di-reset.`
                        );
                      }}
                      className={`px-4 py-2 rounded-lg text-xs font-semibold ${
                        isAnyScheduleActive
                          ? 'bg-slate-800 hover:bg-slate-900 text-white cursor-pointer'
                          : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      Simpan Token
                    </button>
                    <button
                      type="button"
                      disabled={!isAnyScheduleActive}
                      onClick={() => {
                        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
                        let t = '';
                        for (let i = 0; i < 6; i++) {
                          t += chars.charAt(
                            Math.floor(Math.random() * chars.length)
                          );
                        }
                        setCustomTokenInput(t);
                        onUpdateToken(t);
                        showNotice(
                          `Token baru dirilis (${t}) — durasi otomatis ${tokenIntervalMinutes} menit dimulai ulang.`
                        );
                      }}
                      className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold ${
                        isAnyScheduleActive
                          ? 'bg-[#0095ff] hover:bg-[#007acc] text-white cursor-pointer'
                          : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Rilis Token Baru</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs">
                  <div className="text-xs font-semibold text-slate-500">
                    Total Peserta Terdaftar
                  </div>
                  <div className="mt-2 font-mono text-2xl font-extrabold text-slate-800">
                    {participants.length} Peserta
                  </div>
                </div>
                <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs">
                  <div className="text-xs font-semibold text-slate-500">
                    Mapel Jadwal Aktif
                  </div>
                  <div className="mt-2 font-mono text-2xl font-extrabold text-emerald-600">
                    {activeSchedules.length} / {schedules.length} Mapel
                  </div>
                </div>
                <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs">
                  <div className="text-xs font-semibold text-slate-500">
                    Token Ujian Saat Ini ({tokenIntervalMinutes} Menit)
                  </div>
                  <div className="mt-2 flex items-baseline justify-between gap-2">
                    {isAnyScheduleActive ? (
                      <>
                        <span className="font-mono text-2xl font-black tracking-widest text-red-600 underline decoration-red-600 decoration-2 underline-offset-4">
                          {activeToken}
                        </span>
                        <span className="font-mono text-xs font-bold text-slate-500">
                          {tokenCountdownLabel}
                        </span>
                      </>
                    ) : (
                      <span className="font-mono text-xl font-black tracking-wider text-slate-400 underline decoration-slate-300 decoration-2 underline-offset-4">
                        BELUM KELUAR
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 border border-slate-200/80 shadow-2xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-800">
                        Penyimpanan Cloud Vercel (`/api/storage`)
                      </h3>
                      {storageEngine === 'vercel-kv' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-100 text-emerald-700 text-[11px] font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Vercel KV / Upstash Redis Terhubung</span>
                        </span>
                      ) : ephemeralStorageWarning ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[11px] font-bold border border-amber-200">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>Serverless Sementara (Belum Ada Redis)</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-100 text-emerald-700 text-[11px] font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Penyimpanan Server Lokal Aktif</span>
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      Seluruh data Jadwal Ujian, Daftar Proktor, Daftar Peserta, Kelompok Tes, Bank Soal, Token Aktif, dan Laporan Nilai tersimpan otomatis di Vercel Storage ({lastSyncedLabel}).
                    </p>
                  </div>
                  {onForceSyncStorage && (
                    <button
                      type="button"
                      onClick={() => {
                        onForceSyncStorage();
                        showNotice(
                          'Data sistem berhasil disinkronkan ke Penyimpanan Vercel!'
                        );
                      }}
                      className="shrink-0 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Sinkronkan ke Vercel</span>
                    </button>
                  )}
                </div>

                {/* Kolom URL & Tombol Tarik Data Storage (Migrasi Server 1 ke Server 2) */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="block text-xs font-bold text-slate-700">
                      Tarik Semua Data dari Server 1 / Storage Sebelumnya ke Server 2
                    </label>
                    <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                      Peserta • Kelompok Tes • Jadwal • Bank Soal • Proktor • Nilai
                    </span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-stretch">
                    <input
                      type="text"
                      value={pullStorageUrl}
                      onChange={(e) => {
                        const val = e.target.value;
                        setPullStorageUrl(val);
                        try {
                          localStorage.setItem('cbt_pull_storage_url', val);
                        } catch {
                          // ignore
                        }
                      }}
                      placeholder="URL Web Server 1 (https://server1.vercel.app) atau KV_REST_API_URL (https://xxx.upstash.io)"
                      className="md:col-span-6 px-3.5 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff] focus:ring-2 focus:ring-[#0095ff]/20"
                    />
                    <input
                      type="password"
                      value={pullStorageToken}
                      onChange={(e) => {
                        const val = e.target.value;
                        setPullStorageToken(val);
                        try {
                          localStorage.setItem('cbt_pull_storage_token', val);
                        } catch {
                          // ignore
                        }
                      }}
                      placeholder="Token KV_REST_API_TOKEN / Password Admin Server 1 (Opsional)"
                      className="md:col-span-3 px-3.5 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff] focus:ring-2 focus:ring-[#0095ff]/20"
                    />
                    <button
                      type="button"
                      disabled={isPullingStorage}
                      onClick={async () => {
                        if (!onPullStorage) return;
                        setIsPullingStorage(true);
                        try {
                          const target = pullStorageUrl.trim() || '/api/storage';
                          const res = await onPullStorage(target, pullStorageToken.trim());
                          showNotice(res.message);
                        } finally {
                          setIsPullingStorage(false);
                        }
                      }}
                      className={`md:col-span-3 shrink-0 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-white text-xs font-semibold shadow-2xs transition-colors ${
                        isPullingStorage
                          ? 'bg-emerald-400 cursor-wait'
                          : 'bg-emerald-600 hover:bg-emerald-700 cursor-pointer'
                      }`}
                    >
                      <Download
                        className={`w-3.5 h-3.5 ${
                          isPullingStorage ? 'animate-bounce' : ''
                        }`}
                      />
                      <span>
                        {isPullingStorage
                          ? 'Menarik Data Storage...'
                          : 'Tarik Data Storage'}
                      </span>
                    </button>
                  </div>
                  <div className="text-[11px] text-slate-500 space-y-1 leading-relaxed">
                    <p>
                      <strong className="text-slate-700">Cara 1 (Dari Link Web Server 1):</strong> Masukkan alamat web Server 1 (contoh: <code className="font-mono font-semibold text-slate-700">https://cbt-server1.vercel.app</code> atau <code className="font-mono font-semibold text-slate-700">https://cbt-server1.vercel.app/api/storage</code>), lalu klik <strong>Tarik Data Storage</strong>.
                    </p>
                    <p>
                      <strong className="text-slate-700">Cara 2 (Dari Database Vercel KV / Upstash Redis Sebelumnya):</strong> Buka Dashboard Vercel &rarr; tab <strong>Storage</strong> &rarr; klik database KV/Redis lama &rarr; salin <code className="font-mono font-semibold text-slate-700">KV_REST_API_URL</code> ke kolom URL dan <code className="font-mono font-semibold text-slate-700">KV_REST_API_TOKEN</code> ke kolom Token, lalu klik <strong>Tarik Data Storage</strong>. Seluruh data otomatis disalin dan disimpan ke Server 2.
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-700">
                    Dashboard Administrator — CBT SMA Islam Diponegoro Wagir
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Kartu <strong>Token Ujian Aktif</strong> pada halaman Beranda ini akan berganti secara otomatis setiap <strong>10 menit</strong>. Gunakan menu <strong>Daftar Proktor</strong> untuk mengelola akun proktor ruang ujian, menu <strong>Kelompok Tes</strong> untuk mengaktifkan (Assign) peserta ujian, menu <strong>Daftar Peserta</strong> untuk menambah peserta baru, menu <strong>Status Tes</strong> untuk mengelola Bank Soal, dan menu <strong>Laporan Pengolahan</strong> untuk merekapitulasi nilai.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 2B. DAFTAR PROKTOR */}
          {activeMenu === 'daftar_proktor' && (
            <div className="space-y-6">
              {/* Form Tambah Proktor Baru */}
              <form
                onSubmit={handleAddProctor}
                className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-800">
                    Tambah Akun Proktor Ruang Baru
                  </h3>
                  <span className="text-xs text-slate-500">
                    Total Proktor: <strong>{proctors.length}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
                  <div className="space-y-1">
                    <label className="flex items-center justify-between text-xs font-semibold text-slate-500">
                      <span>ID / Username Proktor</span>
                      <span className="text-[10px] font-bold text-emerald-600 uppercase">
                        Otomatis
                      </span>
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={autoGeneratedProctorId}
                      title="ID / Username Proktor terisi otomatis"
                      className="w-full px-3 py-2 font-mono font-semibold text-xs text-slate-700 bg-slate-100 border border-slate-200 rounded-lg cursor-not-allowed select-all"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Nama Lengkap Proktor *
                    </label>
                    <input
                      type="text"
                      required
                      value={newProctorName}
                      onChange={(e) => setNewProctorName(e.target.value)}
                      placeholder="Nama lengkap & gelar"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Ruang / Lab Ujian
                    </label>
                    <input
                      type="text"
                      value={newProctorRoom}
                      onChange={(e) => setNewProctorRoom(e.target.value)}
                      placeholder="Misal: LAB KOMPUTER 1"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Rombel yang Dipegang
                    </label>
                    <input
                      type="text"
                      value={newProctorRombel}
                      onChange={(e) => setNewProctorRombel(e.target.value)}
                      placeholder="Misal: Kelas X & XI IPA"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="flex items-center justify-between text-xs font-semibold text-slate-500">
                      <span>Kode Enkripsi</span>
                      <span className="text-[10px] font-bold text-emerald-600 uppercase">
                        Otomatis
                      </span>
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={autoGeneratedProctorEnc}
                      title="Kode Enkripsi terisi otomatis"
                      className="w-full px-3 py-2 font-mono font-bold text-xs text-emerald-700 bg-emerald-50/70 border border-emerald-200 rounded-lg cursor-not-allowed select-all"
                    />
                  </div>

                  <div>
                    <button
                      type="submit"
                      className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Tambah Proktor</span>
                    </button>
                  </div>
                </div>
              </form>

              {/* Tabel Daftar Proktor */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-100 overflow-hidden">
                <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100">
                  <div className="relative w-full sm:max-w-xs">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={proctorSearch}
                      onChange={(e) => setProctorSearch(e.target.value)}
                      placeholder="Cari ID Proktor, Nama, Ruang, atau Rombel..."
                      className="w-full pl-10 pr-4 py-2 text-xs text-slate-700 placeholder:text-slate-400 bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        generateProctorCardsPDF(
                          proctors,
                          'Kartu_Semua_Proktor_CBT_SMADIP.pdf',
                          schedules
                        );
                        showNotice(
                          'File PDF seluruh Kartu Proktor berhasil diunduh!'
                        );
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak Semua Kartu Proktor (PDF)</span>
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#f8f9fc] border-b border-slate-100 text-slate-600 font-bold">
                        <th className="py-3.5 px-5">Status</th>
                        <th className="py-3.5 px-4">ID Proktor</th>
                        <th className="py-3.5 px-4">Nama Proktor</th>
                        <th className="py-3.5 px-4">Ruang / Lab</th>
                        <th className="py-3.5 px-4">Rombel yang Dipegang</th>
                        <th className="py-3.5 px-4">Kode Enkripsi</th>
                        <th className="py-3.5 px-4">Kata Sandi</th>
                        <th className="py-3.5 px-4 text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {proctors
                        .filter((pr) => {
                          if (!proctorSearch.trim()) return true;
                          const q = proctorSearch.toLowerCase();
                          return (
                            String(pr?.proctorId || '').toLowerCase().includes(q) ||
                            String(pr?.fullName || '').toLowerCase().includes(q) ||
                            String(pr?.roomName || '').toLowerCase().includes(q) ||
                            String(pr?.rombel || '').toLowerCase().includes(q)
                          );
                        })
                        .map((pr) => (
                          <tr key={pr.id} className="hover:bg-slate-50/90">
                            <td className="py-4 px-5">
                              {pr.status === 'Active' ? (
                                <span className="inline-block min-w-[96px] text-center px-3 py-1 rounded-md bg-emerald-100 text-emerald-700 font-semibold text-[11.5px]">
                                  Active
                                </span>
                              ) : (
                                <span className="inline-block min-w-[96px] text-center px-3 py-1 rounded-md bg-[#ffe4e6] text-[#f43f5e] font-semibold text-[11.5px]">
                                  Non Active
                                </span>
                              )}
                            </td>
                            <td className="py-4 px-4 font-mono font-semibold text-slate-700">
                              {pr.proctorId}
                            </td>
                            <td className="py-4 px-4 font-semibold text-slate-800">
                              {pr.fullName}
                            </td>
                            <td className="py-4 px-4 text-slate-600">
                              {pr.roomName}
                            </td>
                            <td className="py-4 px-4">
                              <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200/80 font-semibold text-[11px]">
                                {pr.rombel}
                              </span>
                            </td>
                            <td className="py-4 px-4 font-mono font-bold text-[#0095ff]">
                              {pr.encryptionCode}
                            </td>
                            <td className="py-4 px-4 font-mono text-slate-500">
                              {pr.password}
                            </td>
                            <td className="py-4 px-4 text-right space-x-2 whitespace-nowrap">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingProctor(pr);
                                  setEditingProctorForm({ ...pr });
                                }}
                                className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-[11px] font-semibold cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                                title="Edit & Simpan Data Proktor"
                              >
                                <Edit className="w-3.5 h-3.5 text-[#0095ff]" />
                                <span>Edit</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleToggleProctorStatus(pr.id)}
                                className="px-3 py-1.5 rounded-lg border border-blue-200 bg-blue-50 hover:bg-blue-100 text-[#0095ff] text-[11px] font-semibold cursor-pointer"
                              >
                                {pr.status === 'Active' ? 'Nonaktifkan' : 'Aktifkan'}
                              </button>
                              {proctors.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteProctor(pr.id)}
                                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer inline-flex items-center"
                                  title="Hapus Proktor"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Template Kartu Proktor (Sesuai Contoh Resmi) */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-100 p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-800">
                      Template Kartu Proktor
                    </h3>
                    <p className="text-xs text-slate-500">
                      Pratinjau format cetak Kartu Proktor (Nama Proktor, ID Proktor, Rombel yang Dipegang, Kode Enkripsi, Kata Sandi, dan Nama Sekolah)
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  {proctors
                    .filter((pr) => {
                      if (!proctorSearch.trim()) return true;
                      const q = proctorSearch.toLowerCase();
                      return (
                        String(pr?.proctorId || '').toLowerCase().includes(q) ||
                        String(pr?.fullName || '').toLowerCase().includes(q) ||
                        String(pr?.roomName || '').toLowerCase().includes(q) ||
                        String(pr?.rombel || '').toLowerCase().includes(q)
                      );
                    })
                    .map((pr) => (
                      <div
                        key={`card_${pr.id}`}
                        className="bg-white border border-slate-300 p-5 text-slate-900 shadow-2xs"
                      >
                        {/* Header Kartu dengan garis atas & bawah */}
                        <div className="border-y border-black py-2.5 px-2 flex items-center justify-between gap-3">
                          <TutWuriLogo className="w-14 h-14 shrink-0" />
                          <div className="text-center leading-snug font-bold text-black text-[13px] sm:text-sm tracking-tight">
                            <div>KARTU PROKTOR</div>
                            <div>SUMATIF AKHIR SEMESTER</div>
                            <div>TAHUN 2026</div>
                          </div>
                          <div className="w-14 shrink-0" aria-hidden="true" />
                        </div>

                        {/* Isi Data Proktor */}
                        <div className="mt-4 space-y-2 text-xs sm:text-[13px] text-black">
                          <div className="grid grid-cols-[155px_12px_1fr]">
                            <span>Nama Proktor</span>
                            <span>:</span>
                            <span className="font-medium">{pr.fullName}</span>
                          </div>
                          <div className="grid grid-cols-[155px_12px_1fr]">
                            <span>ID Proktor</span>
                            <span>:</span>
                            <span className="font-mono">{pr.proctorId}</span>
                          </div>
                          <div className="grid grid-cols-[155px_12px_1fr]">
                            <span>Rombel yang Dipegang</span>
                            <span>:</span>
                            <span>{pr.rombel}</span>
                          </div>
                          <div className="grid grid-cols-[155px_12px_1fr]">
                            <span>Kode Enkripsi</span>
                            <span>:</span>
                            <span className="font-mono">{pr.encryptionCode}</span>
                          </div>
                          <div className="grid grid-cols-[155px_12px_1fr]">
                            <span>Kata Sandi</span>
                            <span>:</span>
                            <span className="font-mono">{pr.password}</span>
                          </div>
                          <div className="grid grid-cols-[155px_12px_1fr]">
                            <span>Nama Sekolah</span>
                            <span>:</span>
                            <span>SMA ISLAM DIPONEGORO WAGIR</span>
                          </div>
                        </div>

                        <div className="mt-5 border-b border-black" />
                      </div>
                    ))}
                </div>
              </div>

              {/* Modal Edit Data Proktor */}
              {editingProctor && editingProctorForm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
                  <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                    <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-[#f8f9fc]">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-blue-100 text-[#0095ff] flex items-center justify-center font-bold">
                          <Edit className="w-4 h-4" />
                        </div>
                        <div>
                          <h3 className="text-sm font-bold text-slate-800">Edit Data Proktor</h3>
                          <p className="text-[11px] text-slate-500">ID: {editingProctor.proctorId}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingProctor(null);
                          setEditingProctorForm(null);
                        }}
                        className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <form onSubmit={handleSaveEditingProctor} className="p-6 space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Nama Lengkap Proktor / Gelar
                        </label>
                        <input
                          type="text"
                          required
                          value={editingProctorForm.fullName}
                          onChange={(e) =>
                            setEditingProctorForm((prev) =>
                              prev ? { ...prev, fullName: e.target.value } : null
                            )
                          }
                          placeholder="Contoh: DRS. H. AHMAD FAUZI, M.PD."
                          className="w-full px-3 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0095ff]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Ruang / Lab Ujian
                        </label>
                        <input
                          type="text"
                          required
                          value={editingProctorForm.roomName}
                          onChange={(e) =>
                            setEditingProctorForm((prev) =>
                              prev ? { ...prev, roomName: e.target.value } : null
                            )
                          }
                          placeholder="Contoh: LAB KOMPUTER 1"
                          className="w-full px-3 py-2 text-xs text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0095ff]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Rombel yang Dipegang
                        </label>
                        <input
                          type="text"
                          required
                          value={editingProctorForm.rombel}
                          onChange={(e) =>
                            setEditingProctorForm((prev) =>
                              prev ? { ...prev, rombel: e.target.value } : null
                            )
                          }
                          placeholder="Contoh: Kelas X & XI IPA"
                          className="w-full px-3 py-2 text-xs text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0095ff]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Kata Sandi Login Proktor
                        </label>
                        <input
                          type="text"
                          required
                          value={editingProctorForm.password}
                          onChange={(e) =>
                            setEditingProctorForm((prev) =>
                              prev ? { ...prev, password: e.target.value } : null
                            )
                          }
                          className="w-full px-3 py-2 text-xs font-mono text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0095ff]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Status Akun
                        </label>
                        <select
                          value={editingProctorForm.status}
                          onChange={(e) =>
                            setEditingProctorForm((prev) =>
                              prev
                                ? { ...prev, status: e.target.value as 'Active' | 'Non Active' }
                                : null
                            )
                          }
                          className="w-full px-3 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0095ff]"
                        >
                          <option value="Active">Active (Aktif Melayani Ujian)</option>
                          <option value="Non Active">Non Active (Nonaktif)</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingProctor(null);
                            setEditingProctorForm(null);
                          }}
                          className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 text-xs font-semibold text-white bg-[#0095ff] hover:bg-[#007acc] rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                        >
                          <Save className="w-3.5 h-3.5" />
                          Simpan Perubahan
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 3. DAFTAR PESERTA / STATUS PESERTA / REQUEST RESET / DAFTAR LOGIN */}
          {(activeMenu === 'daftar_peserta' ||
            activeMenu === 'status_peserta' ||
            activeMenu === 'request_reset' ||
            activeMenu === 'daftar_login') && (
            <div className="space-y-6">
              {activeMenu === 'daftar_peserta' && (
                <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  {/* Logo Kementerian Pendidikan di Sebelah Kiri Atas */}
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 shrink-0 rounded-xl bg-blue-50/70 border border-blue-200/80 p-1 flex items-center justify-center shadow-xs">
                      <TutWuriLogo className="w-11 h-11" />
                    </div>
                    <div>
                      <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                        Kementerian Pendidikan Dasar dan Menengah RI
                      </div>
                      <h2 className="text-base font-extrabold text-[#001a6e] tracking-tight">
                        Daftar Peserta & Cetak Kartu Login SAS 2026
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {appConfig?.namaSekolah || 'SMA Islam Diponegoro Wagir'} · NPSN: {appConfig?.npsn || '20517890'} · Total Terdaftar: <strong>{participants.length} Siswa</strong>
                      </p>
                    </div>
                  </div>

                  {/* Tombol Upload Excel (Nama Siswa & Kelas) dan Unduh Kartu Peserta (PDF) */}
                  <div className="flex items-center gap-2.5 flex-wrap self-start md:self-auto">
                    <input
                      ref={excelInputRef}
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleUploadParticipantExcel}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={handleDownloadTemplateExcel}
                      className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
                      title="Unduh contoh file Excel dengan format kolom Nama Siswa dan Kelas"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                      <span>Unduh Format Excel</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => excelInputRef.current?.click()}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-2 shadow-sm"
                      title="Upload file Excel (.xlsx / .xls / .csv) dengan format kolom Nama Siswa dan Kelas"
                    >
                      <Upload className="w-4 h-4 text-white" />
                      <span>Upload Excel (Nama Siswa & Kelas)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        generateParticipantCardsPDF(
                          participants,
                          `Kartu_Peserta_SAS_2026_${(appConfig?.namaSekolah || 'SMA_Islam_Diponegoro_Wagir').replace(/\s+/g, '_')}.pdf`,
                          appConfig?.namaSekolah || 'SMA ISLAM DIPONEGORO WAGIR',
                          appConfig?.namaKepalaSekolah || 'ROMEO GALISTRA, S.Pd.',
                          appConfig?.logoKartuPeserta
                        );
                        showNotice(`File PDF Kartu Peserta (${participants.length} Siswa) berhasil diunduh!`);
                      }}
                      className="px-4 py-2 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-2 shadow-sm"
                      title="Unduh seluruh kartu peserta dalam format PDF (A4 siap cetak)"
                    >
                      <Download className="w-4 h-4 text-[#0095ff]" />
                      <span>Unduh Kartu Peserta (PDF)</span>
                    </button>
                  </div>
                </div>
              )}

              {activeMenu === 'daftar_peserta' && (
                <form
                  onSubmit={handleAddParticipant}
                  className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h3 className="text-sm font-bold text-slate-800">
                        Tambah Peserta Baru (Username & Password Otomatis)
                      </h3>
                      <p className="text-xs text-slate-500">
                        Cukup masukkan <strong>Nama Lengkap Peserta</strong> saja. Username dan Password peserta akan terisi secara otomatis oleh sistem.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 items-end">
                    {/* Input Nama Peserta Saja */}
                    <div className="lg:col-span-3 space-y-1">
                      <label className="block text-xs font-semibold text-slate-700">
                        Nama Lengkap Peserta *
                      </label>
                      <input
                        type="text"
                        required
                        value={newParticipantName}
                        onChange={(e) => setNewParticipantName(e.target.value)}
                        placeholder="Ketikkan nama lengkap peserta saja..."
                        className="w-full px-3.5 py-2 text-xs bg-white border border-blue-300 focus:border-[#0095ff] rounded-lg focus:outline-none shadow-2xs"
                      />
                    </div>

                    {/* Auto-filled Username */}
                    <div className="lg:col-span-3 space-y-1">
                      <label className="flex items-center justify-between text-xs font-semibold text-slate-500">
                        <span>Username Peserta</span>
                        <span className="text-[10px] font-bold text-[#0095ff] uppercase">
                          Otomatis
                        </span>
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={autoGeneratedUsername}
                        title="Username terisi otomatis"
                        className="w-full px-3.5 py-2 font-mono font-semibold text-xs text-slate-700 bg-slate-100 border border-slate-200 rounded-lg cursor-not-allowed select-all"
                      />
                    </div>

                    {/* Auto-filled Password */}
                    <div className="lg:col-span-2 space-y-1">
                      <label className="flex items-center justify-between text-xs font-semibold text-slate-500">
                        <span>Password</span>
                        <span className="text-[10px] font-bold text-emerald-600 uppercase">
                          Otomatis
                        </span>
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={autoGeneratedPassword}
                        title="Password terisi otomatis"
                        className="w-full px-3.5 py-2 font-mono font-bold text-xs text-emerald-700 bg-emerald-50/70 border border-emerald-200 rounded-lg cursor-not-allowed select-all"
                      />
                    </div>

                    {/* Kelas */}
                    <div className="lg:col-span-2 space-y-1">
                      <label className="block text-xs font-semibold text-slate-600">
                        Kelas
                      </label>
                      <select
                        value={newParticipantKelas}
                        onChange={(e) => setNewParticipantKelas(e.target.value)}
                        className="w-full px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                      >
                        {KELAS_OPTIONS.map((kls) => (
                          <option key={kls} value={kls}>
                            {kls}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Submit Button */}
                    <div className="lg:col-span-2">
                      <button
                        type="submit"
                        className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Tambah Peserta</span>
                      </button>
                    </div>
                  </div>
                </form>
              )}

              <div className="bg-white rounded-xl shadow-xs border border-slate-100 overflow-hidden">
                <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h3 className="text-sm font-bold text-slate-800 whitespace-nowrap">
                      {currentMenuMeta.label} (
                      {activeMenu === 'request_reset'
                        ? `${
                            participants.filter((p) =>
                              isParticipantLockedByViolation(p)
                            ).length
                          } Permintaan Reset`
                        : `${participants.length} Peserta`}
                      )
                    </h3>
                    <div className="relative w-full sm:w-64">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={participantSearchQuery}
                        onChange={(e) => setParticipantSearchQuery(e.target.value)}
                        placeholder="Cari nama siswa..."
                        className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-700 placeholder:text-slate-400 focus:outline-none focus:border-[#0095ff] focus:ring-2 focus:ring-[#0095ff]/15"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    {activeMenu === 'request_reset' &&
                      participants.some((p) =>
                        isParticipantLockedByViolation(p)
                      ) && (
                        <button
                          type="button"
                          onClick={() => {
                            const nowTs = Date.now();
                            setParticipants((prev) =>
                              prev.map((row) => {
                                const needsReset =
                                  isParticipantLockedByViolation(row) ||
                                  Boolean(row.requestReset) ||
                                  row.loginState === 'Terkunci (Pelanggaran)';
                                if (!needsReset) return row;
                                const resetTs = Math.max(
                                  nowTs,
                                  (row.violationTimestamp || 0) + 1000,
                                  (row.lastResetAt || 0) + 1,
                                  (row.violationResetAt || 0) + 1,
                                  (row.loginUpdatedAt || 0) + 1
                                );
                                return buildResetParticipantRowPatch(
                                  row,
                                  resetTs,
                                  {
                                    clearViolationCount: true,
                                    onlyResetStateIfLocked: true,
                                    packages,
                                    resultsHistory,
                                  }
                                );
                              })
                            );
                            showNotice(
                              'Seluruh permintaan Reset Login dan hitungan pelanggaran peserta telah dibersihkan (kembali ke 0/6).'
                            );
                          }}
                          className="px-3.5 py-1.5 rounded-lg bg-[#f04452] hover:bg-[#d93240] text-white text-xs font-semibold cursor-pointer inline-flex items-center gap-1.5"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Reset Semua Pelanggaran</span>
                        </button>
                      )}
                    {(activeMenu === 'daftar_peserta' ||
                      activeMenu === 'status_peserta') && (() => {
                      const violationTotalCount = participants.filter(
                        (p) =>
                          isParticipantLockedByViolation(p) ||
                          Boolean(p.requestReset) ||
                          p.loginState === 'Terkunci (Pelanggaran)' ||
                          (typeof p.violationCount === 'number' && p.violationCount > 0)
                      ).length;
                      return (
                        <button
                          type="button"
                          onClick={() => {
                            if (violationTotalCount === 0) {
                              showNotice(
                                'Tidak ada catatan pelanggaran peserta yang perlu di-reset saat ini.'
                              );
                              return;
                            }
                            const nowTs = Date.now();
                            setParticipants((prev) =>
                              prev.map((row) => {
                                const hasViolation =
                                  isParticipantLockedByViolation(row) ||
                                  Boolean(row.requestReset) ||
                                  row.loginState === 'Terkunci (Pelanggaran)' ||
                                  (typeof row.violationCount === 'number' &&
                                    row.violationCount > 0) ||
                                  Boolean(row.violationReason || row.violationTimestamp);
                                if (!hasViolation) return row;
                                const resetTs = Math.max(
                                  nowTs,
                                  (row.violationTimestamp || 0) + 1000,
                                  (row.lastResetAt || 0) + 1,
                                  (row.violationResetAt || 0) + 1,
                                  (row.loginUpdatedAt || 0) + 1
                                );
                                return buildResetParticipantRowPatch(
                                  row,
                                  resetTs,
                                  {
                                    clearViolationCount: true,
                                    onlyResetStateIfLocked: true,
                                    packages,
                                    resultsHistory,
                                  }
                                );
                              })
                            );
                            showNotice(
                              `Berhasil mereset pelanggaran untuk ${violationTotalCount} peserta. Hitungan pelanggaran kembali ke 0/6.`
                            );
                          }}
                          className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer inline-flex items-center gap-1.5"
                          title="Reset seluruh catatan dan hitungan pelanggaran peserta (kembali ke 0/6)"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>
                            Reset Pelanggaran
                            {violationTotalCount > 0 ? ` (${violationTotalCount})` : ''}
                          </span>
                        </button>
                      );
                    })()}
                    <button
                      type="button"
                      onClick={() => setActiveMenu('kelompok_tes')}
                      className="text-xs font-semibold text-[#0095ff] hover:underline cursor-pointer"
                    >
                      Ke Menu Kelompok Tes →
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#f8f9fc] border-b border-slate-100 text-slate-600 font-bold">
                        <th className="py-3.5 px-5">Username</th>
                        <th className="py-3.5 px-4">Password</th>
                        <th className="py-3.5 px-4">Nama Peserta</th>
                        <th className="py-3.5 px-4">Ruang Ujian</th>
                        <th className="py-3.5 px-4">Kode Test</th>
                        <th className="py-3.5 px-4 text-center">Kelas</th>
                        <th className="py-3.5 px-4">Status</th>
                        <th className="py-3.5 px-4">Sesi Login</th>
                        <th className="py-3.5 px-4 text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(() => {
                        const filteredParticipantList = participants.filter((p) => {
                          const matchesMenu =
                            activeMenu === 'request_reset'
                              ? isParticipantLockedByViolation(p)
                              : true;
                          if (!matchesMenu) return false;
                          if (participantSearchQuery.trim()) {
                            const q = participantSearchQuery.trim().toLowerCase();
                            return (
                              String(p?.namaPeserta || '').toLowerCase().includes(q) ||
                              String(p?.username || '').toLowerCase().includes(q)
                            );
                          }
                          return true;
                        });

                        if (filteredParticipantList.length === 0) {
                          return (
                            <tr>
                              <td
                                colSpan={9}
                                className="py-10 px-5 text-center text-slate-500"
                              >
                                {activeMenu === 'request_reset' &&
                                !participantSearchQuery.trim()
                                  ? 'Tidak ada pelanggaran atau permintaan Reset Login saat ini. Seluruh sesi peserta berjalan normal.'
                                  : `Tidak ada peserta dengan nama "${participantSearchQuery}" yang ditemukan.`}
                              </td>
                            </tr>
                          );
                        }

                        return filteredParticipantList.map((p, idx) => {
                          const displayPassword =
                            p.password || `SMADIP${1547 + idx * 9}*`;
                          const currentKelas =
                            p.kelas || KELAS_OPTIONS[idx % KELAS_OPTIONS.length];
                          return (
                            <tr key={p.id} className="hover:bg-slate-50">
                              <td className="py-3.5 px-5 font-mono font-semibold text-slate-700">
                                {p.username}
                              </td>
                              <td className="py-3.5 px-4 font-mono font-bold text-[#0095ff]">
                                {displayPassword}
                              </td>
                              <td className="py-3.5 px-4 font-semibold text-slate-800">
                                {p.namaPeserta}
                              </td>
                              <td className="py-3.5 px-4">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded bg-blue-50 text-[#001a6e] border border-blue-200 font-bold text-[11px]">
                                  {resolveParticipantRuang(p)}
                                </span>
                              </td>
                              <td className="py-3.5 px-4 text-slate-600">
                                {p.kodeTes}
                              </td>
                              <td className="py-3.5 px-4 text-center font-semibold text-slate-700">
                                {currentKelas}
                              </td>
                              <td className="py-3.5 px-4">
                                {p.status === 'Active' ? (
                                  <span className="px-2.5 py-1 rounded bg-emerald-100 text-emerald-700 font-semibold">
                                    Active
                                  </span>
                                ) : (
                                  <span className="px-2.5 py-1 rounded bg-[#ffe4e6] text-[#f43f5e] font-semibold">
                                    Non Active
                                  </span>
                                )}
                              </td>
                              <td className="py-3.5 px-4">
                                {isParticipantLockedByViolation(p) ? (
                                  <div className="space-y-1">
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-rose-100 text-rose-700 font-bold text-[11px]">
                                        Terkunci (Pelanggaran Keluar CBT)
                                      </span>
                                      {typeof p.violationCount === 'number' &&
                                        p.violationCount > 0 && (
                                          <span
                                            className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-extrabold ${
                                              p.violationCount >= 6
                                                ? 'bg-rose-600 text-white'
                                                : 'bg-amber-100 text-amber-800 border border-amber-300'
                                            }`}
                                          >
                                            Pelanggaran {p.violationCount}/6
                                            {p.violationCount >= 6
                                              ? ' (Jawaban Dihapus)'
                                              : ''}
                                          </span>
                                        )}
                                    </div>
                                    {p.violationReason && (
                                      <div className="text-[11px] text-rose-600">
                                        {p.violationReason}
                                        {p.violationAt
                                          ? ` (${p.violationAt})`
                                          : ''}
                                      </div>
                                    )}
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span>{p.loginState}</span>
                                    {typeof p.violationCount === 'number' &&
                                      p.violationCount > 0 && (
                                        <span className="inline-flex items-center px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold">
                                          Pelanggaran {p.violationCount}/6
                                        </span>
                                      )}
                                  </div>
                                )}
                              </td>
                              <td className="py-3.5 px-4 text-right space-x-2 whitespace-nowrap">
                                <button
                                  type="button"
                                  onClick={() => {
                                    const targetUser = p.username.trim().toUpperCase();
                                    const nowTs = Date.now();
                                    setParticipants((prev) =>
                                      prev.map((row) => {
                                        if (
                                          row.id !== p.id &&
                                          row.username.trim().toUpperCase() !== targetUser
                                        ) {
                                          return row;
                                        }
                                        const resetTs = Math.max(
                                          nowTs,
                                          (row.violationTimestamp || 0) + 1000,
                                          (row.lastResetAt || 0) + 1,
                                          (row.loginUpdatedAt || 0) + 1
                                        );
                                        return buildResetParticipantRowPatch(
                                          row,
                                          resetTs,
                                          {
                                            packages,
                                            resultsHistory,
                                          }
                                        );
                                      })
                                    );
                                    showNotice(
                                      `Login peserta ${p.namaPeserta} (${p.username}) berhasil di-reset. Siswa kini dapat login kembali.`
                                    );
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-[#f04452] hover:bg-[#d93240] text-white text-[11px] font-semibold cursor-pointer"
                                >
                                  Reset Login
                                </button>
                                {participants.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setParticipants((prev) =>
                                        prev.filter((row) => row.id !== p.id)
                                      );
                                      showNotice(
                                        `Peserta ${p.namaPeserta} telah dihapus.`
                                      );
                                    }}
                                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer inline-flex items-center"
                                    title="Hapus Peserta"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 3B. JADWAL UJIAN (Di atas menu Status Tes) */}
          {activeMenu === 'jadwal' && (
            <div className="space-y-6">
              {/* Form Tambah Jadwal Ujian */}
              <form
                onSubmit={handleAddSchedule}
                className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-800">
                      Tambah Jadwal Ujian Sumatif Akhir Semester
                    </h3>
                    <p className="text-xs text-slate-500">
                      Input manual atau upload file Excel dengan kolom:{' '}
                      <strong>Hari dan Tanggal, Kelas, Mapel, Waktu Mulai, Durasi</strong>.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      ref={scheduleExcelInputRef}
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleUploadScheduleExcel}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={handleDownloadScheduleTemplateExcel}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-semibold transition-colors cursor-pointer"
                      title="Unduh template Excel jadwal (Hari dan Tanggal, Kelas, Mapel, Waktu Mulai, Durasi)"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Format Excel</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => scheduleExcelInputRef.current?.click()}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                      title="Upload jadwal ujian dari file Excel (.xlsx, .xls, .csv)"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Jadwal</span>
                    </button>
                    <span className="text-xs text-slate-500 ml-1">
                      Total Jadwal: <strong>{schedules.length}</strong>
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 items-end">
                  {/* Hari dan Tanggal */}
                  <div className="lg:col-span-3 space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Hari dan Tanggal *
                    </label>
                    <input
                      type="text"
                      required
                      value={newHariTanggal}
                      onChange={(e) => setNewHariTanggal(e.target.value)}
                      placeholder="Contoh: Senin, 07 Desember 2026"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    />
                  </div>

                  {/* Kelas */}
                  <div className="lg:col-span-2 space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Kelas *
                    </label>
                    <select
                      value={newJadwalKelas}
                      onChange={(e) => setNewJadwalKelas(e.target.value)}
                      className="w-full px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    >
                      {KELAS_OPTIONS.map((kls) => (
                        <option key={kls} value={kls}>
                          {kls}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Mapel */}
                  <div className="lg:col-span-3 space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Mapel (Mata Pelajaran) *
                    </label>
                    <input
                      type="text"
                      required
                      list="mapel-settings-suggestions"
                      value={newJadwalMapel}
                      onChange={(e) => setNewJadwalMapel(e.target.value)}
                      placeholder="Contoh: Matematika Wajib"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    />
                    <datalist id="mapel-settings-suggestions">
                      {(appConfig.mapelList || []).map((mpl: any, mIdx: number) => (
                        <option key={mpl.kode + mIdx} value={mpl.nama}>
                          {mpl.kode} - {mpl.nama} ({mpl.alokasiMenit} mnt)
                        </option>
                      ))}
                    </datalist>
                  </div>

                  {/* Waktu Mulai */}
                  <div className="lg:col-span-2 space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Waktu Mulai
                    </label>
                    <input
                      type="text"
                      value={newWaktuMulai}
                      onChange={(e) => setNewWaktuMulai(e.target.value)}
                      placeholder="Contoh: 07:30 WIB"
                      className="w-full px-3 py-2 font-mono text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                    />
                  </div>

                  {/* Durasi */}
                  <div className="lg:col-span-2 space-y-1">
                    <label className="block text-xs font-semibold text-slate-600">
                      Durasi
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={newDurasi}
                        onChange={(e) => setNewDurasi(e.target.value)}
                        placeholder="90 Menit"
                        className="w-full px-3 py-2 font-mono text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0095ff]"
                      />
                      <button
                        type="submit"
                        className="shrink-0 inline-flex items-center justify-center gap-1 px-3.5 py-2 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                        title="Tambah Jadwal"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Tambah</span>
                      </button>
                    </div>
                  </div>
                </div>
              </form>

              {/* Tabel Jadwal Ujian */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-100 overflow-hidden">
                <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#0095ff]" />
                      <h3 className="text-sm font-bold text-slate-800">
                        Daftar Jadwal Ujian — CBT SMA Islam Diponegoro Wagir
                      </h3>
                    </div>
                    <p className="text-xs text-slate-500">
                      Klik tombol <strong>Aktifkan Mapel</strong> pada jadwal di bawah agar Token Ujian keluar pada halaman Proktor dan Siswa dapat mulai mengerjakan.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          ensureBankSoalForSchedules(safeSchedules);
                          const nowTs = Date.now();
                          onUpdateSchedules(
                            safeSchedules.map((s) => ({
                              ...s,
                              isActive: true,
                              updatedAt: nowTs,
                            }))
                          );
                          showNotice(
                            'Semua mata pelajaran diaktifkan! Token ujian kini keluar di halaman Proktor & Siswa.'
                          );
                        }}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Aktifkan Semua Mapel</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const nowTs = Date.now();
                          onUpdateSchedules(
                            safeSchedules.map((s) => ({
                              ...s,
                              isActive: false,
                              updatedAt: nowTs,
                            }))
                          );
                          showNotice(
                            'Semua mata pelajaran dinonaktifkan. Token ujian disembunyikan dari Proktor & Siswa.'
                          );
                        }}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold cursor-pointer"
                      >
                        <span>Nonaktifkan Semua</span>
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-[#f8f9fc] border-b border-slate-100 text-slate-600 font-bold">
                          <th className="py-3.5 px-5 w-12">No</th>
                          <th className="py-3.5 px-4">Status Mapel</th>
                          <th className="py-3.5 px-4">Hari dan Tanggal</th>
                          <th className="py-3.5 px-4 text-center">Kelas</th>
                          <th className="py-3.5 px-4">Mapel</th>
                          <th className="py-3.5 px-4">Waktu Mulai</th>
                          <th className="py-3.5 px-4">Durasi</th>
                          <th className="py-3.5 px-4 text-right">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {safeSchedules.map((sch, index) => (
                        <tr key={sch.id} className="hover:bg-slate-50/90">
                          <td className="py-3.5 px-5 font-mono text-slate-500">
                            {index + 1}
                          </td>
                          <td className="py-3.5 px-4">
                            {sch.isActive ? (
                              <span className="inline-block min-w-[110px] text-center px-3 py-1 rounded-md bg-emerald-100 text-emerald-700 font-semibold text-[11.5px]">
                                Aktif (Token Keluar)
                              </span>
                            ) : (
                              <span className="inline-block min-w-[110px] text-center px-3 py-1 rounded-md bg-[#ffe4e6] text-[#f43f5e] font-semibold text-[11.5px]">
                                Belum Diaktifkan
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 font-semibold text-slate-800">
                            {sch.hariTanggal}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className="inline-block px-2.5 py-1 rounded-md bg-blue-50 text-[#0095ff] font-bold">
                              {sch.kelas}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 font-semibold text-slate-700">
                            {sch.mapel}
                          </td>
                          <td className="py-3.5 px-4 font-mono text-slate-700">
                            <span className="inline-flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5 text-slate-400" />
                              <span>{sch.waktuMulai}</span>
                            </span>
                          </td>
                          <td className="py-3.5 px-4 font-mono font-semibold text-emerald-700">
                            {sch.durasi}
                          </td>
                          <td className="py-3.5 px-4 text-right space-x-2 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => handleToggleScheduleActive(sch.id)}
                              className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer ${
                                sch.isActive
                                  ? 'border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-600'
                                  : 'bg-[#0095ff] hover:bg-[#007acc] text-white shadow-2xs'
                              }`}
                            >
                              {sch.isActive
                                ? 'Nonaktifkan Mapel'
                                : 'Aktifkan Mapel'}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteSchedule(sch.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer inline-flex items-center"
                              title="Hapus Jadwal"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 4. STATUS TES (Manajemen Bank Soal & Input Soal) */}
          {activeMenu === 'status_tes' && !selectedPackage && (
            <div className="bg-white p-8 rounded-xl border border-slate-200/80 shadow-2xs text-center space-y-3">
              <FolderTree className="w-10 h-10 text-slate-300 mx-auto" />
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-800">
                  Belum Ada Mata Pelajaran Terdaftar
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Silakan daftarkan mata pelajaran terlebih dahulu pada menu <strong>Pengaturan &rarr; Daftar Mata Pelajaran Ujian</strong> agar muncul pada kartu pengelompokan mata pelajaran.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveMenu('pengaturan')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#001a6e] hover:bg-[#00155a] text-white text-xs font-bold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Buka Pengaturan Mata Pelajaran</span>
              </button>
            </div>
          )}

          {activeMenu === 'status_tes' && selectedPackage && (
            <div className="space-y-6">
              {/* KARTU 0: PENGELOMPOKAN MATA PELAJARAN SESUAI KELASNYA */}
              <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-2xs space-y-4">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <FolderTree className="w-5 h-5 text-[#0095ff] shrink-0" />
                    <div>
                      <h3 className="text-sm font-bold text-slate-800">
                        Pengelompokan Mata Pelajaran Sesuai Kelasnya
                      </h3>
                      <p className="text-[11.5px] text-slate-500">
                        Daftar mata pelajaran dari menu Pengaturan dikelompokkan berdasarkan masing-masing kelas (Kelas X, XI IPA, XI IPS, XII IPA, XII IPS).
                      </p>
                    </div>
                  </div>

                  {/* Filter Cepat Kelas pada Kartu Pengelompokan */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    {(['Semua Kelas', ...STATUS_TES_CLASS_GROUPS] as const).map((klsTab) => {
                      const isTabActive = statusTesKelas === klsTab;
                      const countInClass =
                        klsTab === 'Semua Kelas'
                          ? displayPackages.length
                          : displayPackages.filter((p) => getPkgClass(p) === klsTab).length;
                      return (
                        <button
                          key={klsTab}
                          type="button"
                          onClick={() => {
                            setStatusTesKelas(klsTab);
                            if (klsTab !== 'Semua Kelas') {
                              const firstPkgInClass = displayPackages.find(
                                (p) => getPkgClass(p) === klsTab
                              );
                              if (firstPkgInClass) {
                                setSelectedPkgId(firstPkgInClass.id);
                              }
                            }
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer flex items-center gap-1.5 border ${
                            isTabActive
                              ? 'bg-[#001a6e] text-white border-[#001a6e] shadow-2xs'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-blue-50 hover:text-[#0095ff] hover:border-blue-200'
                          }`}
                        >
                          <span>{klsTab}</span>
                          <span
                            className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                              isTabActive
                                ? 'bg-white/20 text-white'
                                : 'bg-slate-200/80 text-slate-700'
                            }`}
                          >
                            {countInClass}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div
                  className={`grid grid-cols-1 ${
                    statusTesKelas === 'Semua Kelas'
                      ? 'md:grid-cols-2 lg:grid-cols-3'
                      : 'md:grid-cols-1'
                  } gap-4`}
                >
                  {STATUS_TES_CLASS_GROUPS.filter(
                    (groupName) =>
                      statusTesKelas === 'Semua Kelas' || statusTesKelas === groupName
                  ).map((groupName) => {
                    const groupPkgs = displayPackages.filter(
                      (p) => getPkgClass(p) === groupName
                    );

                    const badgeStyle: Record<string, string> = {
                      'Kelas X': 'bg-blue-100 text-blue-800 border-blue-200',
                      'Kelas XI IPA': 'bg-emerald-100 text-emerald-800 border-emerald-200',
                      'Kelas XI IPS': 'bg-amber-100 text-amber-800 border-amber-200',
                      'Kelas XII IPA': 'bg-purple-100 text-purple-800 border-purple-200',
                      'Kelas XII IPS': 'bg-rose-100 text-rose-800 border-rose-200',
                    };

                    const headerBgStyle: Record<string, string> = {
                      'Kelas X': 'border-t-4 border-t-blue-500',
                      'Kelas XI IPA': 'border-t-4 border-t-emerald-500',
                      'Kelas XI IPS': 'border-t-4 border-t-amber-500',
                      'Kelas XII IPA': 'border-t-4 border-t-purple-500',
                      'Kelas XII IPS': 'border-t-4 border-t-rose-500',
                    };

                    return (
                      <div
                        key={groupName}
                        className={`p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3 ${headerBgStyle[groupName] || ''}`}
                      >
                        <div className="flex items-center justify-between border-b border-slate-200/70 pb-2.5">
                          <div className="flex items-center gap-2">
                            <GraduationCap className="w-4 h-4 text-slate-600" />
                            <span
                              className={`px-2.5 py-0.5 text-xs font-extrabold rounded-md border ${
                                badgeStyle[groupName] || 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {groupName}
                            </span>
                          </div>
                          <span className="text-[11px] font-bold text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                            {groupPkgs.length} Mata Pelajaran
                          </span>
                        </div>

                        <div
                          className={
                            statusTesKelas !== 'Semua Kelas'
                              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3'
                              : 'space-y-2.5'
                          }
                        >
                          {groupPkgs.length === 0 ? (
                            <p className="text-xs text-slate-400 italic py-4 text-center col-span-full">
                              Belum ada mata pelajaran untuk {groupName}
                            </p>
                          ) : (
                            groupPkgs.map((pkg, idxMapel) => {
                              const isSelected = selectedPackage.id === pkg.id;
                              const cleanTitle = pkg.title
                                .replace(/^Simulasi TKA\s*-\s*/i, '')
                                .replace(/\s*\(SMA\/MA\/SMK\)/i, '');

                              return (
                                <div
                                  key={pkg.id}
                                  onClick={() => setSelectedPkgId(pkg.id)}
                                  className={`p-3 rounded-lg border transition-all cursor-pointer flex items-start justify-between gap-2 group ${
                                    isSelected
                                      ? 'bg-blue-50/90 border-[#0095ff] ring-1 ring-[#0095ff]/30 shadow-xs'
                                      : 'bg-white border-slate-200 hover:border-blue-300 hover:bg-slate-50/60'
                                  }`}
                                >
                                  <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                                        {idxMapel + 1}. {pkg.code}
                                      </span>
                                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-50 text-[#001a6e] border border-blue-200">
                                        {groupName}
                                      </span>
                                      {pkg.questions.length > 0 ? (
                                        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                                          <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                          <span>{pkg.questions.length} Soal</span>
                                        </span>
                                      ) : (
                                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                                          <span>Belum Upload</span>
                                        </span>
                                      )}
                                    </div>
                                    <div className="text-xs font-bold text-slate-800 mt-1.5 leading-snug">
                                      {cleanTitle}
                                    </div>
                                    <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                                      {pkg.subtest} · {pkg.durationMinutes} mnt
                                    </p>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleDeleteMapelPackage(pkg);
                                    }}
                                    className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors cursor-pointer shrink-0"
                                    title={`Hapus mata pelajaran ${cleanTitle}`}
                                    aria-label={`Hapus mata pelajaran ${cleanTitle}`}
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* TABEL STATUS CENTANG SOAL MATA PELAJARAN YANG SUDAH DIUPLOAD */}
              {(() => {
                const checklistPackages =
                  statusTesKelas === 'Semua Kelas'
                    ? displayPackages
                    : displayPackages.filter(
                        (p) => getPkgClass(p) === statusTesKelas
                      );
                const uploadedCount = checklistPackages.filter(
                  (p) => Array.isArray(p.questions) && p.questions.length > 0
                ).length;
                const notUploadedCount =
                  checklistPackages.length - uploadedCount;

                return (
                  <div className="bg-white rounded-xl border border-slate-200/80 shadow-2xs overflow-hidden">
                    <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                      <div className="flex items-start gap-2.5">
                        <ClipboardCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <h3 className="text-sm font-bold text-slate-800">
                            Tabel Status Centang Soal Mata Pelajaran ({statusTesKelas})
                          </h3>
                          <p className="text-[11.5px] text-slate-500">
                            Daftar status kelengkapan upload bank soal untuk setiap mata pelajaran. Klik baris mata pelajaran untuk memilih atau mengunggah soal.
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-100 text-slate-700 font-bold border border-slate-200">
                          <span>Total Mapel:</span>
                          <span className="font-mono">{checklistPackages.length}</span>
                        </span>
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Sudah Diupload:</span>
                          <span className="font-mono">{uploadedCount}</span>
                        </span>
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-rose-50 text-rose-700 font-bold border border-rose-200">
                          <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                          <span>Belum Diupload:</span>
                          <span className="font-mono">{notUploadedCount}</span>
                        </span>
                      </div>
                    </div>

                    <div className="overflow-x-auto max-h-96">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead className="sticky top-0 z-10 bg-[#f8f9fc] border-b border-slate-200 text-slate-600 font-bold">
                          <tr>
                            <th className="py-3 px-4 w-12 text-center">No</th>
                            <th className="py-3 px-4 text-center w-36">Status Centang</th>
                            <th className="py-3 px-4">Kode Mapel</th>
                            <th className="py-3 px-4">Mata Pelajaran</th>
                            <th className="py-3 px-4 text-center">Kelas</th>
                            <th className="py-3 px-4">Kategori</th>
                            <th className="py-3 px-4 text-center">Jumlah Soal</th>
                            <th className="py-3 px-4 text-right min-w-[180px]">Aksi</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {checklistPackages.length === 0 ? (
                            <tr>
                              <td
                                colSpan={8}
                                className="py-8 px-4 text-center text-slate-400 italic"
                              >
                                Tidak ada mata pelajaran untuk filter {statusTesKelas}.
                              </td>
                            </tr>
                          ) : (
                            checklistPackages.map((pkg, idx) => {
                              const qCount = Array.isArray(pkg.questions)
                                ? pkg.questions.length
                                : 0;
                              const isUploaded = qCount > 0;
                              const isSelected = selectedPackage.id === pkg.id;
                              const pkgClass = getPkgClass(pkg);
                              const cleanTitle = pkg.title
                                .replace(/^Simulasi TKA\s*-\s*/i, '')
                                .replace(/\s*\(SMA\/MA\/SMK\)/i, '');

                              return (
                                <tr
                                  key={pkg.id}
                                  onClick={() => setSelectedPkgId(pkg.id)}
                                  className={`transition-colors cursor-pointer ${
                                    isSelected
                                      ? 'bg-blue-50/70 hover:bg-blue-50'
                                      : 'hover:bg-slate-50'
                                  }`}
                                >
                                  <td className="py-3 px-4 text-center font-mono font-semibold text-slate-500">
                                    {idx + 1}
                                  </td>
                                  <td className="py-3 px-4 text-center">
                                    {isUploaded ? (
                                      <span className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-[11px]">
                                        <span className="w-4 h-4 rounded bg-emerald-600 text-white inline-flex items-center justify-center text-[11px] font-extrabold leading-none shadow-2xs">
                                          ✓
                                        </span>
                                        <span>Sudah Upload</span>
                                      </span>
                                    ) : (
                                      <span className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-500 border border-slate-200 font-semibold text-[11px]">
                                        <span className="w-4 h-4 rounded border border-slate-300 bg-white inline-flex items-center justify-center text-[10px] leading-none text-transparent">
                                          ✓
                                        </span>
                                        <span>Belum Upload</span>
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-3 px-4 font-mono font-bold text-slate-700">
                                    {pkg.code}
                                  </td>
                                  <td className="py-3 px-4 font-bold text-slate-800">
                                    {cleanTitle}
                                  </td>
                                  <td className="py-3 px-4 text-center">
                                    <span className="px-2 py-0.5 rounded bg-blue-50 text-[#001a6e] border border-blue-200 font-bold text-[11px]">
                                      {pkgClass}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4 text-slate-600">
                                    {pkg.subtest}
                                  </td>
                                  <td className="py-3 px-4 text-center">
                                    {isUploaded ? (
                                      <span className="font-mono font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md">
                                        {qCount} Soal
                                      </span>
                                    ) : (
                                      <span className="font-mono text-slate-400">
                                        0 Soal
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-3 px-4 text-right whitespace-nowrap">
                                    {isUploaded ? (
                                      <div className="inline-flex items-center justify-end gap-1.5">
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setConfirmClearPkgId(null);
                                            setSelectedPkgId(pkg.id);
                                            setPreviewQuestionIdx(0);
                                            setShowQuestionPreviewModal(true);
                                          }}
                                          className="px-2.5 py-1 rounded-md bg-blue-50 hover:bg-[#001a6e] text-[#001a6e] hover:text-white border border-blue-200 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer transition-colors"
                                          title={`Pratinjau soal ${cleanTitle}`}
                                        >
                                          <Eye className="w-3 h-3" />
                                          <span>Lihat</span>
                                        </button>
                                        {confirmClearPkgId === pkg.id ? (
                                          <>
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleDeletePackageQuestions(pkg);
                                                setConfirmClearPkgId(null);
                                              }}
                                              className="px-2.5 py-1 rounded-md bg-rose-600 hover:bg-rose-700 text-white border border-rose-600 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer transition-colors"
                                              title={`Konfirmasi hapus semua soal ${cleanTitle}`}
                                            >
                                              <Trash2 className="w-3 h-3" />
                                              <span>Yakin Hapus?</span>
                                            </button>
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                setConfirmClearPkgId(null);
                                              }}
                                              className="px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200 text-[11px] font-semibold cursor-pointer transition-colors"
                                            >
                                              Batal
                                            </button>
                                          </>
                                        ) : (
                                          <button
                                            type="button"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setConfirmClearPkgId(pkg.id);
                                            }}
                                            className="px-2.5 py-1 rounded-md bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 hover:border-rose-600 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer transition-colors"
                                            title={`Hapus semua soal mata pelajaran ${cleanTitle}`}
                                          >
                                            <Trash2 className="w-3 h-3" />
                                            <span>Hapus Soal</span>
                                          </button>
                                        )}
                                      </div>
                                    ) : (
                                      <span className="text-[11px] text-slate-400 font-mono">
                                        -
                                      </span>
                                    )}
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })()}

              {/* KARTU 1 (ATAS): TAMBAH BUTIR SOAL BARU & UPLOAD WORD */}
              <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-2xs space-y-4">
                <div className="space-y-3.5 pb-3.5 border-b border-slate-100">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Plus className="w-4 h-4 text-[#0095ff]" />
                      <h3 className="text-sm font-bold text-slate-800">
                        Tambah Butir Soal Baru ({getQuestionTypeLabel(newQuestionType)})
                      </h3>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-slate-500 font-medium">Mapel Target:</span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
                        {getPkgClass(selectedPackage)}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-[#001a6e] font-semibold border border-blue-200">
                        {selectedPackage.title
                          .replace(/^Simulasi TKA\s*-\s*/i, '')
                          .replace(/\s*\(SMA\/MA\/SMK\)/i, '')}
                      </span>
                    </div>
                  </div>

                  {/* Baris Atas (Di Atas Tombol Upload Word): Kelas, Mata Pelajaran, Tipe Soal, Pratinjau Soal, Arsip Soal */}
                  <div className="p-3.5 rounded-xl bg-slate-50/90 border border-slate-200/80 flex flex-wrap items-center gap-3 text-xs">
                    {/* Dropdown Kelas */}
                    <div className="flex items-center gap-1.5">
                      <label className="font-semibold text-slate-700 whitespace-nowrap">
                        Kelas:
                      </label>
                      <select
                        value={statusTesKelas}
                        onChange={(e) => {
                          const newKelas = e.target.value;
                          setStatusTesKelas(newKelas);
                          if (newKelas !== 'Semua Kelas') {
                            const matched = displayPackages.find(
                              (p) => getPkgClass(p) === newKelas
                            );
                            if (matched) {
                              setSelectedPkgId(matched.id);
                            }
                          }
                        }}
                        className="px-3 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                      >
                        <option value="Semua Kelas">Semua Kelas</option>
                        {STATUS_TES_CLASS_GROUPS.map((kls) => (
                          <option key={kls} value={kls}>
                            {kls}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Dropdown Mata Pelajaran (Dikelompokkan Sesuai Kelasnya) */}
                    <div className="flex items-center gap-1.5">
                      <label className="font-semibold text-slate-700 whitespace-nowrap">
                        Mata Pelajaran:
                      </label>
                      <select
                        value={selectedPackage.id}
                        onChange={(e) => setSelectedPkgId(e.target.value)}
                        className="px-3 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                      >
                        {displayPackages.length === 0 && (
                          <option value="pkg_empty_fallback">
                            Belum Ada Mata Pelajaran Terdaftar
                          </option>
                        )}
                        {STATUS_TES_CLASS_GROUPS.filter(
                          (groupName) =>
                            statusTesKelas === 'Semua Kelas' ||
                            statusTesKelas === groupName
                        ).map((groupName) => {
                          const groupPkgs = displayPackages.filter(
                            (p) => getPkgClass(p) === groupName
                          );
                          if (groupPkgs.length === 0) return null;
                          return (
                            <optgroup
                              key={groupName}
                              label={`── ${groupName.toUpperCase()} (${groupPkgs.length} Mapel) ──`}
                            >
                              {groupPkgs.map((p) => {
                                const cleanTitle = p.title
                                  .replace(/^Simulasi TKA\s*-\s*/i, '')
                                  .replace(/\s*\(SMA\/MA\/SMK\)/i, '');
                                return (
                                  <option key={p.id} value={p.id}>
                                    [{groupName}] {cleanTitle} ({p.code})
                                  </option>
                                );
                              })}
                            </optgroup>
                          );
                        })}
                      </select>
                    </div>

                    {/* Dropdown Tipe Soal */}
                    <div className="flex items-center gap-1.5">
                      <label className="font-semibold text-slate-700 whitespace-nowrap">
                        Tipe Soal:
                      </label>
                      <select
                        value={statusTesTipeSoal}
                        onChange={(e) => {
                          const val = e.target.value;
                          setStatusTesTipeSoal(val);
                          if (val !== 'Semua Tipe Soal') {
                            setNewQuestionType(val as QuestionType);
                          }
                        }}
                        className="px-3 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                      >
                        <option value="Semua Tipe Soal">Semua Tipe Soal</option>
                        <option value="pilihan_ganda">Pilihan Ganda (PG)</option>
                        <option value="pilihan_ganda_kompleks">
                          Pilihan Ganda Kompleks (PG Kompleks)
                        </option>
                        <option value="benar_salah">Benar / Salah</option>
                        <option value="menjodohkan">Menjodohkan</option>
                        <option value="isian_singkat">Isian Singkat / Uraian</option>
                      </select>
                    </div>

                    {/* Tombol Pratinjau Soal */}
                    <button
                      type="button"
                      onClick={() => {
                        setPreviewQuestionIdx(0);
                        setShowQuestionPreviewModal(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-[#001a6e] text-[#001a6e] hover:text-white border border-blue-200 hover:border-[#001a6e] text-xs font-bold cursor-pointer flex items-center gap-1.5 transition-colors shadow-2xs"
                      title="Pratinjau butir soal pada mata pelajaran ini"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>
                        Pratinjau Soal (
                        {
                          selectedPackage.questions.filter((q) => {
                            if (statusTesTipeSoal === 'Semua Tipe Soal') return true;
                            return q.type === statusTesTipeSoal;
                          }).length
                        }
                        )
                      </span>
                    </button>

                    {/* Tombol Arsip Soal */}
                    <button
                      type="button"
                      onClick={() => {
                        downloadWordQuestionArchive(
                          selectedPackage,
                          statusTesTipeSoal
                        );
                        showNotice(
                          `Arsip soal (${statusTesTipeSoal}) mata pelajaran ${selectedPackage.title} berhasil diunduh (.docx).`
                        );
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white border border-emerald-300 hover:border-emerald-600 text-xs font-bold cursor-pointer flex items-center gap-1.5 transition-colors shadow-2xs"
                      title="Unduh butir soal yang sedang ditampilkan ke dalam dokumen Word (.docx) untuk arsip bank soal"
                    >
                      <Archive className="w-3.5 h-3.5" />
                      <span>Arsip Soal</span>
                    </button>
                  </div>

                  {/* Baris Bawah: Tombol Upload Word / File Soal & Template Word */}
                  <div className="flex flex-wrap items-center gap-2.5 text-xs">
                    {/* Input File Soal Tersembunyi (Mendukung Semua Format & Semua Tipe Soal) */}
                    <input
                      ref={wordQuestionInputRef}
                      type="file"
                      accept=".pdf,.docx,.doc,.xlsx,.xls,.csv,.txt,.rtf,.json,.html,.htm"
                      onChange={handleUploadWordQuestions}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={triggerUploadWordFile}
                      className="px-3.5 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-2xs transition-colors"
                      title="Upload file soal (.pdf, .docx, .doc, .xlsx, .xls, .csv, .txt, .rtf, .json) — otomatis mengenali semua jenis/tipe soal"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      Upload Word / PDF / File Soal (Otomatis Kenali Tipe Soal)
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        downloadWordQuestionTemplate(selectedPackage.title)
                      }
                      className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-semibold cursor-pointer flex items-center gap-1.5 transition-colors"
                      title="Unduh contoh format soal Word (.docx) dengan jawaban benar berwarna merah"
                    >
                      <FileText className="w-3.5 h-3.5 text-blue-600" />
                      Template Word
                    </button>

                    <label
                      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700 font-semibold cursor-pointer select-none hover:bg-slate-100 transition-colors"
                      title="Centang jika ingin menambahkan soal dari file ke soal yang sudah ada tanpa mengganti hasil unggahan sebelumnya"
                    >
                      <input
                        type="checkbox"
                        checked={appendUploadMode}
                        onChange={(e) => setAppendUploadMode(e.target.checked)}
                        className="w-3.5 h-3.5 rounded accent-[#0066ff] cursor-pointer"
                      />
                      <span>Tambahkan ke soal yang ada</span>
                    </label>

                    <div className="flex items-center gap-1.5 ml-auto">
                      <label className="font-semibold text-slate-700 whitespace-nowrap">
                        Jenis Input Manual:
                      </label>
                      <select
                        value={newQuestionType}
                        onChange={(e) =>
                          setNewQuestionType(e.target.value as QuestionType)
                        }
                        className="px-3 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                      >
                        <option value="pilihan_ganda">Pilihan Ganda (PG)</option>
                        <option value="pilihan_ganda_kompleks">
                          Pilihan Ganda Kompleks (PG Kompleks)
                        </option>
                        <option value="benar_salah">Benar / Salah</option>
                        <option value="menjodohkan">Menjodohkan</option>
                        <option value="isian_singkat">Isian Singkat / Uraian</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-3.5 py-2.5 rounded-lg bg-rose-50/70 border border-rose-200/80 text-xs text-rose-900">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>
                      <strong>Format Upload Word (.docx / .doc / .rtf), PDF & Excel:</strong> Otomatis membaca semua 5 jenis soal (<strong>PG, PG Kompleks, Benar/Salah, Menjodohkan, Isian Singkat</strong>), tabel horizontal/vertikal, rumus Word Equation, <strong>gambar soal/opsi/stimulus</strong>, serta wacana/stimulus. Kunci jawaban terbaca otomatis dari{' '}
                      <span className="font-bold text-rose-600 underline">
                        teks warna merah
                      </span>
                      , stabilo/highlight, garis bawah, cetak tebal, baris <strong>Kunci:</strong>, tanda <strong>* / ✓</strong>, atau daftar <strong>Kunci Jawaban</strong> di akhir dokumen.
                    </span>
                  </div>
                  {lastUploadedWordFile && (
                    <span className="px-2.5 py-1 rounded-md bg-emerald-100 text-emerald-800 font-bold border border-emerald-300 shrink-0">
                      Terunggah: {lastUploadedWordFile}
                    </span>
                  )}
                </div>

                <form
                  onSubmit={handleAddQuestion}
                  className="space-y-4 text-xs"
                >
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Judul Stimulus / Wacana{' '}
                        <span className="font-normal text-slate-500">(Opsional)</span>
                      </label>
                      <input
                        type="text"
                        value={newStimulusTitle}
                        onChange={(e) => setNewStimulusTitle(e.target.value)}
                        placeholder="Misal: Teks Bacaan 1"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block font-semibold text-slate-700 mb-1">
                        Isi Stimulus / Wacana{' '}
                        <span className="font-normal text-slate-500">(Opsional)</span>
                      </label>
                      <textarea
                        rows={2}
                        value={newStimulusText}
                        onChange={(e) => setNewStimulusText(e.target.value)}
                        placeholder="Ketik teks bacaan, pengantar, atau data stimulus soal di sini jika diperlukan..."
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Pertanyaan Soal{' '}
                      <span className="font-normal text-slate-500">
                        (Opsional / Tidak harus diisi jika sudah Upload Word)
                      </span>
                    </label>
                    <input
                      type="text"
                      value={newQuestionText}
                      onChange={(e) => setNewQuestionText(e.target.value)}
                      placeholder={
                        newQuestionType === 'pilihan_ganda'
                          ? 'Ketik butir pertanyaan soal pilihan ganda di sini (opsional jika menggunakan Upload Word)'
                          : newQuestionType === 'pilihan_ganda_kompleks'
                          ? 'Ketik butir pertanyaan soal pilihan ganda kompleks di sini (opsional jika menggunakan Upload Word)'
                          : newQuestionType === 'menjodohkan'
                          ? 'Ketik instruksi / pertanyaan soal menjodohkan di sini...'
                          : newQuestionType === 'isian_singkat'
                          ? 'Ketik pertanyaan soal isian singkat di sini...'
                          : 'Ketik pokok pertanyaan / instruksi soal benar-salah di sini (opsional jika menggunakan Upload Word)'
                      }
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                    />
                  </div>

                  {/* Input Khusus Tipe: Pilihan Ganda (PG) */}
                  {newQuestionType === 'pilihan_ganda' && (
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Pilihan Jawaban (A, B, C, D, E) & Kunci Jawaban Tunggal{' '}
                        <span className="font-normal text-slate-500">
                          (Opsional / Tidak harus diisi jika sudah Upload Word)
                        </span>
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                        <input
                          type="text"
                          value={optA}
                          onChange={(e) => setOptA(e.target.value)}
                          placeholder="Opsi A"
                          className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                        />
                        <input
                          type="text"
                          value={optB}
                          onChange={(e) => setOptB(e.target.value)}
                          placeholder="Opsi B"
                          className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                        />
                        <input
                          type="text"
                          value={optC}
                          onChange={(e) => setOptC(e.target.value)}
                          placeholder="Opsi C"
                          className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                        />
                        <input
                          type="text"
                          value={optD}
                          onChange={(e) => setOptD(e.target.value)}
                          placeholder="Opsi D"
                          className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                        />
                        <input
                          type="text"
                          value={optE}
                          onChange={(e) => setOptE(e.target.value)}
                          placeholder="Opsi E"
                          className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                        />
                        <select
                          value={correctOpt}
                          onChange={(e) => setCorrectOpt(e.target.value)}
                          className="px-3 py-1.5 font-bold bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                        >
                          {['A', 'B', 'C', 'D', 'E'].map((k) => (
                            <option key={k} value={k}>
                              Kunci: Opsi {k}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Input Khusus Tipe: Pilihan Ganda Kompleks (PG Kompleks) */}
                  {newQuestionType === 'pilihan_ganda_kompleks' && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="block font-semibold text-slate-700">
                          Pilihan Jawaban (A, B, C, D, E) & Centang Kunci Jawaban Benar (Bisa Lebih dari 1) *
                        </label>
                        <span className="text-[11px] text-blue-600 font-medium">
                          Terpilih: {complexCorrectOpts.join(', ') || 'Belum ada'}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                        {[
                          { id: 'A', val: optA, setVal: setOptA, ph: 'Opsi A *' },
                          { id: 'B', val: optB, setVal: setOptB, ph: 'Opsi B *' },
                          { id: 'C', val: optC, setVal: setOptC, ph: 'Opsi C' },
                          { id: 'D', val: optD, setVal: setOptD, ph: 'Opsi D' },
                          { id: 'E', val: optE, setVal: setOptE, ph: 'Opsi E' },
                        ].map((item) => {
                          const isChecked = complexCorrectOpts.includes(item.id);
                          return (
                            <div key={item.id} className="flex items-center gap-2 p-1.5 bg-slate-50 border border-slate-200 rounded-lg">
                              <label className="flex items-center gap-1.5 font-bold text-slate-700 cursor-pointer text-xs shrink-0 px-1">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setComplexCorrectOpts((prev) => [...prev, item.id].sort());
                                    } else {
                                      setComplexCorrectOpts((prev) => prev.filter((x) => x !== item.id));
                                    }
                                  }}
                                  className="w-4 h-4 text-[#001a6e] rounded border-slate-300 focus:ring-[#0095ff]"
                                />
                                <span>{item.id}</span>
                              </label>
                              <input
                                type="text"
                                value={item.val}
                                onChange={(e) => item.setVal(e.target.value)}
                                placeholder={item.ph}
                                className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs text-slate-800 focus:outline-none focus:border-[#0095ff]"
                              />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Input Khusus Tipe: Benar / Salah */}
                  {newQuestionType === 'benar_salah' && (
                    <div className="space-y-2.5">
                      <label className="block font-semibold text-slate-700">
                        Daftar Pernyataan & Kunci Nilai (Benar / Salah) *
                      </label>
                      <div className="space-y-2">
                        {[
                          { id: 'st1', label: 'Pernyataan 1', val: statement1, setVal: setStatement1, ans: statement1Val, setAns: setStatement1Val },
                          { id: 'st2', label: 'Pernyataan 2', val: statement2, setVal: setStatement2, ans: statement2Val, setAns: setStatement2Val },
                          { id: 'st3', label: 'Pernyataan 3', val: statement3, setVal: setStatement3, ans: statement3Val, setAns: setStatement3Val },
                        ].map((st) => (
                          <div key={st.id} className="flex flex-col sm:flex-row sm:items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                            <span className="font-semibold text-slate-700 shrink-0 w-24">
                              {st.label}:
                            </span>
                            <input
                              type="text"
                              value={st.val}
                              onChange={(e) => st.setVal(e.target.value)}
                              placeholder={`Ketik isi ${st.label.toLowerCase()} di sini...`}
                              className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded text-xs text-slate-800 focus:outline-none focus:border-[#0095ff]"
                            />
                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                type="button"
                                onClick={() => st.setAns('Benar')}
                                className={`px-3 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                                  st.ans === 'Benar'
                                    ? 'bg-emerald-600 text-white shadow-2xs'
                                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                                }`}
                              >
                                Benar
                              </button>
                              <button
                                type="button"
                                onClick={() => st.setAns('Salah')}
                                className={`px-3 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                                  st.ans === 'Salah'
                                    ? 'bg-rose-600 text-white shadow-2xs'
                                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                                }`}
                              >
                                Salah
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Input Khusus Tipe: Menjodohkan */}
                  {newQuestionType === 'menjodohkan' && (
                    <div className="space-y-2.5">
                      <label className="block font-semibold text-slate-700">
                        Pasangan Premis & Jawaban Benar (Menjodohkan) *
                      </label>
                      <div className="space-y-2">
                        {[
                          { id: 'm1', label: 'Pasangan 1', p: matchPremise1, setP: setMatchPremise1, r: matchResponse1, setR: setMatchResponse1 },
                          { id: 'm2', label: 'Pasangan 2', p: matchPremise2, setP: setMatchPremise2, r: matchResponse2, setR: setMatchResponse2 },
                          { id: 'm3', label: 'Pasangan 3', p: matchPremise3, setP: setMatchPremise3, r: matchResponse3, setR: setMatchResponse3 },
                        ].map((pair) => (
                          <div key={pair.id} className="grid grid-cols-1 sm:grid-cols-2 gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                            <input
                              type="text"
                              value={pair.p}
                              onChange={(e) => pair.setP(e.target.value)}
                              placeholder={`${pair.label} — Premis (Sisi Kiri)`}
                              className="px-3 py-1.5 bg-white border border-slate-300 rounded text-xs text-slate-800 focus:outline-none focus:border-[#0095ff]"
                            />
                            <input
                              type="text"
                              value={pair.r}
                              onChange={(e) => pair.setR(e.target.value)}
                              placeholder={`${pair.label} — Pasangan Jawaban Benar (Sisi Kanan)`}
                              className="px-3 py-1.5 bg-white border border-slate-300 rounded text-xs text-slate-800 focus:outline-none focus:border-[#0095ff]"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Input Khusus Tipe: Isian Singkat */}
                  {newQuestionType === 'isian_singkat' && (
                    <div className="space-y-1.5">
                      <label className="block font-semibold text-slate-700">
                        Kunci Jawaban Singkat{' '}
                        <span className="font-normal text-slate-500">
                          (Pisahkan variasi jawaban yang diterima dengan tanda koma, misal: Soekarno, Ir. Soekarno)
                        </span>
                      </label>
                      <input
                        type="text"
                        value={shortAnswerKeyInput}
                        onChange={(e) => setShortAnswerKeyInput(e.target.value)}
                        placeholder="Ketik kunci jawaban singkat di sini..."
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff]"
                      />
                    </div>
                  )}

                  <div className="flex items-center justify-end pt-2">
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-lg bg-[#001a6e] hover:bg-[#00155a] text-white text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-sm transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Simpan Soal ({getQuestionTypeLabel(newQuestionType)})
                    </button>
                  </div>
                </form>

                {/* BAGIAN BAWAH (TERGABUNG): MANAJEMEN BANK SOAL */}
                <div className="pt-6 border-t border-slate-200 space-y-5">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-[#0095ff]" />
                      <h3 className="text-sm font-bold text-slate-800">
                        Manajemen Bank Soal — {getPkgClass(selectedPackage)} ({
                          selectedPackage.questions.filter((q) => {
                            if (statusTesTipeSoal === 'Semua Tipe Soal') return true;
                            return q.type === statusTesTipeSoal;
                          }).length
                        } dari {selectedPackage.questions.length} Soal)
                      </h3>
                    </div>

                    {selectedPackage.questions.length > 0 && (
                      <div className="flex flex-wrap items-center gap-3">
                        <button
                          type="button"
                          onClick={handleDeleteAllQuestions}
                          className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 hover:border-rose-600 text-xs font-bold cursor-pointer flex items-center gap-1.5 transition-colors"
                          title="Hapus semua butir soal pada daftar ini"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Hapus Semua Soal</span>
                        </button>
                      </div>
                    )}
                  </div>

                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto border border-slate-200 rounded-lg">
                  {selectedPackage.questions.filter((q) => {
                    if (statusTesTipeSoal === 'Semua Tipe Soal') return true;
                    return q.type === statusTesTipeSoal;
                  }).length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-400 italic">
                      Belum ada butir soal pada mata pelajaran ini. Silakan klik tombol <strong>Upload Word / File Soal</strong> atau tambahkan soal baru di atas.
                    </div>
                  ) : (
                    selectedPackage.questions
                      .filter((q) => {
                        if (statusTesTipeSoal === 'Semua Tipe Soal') return true;
                        return q.type === statusTesTipeSoal;
                      })
                      .map((q) => (
                      <div
                        key={q.id}
                        className="p-3.5 flex items-start justify-between gap-3 hover:bg-slate-50 text-xs"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="font-mono font-bold text-[#0095ff]">
                              No. {q.number}
                            </span>
                            <span className="font-semibold text-slate-700">
                              [{getQuestionTypeLabel(q.type)}]
                            </span>
                            <span className="text-slate-400">· {q.category}</span>
                            {q.correctOptionId && (
                              <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-bold text-[11px]">
                                Kunci: {q.correctOptionId}
                              </span>
                            )}
                            {q.correctOptionIds && q.correctOptionIds.length > 0 && (
                              <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-bold text-[11px]">
                                Kunci: {q.correctOptionIds.join(', ')}
                              </span>
                            )}
                            {q.statements && q.statements.length > 0 && (
                              <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-bold text-[11px]">
                                Kunci {q.trueLabel || 'Benar'}/{q.falseLabel || 'Salah'}:{' '}
                                {q.statements
                                  .map((s) =>
                                    s.correctValue === 'Benar'
                                      ? q.trueLabel || 'Benar'
                                      : q.falseLabel || 'Salah'
                                  )
                                  .join(', ')}
                              </span>
                            )}
                            {q.premises && q.premises.length > 0 && (
                              <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-bold text-[11px]">
                                {q.premises.length} Premis · {q.responses?.length || q.premises.length} Respon
                              </span>
                            )}
                            {q.correctShortAnswers && q.correctShortAnswers.length > 0 && (
                              <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-bold text-[11px]">
                                Kunci: {q.correctShortAnswers.join(' / ')}
                              </span>
                            )}
                            {(q.stimulusTitle || q.stimulusText) && (
                              <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 font-semibold text-[11px]">
                                Stimulus
                              </span>
                            )}
                            {((q.questionImages?.length || 0) +
                              (q.stimulusImages?.length || 0) +
                              (q.options?.reduce((acc, o) => acc + (o.images?.length || 0), 0) || 0) >
                              0) && (
                              <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold text-[11px]">
                                {(q.questionImages?.length || 0) +
                                  (q.stimulusImages?.length || 0) +
                                  (q.options?.reduce((acc, o) => acc + (o.images?.length || 0), 0) || 0)}{' '}
                                Gambar
                              </span>
                            )}
                          </div>
                          <MathText text={q.questionText} className="text-slate-700 mt-1 whitespace-pre-line" />
                          {q.stimulusTable && (
                            <div className="mt-2 overflow-x-auto border border-slate-200 rounded-lg bg-white max-w-2xl">
                              <table className="w-full text-left border-collapse text-[11px]">
                                <thead>
                                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-700">
                                    {q.stimulusTable.headers.map((h, hIdx) => (
                                      <th key={hIdx} className="py-1.5 px-2.5 font-semibold border-r last:border-r-0 border-slate-200">
                                        <MathText text={h} inline />
                                      </th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {q.stimulusTable.rows.map((r, rIdx) => (
                                    <tr key={rIdx}>
                                      {r.map((cell, cIdx) => (
                                        <td key={cIdx} className="py-1 px-2.5 text-slate-700 border-r last:border-r-0 border-slate-100">
                                          <MathText text={cell} inline />
                                        </td>
                                      ))}
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDeleteQuestion(q.id, q.number, q)}
                          title="Hapus soal ini"
                          className="p-1.5 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. LAPORAN PENGOLAHAN */}
          {activeMenu === 'laporan_pengolahan' && (
            <div className="space-y-6">
              {/* Header Kop & Tombol Unduh Semua Kelas */}
              <div className="bg-white rounded-xl p-6 shadow-xs border border-slate-200 space-y-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b border-slate-100">
                  <div>
                    <span className="inline-block text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-blue-50 text-[#001a6e] border border-blue-200 mb-1.5">
                      Dokumen Resmi PDF Setiap Kelas
                    </span>
                    <h3 className="text-base font-extrabold text-slate-900">
                      LAPORAN NILAI HASIL UJIAN — SMA ISLAM DIPONEGORO WAGIR
                    </h3>
                    <p className="text-xs font-semibold text-slate-600 mt-0.5">
                      TAHUN AJARAN 2026/2027 • SEMESTER 1
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() =>
                        generateExamReportPDF(
                          'ALL',
                          safeResultsHistory,
                          participants
                        )
                      }
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#001a6e] hover:bg-[#00124d] text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Unduh Laporan Semua Kelas (PDF)</span>
                    </button>
                    {safeResultsHistory.length > 0 && (
                      <button
                        type="button"
                        onClick={onClearHistory}
                        className="px-3 py-2 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-xs font-semibold text-rose-700 transition-colors cursor-pointer"
                      >
                        Bersihkan Riwayat
                      </button>
                    )}
                  </div>
                </div>

                {/* Daftar Kartu Unduh Cepat Setiap Kelas */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                  {STATUS_TES_CLASS_GROUPS.map((cls) => {
                    const classResults = safeResultsHistory.filter((r) =>
                      doesKelasMatch(
                        resolveResultClass(r, participants),
                        cls
                      )
                    );
                    const classStudents = participants.filter((p) =>
                      doesKelasMatch(p.kelas, cls)
                    );
                    return (
                      <div
                        key={cls}
                        className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 flex flex-col justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-extrabold text-slate-900">
                              {cls}
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                              {classResults.length} Nilai
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-1">
                            Terdaftar: {classStudents.length} Peserta
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            generateExamReportPDF(
                              cls,
                              safeResultsHistory,
                              participants
                            )
                          }
                          className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-[#0066ff] hover:bg-[#0052cc] text-white text-[11px] font-bold shadow-2xs transition-colors cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 shrink-0" />
                          <span>Unduh Laporan Hasil Ujian</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Tabel Laporan Nilai Hasil Ujian Per Kelas */}
              {STATUS_TES_CLASS_GROUPS.map((cls) => {
                const classResults = safeResultsHistory.filter((r) =>
                  doesKelasMatch(resolveResultClass(r, participants), cls)
                );
                const classStudents = participants.filter((p) =>
                  doesKelasMatch(p.kelas, cls)
                );

                return (
                  <div
                    key={cls}
                    className="bg-white rounded-xl p-6 shadow-xs border border-slate-200 space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-100">
                      <div>
                        <h4 className="text-sm font-extrabold text-slate-900">
                          Laporan Pengolahan Nilai — {cls}
                        </h4>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {classResults.length} hasil ujian selesai dari{' '}
                          {classStudents.length} peserta terdaftar di {cls}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          generateExamReportPDF(
                            cls,
                            safeResultsHistory,
                            participants
                          )
                        }
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#0066ff] hover:bg-[#0052cc] text-white text-xs font-bold shadow-xs transition-colors cursor-pointer shrink-0"
                      >
                        <Download className="w-4 h-4" />
                        <span>
                          Unduh Laporan Hasil Ujian {cls} (PDF)
                        </span>
                      </button>
                    </div>

                    {classResults.length === 0 ? (
                      <div className="py-8 text-center rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-500">
                        Belum ada peserta {cls} yang menyelesaikan ujian.
                        Klik tombol{' '}
                        <strong className="text-slate-700">
                          Unduh Laporan Hasil Ujian {cls} (PDF)
                        </strong>{' '}
                        di atas untuk mengunduh rekap daftar peserta {cls}.
                      </div>
                    ) : (
                      <div className="overflow-x-auto border border-slate-200 rounded-xl">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                              <th className="py-3 px-4 w-12">No</th>
                              <th className="py-3 px-4">Username</th>
                              <th className="py-3 px-4">Nama Peserta</th>
                              <th className="py-3 px-4">Kelas</th>
                              <th className="py-3 px-4">Mata Ujian</th>
                              <th className="py-3 px-4">Benar</th>
                              <th className="py-3 px-4">Nilai Akhir</th>
                              <th className="py-3 px-4">Waktu Selesai</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {classResults.map((r, idx) => (
                              <tr key={r.id || idx} className="hover:bg-slate-50/80">
                                <td className="py-3 px-4 font-mono text-slate-500">
                                  {idx + 1}
                                </td>
                                <td className="py-3 px-4 font-mono font-semibold text-slate-800">
                                  {r?.participant?.username || '-'}
                                </td>
                                <td className="py-3 px-4 font-semibold text-slate-800">
                                  {r?.participant?.fullName || '-'}
                                </td>
                                <td className="py-3 px-4 font-semibold text-slate-700">
                                  {cls}
                                </td>
                                <td className="py-3 px-4">{r.packageTitle}</td>
                                <td className="py-3 px-4 font-mono">
                                  {r.correctCount} / {r.totalQuestions}
                                </td>
                                <td className="py-3 px-4 font-mono font-bold text-[#0066ff]">
                                  {r.finalScore}
                                </td>
                                <td className="py-3 px-4 text-slate-500">
                                  {r.completedAt}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* MENU 11: PENGATURAN SISTEM UJIAN SAS */}
          {activeMenu === 'pengaturan' && (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                    <Settings className="w-5 h-5 text-[#001a6e]" />
                    Pengaturan Sistem & Pelaksanaan Ujian SAS
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Konfigurasi parameter pelaksanaan Sumatif Akhir Semester, aturan anti-curang, dan sinkronisasi server.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleExportSettings}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 text-slate-700 bg-white hover:bg-slate-50 flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Ekspor JSON
                  </button>
                </div>
              </div>

              <form onSubmit={handleSaveSettings} className="space-y-6">
                {/* Bagian 1: Identitas Lembaga & Sesi Ujian */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-[#0095ff]" />
                    1. Identitas Satuan Pendidikan & Kegiatan Ujian
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Nama Satuan Pendidikan / Sekolah
                      </label>
                      <input
                        type="text"
                        value={appConfig.namaSekolah}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, namaSekolah: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium focus:ring-2 focus:ring-[#0095ff] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        NPSN Sekolah
                      </label>
                      <input
                        type="text"
                        value={appConfig.npsn}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, npsn: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Nama Kepala Sekolah
                      </label>
                      <input
                        type="text"
                        value={appConfig.namaKepalaSekolah || 'ROMEO GALISTRA, S.Pd.'}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, namaKepalaSekolah: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium focus:ring-2 focus:ring-[#0095ff] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Nama Kegiatan Ujian
                      </label>
                      <input
                        type="text"
                        value={appConfig.namaUjian}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, namaUjian: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium focus:ring-2 focus:ring-[#0095ff] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Semester / Tahun Ajaran
                      </label>
                      <input
                        type="text"
                        value={appConfig.semester}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, semester: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Moda Pelaksanaan
                      </label>
                      <select
                        value={appConfig.modaPelaksanaan}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, modaPelaksanaan: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium focus:ring-2 focus:ring-[#0095ff] outline-none"
                      >
                        <option value="Daring (Online)">Daring (Online Penuh / Cloud)</option>
                        <option value="Semi-Daring (Semi-Online)">Semi-Daring (Local Server / VHD)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Ruang Pelaksanaan Utama
                      </label>
                      <input
                        type="text"
                        value={appConfig.ruangDefault}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, ruangDefault: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Tingkat / Jenjang Sasaran
                      </label>
                      <select
                        value={appConfig.tingkatKelas || 'Semua Tingkat (Kelas X, XI, XII)'}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, tingkatKelas: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium focus:ring-2 focus:ring-[#0095ff] outline-none"
                      >
                        <option value="Semua Tingkat (Kelas X, XI, XII)">Semua Tingkat (Kelas X, XI, XII)</option>
                        <option value="Kelas X (Fase E)">Kelas X (Fase E)</option>
                        <option value="Kelas XI (Fase F)">Kelas XI (Fase F)</option>
                        <option value="Kelas XII (Tingkat Akhir)">Kelas XII (Tingkat Akhir)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Kolom Ringkasan Rombel
                      </label>
                      <input
                        type="text"
                        value={appConfig.daftarKelas || ''}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, daftarKelas: e.target.value })
                        }
                        placeholder="Contoh: X-1, X-2, XI-IPA..."
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-mono text-[11px] text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Nama Administrator Utama
                      </label>
                      <input
                        type="text"
                        value={appConfig.adminNama || 'SHAHRUR ROBBY, S.Pd.'}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, adminNama: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        ID Administrator Utama
                      </label>
                      <input
                        type="text"
                        value={appConfig.adminId || 'K05060108-KB6K'}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, adminId: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Nama Proktor Utama / Penanggung Jawab Ruang
                      </label>
                      <input
                        type="text"
                        value={appConfig.namaProktor ?? proctors[0]?.fullName ?? 'DRS. H. AHMAD FAUZI, M.PD.'}
                        onChange={(e) => {
                          const val = e.target.value;
                          setAppConfig((prev) => ({ ...prev, namaProktor: val }));
                        }}
                        placeholder="Contoh: DRS. H. AHMAD FAUZI, M.PD."
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        No. Kontak / WhatsApp Admin
                      </label>
                      <input
                        type="text"
                        value={appConfig.adminNoHp || '0812-3456-7890'}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, adminNoHp: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Email Resmi Administrator
                      </label>
                      <input
                        type="email"
                        value={appConfig.adminEmail || 'admin.cbt@smadiponegorowagir.sch.id'}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, adminEmail: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                  </div>

                  {/* Upload Logo untuk Kop di Kartu Peserta */}
                  <div className="pt-4 mt-2 border-t border-slate-200">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
                      <div className="space-y-1.5">
                        <label className="block text-xs font-bold text-slate-800">
                          Logo Sekolah / Instansi untuk Kop Kartu Peserta
                        </label>
                        <p className="text-[11px] text-slate-500 max-w-xl">
                          Unggah logo sekolah atau yayasan (format PNG, JPG, WEBP, atau SVG). Logo ini akan otomatis ditampilkan pada bagian kiri Kop Kartu Peserta saat mencetak / mengunduh PDF Kartu Peserta.
                        </p>
                        <div className="flex flex-wrap items-center gap-2.5 pt-1">
                          <input
                            ref={logoKartuInputRef}
                            type="file"
                            accept="image/*"
                            onChange={handleUploadLogoKartuPeserta}
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => logoKartuInputRef.current?.click()}
                            className="px-3.5 py-2 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-2 shadow-sm"
                          >
                            <Upload className="w-3.5 h-3.5 text-[#0095ff]" />
                            <span>
                              {appConfig.logoKartuPeserta
                                ? 'Ganti Logo Kop Kartu Peserta'
                                : 'Upload Logo Kop Kartu Peserta'}
                            </span>
                          </button>
                          {appConfig.logoKartuPeserta && (
                            <button
                              type="button"
                              onClick={handleRemoveLogoKartuPeserta}
                              className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Hapus Logo</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Pratinjau Kop Kartu Peserta */}
                      <div className="w-full lg:w-[360px] shrink-0">
                        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                          Pratinjau Kop Kartu Peserta:
                        </div>
                        <div className="border-2 border-slate-700 rounded-md bg-white p-2.5 flex items-center gap-2.5 shadow-2xs">
                          <div className="w-12 h-12 rounded border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0 overflow-hidden">
                            {appConfig.logoKartuPeserta ? (
                              <img
                                src={appConfig.logoKartuPeserta}
                                alt="Logo Kop Kartu Peserta"
                                className="w-full h-full object-contain"
                              />
                            ) : (
                              <span className="text-[9px] text-slate-400 font-semibold text-center leading-tight px-1">
                                Tanpa Logo
                              </span>
                            )}
                          </div>
                          <div className="flex-1 text-center leading-tight min-w-0">
                            <div className="text-[10px] font-extrabold text-slate-900 uppercase truncate">
                              KARTU PESERTA
                            </div>
                            <div className="text-[9px] font-bold text-slate-800 uppercase truncate">
                              {appConfig.namaUjian || 'SUMATIF AKHIR SEMESTER (SAS)'}
                            </div>
                            <div className="text-[9px] font-bold text-slate-800 uppercase truncate">
                              {appConfig.namaSekolah || 'SMA ISLAM DIPONEGORO WAGIR'}
                            </div>
                            <div className="text-[8px] font-medium text-slate-600">
                              TAHUN PELAJARAN 2025/2026
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bagian 2: Kolom Data Administrator & Penanggung Jawab CBT */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                        <UserCog className="w-4 h-4 text-[#0095ff]" />
                        2. Kolom Data Administrator & Penanggung Jawab CBT
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Kelola data akun administrator sistem ujian SAS, hak akses wewenang, ID administrator, kontak resmi, dan status keaktifan akun.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-[#001a6e] border border-blue-200 rounded-full text-xs font-bold shadow-2xs">
                        <ShieldCheck className="w-3.5 h-3.5 text-[#0095ff]" />
                        Total {(appConfig.adminList || []).length} Administrator Terdaftar
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowAdminForm((prev) => !prev)}
                        className="px-3.5 py-1.5 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                        title="Klik untuk membuka formulir input data administrator baru"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{showAdminForm ? 'Tutup Form' : 'Tambah Administrator'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Form Tambah Administrator Baru */}
                  {(showAdminForm || (appConfig.adminList || []).length === 0) && (
                    <div className="bg-white border-2 border-blue-200/90 rounded-lg p-4 space-y-3 shadow-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                          <Plus className="w-3.5 h-3.5 text-[#0095ff]" />
                          Form Tambah Kolom Data Administrator Baru
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Lengkapi ID Administrator dan Nama Lengkap lalu tekan Simpan
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-xs">
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1">
                            ID Administrator *
                          </label>
                          <input
                            type="text"
                            placeholder="Contoh: ADM-TEKNIS-02"
                            value={newAdminId}
                            onChange={(e) => setNewAdminId(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white font-mono uppercase text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          />
                        </div>
                        <div className="lg:col-span-2">
                          <label className="block font-semibold text-slate-600 mb-1">
                            Nama Lengkap Administrator *
                          </label>
                          <input
                            type="text"
                            placeholder="Contoh: AHMAD FAUZI, S.Kom."
                            value={newAdminNama}
                            onChange={(e) => setNewAdminNama(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1">
                            NIP / NUPTK
                          </label>
                          <input
                            type="text"
                            placeholder="Contoh: 198503152010011012"
                            value={newAdminNip}
                            onChange={(e) => setNewAdminNip(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1">
                            Peran / Wewenang
                          </label>
                          <select
                            value={newAdminRole}
                            onChange={(e) => setNewAdminRole(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          >
                            <option value="Penanggung Jawab / Super Admin">Penanggung Jawab / Super Admin</option>
                            <option value="Administrator Server & Database">Administrator Server & Database</option>
                            <option value="Administrator Kurikulum & Bank Soal">Administrator Kurikulum & Bank Soal</option>
                            <option value="Tim Teknis / IT Support">Tim Teknis / IT Support</option>
                          </select>
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1">
                            Kontak / No. WhatsApp
                          </label>
                          <input
                            type="text"
                            placeholder="0812-xxxx-xxxx"
                            value={newAdminNoHp}
                            onChange={(e) => setNewAdminNoHp(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 items-end gap-3 pt-2 border-t border-slate-100">
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1 text-xs">
                            Email Resmi Administrator
                          </label>
                          <input
                            type="email"
                            placeholder="admin.cbt@smadiponegorowagir.sch.id"
                            value={newAdminEmail}
                            onChange={(e) => setNewAdminEmail(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none text-xs"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1 text-xs">
                            Password Login Admin *
                          </label>
                          <input
                            type="text"
                            placeholder="Default: SAS2026"
                            value={newAdminPassword}
                            onChange={(e) => setNewAdminPassword(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none text-xs"
                          />
                        </div>
                        <div className="flex items-center justify-end gap-2">
                          {showAdminForm && (
                            <button
                              type="button"
                              onClick={() => setShowAdminForm(false)}
                              className="py-1.5 px-3 border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
                            >
                              Batal
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={handleAddAdminToSettings}
                            className="py-1.5 px-4 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            Simpan Administrator
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tombol Akses Cepat Tambah Administrator */}
                  {!showAdminForm && (appConfig.adminList || []).length > 0 && (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 bg-white border border-dashed border-blue-300 rounded-lg hover:border-blue-400 transition-colors gap-2">
                      <div className="flex items-center gap-2 text-xs text-slate-700">
                        <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center shrink-0">
                          <UserCog className="w-4 h-4 text-[#0095ff]" />
                        </div>
                        <div>
                          <div className="font-bold text-slate-800">Tambah Akun Administrator Baru</div>
                          <div className="text-[11px] text-slate-500">Klik tombol di sebelah kanan untuk menambahkan administrator atau tim teknis CBT baru.</div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowAdminForm(true)}
                        className="py-2 px-4 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm shrink-0"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Tambah Administrator
                      </button>
                    </div>
                  )}

                  {/* Tabel Kolom Data Administrator */}
                  <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                          <th className="py-2.5 px-3 w-12 text-center">No</th>
                          <th className="py-2.5 px-3">ID Administrator</th>
                          <th className="py-2.5 px-3">Nama Lengkap Administrator</th>
                          <th className="py-2.5 px-3">NIP / NUPTK</th>
                          <th className="py-2.5 px-3">Kontak / WhatsApp</th>
                          <th className="py-2.5 px-3">Email Resmi</th>
                          <th className="py-2.5 px-3">Peran / Hak Akses</th>
                          <th className="py-2.5 px-3">Password</th>
                          <th className="py-2.5 px-3 text-center">Status</th>
                          <th className="py-2.5 px-3 text-center w-20">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {(appConfig.adminList || []).map((adm: any, idx: number) => {
                          const isEditingPass = editingAdminPassId === adm.adminId;
                          return (
                            <tr key={adm.id || adm.adminId + idx} className="hover:bg-slate-50/80 transition-colors">
                              <td className="py-2.5 px-3 text-center text-slate-500 font-medium">{idx + 1}</td>
                              <td className="py-2.5 px-3 font-bold">
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-blue-50 text-[#001a6e] border border-blue-200 font-mono font-bold text-[11px]">
                                  {adm.adminId}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 font-semibold text-slate-800">
                                {adm.namaLengkap}
                              </td>
                              <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">
                                {adm.nip || '-'}
                              </td>
                              <td className="py-2.5 px-3 text-slate-600 font-medium">
                                {adm.noHp || '-'}
                              </td>
                              <td className="py-2.5 px-3 text-slate-600">
                                {adm.email || '-'}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="inline-block px-2 py-0.5 rounded bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-semibold">
                                  {adm.role || 'Administrator'}
                                </span>
                              </td>
                              <td className="py-2.5 px-3">
                                {isEditingPass ? (
                                  <div className="flex items-center gap-1">
                                    <input
                                      type="text"
                                      value={editingAdminPassValue}
                                      onChange={(e) => setEditingAdminPassValue(e.target.value)}
                                      className="w-28 px-2 py-1 border border-blue-400 rounded font-mono text-[11px] text-slate-800 bg-white focus:outline-none"
                                      placeholder="Min 4 huruf"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => handleSaveAdminPassword(adm.adminId)}
                                      className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold cursor-pointer"
                                    >
                                      Simpan
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setEditingAdminPassId(null);
                                        setEditingAdminPassValue('');
                                      }}
                                      className="px-1.5 py-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] font-bold cursor-pointer"
                                    >
                                      Batal
                                    </button>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-mono font-semibold text-slate-700 text-[11px]">
                                      {adm.password || 'SAS2026'}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setEditingAdminPassId(adm.adminId);
                                        setEditingAdminPassValue(adm.password || 'SAS2026');
                                      }}
                                      className="p-1 rounded text-[#0095ff] hover:bg-blue-50 cursor-pointer"
                                      title={`Ubah password ${adm.namaLengkap}`}
                                    >
                                      <Edit className="w-3 h-3" />
                                    </button>
                                  </div>
                                )}
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleToggleAdminStatusInSettings(adm.adminId)}
                                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold transition-colors cursor-pointer ${
                                    adm.status === 'Aktif'
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                                      : 'bg-slate-100 text-slate-500 border border-slate-200 hover:bg-slate-200'
                                  }`}
                                  title="Klik untuk ubah status keaktifan"
                                >
                                  <span
                                    className={`w-1.5 h-1.5 rounded-full ${
                                      adm.status === 'Aktif' ? 'bg-emerald-500' : 'bg-slate-400'
                                    }`}
                                  ></span>
                                  {adm.status || 'Aktif'}
                                </button>
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleDeleteAdminFromSettings(adm.adminId)}
                                  className="text-rose-600 hover:text-rose-800 p-1 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                                  title={`Hapus administrator ${adm.namaLengkap}`}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                        {(!appConfig.adminList || appConfig.adminList.length === 0) && (
                          <tr>
                            <td colSpan={10} className="py-6 text-center text-slate-400">
                              Belum ada akun administrator yang didaftarkan. Gunakan formulir di atas untuk menambahkan.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Pratinjau Tag Kolom Administrator Terdaftar */}
                  <div className="pt-1 flex flex-wrap items-center gap-1.5 text-xs">
                    <span className="font-semibold text-slate-600 mr-1">Administrator Aktif:</span>
                    {(appConfig.adminList || []).map((adm: any, idx: number) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2 py-0.5 bg-white border border-slate-300 text-slate-700 rounded-md font-mono text-[11px] shadow-2xs"
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${adm.status === 'Aktif' ? 'bg-emerald-500' : 'bg-slate-400'}`}></span>
                        {adm.adminId} ({adm.namaLengkap})
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bagian 3: Kolom Kelas & Rombongan Belajar (Rombel) */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                        <GraduationCap className="w-4 h-4 text-[#0095ff]" />
                        3. Kolom Kelas & Rombongan Belajar (Rombel) Peserta Ujian
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Konfigurasi kolom kelas aktif, penetapan tingkat, program keahlian/jurusan, dan ruang ujian pelaksanaan.
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-[#001a6e] border border-blue-200 rounded-full text-xs font-bold shadow-2xs self-start sm:self-auto">
                      <GraduationCap className="w-3.5 h-3.5 text-[#0095ff]" />
                      Total {(appConfig.kelasList || []).length} Kolom Kelas Terdaftar
                    </span>
                  </div>

                  {/* Form Tambah Kolom Kelas Baru */}
                  <div className="bg-white border border-slate-200 rounded-lg p-4 space-y-3 shadow-2xs">
                    <span className="text-xs font-bold text-slate-700 block">
                      Tambah Kolom Kelas / Rombel Baru
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 text-xs">
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">
                          Nama / Kode Kelas
                        </label>
                        <input
                          type="text"
                          placeholder="Misal: X-3 atau XII-BAHASA"
                          value={newPengaturanKelasKode}
                          onChange={(e) => setNewPengaturanKelasKode(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-slate-50 text-slate-800 font-semibold uppercase focus:bg-white focus:ring-2 focus:ring-[#0095ff] outline-none"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">
                          Tingkat / Jenjang
                        </label>
                        <select
                          value={newPengaturanKelasTingkat}
                          onChange={(e) => setNewPengaturanKelasTingkat(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                        >
                          <option value="Kelas X">Kelas X (Fase E)</option>
                          <option value="Kelas XI">Kelas XI (Fase F)</option>
                          <option value="Kelas XII">Kelas XII (Tingkat Akhir)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">
                          Program / Peminatan
                        </label>
                        <select
                          value={newPengaturanKelasJurusan}
                          onChange={(e) => setNewPengaturanKelasJurusan(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                        >
                          <option value="Fase E (Umum)">Fase E (Umum)</option>
                          <option value="MIPA (Fase F)">MIPA (Fase F)</option>
                          <option value="IPS (Fase F)">IPS (Fase F)</option>
                          <option value="Bahasa & Budaya">Bahasa & Budaya</option>
                          <option value="Keagamaan">Keagamaan</option>
                        </select>
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">
                          Ruang Lab Pelaksanaan
                        </label>
                        <input
                          type="text"
                          value={newPengaturanKelasRuang}
                          onChange={(e) => setNewPengaturanKelasRuang(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                        />
                      </div>
                      <div className="flex items-end">
                        <button
                          type="button"
                          onClick={handleAddKelasToSettings}
                          className="w-full py-1.5 px-3 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          Tambah Kolom
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Tabel Kolom Kelas */}
                  <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                          <th className="py-2.5 px-3 w-12 text-center">No</th>
                          <th className="py-2.5 px-3">Kolom / Nama Kelas</th>
                          <th className="py-2.5 px-3">Tingkat / Fase</th>
                          <th className="py-2.5 px-3">Program / Jurusan</th>
                          <th className="py-2.5 px-3">Ruang Ujian</th>
                          <th className="py-2.5 px-3">Sesi Bawaan</th>
                          <th className="py-2.5 px-3 text-center">Status</th>
                          <th className="py-2.5 px-3 text-center w-20">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {(appConfig.kelasList || []).map((kls: any, idx: number) => {
                          const tingkatBadgeColor =
                            kls.tingkat === 'Kelas X'
                              ? 'bg-blue-50 text-blue-700 border-blue-200'
                              : kls.tingkat === 'Kelas XI'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-purple-50 text-purple-700 border-purple-200';

                          return (
                            <tr key={kls.kode + idx} className="hover:bg-slate-50/80 transition-colors">
                              <td className="py-2 px-3 text-center text-slate-500 font-medium">{idx + 1}</td>
                              <td className="py-2 px-3 font-bold text-slate-800">
                                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-slate-800 font-mono">
                                  {kls.kode}
                                </span>
                              </td>
                              <td className="py-2 px-3">
                                <span className={`inline-block px-2 py-0.5 rounded border text-[11px] font-semibold ${tingkatBadgeColor}`}>
                                  {kls.tingkat}
                                </span>
                              </td>
                              <td className="py-2 px-3 text-slate-600 font-medium">{kls.jurusan}</td>
                              <td className="py-2 px-3 text-slate-600 font-mono text-[11px]">{kls.ruang}</td>
                              <td className="py-2 px-3 text-slate-600">{kls.sesi}</td>
                              <td className="py-2 px-3 text-center">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full font-semibold text-[10px]">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                  {kls.status || 'Aktif'}
                                </span>
                              </td>
                              <td className="py-2 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleDeleteKelasFromSettings(kls.kode)}
                                  className="text-rose-600 hover:text-rose-800 p-1 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                                  title={`Hapus kelas ${kls.kode}`}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                        {(!appConfig.kelasList || appConfig.kelasList.length === 0) && (
                          <tr>
                            <td colSpan={8} className="py-6 text-center text-slate-400">
                              Belum ada kolom kelas yang didaftarkan. Gunakan formulir di atas untuk menambahkan.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Pratinjau Tag Kolom Kelas Aktif */}
                  <div className="pt-1 flex flex-wrap items-center gap-1.5 text-xs">
                    <span className="font-semibold text-slate-600 mr-1">Rombel Terdaftar:</span>
                    {(appConfig.kelasList || []).map((kls: any, idx: number) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2 py-0.5 bg-white border border-slate-300 text-slate-700 rounded-md font-mono text-[11px] shadow-2xs"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-[#0095ff]"></span>
                        {kls.kode}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bagian 4: Daftar & Pengaturan Mata Pelajaran (Mapel) Ujian */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-[#0095ff]" />
                        4. Mata Pelajaran (Mapel) Ujian SAS
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Kelola kurikulum mata pelajaran ujian SAS, penetapan kode mapel, tingkat sasaran, durasi waktu pengerjaan, dan KKM kelulusan.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-[#001a6e] border border-blue-200 rounded-full text-xs font-bold shadow-2xs">
                        <BookOpen className="w-3.5 h-3.5 text-[#0095ff]" />
                        Total {(appConfig.mapelList || []).length} Mapel Terdaftar
                      </span>
                      {/* Input file Excel tersembunyi untuk Upload Mata Pelajaran */}
                      <input
                        type="file"
                        ref={mapelExcelInputRef}
                        onChange={handleUploadMapelExcel}
                        accept=".xlsx, .xls, .csv"
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={handleExportMapelToExcel}
                        className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-300 font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                        title="Unduh seluruh daftar mata pelajaran aktif ke file Excel (.xlsx)"
                      >
                        <Download className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Unduh Excel</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleDownloadMapelTemplateExcel}
                        className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                        title="Unduh contoh template Excel dengan format: Nama mapel, tingkat/fase, kategori, durasi, KKM"
                      >
                        <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Format Excel</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => mapelExcelInputRef.current?.click()}
                        className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                        title="Upload file Excel mata pelajaran (Format: Nama mapel, tingkat/fase, kategori, durasi, KKM)"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Excel Mapel</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowMapelForm((prev) => !prev)}
                        className="px-3.5 py-1.5 bg-[#0095ff] hover:bg-[#007acc] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                        title="Klik untuk membuka formulir input mata pelajaran baru"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{showMapelForm ? 'Tutup Form' : 'Input Mata Pelajaran'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Form Input Mata Pelajaran Baru */}
                  {(showMapelForm || (appConfig.mapelList || []).length === 0) && (
                    <div className="bg-white border-2 border-blue-200/90 rounded-lg p-4 space-y-3 shadow-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                          <Plus className="w-3.5 h-3.5 text-[#0095ff]" />
                          Form Input Mata Pelajaran Baru
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Lengkapi nama mata pelajaran lalu tekan Simpan
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-xs">
                        <div className="lg:col-span-2">
                          <label className="block font-semibold text-slate-600 mb-1">
                            Nama Mata Pelajaran *
                          </label>
                          <input
                            type="text"
                            placeholder="Contoh: Bahasa Indonesia & Literasi"
                            value={newMapelNama}
                            onChange={(e) => setNewMapelNama(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                e.stopPropagation();
                                handleAddMapelToSettings();
                              }
                            }}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1">
                            Kode Mapel (Opsional)
                          </label>
                          <input
                            type="text"
                            placeholder="Contoh: BIN-SAS"
                            value={newMapelKode}
                            onChange={(e) => setNewMapelKode(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                e.stopPropagation();
                                handleAddMapelToSettings();
                              }
                            }}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white font-mono uppercase text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1">
                            Kelas Sasaran
                          </label>
                          <select
                            value={newMapelTingkat}
                            onChange={(e) => setNewMapelTingkat(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          >
                            <option value="Kelas X">Kelas X</option>
                            <option value="Kelas XI IPA">Kelas XI IPA</option>
                            <option value="Kelas XI IPS">Kelas XI IPS</option>
                            <option value="Kelas XII IPA">Kelas XII IPA</option>
                            <option value="Kelas XII IPS">Kelas XII IPS</option>
                          </select>
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 mb-1">
                            Kategori / Jurusan
                          </label>
                          <select
                            value={newMapelKategori}
                            onChange={(e) => setNewMapelKategori(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                          >
                            <option value="Wajib Umum">Wajib Umum</option>
                            <option value="Peminatan MIPA">Peminatan MIPA</option>
                            <option value="Peminatan IPS">Peminatan IPS</option>
                            <option value="Pendidikan Agama">Pendidikan Agama</option>
                            <option value="Muatan Lokal / Bahasa">Muatan Lokal</option>
                          </select>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block font-semibold text-slate-600 mb-1">
                              Durasi (Mnt)
                            </label>
                            <input
                              type="number"
                              min={10}
                              max={240}
                              value={newMapelAlokasi}
                              onChange={(e) => setNewMapelAlokasi(Number(e.target.value) || 90)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  handleAddMapelToSettings();
                                }
                              }}
                              className="w-full px-2 py-1.5 border border-slate-300 rounded-lg bg-white text-center font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                            />
                          </div>
                          <div>
                            <label className="block font-semibold text-slate-600 mb-1">
                              KKM
                            </label>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={newMapelKKM}
                              onChange={(e) => setNewMapelKKM(Number(e.target.value) || 75)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  handleAddMapelToSettings();
                                }
                              }}
                              className="w-full px-2 py-1.5 border border-slate-300 rounded-lg bg-white text-center font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Pilihan Cepat / Preset Mata Pelajaran */}
                      <div className="pt-2 border-t border-slate-100 space-y-1.5">
                        <div className="text-[11px] font-semibold text-slate-500">
                          Pilihan Cepat Mapel (Klik untuk mengisi formulir):
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {[
                            { nama: 'Bahasa Indonesia & Literasi Membaca', kode: 'BIN-SAS', tingkat: 'Kelas X', kategori: 'Wajib Umum' },
                            { nama: 'Pendidikan Agama Islam & Budi Pekerti', kode: 'PAI-SAS', tingkat: 'Kelas X', kategori: 'Pendidikan Agama' },
                            { nama: 'Biologi & Kimia Terapan', kode: 'BIO-SAS', tingkat: 'Kelas XI IPA', kategori: 'Peminatan MIPA' },
                            { nama: 'Matematika Lanjut & Penalaran Sains', kode: 'TKA-SAINS-02', tingkat: 'Kelas XI IPA', kategori: 'Peminatan MIPA' },
                            { nama: 'Matematika Wajib & Numerasi', kode: 'MAT-SAS', tingkat: 'Kelas XI IPS', kategori: 'Wajib Umum' },
                            { nama: 'Ekonomi & Sosiologi Terapan', kode: 'EKO-SAS', tingkat: 'Kelas XI IPS', kategori: 'Peminatan IPS' },
                            { nama: 'Bahasa Inggris & Literasi Digital', kode: 'BIG-SAS', tingkat: 'Kelas XII IPA', kategori: 'Wajib Umum' },
                            { nama: 'Fisika & Kimia Analisis Lanjut', kode: 'FIS-SAS', tingkat: 'Kelas XII IPA', kategori: 'Peminatan MIPA' },
                            { nama: 'Sejarah Indonesia & Kebangsaan', kode: 'SEJ-SAS', tingkat: 'Kelas XII IPS', kategori: 'Wajib Umum' },
                            { nama: 'Geografi & Sosiologi Kontemporer', kode: 'GEO-SAS', tingkat: 'Kelas XII IPS', kategori: 'Peminatan IPS' },
                            { nama: 'Informatika & Koding', kode: 'INF-SAS', tingkat: 'Kelas X', kategori: 'Peminatan MIPA' },
                            { nama: 'Pendidikan Pancasila & Kewarganegaraan (PPKn)', kode: 'PPKN-SAS', tingkat: 'Kelas X', kategori: 'Wajib Umum' },
                            { nama: 'Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK)', kode: 'PJOK-SAS', tingkat: 'Kelas XI IPA', kategori: 'Wajib Umum' },
                            { nama: 'Seni Budaya & Prakarya', kode: 'SNB-SAS', tingkat: 'Kelas XI IPS', kategori: 'Wajib Umum' },
                          ].map((preset, pIdx) => (
                            <button
                              key={pIdx}
                              type="button"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setNewMapelNama(preset.nama);
                                setNewMapelKode(preset.kode);
                                setNewMapelTingkat(preset.tingkat);
                                setNewMapelKategori(preset.kategori);
                                showNotice(`Form diisi: "${preset.nama}". Tekan Simpan Mata Pelajaran.`);
                              }}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded text-[11px] text-slate-700 font-medium transition-colors cursor-pointer"
                            >
                              + {preset.kode.split('-')[0]}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                        {showMapelForm && (
                          <button
                            type="button"
                            onClick={() => setShowMapelForm(false)}
                            className="py-1.5 px-3 border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
                          >
                            Batal
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            handleAddMapelToSettings();
                          }}
                          className="py-1.5 px-4 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          Simpan Mata Pelajaran
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Tombol Input Mata Pelajaran Akses Cepat */}
                  {!showMapelForm && (appConfig.mapelList || []).length > 0 && (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 bg-white border border-dashed border-blue-300 rounded-lg hover:border-blue-400 transition-colors gap-2">
                      <div className="flex items-center gap-2 text-xs text-slate-700">
                        <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center shrink-0">
                          <BookOpen className="w-4 h-4 text-[#0095ff]" />
                        </div>
                        <div>
                          <div className="font-bold text-slate-800">Tambah Mata Pelajaran Ujian Baru</div>
                          <div className="text-[11px] text-slate-500">Klik tombol di sebelah kanan untuk membuka formulir input mata pelajaran.</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap shrink-0">
                        <button
                          type="button"
                          onClick={handleExportMapelToExcel}
                          className="py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-300 font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                          title="Unduh seluruh daftar mata pelajaran aktif ke file Excel (.xlsx)"
                        >
                          <Download className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Unduh Excel</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleDownloadMapelTemplateExcel}
                          className="py-2 px-3 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                          title="Unduh contoh template Excel: Nama mapel, tingkat/fase, kategori, durasi, KKM"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Format Excel</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => mapelExcelInputRef.current?.click()}
                          className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                          title="Upload file Excel mata pelajaran (Format: Nama mapel, tingkat/fase, kategori, durasi, KKM)"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>Upload Excel Mapel</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowMapelForm(true)}
                          className="py-2 px-4 bg-[#001a6e] hover:bg-[#00155a] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Input Manual</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Tabel Daftar Mata Pelajaran */}
                  <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                          <th className="py-2.5 px-3 w-12 text-center">No</th>
                          <th className="py-2.5 px-3">Kode Mapel</th>
                          <th className="py-2.5 px-3">Nama Mata Pelajaran</th>
                          <th className="py-2.5 px-3">Tingkat / Fase</th>
                          <th className="py-2.5 px-3">Kategori</th>
                          <th className="py-2.5 px-3 text-center">Durasi</th>
                          <th className="py-2.5 px-3 text-center">KKM</th>
                          <th className="py-2.5 px-3 text-center">Status</th>
                          <th className="py-2.5 px-3 text-center w-20">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {(appConfig.mapelList || []).map((mpl: any, idx: number) => {
                          return (
                            <tr key={mpl.kode + idx} className="hover:bg-slate-50/80 transition-colors">
                              <td className="py-2.5 px-3 text-center text-slate-500 font-medium">{idx + 1}</td>
                              <td className="py-2.5 px-3 font-bold">
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-blue-50 text-[#001a6e] border border-blue-200 font-mono font-bold text-[11px]">
                                  {mpl.kode}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 font-semibold text-slate-800">
                                {mpl.nama}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="inline-block px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-medium">
                                  {mpl.tingkat}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-slate-600 font-medium">{mpl.kategori}</td>
                              <td className="py-2.5 px-3 text-center font-mono text-slate-700 font-semibold">
                                {mpl.alokasiMenit} mnt
                              </td>
                              <td className="py-2.5 px-3 text-center font-mono font-bold text-emerald-700">
                                {mpl.kkm}
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleToggleMapelStatus(mpl.kode)}
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 border rounded-full font-semibold text-[10px] cursor-pointer transition-colors ${
                                    mpl.status === 'Aktif'
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                      : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                                  }`}
                                  title="Klik untuk mengubah status aktif/non-aktif"
                                >
                                  <span
                                    className={`w-1.5 h-1.5 rounded-full ${
                                      mpl.status === 'Aktif' ? 'bg-emerald-500' : 'bg-slate-400'
                                    }`}
                                  ></span>
                                  {mpl.status || 'Aktif'}
                                </button>
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleDeleteMapelFromSettings(mpl.kode)}
                                  className="text-rose-600 hover:text-rose-800 p-1 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                                  title={`Hapus mata pelajaran ${mpl.nama}`}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                        {(!appConfig.mapelList || appConfig.mapelList.length === 0) && (
                          <tr>
                            <td colSpan={9} className="py-6 text-center text-slate-400">
                              Belum ada mata pelajaran yang didaftarkan. Gunakan tombol Input Mata Pelajaran di atas untuk menambahkan.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Pratinjau Tag Mata Pelajaran Terdaftar */}
                  <div className="pt-1 flex flex-wrap items-center gap-1.5 text-xs">
                    <span className="font-semibold text-slate-600 mr-1">Mapel Terdaftar:</span>
                    {(appConfig.mapelList || []).map((mpl: any, idx: number) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2 py-0.5 bg-white border border-slate-300 text-slate-700 rounded-md font-mono text-[11px] shadow-2xs"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        {mpl.kode} - {mpl.nama}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bagian 5: Parameter Teknis Ujian */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#0095ff]" />
                    5. Parameter Waktu & Alur Pengerjaan
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Durasi Standar Ujian (Menit)
                      </label>
                      <input
                        type="number"
                        min={10}
                        max={300}
                        value={appConfig.durasiDefault}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            durasiDefault: Number(e.target.value) || 90,
                          })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                      <span className="text-[11px] text-slate-500 mt-1 block">
                        Durasi bawaan saat membuat jadwal baru.
                      </span>
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Waktu Minimal Tombol Selesai (Menit)
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={appConfig.durasiDefault}
                        value={appConfig.minMinutesBeforeFinish}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            minMinutesBeforeFinish: Number(e.target.value) || 0,
                          })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                      <span className="text-[11px] text-slate-500 mt-1 block">
                        Peserta tidak dapat klik selesai sebelum waktu ini lewat.
                      </span>
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Interval Pembaruan Token (Menit)
                      </label>
                      <input
                        type="number"
                        min={5}
                        max={60}
                        value={appConfig.tokenIntervalMenit}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            tokenIntervalMenit: Number(e.target.value) || 10,
                          })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-mono text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                      <span className="text-[11px] text-slate-500 mt-1 block">
                        Sistem merefresh token otomatis tiap X menit.
                      </span>
                    </div>
                  </div>

                  <div className="pt-2 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                      <input
                        type="checkbox"
                        checked={Boolean(appConfig.enforceMinFinishTime)}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            enforceMinFinishTime: e.target.checked,
                          })
                        }
                        className="w-4 h-4 text-[#001a6e] rounded border-slate-300 focus:ring-[#0095ff]"
                      />
                      <div>
                        <span className="font-semibold text-slate-800 block">
                          Aktifkan Batas Waktu Minimal Selesai ({appConfig.minMinutesBeforeFinish || 0} Menit)
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Jika dicentang, peserta baru dapat menekan Selesai setelah waktu minimal di atas terlewati.
                        </span>
                      </div>
                    </label>
                    <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                      <input
                        type="checkbox"
                        checked={appConfig.acakSoal}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, acakSoal: e.target.checked })
                        }
                        className="w-4 h-4 text-[#001a6e] rounded border-slate-300 focus:ring-[#0095ff]"
                      />
                      <div>
                        <span className="font-semibold text-slate-800 block">
                          Acak Urutan Soal (Shuffle Questions)
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Urutan nomor soal berbeda untuk tiap peserta.
                        </span>
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                      <input
                        type="checkbox"
                        checked={appConfig.acakOpsi}
                        onChange={(e) =>
                          setAppConfig({ ...appConfig, acakOpsi: e.target.checked })
                        }
                        className="w-4 h-4 text-[#001a6e] rounded border-slate-300 focus:ring-[#0095ff]"
                      />
                      <div>
                        <span className="font-semibold text-slate-800 block">
                          Acak Pilihan Jawaban (Shuffle Options)
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Pilihan A, B, C, D, E diacak secara dinamis.
                        </span>
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                      <input
                        type="checkbox"
                        checked={appConfig.tampilkanNilaiPeserta}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            tampilkanNilaiPeserta: e.target.checked,
                          })
                        }
                        className="w-4 h-4 text-[#001a6e] rounded border-slate-300 focus:ring-[#0095ff]"
                      />
                      <div>
                        <span className="font-semibold text-slate-800 block">
                          Tampilkan Nilai Akhir ke Siswa
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Siswa langsung melihat skor setelah menekan tombol selesai.
                        </span>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Bagian 6: Keamanan & Pengawasan Ujian */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    6. Keamanan, Anti-Kecurangan & Kunci Sistem
                  </h4>
                  <div className="space-y-3 text-xs">
                    <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                      <input
                        type="checkbox"
                        checked={appConfig.wajibFullscreen}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            wajibFullscreen: e.target.checked,
                          })
                        }
                        className="w-4 h-4 text-[#001a6e] rounded border-slate-300 focus:ring-[#0095ff]"
                      />
                      <div>
                        <span className="font-semibold text-slate-800 block">
                          Wajib Mode Layar Penuh (Fullscreen Lock)
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Memaksa tampilan layar penuh pada perangkat HP dan komputer.
                        </span>
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                      <input
                        type="checkbox"
                        checked={appConfig.kunciKeluarSistem}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            kunciKeluarSistem: e.target.checked,
                          })
                        }
                        className="w-4 h-4 text-[#001a6e] rounded border-slate-300 focus:ring-[#0095ff]"
                      />
                      <div>
                        <span className="font-semibold text-slate-800 block">
                          Wajib Reset Login oleh Proktor saat Pelanggaran Keluar Sistem
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Jika siswa berpindah aplikasi / tab browser / keluar fullscreen, status peserta terkunci dan harus disetujui di menu Request Reset Login.
                        </span>
                      </div>
                    </label>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Pesan Peringatan Pelanggaran untuk Peserta
                      </label>
                      <input
                        type="text"
                        value={appConfig.pesanPelanggaran}
                        onChange={(e) =>
                          setAppConfig({
                            ...appConfig,
                            pesanPelanggaran: e.target.value,
                          })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#0095ff] outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Bagian 7: Status Penyimpanan & Server */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    7. Status Server & Penyimpanan Cloud
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <div className="p-3 bg-white border border-slate-200 rounded-lg">
                      <span className="text-[11px] text-slate-500 block">Storage Engine</span>
                      <span className="font-bold text-slate-800 uppercase font-mono">
                        {storageEngine}
                      </span>
                    </div>
                    <div className="p-3 bg-white border border-slate-200 rounded-lg">
                      <span className="text-[11px] text-slate-500 block">Sinkronisasi Terakhir</span>
                      <span className="font-semibold text-emerald-700">
                        {lastSyncedLabel}
                      </span>
                    </div>
                    <div className="p-3 bg-white border border-slate-200 rounded-lg">
                      <span className="text-[11px] text-slate-500 block">Sistem Operasi / Target</span>
                      <span className="font-semibold text-slate-700">
                        Vercel Cloud Deployment
                      </span>
                    </div>
                  </div>

                  {/* Kolom URL & Tombol Tarik Data Storage di Menu Pengaturan */}
                  <div className="pt-2 border-t border-slate-200/80 space-y-2.5">
                    <label className="block text-xs font-bold text-slate-700">
                      Tarik Semua Data dari Server 1 / Storage Sebelumnya ke Server 2
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-stretch">
                      <input
                        type="text"
                        value={pullStorageUrl}
                        onChange={(e) => {
                          const val = e.target.value;
                          setPullStorageUrl(val);
                          try {
                            localStorage.setItem('cbt_pull_storage_url', val);
                          } catch {
                            // ignore
                          }
                        }}
                        placeholder="URL Web Server 1 (https://server1.vercel.app) atau KV_REST_API_URL (https://xxx.upstash.io)"
                        className="md:col-span-5 px-3.5 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff] focus:ring-2 focus:ring-[#0095ff]/20"
                      />
                      <input
                        type="password"
                        value={pullStorageToken}
                        onChange={(e) => {
                          const val = e.target.value;
                          setPullStorageToken(val);
                          try {
                            localStorage.setItem('cbt_pull_storage_token', val);
                          } catch {
                            // ignore
                          }
                        }}
                        placeholder="Token KV_REST_API_TOKEN / Password Admin (Opsional)"
                        className="md:col-span-3 px-3.5 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0095ff] focus:ring-2 focus:ring-[#0095ff]/20"
                      />
                      <button
                        type="button"
                        disabled={isPullingStorage}
                        onClick={async () => {
                          if (!onPullStorage) return;
                          setIsPullingStorage(true);
                          try {
                            const target =
                              pullStorageUrl.trim() || '/api/storage';
                            const res = await onPullStorage(
                              target,
                              pullStorageToken.trim()
                            );
                            showNotice(res.message);
                          } finally {
                            setIsPullingStorage(false);
                          }
                        }}
                        className={`md:col-span-2 shrink-0 inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg text-white text-xs font-semibold shadow-2xs transition-colors ${
                          isPullingStorage
                            ? 'bg-emerald-400 cursor-wait'
                            : 'bg-emerald-600 hover:bg-emerald-700 cursor-pointer'
                        }`}
                      >
                        <Download
                          className={`w-3.5 h-3.5 ${
                            isPullingStorage ? 'animate-bounce' : ''
                          }`}
                        />
                        <span>
                          {isPullingStorage
                            ? 'Menarik...'
                            : 'Tarik Data Storage'}
                        </span>
                      </button>
                      {onForceSyncStorage && (
                        <button
                          type="button"
                          onClick={() => {
                            onForceSyncStorage();
                            showNotice(
                              'Data sistem berhasil disinkronkan ke Penyimpanan Vercel!'
                            );
                          }}
                          className="md:col-span-2 shrink-0 inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#0095ff] hover:bg-[#007acc] text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Sinkronkan ke Vercel</span>
                        </button>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      Isi dengan <strong>URL Web Server 1</strong> (misal <code className="font-mono font-semibold text-slate-700">https://cbt-server1.vercel.app</code>) atau <strong>URL Database Vercel KV / Upstash Redis Sebelumnya</strong> (<code className="font-mono font-semibold text-slate-700">KV_REST_API_URL</code> beserta <code className="font-mono font-semibold text-slate-700">KV_REST_API_TOKEN</code> pada kolom Token), lalu klik <strong>Tarik Data Storage</strong> untuk mengambil & menyimpan semua data dari storage sebelumnya ke Server 2.
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#001a6e] hover:bg-[#00155a] text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    Simpan Pengaturan
                  </button>
                </div>
              </form>
            </div>
          )}
        </main>
      </div>

      {/* Pop Up Konfirmasi Keluar Administrator */}
      {showLogoutConfirmModal && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
          aria-labelledby="admin-logout-modal-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setShowLogoutConfirmModal(false);
            }
          }}
        >
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
            {/* Modal Header Bar */}
            <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <LogOut className="w-5 h-5" />
              </div>
              <div>
                <h3
                  id="admin-logout-modal-title"
                  className="text-sm font-bold text-slate-800"
                >
                  Konfirmasi Keluar Administrator
                </h3>
                <p className="text-[11px] text-slate-500 font-medium">
                  Sesi Ujian Sumatif Akhir Semester (SAS)
                </p>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-3">
              <p className="text-xs text-slate-600 leading-relaxed">
                Apakah Anda yakin ingin keluar dari halaman{' '}
                <strong>Administrator CBT</strong>? Semua perubahan yang telah
                disimpan akan tetap tersimpan di sistem.
              </p>
              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-800 flex items-start gap-2">
                <span className="font-bold">Info:</span>
                <span>
                  Untuk masuk kembali, Anda perlu memasukkan kode & password Administrator.
                </span>
              </div>
            </div>

            {/* Modal Footer Buttons */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setShowLogoutConfirmModal(false)}
                className="px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutConfirmModal(false);
                  onLogoutAdmin();
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 active:scale-[0.98] text-xs font-bold text-white shadow-sm transition-all cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Ya, Keluar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Pratinjau Soal CBT */}
      {showQuestionPreviewModal && selectedPackage && (
        <QuestionPreviewModal
          pkg={selectedPackage}
          filterType={statusTesTipeSoal}
          initialIndex={previewQuestionIdx}
          onClose={() => setShowQuestionPreviewModal(false)}
          onDeleteQuestion={(q) => handleDeleteQuestion(q.id, q.number, q)}
        />
      )}
    </div>
  );
};

export interface QuestionPreviewModalProps {
  pkg: ExamPackage;
  filterType: string;
  initialIndex?: number;
  onClose: () => void;
  onDeleteQuestion?: (q: Question) => void;
}

export const QuestionPreviewModal: React.FC<QuestionPreviewModalProps> = ({
  pkg,
  filterType,
  initialIndex = 0,
  onClose,
  onDeleteQuestion,
}) => {
  const filteredQuestions = useMemo(() => {
    const baseQuestions = Array.isArray(pkg?.questions)
      ? pkg.questions.filter((q): q is Question => Boolean(q && typeof q === 'object'))
      : [];
    const byFilter = baseQuestions.filter((q) => {
      if (!filterType || filterType === 'Semua Tipe Soal') return true;
      return q.type === filterType;
    });
    return byFilter.length > 0 ? byFilter : baseQuestions;
  }, [pkg?.questions, filterType]);

  const [currentIdx, setCurrentIdx] = useState(initialIndex);
  const [showAnswerKey, setShowAnswerKey] = useState(true);

  useEffect(() => {
    if (currentIdx >= filteredQuestions.length) {
      setCurrentIdx(Math.max(0, filteredQuestions.length - 1));
    }
  }, [filteredQuestions.length, currentIdx]);

  const activeQuestion = filteredQuestions[currentIdx];
  const cleanTitle = String(pkg?.title ?? '')
    .replace(/^Simulasi TKA\s*-\s*/i, '')
    .replace(/\s*\(SMA\/MA\/SMK\)/i, '');

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="bg-[#001a6e] text-white px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Eye className="w-5 h-5 text-sky-300" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-sm font-extrabold tracking-wide">
                  PRATINJAU SOAL UJIAN CBT — {cleanTitle.toUpperCase()}
                </h3>
                <span className="px-2 py-0.5 rounded bg-sky-500/25 border border-sky-300/30 text-[10px] font-bold text-sky-100">
                  {getPkgClass(pkg)} • {pkg.code}
                </span>
              </div>
              <p className="text-[11px] text-blue-100 mt-0.5">
                Filter Tipe:{' '}
                <strong>
                  {filterType === 'Semua Tipe Soal'
                    ? 'Semua Tipe Soal'
                    : getQuestionTypeLabel(filterType as QuestionType)}
                </strong>{' '}
                • Total Ditampilkan: <strong>{filteredQuestions.length} Soal</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowAnswerKey((prev) => !prev)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors border ${
                showAnswerKey
                  ? 'bg-emerald-500 text-white border-emerald-400'
                  : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
              }`}
            >
              {showAnswerKey ? (
                <Eye className="w-3.5 h-3.5" />
              ) : (
                <EyeOff className="w-3.5 h-3.5" />
              )}
              <span>{showAnswerKey ? 'Kunci Jawaban: Tampil' : 'Kunci Jawaban: Sembunyi'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-rose-600 text-white text-xs font-bold cursor-pointer transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>

        {filteredQuestions.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <BookOpen className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-700">
              Belum Ada Butir Soal untuk Dipratinjau
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Mata pelajaran <strong>{cleanTitle}</strong> saat ini belum memiliki butir soal. Silakan klik tombol <strong>Upload Word / File Soal</strong> atau tambahkan soal manual terlebih dahulu.
            </p>
          </div>
        ) : (
          <>
            {/* Nomor Soal Navigation Bar */}
            <div className="bg-slate-50 px-5 py-3 border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto shrink-0">
              <span className="text-[11px] font-bold text-slate-500 mr-2 shrink-0">
                Nomor Soal:
              </span>
              {filteredQuestions.map((q, idx) => {
                const isActive = idx === currentIdx;
                return (
                  <button
                    key={q.id || idx}
                    type="button"
                    onClick={() => setCurrentIdx(idx)}
                    className={`w-7 h-7 rounded-lg text-xs font-bold shrink-0 cursor-pointer transition-all flex items-center justify-center border ${
                      isActive
                        ? 'bg-[#001a6e] text-white border-[#001a6e] shadow-xs scale-105'
                        : 'bg-white text-slate-700 border-slate-300 hover:border-[#0095ff] hover:text-[#0095ff]'
                    }`}
                  >
                    {q.number}
                  </button>
                );
              })}
            </div>

            {/* Active Question Content */}
            {activeQuestion && (() => {
              const totalQuestionImages =
                (activeQuestion.stimulusImages?.length || 0) +
                (activeQuestion.questionImages?.length || 0) +
                (activeQuestion.options?.reduce(
                  (acc, o) => acc + (o.images?.length || 0),
                  0
                ) || 0) +
                (activeQuestion.statements?.reduce(
                  (acc, s) => acc + (s.images?.length || 0),
                  0
                ) || 0) +
                (activeQuestion.premises?.reduce(
                  (acc, pr) => acc + (pr.images?.length || 0),
                  0
                ) || 0) +
                (activeQuestion.responses?.reduce(
                  (acc, rs) => acc + (rs.images?.length || 0),
                  0
                ) || 0);

              return (
              <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs">
                {/* Question Meta Header */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-1 rounded-md bg-[#001a6e] text-white font-extrabold text-xs">
                      SOAL NO. {activeQuestion.number}
                    </span>
                    <span className="px-2.5 py-1 rounded-md bg-blue-50 text-[#001a6e] border border-blue-200 font-bold">
                      {getQuestionTypeLabel(activeQuestion.type)}
                    </span>
                    <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-600 font-semibold">
                      {activeQuestion.category || 'Materi Ujian'}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-bold text-[11px]">
                      Bobot: {activeQuestion.points || 10} Poin
                    </span>
                    {totalQuestionImages > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-200 font-bold text-[11px]">
                        <ImageIcon className="w-3 h-3" />
                        <span>{totalQuestionImages} Gambar</span>
                      </span>
                    )}
                  </div>

                  {onDeleteQuestion && (
                    <button
                      type="button"
                      onClick={() => onDeleteQuestion(activeQuestion)}
                      className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 hover:border-rose-600 font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                      title="Hapus butir soal ini dari bank soal"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Hapus Soal Ini</span>
                    </button>
                  )}
                </div>

                {/* Stimulus Content */}
                {(activeQuestion.stimulusTitle ||
                  activeQuestion.stimulusText ||
                  activeQuestion.stimulusTable ||
                  (activeQuestion.stimulusImages &&
                    activeQuestion.stimulusImages.length > 0)) && (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                    {activeQuestion.stimulusTitle && (
                      <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wide">
                        {activeQuestion.stimulusTitle}
                      </h4>
                    )}
                    {activeQuestion.stimulusText && (
                      <MathText
                        text={activeQuestion.stimulusText}
                        className="text-slate-700 leading-relaxed whitespace-pre-line"
                      />
                    )}
                    {activeQuestion.stimulusImages &&
                      activeQuestion.stimulusImages.length > 0 && (
                        <QuestionImageGallery
                          images={activeQuestion.stimulusImages}
                          altPrefix={`Gambar stimulus soal ${activeQuestion.number}`}
                          maxHeightClass="max-h-64"
                        />
                      )}
                    {activeQuestion.stimulusTable && (
                      <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                        {activeQuestion.stimulusTable.title && (
                          <div className="px-3 py-1.5 bg-slate-100 border-b border-slate-200 font-bold text-slate-700 text-[11px]">
                            <MathText text={activeQuestion.stimulusTable.title} inline />
                          </div>
                        )}
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-slate-700">
                              {activeQuestion.stimulusTable.headers.map((h, hIdx) => (
                                <th
                                  key={hIdx}
                                  className="py-2 px-3 font-bold border-r last:border-r-0 border-slate-200"
                                >
                                  <MathText text={h} inline />
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {activeQuestion.stimulusTable.rows.map((r, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-50/70">
                                {r.map((cell, cIdx) => (
                                  <td
                                    key={cIdx}
                                    className="py-1.5 px-3 text-slate-700 border-r last:border-r-0 border-slate-100"
                                  >
                                    <MathText text={cell} inline />
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    {activeQuestion.stimulusHighlightBox && (
                      <MathText
                        text={activeQuestion.stimulusHighlightBox}
                        className="p-2.5 rounded-lg bg-blue-50 border border-blue-200 text-[#001a6e] font-semibold text-[11px] whitespace-pre-line"
                      />
                    )}
                  </div>
                )}

                {/* Question Text & Images */}
                <div className="space-y-2">
                  <MathText
                    text={activeQuestion.questionText}
                    className="text-sm font-semibold text-slate-900 leading-relaxed whitespace-pre-line"
                  />
                  {activeQuestion.questionImages &&
                    activeQuestion.questionImages.length > 0 && (
                      <QuestionImageGallery
                        images={activeQuestion.questionImages}
                        altPrefix={`Gambar soal ${activeQuestion.number}`}
                        maxHeightClass="max-h-72"
                      />
                    )}
                  {activeQuestion.instructionText && (
                    <p className="text-[11px] italic text-slate-500">
                      {activeQuestion.instructionText}
                    </p>
                  )}
                </div>

                {/* Options / Answer Area based on Question Type */}
                {(activeQuestion.type === 'pilihan_ganda' ||
                  activeQuestion.type === 'pilihan_ganda_kompleks') &&
                  activeQuestion.options && (
                    <div className="space-y-2 pt-1">
                      {activeQuestion.options.map((opt) => {
                        const isCorrect =
                          activeQuestion.type === 'pilihan_ganda'
                            ? activeQuestion.correctOptionId === opt.id
                            : Boolean(
                                activeQuestion.correctOptionIds?.includes(opt.id)
                              );
                        return (
                          <div
                            key={opt.id}
                            className={`p-3 rounded-xl border flex items-start gap-3 transition-colors ${
                              showAnswerKey && isCorrect
                                ? 'bg-emerald-50 border-emerald-400 text-emerald-950'
                                : 'bg-white border-slate-200 text-slate-800'
                            }`}
                          >
                            <span
                              className={`w-6 h-6 rounded-lg font-bold text-xs flex items-center justify-center shrink-0 border ${
                                showAnswerKey && isCorrect
                                  ? 'bg-emerald-600 text-white border-emerald-600'
                                  : 'bg-slate-100 text-slate-700 border-slate-300'
                              }`}
                            >
                              {opt.id}
                            </span>
                            <div className="flex-1 pt-0.5 leading-relaxed space-y-1.5">
                              {opt.text && <MathText text={opt.text} />}
                              {opt.images && opt.images.length > 0 && (
                                <QuestionImageGallery
                                  images={opt.images}
                                  altPrefix={`Gambar opsi ${opt.id}`}
                                  compact
                                  maxHeightClass="max-h-40"
                                />
                              )}
                            </div>
                            {showAnswerKey && isCorrect && (
                              <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white font-bold text-[10px] shrink-0">
                                Kunci Jawaban
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                {activeQuestion.type === 'benar_salah' &&
                  activeQuestion.statements && (
                    <div className="overflow-x-auto border border-slate-200 rounded-xl">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-slate-100 border-b border-slate-200 text-slate-700">
                            <th className="py-2.5 px-3.5 font-bold">Pernyataan</th>
                            <th className="py-2.5 px-3.5 font-bold text-center w-28">
                              {activeQuestion.trueLabel || 'Benar'}
                            </th>
                            <th className="py-2.5 px-3.5 font-bold text-center w-28">
                              {activeQuestion.falseLabel || 'Salah'}
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {activeQuestion.statements.map((st) => (
                            <tr key={st.id} className="bg-white">
                              <td className="py-2.5 px-3.5 text-slate-800 space-y-1.5">
                                {st.statement && <MathText text={st.statement} />}
                                {st.images && st.images.length > 0 && (
                                  <QuestionImageGallery
                                    images={st.images}
                                    altPrefix={`Gambar pernyataan ${st.id}`}
                                    compact
                                    maxHeightClass="max-h-36"
                                  />
                                )}
                              </td>
                              <td className="py-2.5 px-3.5 text-center">
                                <span
                                  className={`inline-flex px-2.5 py-1 rounded-md font-bold text-[11px] ${
                                    showAnswerKey && st.correctValue === 'Benar'
                                      ? 'bg-emerald-600 text-white'
                                      : 'bg-slate-100 text-slate-400'
                                  }`}
                                >
                                  {activeQuestion.trueLabel || 'Benar'}
                                </span>
                              </td>
                              <td className="py-2.5 px-3.5 text-center">
                                <span
                                  className={`inline-flex px-2.5 py-1 rounded-md font-bold text-[11px] ${
                                    showAnswerKey && st.correctValue === 'Salah'
                                      ? 'bg-rose-600 text-white'
                                      : 'bg-slate-100 text-slate-400'
                                  }`}
                                >
                                  {activeQuestion.falseLabel || 'Salah'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                {activeQuestion.type === 'menjodohkan' &&
                  activeQuestion.premises && (
                    <div className="overflow-x-auto border border-slate-200 rounded-xl">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-slate-100 border-b border-slate-200 text-slate-700">
                            <th className="py-2.5 px-3.5 font-bold">
                              Premis / Pernyataan
                            </th>
                            <th className="py-2.5 px-3.5 font-bold">
                              Pasangan Respon {showAnswerKey ? '(Kunci)' : ''}
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {activeQuestion.premises.map((prem) => {
                            const matchedRespId =
                              activeQuestion.correctPairs?.[prem.id];
                            const matchedResp = activeQuestion.responses?.find(
                              (r) => r.id === matchedRespId
                            );
                            return (
                              <tr key={prem.id} className="bg-white">
                                <td className="py-2.5 px-3.5 font-medium text-slate-800 space-y-1.5">
                                  {prem.text && <MathText text={prem.text} />}
                                  {prem.images && prem.images.length > 0 && (
                                    <QuestionImageGallery
                                      images={prem.images}
                                      altPrefix={`Gambar premis ${prem.id}`}
                                      compact
                                      maxHeightClass="max-h-32"
                                    />
                                  )}
                                </td>
                                <td className="py-2.5 px-3.5 space-y-1.5">
                                  {showAnswerKey ? (
                                    <div className="space-y-1.5">
                                      <span className="inline-flex px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold">
                                        <MathText text={matchedResp?.text || matchedRespId || '-'} inline />
                                      </span>
                                      {matchedResp?.images &&
                                        matchedResp.images.length > 0 && (
                                          <QuestionImageGallery
                                            images={matchedResp.images}
                                            altPrefix={`Gambar respon ${matchedResp.id}`}
                                            compact
                                            maxHeightClass="max-h-32"
                                          />
                                        )}
                                    </div>
                                  ) : (
                                    <span className="text-slate-400 italic">
                                      Pilih pasangan respon...
                                    </span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}

                {activeQuestion.type === 'isian_singkat' && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="text-slate-600 font-semibold">
                      Kolom Jawaban Siswa:
                    </div>
                    <input
                      type="text"
                      readOnly
                      value={
                        showAnswerKey && activeQuestion.correctShortAnswers?.length
                          ? activeQuestion.correctShortAnswers.join(' / ')
                          : ''
                      }
                      placeholder={
                        activeQuestion.placeholder || 'Ketik jawaban singkat...'
                      }
                      className="w-full px-3 py-2 rounded-lg bg-white border border-slate-300 font-bold text-emerald-800"
                    />
                  </div>
                )}

                {showAnswerKey && activeQuestion.explanation && (
                  <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-amber-950 space-y-1">
                    <div className="font-bold text-[11px] uppercase tracking-wider text-amber-800">
                      Keterangan / Pembahasan Kunci:
                    </div>
                    <MathText text={activeQuestion.explanation} className="leading-relaxed whitespace-pre-line" />
                  </div>
                )}
              </div>
              );
            })()}

            {/* Footer Navigation */}
            <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
              <button
                type="button"
                disabled={currentIdx <= 0}
                onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40 text-xs font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
              >
                <ChevronsLeft className="w-4 h-4" />
                <span>Soal Sebelumnya</span>
              </button>

              <span className="text-xs font-bold text-slate-600">
                Soal {currentIdx + 1} dari {filteredQuestions.length}
              </span>

              <button
                type="button"
                disabled={currentIdx >= filteredQuestions.length - 1}
                onClick={() =>
                  setCurrentIdx((i) =>
                    Math.min(filteredQuestions.length - 1, i + 1)
                  )
                }
                className="px-3.5 py-1.5 rounded-lg bg-[#001a6e] hover:bg-[#00124d] disabled:opacity-40 text-xs font-bold text-white flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
              >
                <span>Soal Berikutnya</span>
                <ChevronsRight className="w-4 h-4" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
