/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { PusmendikHeader } from './components/PusmendikHeader';
import { LoginView, ViolationAlertInfo } from './components/LoginView';
import {
  ParticipantConfirmationView,
  TestConfirmationView,
  resolvePackageForSchedule,
  cleanMapelTitle,
} from './components/ConfirmationViews';
import { ExamRunnerView } from './components/ExamRunnerView';
import { ExamResultView } from './components/ExamResultView';
import { ProctorLoginView } from './components/ProctorLoginView';
import {
  ProctorDashboardView,
  ProctorParticipantRow,
  doesKelasMatch,
  getParticipantNameKelasKey,
  isDefaultDemoParticipantRow,
  isDefaultDemoParticipantsList,
  isParticipantLockedByViolation,
  isParticipantStatusActive,
  mergeParticipantLists,
  normalizeKelasCode,
  sanitizeParticipantRows,
  shortenStudentUsername,
} from './components/ProctorDashboardView';
import {
  AdminLoginView,
  AdminDashboardView,
  AdminProctorItem,
  INITIAL_ADMIN_SCHEDULES,
  INITIAL_ADMIN_PARTICIPANTS,
  INITIAL_ADMIN_PROCTORS,
} from './components/AdminViews';
import {
  DEFAULT_EXAM_TOKEN,
  INITIAL_EXAM_PACKAGES,
  stripDemoSampleIfUploadedPresent,
} from './data/cbtData';
import {
  AdminScheduleItem,
  ExamPackage,
  ExamResultSummary,
  ParticipantProfile,
  Question,
  StudentAnswer,
} from './types/cbt';
import {
  clearAuthSessionToken,
  fetchVercelStorage,
  getAuthSessionRole,
  getAuthSessionToken,
  getServerNow,
  hasAuthSessionToken,
  onSessionReplaced,
  pullStorageFromUrl,
  requestResetFromServer,
  saveVercelStorage,
  startExamOnServer,
  submitExamToServer,
} from './utils/vercelStorage';
import { Power } from 'lucide-react';
import { ErrorBoundary } from './components/ErrorBoundary';

type AppStage =
  | 'login'
  | 'proctor_login'
  | 'proctor_dashboard'
  | 'admin_login'
  | 'admin_dashboard'
  | 'confirm_participant'
  | 'confirm_test'
  | 'exam_running'
  | 'exam_result';

const STORAGE_KEYS = {
  PACKAGES: 'pusmendik_cbt_packages_v1',
  PACKAGES_BACKUP: 'pusmendik_cbt_packages_backup_v1',
  DELETED_PACKAGES: 'pusmendik_cbt_deleted_packages_v1',
  SCHEDULES: 'pusmendik_cbt_schedules_v1',
  SCHEDULES_BACKUP: 'pusmendik_cbt_schedules_backup_v1',
  DELETED_SCHEDULES: 'pusmendik_cbt_deleted_schedules_v1',
  PARTICIPANTS: 'pusmendik_cbt_participants_v1',
  PARTICIPANTS_BACKUP: 'pusmendik_cbt_participants_backup_v1',
  DELETED_PARTICIPANTS: 'pusmendik_cbt_deleted_participants_v1',
  PROCTORS: 'pusmendik_cbt_proctors_v1',
  TOKEN: 'pusmendik_cbt_token_v1',
  TOKEN_UPDATED_AT: 'pusmendik_cbt_token_updated_at_v1',
  HISTORY: 'pusmendik_cbt_history_v1',
  DRAFTS: 'pusmendik_cbt_student_drafts_v1',
  PENDING_RESULTS: 'pusmendik_cbt_pending_results_v1',
};

interface PendingExamSubmission {
  localResultId: string;
  packageId: string;
  packageTitle: string;
  answers: Record<string, StudentAnswer>;
  timeUsedSeconds: number;
  participant: ParticipantProfile;
  clientFallbackSummary?: ExamResultSummary;
  queuedAt: number;
}

function readPendingExamSubmissions(): PendingExamSubmission[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PENDING_RESULTS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function safeSetCriticalLocalStorage(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch {
    // Evict large regenerable package caches first so student drafts/pending submits survive 5MB quota limits
    try {
      localStorage.removeItem(STORAGE_KEYS.PACKAGES_BACKUP);
      localStorage.removeItem(STORAGE_KEYS.PACKAGES);
      localStorage.setItem(key, value);
    } catch {
      // ignore if browser storage is completely disabled
    }
  }
}

function writePendingExamSubmissions(items: PendingExamSubmission[]): void {
  try {
    if (items.length === 0) {
      localStorage.removeItem(STORAGE_KEYS.PENDING_RESULTS);
    } else {
      safeSetCriticalLocalStorage(
        STORAGE_KEYS.PENDING_RESULTS,
        JSON.stringify(items)
      );
    }
  } catch {
    // ignore storage quota errors
  }
}

function enqueuePendingExamSubmission(item: PendingExamSubmission): void {
  const existing = readPendingExamSubmissions().filter(
    (x) => x.localResultId !== item.localResultId
  );
  existing.push(item);
  writePendingExamSubmissions(existing);
}

function removePendingExamSubmission(localResultId: string): void {
  const remaining = readPendingExamSubmissions().filter(
    (x) => x.localResultId !== localResultId
  );
  writePendingExamSubmissions(remaining);
}

const DEFAULT_DEMO_SCHEDULE_IDS = new Set([
  'sch1',
  'sch2',
  'sch3',
  'sch4',
  'sch5',
  'sch_1',
  'sch_2',
  'sch_3',
  'sch_4',
  'sch_5',
  's1',
  's2',
  's3',
  's4',
  's5',
]);

function readLocalDeletedSet(storageKey: string): Set<string> {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return new Set(
        parsed.map((id) => String(id || '').trim()).filter(Boolean)
      );
    }
  } catch {
    // ignore
  }
  return new Set();
}

function addLocalDeletedIds(storageKey: string, ids: Iterable<string>): string[] {
  const set = readLocalDeletedSet(storageKey);
  for (const id of ids) {
    const clean = String(id || '').trim();
    if (clean) set.add(clean);
  }
  const arr = Array.from(set);
  try {
    localStorage.setItem(storageKey, JSON.stringify(arr));
  } catch {
    // ignore
  }
  return arr;
}

function isDefaultInactiveSchedulesList(
  rows?: AdminScheduleItem[] | null
): boolean {
  if (!Array.isArray(rows) || rows.length === 0) return true;
  const hasAnyActive = rows.some((s) => Boolean(s && s.isActive));
  if (hasAnyActive) return false;
  if (rows.length > 5) return false;
  return rows.every((s) =>
    DEFAULT_DEMO_SCHEDULE_IDS.has(String(s?.id || '').trim())
  );
}

function mergeSchedulesByTimestamp(
  remoteList: AdminScheduleItem[],
  localList: AdminScheduleItem[],
  deletedIdsInput?: Iterable<string>
): AdminScheduleItem[] {
  const deletedSet = readLocalDeletedSet(STORAGE_KEYS.DELETED_SCHEDULES);
  if (deletedIdsInput) {
    for (const id of deletedIdsInput) {
      const clean = String(id || '').trim();
      if (clean) deletedSet.add(clean);
    }
  }

  const localById = new Map<string, AdminScheduleItem>();
  for (const lSch of localList) {
    if (!lSch || typeof lSch !== 'object') continue;
    const id = String(lSch.id || '').trim();
    if (id && !deletedSet.has(id)) {
      localById.set(id, lSch);
    }
  }

  const matchedIds = new Set<string>();
  const merged = remoteList
    .filter((rSch) => {
      if (!rSch || typeof rSch !== 'object') return false;
      const id = String(rSch.id || '').trim();
      return !id || !deletedSet.has(id);
    })
    .map((rSch) => {
      const id = String(rSch.id || '').trim();
      const lSch = id ? localById.get(id) : undefined;
      if (!lSch) return rSch;
      matchedIds.add(id);

      const rTs = typeof rSch.updatedAt === 'number' ? rSch.updatedAt : 0;
      const lTs = typeof lSch.updatedAt === 'number' ? lSch.updatedAt : 0;

      if (rTs > 0 || lTs > 0) {
        return lTs > rTs ? lSch : rSch;
      }

      // If neither has a timestamp yet, trust the server schedule state
      return rSch;
    });

  // Preserve custom local schedules (not default demo IDs and not deleted) missing from remote
  for (const lSch of localList) {
    if (!lSch || typeof lSch !== 'object') continue;
    const id = String(lSch.id || '').trim();
    if (!id || deletedSet.has(id) || matchedIds.has(id)) continue;
    if (!DEFAULT_DEMO_SCHEDULE_IDS.has(id)) {
      merged.push(lSch);
    }
  }

  return merged;
}

function buildClientSchedulePkgCandidates(
  mapelRaw?: string,
  kelasRaw?: string
): {
  code: string;
  pkgId: string;
  candidateCodes: string[];
  candidatePkgIds: string[];
} {
  const normKelas = normalizeKelasCode(kelasRaw) || 'X';
  const kelasSlug =
    normKelas
      .replace(/^KELAS\s+/i, '')
      .replace(/[^a-zA-Z0-9]+/g, '')
      .toUpperCase()
      .slice(0, 6) || 'X';
  const alphaNumUpper = String(mapelRaw || '')
    .trim()
    .replace(/[^a-zA-Z0-9]+/g, '')
    .toUpperCase();
  const mapelSlug6 = alphaNumUpper.slice(0, 6) || 'MPL';
  const mapelSlug3 =
    String(mapelRaw || '')
      .trim()
      .replace(/[^a-zA-Z]+/g, '')
      .toUpperCase()
      .slice(0, 3) || mapelSlug6.slice(0, 3) || 'MPL';
  const code = `${mapelSlug6}-${kelasSlug}`;
  const pkgId =
    'mapel_pkg_' + code.toLowerCase().replace(/[^a-z0-9]/g, '_');

  const candidateCodes = Array.from(
    new Set([
      code,
      `${mapelSlug3}-${kelasSlug}`,
      `${mapelSlug3}-SAS`,
      `${mapelSlug3}-02-SAS`,
      `${mapelSlug3}-03-SAS`,
      `${mapelSlug6}-SAS`,
    ])
  );
  const candidatePkgIds = candidateCodes.map(
    (c) => 'MAPEL_PKG_' + c.toUpperCase().replace(/[^A-Z0-9]/g, '_')
  );
  return { code, pkgId, candidateCodes, candidatePkgIds };
}

function isLegacyZombieSimulasi(
  titleOrName: unknown,
  obj?: Record<string, any> | null
): boolean {
  if (obj && obj.simulasiWhitelistedV4 === true) {
    return false;
  }
  const rawStr = String(titleOrName || '').trim();
  const cleaned = cleanMapelTitle(rawStr);
  if (/^\s*simulasi\b/i.test(rawStr) || /^\s*simulasi\b/i.test(cleaned)) {
    return true;
  }
  const codeStr = String(obj?.code || obj?.kode || '').trim().toUpperCase();
  if (/^SIMULA/i.test(codeStr) || /^TKA-/i.test(codeStr)) {
    return true;
  }
  const idStr = String(obj?.id || '').trim().toUpperCase();
  if (/^MAPEL_PKG_SIMULA/i.test(idStr) || /^PKG_TKA_/i.test(idStr)) {
    return true;
  }
  return false;
}

function sanitizeClientSchedules(
  rawSchedules?: AdminScheduleItem[] | null,
  currentPackages?: ExamPackage[] | null,
  currentAdminSettings?: Record<string, any> | null,
  extraDeletedScheduleIds?: Iterable<string>,
  extraDeletedPackageIds?: Iterable<string>
): AdminScheduleItem[] {
  if (!Array.isArray(rawSchedules)) return [];
  const deletedSchedSet = readLocalDeletedSet(STORAGE_KEYS.DELETED_SCHEDULES);
  if (extraDeletedScheduleIds) {
    for (const id of extraDeletedScheduleIds) {
      const clean = String(id || '').trim();
      if (clean) deletedSchedSet.add(clean);
    }
  }

  const deletedPkgSet = new Set<string>();
  for (const id of readLocalDeletedSet(STORAGE_KEYS.DELETED_PACKAGES)) {
    const clean = String(id || '').trim().toUpperCase();
    if (clean) deletedPkgSet.add(clean);
  }
  if (extraDeletedPackageIds) {
    for (const id of extraDeletedPackageIds) {
      const clean = String(id || '').trim().toUpperCase();
      if (clean) deletedPkgSet.add(clean);
    }
  }

  const cfg =
    currentAdminSettings && typeof currentAdminSettings === 'object'
      ? currentAdminSettings
      : null;

  const deletedMapelCodesSet = new Set<string>(
    Array.isArray(cfg?.deletedMapelCodes)
      ? cfg!.deletedMapelCodes
          .map((c: unknown) => String(c || '').trim().toUpperCase())
          .filter(Boolean)
      : []
  );
  const deletedMapelNamesSet = new Set<string>(
    Array.isArray(cfg?.deletedMapelNames)
      ? cfg!.deletedMapelNames
          .map((n: unknown) => cleanMapelTitle(String(n || '')))
          .filter(Boolean)
      : []
  );

  // Filter mapelList against deletedPkgSet, deletedMapelCodesSet, deletedMapelNamesSet, and legacy zombie SIMULASI
  const validMapelList = Array.isArray(cfg?.mapelList)
    ? (cfg!.mapelList as Record<string, any>[]).filter((m) => {
        if (!m || typeof m !== 'object') return false;
        if (isLegacyZombieSimulasi(m.nama, m)) return false;
        const mKode = String(m.kode || '').trim().toUpperCase();
        const mPkgId = mKode
          ? 'MAPEL_PKG_' + mKode.replace(/[^A-Z0-9]/g, '_')
          : '';
        const mNama = cleanMapelTitle(String(m.nama || ''));
        if (
          (mKode &&
            (deletedPkgSet.has(mKode) || deletedMapelCodesSet.has(mKode))) ||
          (mPkgId && deletedPkgSet.has(mPkgId))
        ) {
          if (mKode) deletedMapelCodesSet.add(mKode);
          return false;
        }
        if (mNama && deletedMapelNamesSet.has(mNama)) return false;
        return true;
      })
    : null;

  const validPackages = Array.isArray(currentPackages)
    ? currentPackages.filter((p) => {
        if (!p || typeof p !== 'object') return false;
        if (isLegacyZombieSimulasi(p.title, p)) return false;
        const pid = String(p.id || '').trim().toUpperCase();
        const pcode = String(p.code || '').trim().toUpperCase();
        const ptitle = cleanMapelTitle(p.title);
        if (pid && deletedPkgSet.has(pid)) return false;
        if (
          pcode &&
          (deletedPkgSet.has(pcode) || deletedMapelCodesSet.has(pcode))
        ) {
          return false;
        }
        if (ptitle && deletedMapelNamesSet.has(ptitle)) return false;
        return true;
      })
    : [];
  const hasPackagesAuthority =
    Array.isArray(currentPackages) &&
    (currentPackages.length > 0 ||
      deletedPkgSet.size > 0 ||
      deletedMapelCodesSet.size > 0 ||
      deletedMapelNamesSet.size > 0 ||
      Boolean(cfg?.customMapelConfigured));

  const cfgUpdatedAt =
    typeof cfg?.updatedAt === 'number' && Number.isFinite(cfg.updatedAt)
      ? cfg.updatedAt
      : 0;

  const out: AdminScheduleItem[] = [];
  for (const s of rawSchedules) {
    if (!s || typeof s !== 'object') continue;
    const id = String(s.id || '').trim();
    if (id && deletedSchedSet.has(id)) continue;
    if (isLegacyZombieSimulasi(s.mapel, s)) continue;

    const cleanTitle = cleanMapelTitle(s.mapel);
    if (!cleanTitle) continue;

    const sKelas = s.kelas;
    const sUpdatedAt =
      typeof s.updatedAt === 'number' && Number.isFinite(s.updatedAt)
        ? s.updatedAt
        : 0;

    const matchingPkg = Array.isArray(currentPackages)
      ? validPackages.find((pkg) => {
          if (cleanMapelTitle(pkg.title) !== cleanTitle) return false;
          const rawTarget = String(pkg.targetClass || '').trim().toUpperCase();
          if (
            !rawTarget ||
            rawTarget === 'SEMUA' ||
            rawTarget === 'SEMUA KELAS'
          ) {
            return true;
          }
          return (
            doesKelasMatch(rawTarget, sKelas) ||
            doesKelasMatch(sKelas, rawTarget)
          );
        })
      : undefined;

    const matchingMapelCfg = validMapelList
      ? validMapelList.find((m) => {
          if (cleanMapelTitle(String(m.nama || '')) !== cleanTitle) return false;
          const rawTingkat = String(m.tingkat || '').trim();
          if (!rawTingkat || /^semua/i.test(rawTingkat)) return true;
          return (
            doesKelasMatch(rawTingkat, sKelas) ||
            doesKelasMatch(sKelas, rawTingkat)
          );
        })
      : undefined;

    const { candidateCodes, candidatePkgIds } =
      buildClientSchedulePkgCandidates(s.mapel, sKelas);
    const isExplicitlyDeletedCodeOrName =
      deletedMapelNamesSet.has(cleanTitle) ||
      candidateCodes.some(
        (c) => deletedMapelCodesSet.has(c) || deletedPkgSet.has(c)
      ) ||
      candidatePkgIds.some((pid) => deletedPkgSet.has(pid));

    if (!matchingPkg && isExplicitlyDeletedCodeOrName) {
      continue;
    }

    // If the subject was removed from Bank Soal (packages), strip this schedule so deleted subjects never appear on Konfirmasi Data Peserta
    if (
      hasPackagesAuthority &&
      !matchingPkg &&
      (Boolean(s.isActive) ||
        !DEFAULT_DEMO_SCHEDULE_IDS.has(id) ||
        validPackages.length === 0 ||
        deletedPkgSet.size > 0 ||
        Boolean(cfg?.customMapelConfigured))
    ) {
      continue;
    }

    // If the subject was removed from Pengaturan Mata Pelajaran (mapelList), strip this schedule
    if (
      validMapelList &&
      !matchingMapelCfg &&
      (!matchingPkg ||
        Boolean(cfg?.customMapelConfigured) ||
        deletedMapelCodesSet.size > 0 ||
        deletedMapelNamesSet.size > 0)
    ) {
      continue;
    }

    if (
      matchingMapelCfg &&
      String(matchingMapelCfg.status || '').trim().toLowerCase() ===
        'non aktif' &&
      (sUpdatedAt === 0 || cfgUpdatedAt >= sUpdatedAt)
    ) {
      out.push({ ...s, isActive: false });
      continue;
    }

    out.push(s);
  }

  return out;
}

function getRealQuestionsCount(pkg?: ExamPackage | null): number {
  if (!pkg || !Array.isArray(pkg.questions)) return 0;
  return stripDemoSampleIfUploadedPresent(pkg.questions).length;
}

function getTotalUploadedQuestionsCount(pkgs?: ExamPackage[] | null): number {
  if (!Array.isArray(pkgs)) return 0;
  return pkgs.reduce((acc, pkg) => acc + getRealQuestionsCount(pkg), 0);
}

function hasAnyUploadedQuestions(pkgs?: ExamPackage[] | null): boolean {
  return getTotalUploadedQuestionsCount(pkgs) > 0;
}

function getPkgMatchKey(pkg: ExamPackage): string {
  const title = String(pkg.title || '')
    .replace(/^Simulasi TKA\s*-\s*/i, '')
    .trim()
    .toLowerCase();
  const cls = normalizeKelasCode(pkg.targetClass || '');
  return `${title}__${cls}`;
}

function readLocalDeletedMapelSets(extraDeletedPackageIds?: Iterable<string>): {
  deletedCodes: Set<string>;
  deletedNames: Set<string>;
  deletedPkgIds: Set<string>;
  isCustomMapelConfigured: boolean;
} {
  const deletedCodes = new Set<string>();
  const deletedNames = new Set<string>();
  const deletedPkgIds = new Set<string>();
  let isCustomMapelConfigured = false;
  for (const id of readLocalDeletedSet(STORAGE_KEYS.DELETED_PACKAGES)) {
    const clean = String(id || '').trim().toUpperCase();
    if (clean) {
      deletedPkgIds.add(clean);
      deletedCodes.add(clean);
    }
  }
  if (extraDeletedPackageIds) {
    for (const id of extraDeletedPackageIds) {
      const clean = String(id || '').trim().toUpperCase();
      if (clean) {
        deletedPkgIds.add(clean);
        deletedCodes.add(clean);
      }
    }
  }
  try {
    const rawSettings = localStorage.getItem('cbt_admin_settings');
    if (rawSettings) {
      const parsedSettings = JSON.parse(rawSettings);
      if (parsedSettings && typeof parsedSettings === 'object') {
        if (parsedSettings.customMapelConfigured) {
          isCustomMapelConfigured = true;
        }
        if (Array.isArray(parsedSettings.deletedMapelCodes)) {
          parsedSettings.deletedMapelCodes.forEach((c: any) => {
            if (typeof c === 'string' && c.trim()) {
              deletedCodes.add(c.trim().toUpperCase());
            }
          });
        }
        if (Array.isArray(parsedSettings.deletedMapelNames)) {
          parsedSettings.deletedMapelNames.forEach((n: any) => {
            if (typeof n === 'string' && n.trim()) {
              deletedNames.add(n.trim().toLowerCase());
            }
          });
        }
      }
    }
  } catch {
    // ignore
  }
  return { deletedCodes, deletedNames, deletedPkgIds, isCustomMapelConfigured };
}

function mergePackagesPreservingQuestions(
  incomingList: ExamPackage[],
  localList: ExamPackage[],
  extraDeletedPackageIds?: Iterable<string>
): ExamPackage[] {
  const { deletedCodes, deletedNames, deletedPkgIds } =
    readLocalDeletedMapelSets(extraDeletedPackageIds);

  const localById = new Map<string, ExamPackage>();
  const localByCode = new Map<string, ExamPackage>();
  const localByTitleClass = new Map<string, ExamPackage>();

  for (const lPkg of localList) {
    if (!lPkg || typeof lPkg !== 'object') continue;
    const id = String(lPkg.id || '').trim();
    const code = String(lPkg.code || '')
      .trim()
      .toUpperCase();
    if (id && deletedPkgIds.has(id.toUpperCase())) continue;
    if (code && (deletedCodes.has(code) || deletedPkgIds.has(code))) continue;
    const tk = getPkgMatchKey(lPkg);
    if (id) localById.set(id, lPkg);
    if (code) localByCode.set(code, lPkg);
    if (tk) localByTitleClass.set(tk, lPkg);
  }

  const matchedLocalIds = new Set<string>();

  const merged = incomingList
    .filter((pkg) => {
      if (!pkg || typeof pkg !== 'object') return false;
      const pId = String(pkg.id || '')
        .trim()
        .toUpperCase();
      const pCode = String(pkg.code || '')
        .trim()
        .toUpperCase();
      const pTitle = String(pkg.title || '')
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
      if (pId && deletedPkgIds.has(pId)) return false;
      if (pCode && (deletedCodes.has(pCode) || deletedPkgIds.has(pCode))) {
        return false;
      }
      if (pTitle && deletedNames.has(pTitle)) return false;
      return true;
    })
    .map((pkg) => {
      const id = String(pkg.id || '').trim();
      const code = String(pkg.code || '')
        .trim()
        .toUpperCase();
      const tk = getPkgMatchKey(pkg);

      const localMatch =
        (id ? localById.get(id) : undefined) ||
        (code ? localByCode.get(code) : undefined) ||
        (tk ? localByTitleClass.get(tk) : undefined);

      if (localMatch) {
        if (localMatch.id) matchedLocalIds.add(localMatch.id);
        const incQuestions = stripDemoSampleIfUploadedPresent(pkg.questions);
        const localQuestions = stripDemoSampleIfUploadedPresent(
          localMatch.questions
        );
        const incQCount = incQuestions.length;
        const localQCount = localQuestions.length;
        const incQTs =
          typeof pkg.questionsUpdatedAt === 'number' &&
          Number.isFinite(pkg.questionsUpdatedAt)
            ? pkg.questionsUpdatedAt
            : 0;
        const localQTs =
          typeof localMatch.questionsUpdatedAt === 'number' &&
          Number.isFinite(localMatch.questionsUpdatedAt)
            ? localMatch.questionsUpdatedAt
            : 0;
        const isIncomingExplicitlyNewer = incQTs > localQTs && incQCount > 0;

        // Never overwrite local uploaded questions with an empty/smaller remote question list
        // unless the incoming package carries a newer questionsUpdatedAt timestamp
        if (
          !isIncomingExplicitlyNewer &&
          localQCount > 0 &&
          incQCount < localQCount
        ) {
          return {
            ...pkg,
            questions: localQuestions,
            ...(localQTs > 0 ? { questionsUpdatedAt: localQTs } : {}),
          };
        }
        const resolvedQTs = Math.max(incQTs, localQTs);
        return {
          ...pkg,
          questions: incQuestions,
          ...(resolvedQTs > 0 ? { questionsUpdatedAt: resolvedQTs } : {}),
        };
      }
      return {
        ...pkg,
        questions: stripDemoSampleIfUploadedPresent(pkg.questions),
      };
    });

  // Also preserve any local packages that have uploaded questions (or custom mapel) missing from incomingList AND not deleted
  for (const lPkg of localList) {
    if (!lPkg || typeof lPkg !== 'object') continue;
    const lId = String(lPkg.id || '')
      .trim()
      .toUpperCase();
    const lCode = String(lPkg.code || '')
      .trim()
      .toUpperCase();
    const lTitle = String(lPkg.title || '')
      .replace(/^Simulasi TKA\s*-\s*/i, '')
      .trim()
      .toLowerCase();
    if (lId && deletedPkgIds.has(lId)) continue;
    if (lCode && (deletedCodes.has(lCode) || deletedPkgIds.has(lCode))) continue;
    if (lTitle && deletedNames.has(lTitle)) continue;
    if (lPkg.id && matchedLocalIds.has(lPkg.id)) continue;

    const tk = getPkgMatchKey(lPkg);
    const alreadyExists = merged.some((m) => {
      const mCode = String(m.code || '')
        .trim()
        .toUpperCase();
      return (lCode && mCode === lCode) || (tk && getPkgMatchKey(m) === tk);
    });
    if (!alreadyExists && getRealQuestionsCount(lPkg) > 0) {
      merged.push({
        ...lPkg,
        questions: stripDemoSampleIfUploadedPresent(lPkg.questions),
      });
    }
  }

  return merged;
}

const MAX_VIOLATION_LIMIT = 6;

const FALLBACK_EMPTY_PACKAGE: ExamPackage = {
  id: 'pkg_empty_fallback',
  code: 'MAPEL-00',
  title: 'Belum Ada Mata Pelajaran',
  level: 'SMA / MA / SMK / Sederajat',
  subtest: 'Wajib Umum',
  durationMinutes: 90,
  targetClass: 'Kelas X',
  questions: [],
};

interface StudentExamDraft {
  username: string;
  packageId: string;
  answers: Record<string, StudentAnswer>;
  remainingSeconds?: number;
  violationCount: number;
  violationUpdatedAt?: number;
  lastAppliedViolationResetAt?: number;
  updatedAt: number;
}

function getDraftKey(username: string, packageId: string): string {
  return `${username.trim().toUpperCase()}__${packageId.trim()}`;
}

function readAllStudentDrafts(): Record<string, StudentExamDraft> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DRAFTS);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function readStudentDraftFromLocal(
  username: string,
  packageId: string
): StudentExamDraft | null {
  if (!username || !packageId) return null;
  const all = readAllStudentDrafts();
  return all[getDraftKey(username, packageId)] || null;
}

function writeStudentDraftToLocal(draft: StudentExamDraft): void {
  if (!draft.username || !draft.packageId) return;
  try {
    const all = readAllStudentDrafts();
    all[getDraftKey(draft.username, draft.packageId)] = draft;
    safeSetCriticalLocalStorage(STORAGE_KEYS.DRAFTS, JSON.stringify(all));
  } catch {
    // ignore
  }
}

function clearStudentDraftInLocal(username: string, packageId: string): void {
  if (!username || !packageId) return;
  try {
    const all = readAllStudentDrafts();
    delete all[getDraftKey(username, packageId)];
    localStorage.setItem(STORAGE_KEYS.DRAFTS, JSON.stringify(all));
  } catch {
    // ignore
  }
}

function isLocalDraftViolationClearedByRow(
  draft: StudentExamDraft | null | undefined,
  row: ProctorParticipantRow | null | undefined
): boolean {
  if (!draft || !row) return false;
  const resetAt =
    typeof row.violationResetAt === 'number' ? row.violationResetAt : 0;
  if (resetAt <= 0) return false;
  const localVUpdatedAt =
    typeof draft.violationUpdatedAt === 'number'
      ? draft.violationUpdatedAt
      : typeof draft.updatedAt === 'number'
      ? draft.updatedAt
      : 0;
  if (resetAt >= localVUpdatedAt) return true;
  const lastApplied =
    typeof draft.lastAppliedViolationResetAt === 'number'
      ? draft.lastAppliedViolationResetAt
      : 0;
  return (
    resetAt > lastApplied &&
    !isParticipantLockedByViolation(row) &&
    (typeof row.violationCount !== 'number' || row.violationCount === 0)
  );
}

function syncLocalDraftViolationResetForRows(
  rows: ProctorParticipantRow[]
): void {
  if (!Array.isArray(rows) || rows.length === 0) return;
  try {
    const all = readAllStudentDrafts();
    const keys = Object.keys(all);
    if (keys.length === 0) return;

    const resetRowByUser = new Map<string, ProctorParticipantRow>();
    for (const row of rows) {
      if (
        row &&
        typeof row === 'object' &&
        typeof row.violationResetAt === 'number' &&
        row.violationResetAt > 0
      ) {
        const u = String(row.username ?? '').trim().toUpperCase();
        if (u) resetRowByUser.set(u, row);
      }
    }
    if (resetRowByUser.size === 0) return;

    let mutated = false;
    for (const key of keys) {
      const draft = all[key];
      if (!draft || typeof draft !== 'object') continue;
      const u = String(draft.username ?? '').trim().toUpperCase();
      const row = u ? resetRowByUser.get(u) : undefined;
      if (!row) continue;
      const resetAt = row.violationResetAt || 0;
      if (isLocalDraftViolationClearedByRow(draft, row)) {
        if (
          draft.violationCount !== 0 ||
          (draft.lastAppliedViolationResetAt || 0) < resetAt
        ) {
          all[key] = {
            ...draft,
            violationCount: 0,
            violationUpdatedAt: 0,
            lastAppliedViolationResetAt: resetAt,
          };
          mutated = true;
        }
      }
    }
    if (mutated) {
      localStorage.setItem(STORAGE_KEYS.DRAFTS, JSON.stringify(all));
    }
  } catch {
    // ignore
  }
}

function loadNormalizedAdminSettings(): Record<string, any> {
  const defaults: Record<string, any> = {
    tokenIntervalMenit: 10,
    enforceMinFinishTime: false,
    acakSoal: true,
    acakOpsi: true,
    wajibFullscreen: true,
    kunciKeluarSistem: true,
    tampilkanNilaiPeserta: false,
    minMinutesBeforeFinish: 45,
    pesanPelanggaran:
      'Anda terdeteksi keluar dari layar CBT! Harap lapor ke Proktor / Pengawas untuk reset login.',
    updatedAt: 0,
  };
  try {
    const raw = localStorage.getItem('cbt_admin_settings');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        const normalized: Record<string, any> = { ...defaults, ...parsed };
        if (!parsed.updatedAt && parsed.tokenIntervalMenit === 15) {
          normalized.tokenIntervalMenit = 10;
        }
        if (Array.isArray(normalized.mapelList)) {
          normalized.mapelList = normalized.mapelList.filter(
            (m: any) =>
              Boolean(m && typeof m === 'object') &&
              !isLegacyZombieSimulasi(m.nama, m)
          );
        }
        return normalized;
      }
    }
  } catch {
    // ignore
  }
  return defaults;
}

export default function App() {
  const [stage, setStage] = useState<AppStage>('login');
  const stageRef = useRef<AppStage>(stage);
  useEffect(() => {
    stageRef.current = stage;
  }, [stage]);
  const [isAuthSpinning, setIsAuthSpinning] = useState<boolean>(false);
  const authSpinTimerRef = useRef<number | null>(null);
  const [proctorSession, setProctorSession] = useState<{
    name: string;
    encryptionCode: string;
    proctorId?: string;
  }>(() => {
    try {
      const saved = localStorage.getItem('cbt_proctor_session');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed.name === 'string' && parsed.name.trim()) {
          return {
            name: parsed.name.trim().toUpperCase(),
            encryptionCode: (parsed.encryptionCode || 'GLDTKASMA').trim().toUpperCase(),
            ...(typeof parsed.proctorId === 'string' && parsed.proctorId.trim()
              ? { proctorId: parsed.proctorId.trim().toUpperCase() }
              : {}),
          };
        }
      }
    } catch {
      // ignore
    }
    return {
      name: 'DRS. H. AHMAD FAUZI, M.PD.',
      encryptionCode: 'GLDTKASMA',
    };
  });
  const [adminUsername, setAdminUsername] = useState<string>('ADMIN_SMADIP');
  const [participantSyncError, setParticipantSyncError] = useState<string>('');
  const participantSyncErrorRef = useRef<string>('');
  const updateParticipantSyncError = useCallback((msg: string) => {
    participantSyncErrorRef.current = msg;
    setParticipantSyncError(msg);
  }, []);
  const [sessionReplacedNotice, setSessionReplacedNotice] = useState<string | null>(null);

  useEffect(() => {
    return onSessionReplaced((msg) => {
      if (authSpinTimerRef.current) {
        window.clearTimeout(authSpinTimerRef.current);
        authSpinTimerRef.current = null;
      }
      if (draftSyncTimerRef.current) {
        window.clearTimeout(draftSyncTimerRef.current);
        draftSyncTimerRef.current = null;
      }
      if (submitRetryTimerRef.current) {
        window.clearTimeout(submitRetryTimerRef.current);
        submitRetryTimerRef.current = null;
      }
      if (mobileStatusBarBlurTimerRef.current) {
        window.clearTimeout(mobileStatusBarBlurTimerRef.current);
        mobileStatusBarBlurTimerRef.current = null;
      }
      hasActiveFinishMutexRef.current = false;
      setIsAuthSpinning(false);
      setLockedRunningPackage(null);
      setActiveServerDeadlineMs(undefined);
      setSessionReplacedNotice(
        msg || 'Sesi Anda dihentikan karena akun ini login di perangkat lain.'
      );
      setStage('login');
    });
  }, []);

  useEffect(() => {
    return () => {
      if (authSpinTimerRef.current) {
        window.clearTimeout(authSpinTimerRef.current);
      }
      if (draftSyncTimerRef.current) {
        window.clearTimeout(draftSyncTimerRef.current);
      }
      if (submitRetryTimerRef.current) {
        window.clearTimeout(submitRetryTimerRef.current);
      }
    };
  }, []);

  const [schedules, setSchedules] = useState<AdminScheduleItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SCHEDULES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter(
            (s: AdminScheduleItem) =>
              Boolean(s && typeof s === 'object') &&
              !isLegacyZombieSimulasi(s.mapel, s)
          );
        }
      }
      const backupRaw = localStorage.getItem(STORAGE_KEYS.SCHEDULES_BACKUP);
      if (backupRaw) {
        const backupParsed = JSON.parse(backupRaw);
        if (Array.isArray(backupParsed) && backupParsed.length > 0) {
          return backupParsed.filter(
            (s: AdminScheduleItem) =>
              Boolean(s && typeof s === 'object') &&
              !isLegacyZombieSimulasi(s.mapel, s)
          );
        }
      }
    } catch {
      // Fallback to initial schedules
    }
    return INITIAL_ADMIN_SCHEDULES;
  });

  const [participants, setParticipants] = useState<ProctorParticipantRow[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PARTICIPANTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const sanitized = sanitizeParticipantRows(parsed);
          if (!isDefaultDemoParticipantsList(sanitized)) {
            return sanitized;
          }
          // If primary storage only has the 8 demo students, check automatic backup of real uploaded students
          const backupRaw = localStorage.getItem(STORAGE_KEYS.PARTICIPANTS_BACKUP);
          if (backupRaw) {
            const backupParsed = JSON.parse(backupRaw);
            if (
              Array.isArray(backupParsed) &&
              backupParsed.length > 0 &&
              !isDefaultDemoParticipantsList(backupParsed)
            ) {
              return sanitizeParticipantRows(backupParsed);
            }
          }
          return sanitized;
        }
      }
      const backupRaw = localStorage.getItem(STORAGE_KEYS.PARTICIPANTS_BACKUP);
      if (backupRaw) {
        const backupParsed = JSON.parse(backupRaw);
        if (Array.isArray(backupParsed) && backupParsed.length > 0) {
          return sanitizeParticipantRows(backupParsed);
        }
      }
    } catch {
      // Fallback to initial participants
    }
    return sanitizeParticipantRows(INITIAL_ADMIN_PARTICIPANTS);
  });

  const [proctors, setProctors] = useState<AdminProctorItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROCTORS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback to initial proctors
    }
    return INITIAL_ADMIN_PROCTORS;
  });

  const repairLeakedBenarSalahTableQuestion = useCallback(
    (q: Question): Question => {
      if (!q || typeof q !== 'object') return q;
      const st = q.stimulusTable;
      if (!st || typeof st !== 'object') return q;
      const rawHeaders = Array.isArray(st.headers)
        ? st.headers.map((h) => String(h ?? '').replace(/\s+/g, ' ').trim())
        : [];
      const rows = Array.isArray(st.rows) ? st.rows : [];
      if (rawHeaders.length < 2 || rows.length === 0) return q;

      const lowerHeaders = rawHeaders.map((h) => h.toLowerCase());
      const isTrueHeader = (h: string) =>
        /^(?:benar|b|sesuai|ya|fakta|setuju|tepat|valid|mendukung|true)$/.test(h);
      const isFalseHeader = (h: string) =>
        /^(?:salah|s|tidak\s+sesuai|tidak|opini|tidak\s+setuju|tidak\s+tepat|tidak\s+valid|tidak\s+mendukung|false)$/.test(
          h
        );
      const benarCol = lowerHeaders.findIndex(isTrueHeader);
      const salahCol = lowerHeaders.findIndex(isFalseHeader);
      const hasTwoOptionCols = benarCol !== -1 && salahCol !== -1;

      const keyCol = !hasTwoOptionCols
        ? lowerHeaders.findIndex(
            (h) =>
              /^(?:kunci|kunci\s*jawaban|jawaban|kategori|keterangan|status|b\s*\/\s*s|bs)$/.test(
                h
              ) ||
              /benar\s*[\/\-]\s*salah|sesuai\s*[\/\-]\s*tidak\s+sesuai|ya\s*[\/\-]\s*tidak|fakta\s*[\/\-]\s*opini/.test(
                h
              )
          )
        : -1;

      const stmtColIdx = lowerHeaders.findIndex(
        (h) =>
          h.includes('pernyataan') ||
          h.includes('statement') ||
          h.includes('kalimat') ||
          h.includes('uraian') ||
          h.includes('deskripsi') ||
          h.includes('kejadian') ||
          h.includes('peristiwa')
      );

      if (
        !hasTwoOptionCols &&
        (keyCol === -1 ||
          (stmtColIdx === -1 &&
            !/benar|salah|sesuai|ya\s*\/\s*tidak|fakta\s*\/\s*opini|^b\s*\/\s*s$/i.test(
              lowerHeaders[keyCol] || ''
            )))
      ) {
        return q;
      }

      const existingStatements = Array.isArray(q.statements) ? q.statements : [];
      const shouldRepair =
        q.type === 'isian_singkat' ||
        (q.type === 'benar_salah' && existingStatements.length === 0) ||
        (q.type !== 'benar_salah' &&
          (!Array.isArray(q.options) || q.options.length === 0) &&
          (!Array.isArray(q.premises) || q.premises.length === 0));

      if (!shouldRepair) {
        if (q.type === 'benar_salah' && existingStatements.length > 0) {
          const { stimulusTable: _stripDupTable, ...cleanQ } = q;
          return cleanQ;
        }
        return q;
      }

      const effectiveStmtCol =
        stmtColIdx !== -1
          ? stmtColIdx
          : lowerHeaders[0] === 'no' ||
            lowerHeaders[0] === 'no.' ||
            lowerHeaders[0] === 'nomor'
          ? 1
          : 0;

      const strongCheckTokenRegex =
        /^(?:✓|✔|☑|✅|v|●|•|1|ya|benar|b|sesuai|fakta|setuju|tepat|valid|mendukung|true)$/i;
      const crossMarkTokenRegex = /^(?:✗|✘|x)$/i;
      const negativeTokenRegex =
        /^(?:salah|s|tidak\s*sesuai|tidak|opini|tidak\s*setuju|tidak\s*tepat|tidak\s*valid|tidak\s*mendukung|false|0|✗|✘|x)$/i;

      const statements: NonNullable<Question['statements']> = [];
      for (const r of rows) {
        if (!Array.isArray(r)) continue;
        const stmtText = String(r[effectiveStmtCol] ?? '')
          .replace(/^\d+[\.\)\-:]\s*/, '')
          .trim();
        if (!stmtText) continue;

        let isBenar = true;
        if (hasTwoOptionCols) {
          const bTxt = String(r[benarCol] ?? '').trim().toLowerCase();
          const sTxt = String(r[salahCol] ?? '').trim().toLowerCase();
          const bHasStrongCheck = strongCheckTokenRegex.test(bTxt);
          const sHasStrongCheck = strongCheckTokenRegex.test(sTxt);
          const bHasCross = crossMarkTokenRegex.test(bTxt);
          const sHasCross = crossMarkTokenRegex.test(sTxt);

          if (bHasStrongCheck && !sHasStrongCheck) {
            isBenar = true;
          } else if (sHasStrongCheck && !bHasStrongCheck) {
            isBenar = false;
          } else if (sHasCross && !bHasCross) {
            isBenar = false;
          } else if (bHasCross && !sHasCross) {
            isBenar = true;
          } else if (negativeTokenRegex.test(sTxt)) {
            isBenar = false;
          }
        } else if (keyCol !== -1) {
          const kTxt = String(r[keyCol] ?? '').trim().toLowerCase();
          if (strongCheckTokenRegex.test(kTxt)) {
            isBenar = true;
          } else if (negativeTokenRegex.test(kTxt)) {
            isBenar = false;
          } else {
            continue;
          }
        }

        statements.push({
          id: `st${statements.length + 1}`,
          statement: stmtText,
          correctValue: isBenar ? 'Benar' : 'Salah',
        });
      }

      if (statements.length === 0) return q;

      const tRaw = hasTwoOptionCols ? rawHeaders[benarCol] : '';
      const fRaw = hasTwoOptionCols ? rawHeaders[salahCol] : '';
      const trueLabel =
        tRaw && !/^b$/i.test(tRaw) ? tRaw : String(q.trueLabel || 'Benar');
      const falseLabel =
        fRaw && !/^s$/i.test(fRaw) ? fRaw : String(q.falseLabel || 'Salah');

      const cleanedQuestionText = String(q.questionText || '')
        .replace(
          /^\s*[\[\(]\s*(?:benar\s*(?:[\/\-]|\s+)\s*salah|sesuai\s*(?:[\/\-]|\s+)\s*tidak\s+sesuai|b\s*\/\s*s|bs)\s*[\]\)]\s*[:\-]?\s*/i,
          ''
        )
        .trim();

      const {
        stimulusTable: _removedTable,
        correctShortAnswers: _removedShort,
        ...restQ
      } = q;

      return {
        ...restQ,
        type: 'benar_salah',
        questionText: cleanedQuestionText || q.questionText,
        instructionText: `Tentukan ${trueLabel} atau ${falseLabel} untuk setiap pernyataan!`,
        statements,
        trueLabel,
        falseLabel,
        explanation: `Kunci ${trueLabel}/${falseLabel}: ${statements
          .map(
            (s, sIdx) =>
              `(${sIdx + 1}) ${s.correctValue === 'Benar' ? trueLabel : falseLabel}`
          )
          .join(', ')}.`,
      };
    },
    []
  );

  const filterOutSimulasiTka = useCallback(
    (list: ExamPackage[]): ExamPackage[] => {
      if (!Array.isArray(list)) return [];
      return list
        .filter(
          (pkg) =>
            pkg &&
            typeof pkg === 'object' &&
            !isLegacyZombieSimulasi(pkg.title, pkg)
        )
        .map((pkg) => ({
          ...pkg,
          title: String(pkg.title || '').replace(/^Simulasi TKA\s*-\s*/i, ''),
          questions: Array.isArray(pkg.questions)
            ? stripDemoSampleIfUploadedPresent(pkg.questions).map(
                repairLeakedBenarSalahTableQuestion
              )
            : [],
        }));
    },
    [repairLeakedBenarSalahTableQuestion]
  );

  const [packages, setPackages] = useState<ExamPackage[]>(() => {
    try {
      const { deletedCodes, deletedNames, isCustomMapelConfigured } =
        readLocalDeletedMapelSets();

      let backupList: ExamPackage[] = [];
      try {
        const backupRaw = localStorage.getItem(STORAGE_KEYS.PACKAGES_BACKUP);
        if (backupRaw) {
          const parsedBackup = JSON.parse(backupRaw);
          if (Array.isArray(parsedBackup)) {
            backupList = parsedBackup
              .filter(
                (pkg: ExamPackage) =>
                  pkg &&
                  typeof pkg === 'object' &&
                  !isLegacyZombieSimulasi(pkg.title, pkg)
              )
              .map((pkg: ExamPackage) => ({
                ...pkg,
                questions: Array.isArray(pkg.questions)
                  ? stripDemoSampleIfUploadedPresent(pkg.questions).map(
                      repairLeakedBenarSalahTableQuestion
                    )
                  : [],
              }));
          }
        }
      } catch {
        // ignore backup parse error
      }

      const saved = localStorage.getItem(STORAGE_KEYS.PACKAGES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          let list = parsed
            .filter(
              (pkg: ExamPackage) =>
                pkg &&
                typeof pkg === 'object' &&
                !isLegacyZombieSimulasi(pkg.title, pkg)
            )
            .map((pkg: ExamPackage) => ({
              ...pkg,
              title: String(pkg.title || '').replace(/^Simulasi TKA\s*-\s*/i, ''),
              questions: Array.isArray(pkg.questions)
                ? stripDemoSampleIfUploadedPresent(pkg.questions).map(
                    repairLeakedBenarSalahTableQuestion
                  )
                : [],
            }))
            .filter((pkg: ExamPackage) => {
              const pCode = String(pkg.code ?? '').trim().toUpperCase();
              const pTitle = String(pkg.title ?? '').trim().toLowerCase();
              if (pCode && deletedCodes.has(pCode)) return false;
              if (pTitle && deletedNames.has(pTitle)) return false;
              return true;
            });

          // Restore any uploaded questions from PACKAGES_BACKUP if primary was overwritten with 0 questions
          if (backupList.length > 0) {
            list = mergePackagesPreservingQuestions(list, backupList);
          }

          if (isCustomMapelConfigured || deletedCodes.size > 0 || deletedNames.size > 0) {
            return list;
          }

          if (list.length > 0) {
            // Jika belum pernah dikustomisasi dan jumlah paket kurang dari 10 (migrasi versi lama),
            // lengkapi dengan paket standar yang belum ada
            if (list.length < 10) {
              const existingCodes = new Set(
                list.map((p) => String(p.code ?? '').trim().toUpperCase())
              );
              INITIAL_EXAM_PACKAGES.forEach((initPkg) => {
                const initCode = String(initPkg.code ?? '').trim().toUpperCase();
                if (initCode && !existingCodes.has(initCode)) {
                  list.push(initPkg);
                  existingCodes.add(initCode);
                }
              });
            }
            return list;
          }
        }
      }
      if (backupList.length > 0) {
        return mergePackagesPreservingQuestions(
          INITIAL_EXAM_PACKAGES,
          backupList
        );
      }
    } catch {
      // Fallback to initial packages
    }
    return INITIAL_EXAM_PACKAGES;
  });

  const [adminSettings, setAdminSettings] = useState<Record<string, any>>(
    loadNormalizedAdminSettings
  );
  const adminSettingsRef = useRef<Record<string, any>>(adminSettings);
  useEffect(() => {
    adminSettingsRef.current = adminSettings;
  }, [adminSettings]);

  const sanitizedSchedules = useMemo(
    () => sanitizeClientSchedules(schedules, packages, adminSettings),
    [schedules, packages, adminSettings]
  );
  const activeSchedules = useMemo(
    () =>
      sanitizedSchedules.filter((s) =>
        Boolean(s && typeof s === 'object' && s.isActive)
      ),
    [sanitizedSchedules]
  );
  const isScheduleActive = activeSchedules.length > 0;

  const tokenIntervalMins = Math.min(
    60,
    Math.max(5, Number(adminSettings.tokenIntervalMenit) || 10)
  );
  const TOKEN_DURATION_SECONDS = tokenIntervalMins * 60;
  const tokenDurationSecondsRef = useRef<number>(TOKEN_DURATION_SECONDS);
  useEffect(() => {
    tokenDurationSecondsRef.current = TOKEN_DURATION_SECONDS;
  }, [TOKEN_DURATION_SECONDS]);

  const generateRandomToken = useCallback(() => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let next = '';
    for (let i = 0; i < 6; i++) {
      next += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return next;
  }, []);

  const [activeToken, setActiveToken] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.TOKEN) || DEFAULT_EXAM_TOKEN;
    } catch {
      return DEFAULT_EXAM_TOKEN;
    }
  });

  const activeTokenRef = useRef<string>(activeToken);
  useEffect(() => {
    activeTokenRef.current = activeToken;
  }, [activeToken]);

  const tokenUpdatedAtRef = useRef<number>((() => {
    try {
      const saved = Number(localStorage.getItem(STORAGE_KEYS.TOKEN_UPDATED_AT));
      return Number.isFinite(saved) && saved > 0 ? saved : 0;
    } catch {
      return 0;
    }
  })());

  const computeLocalTokenDeadlineMs = useCallback(
    (serverTokenTs: number, durationSeconds: number, allowExpired = false): number => {
      const durationMs = Math.max(60, durationSeconds) * 1000;
      if (!(serverTokenTs > 0)) {
        return Date.now() + durationMs;
      }
      const remainingMs = serverTokenTs + durationMs - getServerNow();
      if (remainingMs > 0) {
        return Date.now() + Math.min(durationMs, remainingMs);
      }
      return allowExpired ? Date.now() : Date.now() + durationMs;
    },
    []
  );

  const initialTokenEndMs = computeLocalTokenDeadlineMs(
    tokenUpdatedAtRef.current,
    TOKEN_DURATION_SECONDS
  );

  const tokenEndTimeRef = useRef<number>(initialTokenEndMs);

  const [tokenSecondsLeft, setTokenSecondsLeft] = useState<number>(() =>
    Math.max(0, Math.ceil((initialTokenEndMs - Date.now()) / 1000))
  );

  const [resultsHistory, setResultsHistory] = useState<ExamResultSummary[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HISTORY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [storageEngine, setStorageEngine] = useState<
    'vercel-kv' | 'vercel-serverless' | 'local'
  >('vercel-serverless');
  const [ephemeralStorageWarning, setEphemeralStorageWarning] =
    useState<boolean>(false);
  const [lastSyncedLabel, setLastSyncedLabel] = useState<string>(
    'Tersimpan Otomatis'
  );
  const isHydratedFromCloud = useRef(false);
  const isApplyingRemoteUpdate = useRef(false);
  const lastLocalMutationAt = useRef<number>(0);
  const lastScheduleMutationAtRef = useRef<number>(0);
  const latestUpdatedAtRef = useRef<number>(0);
  const pendingPushCount = useRef<number>(0);
  const examStartedAtRef = useRef<number>(0);
  const lastFullscreenRequestAtRef = useRef<number>(0);
  const intentionalFullscreenExitAtRef = useRef<number>(0);
  const mobileInputFocusedAtRef = useRef<number>(0);
  const mobileStatusBarBlurTimerRef = useRef<number | null>(null);
  const draftSyncTimerRef = useRef<number | null>(null);
  const lastDraftServerSyncAtRef = useRef<number>(0);
  const submitRetryTimerRef = useRef<number | null>(null);
  const inFlightSubmissionIdsRef = useRef<Set<string>>(new Set());
  const activeFinishCleanupRef = useRef<(() => void) | null>(null);
  const hasActiveFinishMutexRef = useRef<boolean>(false);
  const isSyncInFlightRef = useRef<boolean>(false);
  const syncInFlightPromiseRef = useRef<Promise<ProctorParticipantRow[]> | null>(null);
  const syncInFlightAuthRoleRef = useRef<string | null>(null);
  const lastSyncAttemptAtRef = useRef<number>(0);
  const resultsClearedAtRef = useRef<number>(0);

  const packagesRef = useRef<ExamPackage[]>(packages);
  useEffect(() => {
    packagesRef.current = packages;
  }, [packages]);

  const schedulesRef = useRef<AdminScheduleItem[]>(schedules);
  useEffect(() => {
    schedulesRef.current = schedules;
  }, [schedules]);

  const participantsRef = useRef<ProctorParticipantRow[]>(participants);
  useEffect(() => {
    participantsRef.current = participants;
  }, [participants]);

  const proctorsRef = useRef<AdminProctorItem[]>(proctors);
  useEffect(() => {
    proctorsRef.current = proctors;
  }, [proctors]);

  const resultsHistoryRef = useRef<ExamResultSummary[]>(resultsHistory);
  useEffect(() => {
    resultsHistoryRef.current = resultsHistory;
  }, [resultsHistory]);

  const markSyncedSuccess = useCallback(
    (engine: 'vercel-kv' | 'vercel-serverless' | 'local') => {
      setStorageEngine(engine);
      if (engine === 'vercel-kv') {
        setEphemeralStorageWarning(false);
      }
      setLastSyncedLabel(
        new Date().toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    },
    []
  );

  const broadcastLocalRealtimeUpdate = useCallback(
    (payload: {
      schedules?: AdminScheduleItem[];
      packages?: ExamPackage[];
      adminSettings?: Record<string, any>;
      activeToken?: string;
      tokenUpdatedAt?: number;
      deletedScheduleIds?: string[];
      deletedPackageIds?: string[];
    }) => {
      try {
        if (typeof BroadcastChannel !== 'undefined') {
          const bc = new BroadcastChannel('smadip_cbt_realtime_v1');
          bc.postMessage({
            type: 'cbt_state_updated',
            ...payload,
            timestamp: Date.now(),
          });
          bc.close();
        }
      } catch {
        // ignore
      }
    },
    []
  );

  const handleUpdateAdminSettings = useCallback(
    (nextCfg: Record<string, any>) => {
      const nowTs = Date.now();
      const stamped: Record<string, any> = {
        ...nextCfg,
        updatedAt: Math.max(Number(nextCfg.updatedAt) || 0, nowTs),
      };
      lastLocalMutationAt.current = nowTs;
      adminSettingsRef.current = stamped;
      setAdminSettings(stamped);
      try {
        localStorage.setItem('cbt_admin_settings', JSON.stringify(stamped));
      } catch {
        // ignore
      }
      broadcastLocalRealtimeUpdate({
        adminSettings: stamped,
        schedules: schedulesRef.current,
        packages: packagesRef.current,
      });
      pendingPushCount.current += 1;
      saveVercelStorage({ adminSettings: stamped })
        .then((res) => {
          if (res.ok) {
            if (typeof res.updatedAt === 'number') {
              latestUpdatedAtRef.current = Math.max(
                latestUpdatedAtRef.current,
                res.updatedAt
              );
            }
            markSyncedSuccess(res.engine);
          }
        })
        .finally(() => {
          pendingPushCount.current = Math.max(0, pendingPushCount.current - 1);
        });
    },
    [broadcastLocalRealtimeUpdate, markSyncedSuccess]
  );

  const handleUpdateToken = useCallback(
    (nextToken: string, isManualUpdate = true) => {
      const cleanToken =
        nextToken.replace(/[\s\u200B-\u200D\uFEFF]+/g, '').toUpperCase() ||
        DEFAULT_EXAM_TOKEN;
      const nowTs = Date.now();
      lastLocalMutationAt.current = nowTs;
      activeTokenRef.current = cleanToken;
      tokenUpdatedAtRef.current = nowTs;
      tokenEndTimeRef.current = nowTs + TOKEN_DURATION_SECONDS * 1000;
      setActiveToken(cleanToken);
      setTokenSecondsLeft(TOKEN_DURATION_SECONDS);
      try {
        localStorage.setItem(STORAGE_KEYS.TOKEN, cleanToken);
        localStorage.setItem(STORAGE_KEYS.TOKEN_UPDATED_AT, String(nowTs));
      } catch {
        // ignore
      }
      broadcastLocalRealtimeUpdate({
        activeToken: cleanToken,
        tokenUpdatedAt: nowTs,
      });
      pendingPushCount.current += 1;
      saveVercelStorage({
        activeToken: cleanToken,
        tokenUpdatedAt: nowTs,
        forceTokenUpdate: isManualUpdate,
      })
        .then((res) => {
          if (res.ok) {
            if (typeof res.updatedAt === 'number') {
              latestUpdatedAtRef.current = Math.max(
                latestUpdatedAtRef.current,
                res.updatedAt
              );
            }
            const serverToken =
              typeof res.data?.activeToken === 'string'
                ? res.data.activeToken
                    .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
                    .toUpperCase()
                : '';
            const serverTokenTs =
              typeof res.data?.tokenUpdatedAt === 'number'
                ? res.data.tokenUpdatedAt
                : 0;
            if (serverToken) {
              if (serverToken !== activeTokenRef.current) {
                activeTokenRef.current = serverToken;
                setActiveToken(serverToken);
              }
              if (serverTokenTs > 0) {
                tokenUpdatedAtRef.current = Math.max(
                  tokenUpdatedAtRef.current,
                  serverTokenTs
                );
                const syncedEndMs = computeLocalTokenDeadlineMs(
                  serverTokenTs,
                  TOKEN_DURATION_SECONDS
                );
                tokenEndTimeRef.current = syncedEndMs;
                setTokenSecondsLeft(
                  Math.max(0, Math.ceil((syncedEndMs - Date.now()) / 1000))
                );
              }
              try {
                localStorage.setItem(STORAGE_KEYS.TOKEN, serverToken);
                if (tokenUpdatedAtRef.current > 0) {
                  localStorage.setItem(
                    STORAGE_KEYS.TOKEN_UPDATED_AT,
                    String(tokenUpdatedAtRef.current)
                  );
                }
              } catch {
                // ignore
              }
            }
            markSyncedSuccess(res.engine);
          }
        })
        .finally(() => {
          pendingPushCount.current = Math.max(0, pendingPushCount.current - 1);
        });
    },
    [
      broadcastLocalRealtimeUpdate,
      markSyncedSuccess,
      TOKEN_DURATION_SECONDS,
      computeLocalTokenDeadlineMs,
    ]
  );

  useEffect(() => {
    if (tokenUpdatedAtRef.current > 0) {
      const nextEndMs = computeLocalTokenDeadlineMs(
        tokenUpdatedAtRef.current,
        TOKEN_DURATION_SECONDS,
        true
      );
      tokenEndTimeRef.current = nextEndMs;
      setTokenSecondsLeft(
        Math.max(0, Math.ceil((nextEndMs - Date.now()) / 1000))
      );
    }
  }, [TOKEN_DURATION_SECONDS, computeLocalTokenDeadlineMs]);

  // Automatic token countdown timer (wall-clock based, single primary authority on Admin)
  useEffect(() => {
    const tick = () => {
      const diffMs = tokenEndTimeRef.current - Date.now();
      const secsLeft = Math.max(0, Math.ceil(diffMs / 1000));
      setTokenSecondsLeft(secsLeft);

      if (isScheduleActive) {
        // Admin rotates immediately when countdown hits 0; Proctor only acts as fallback 15s later if Admin is offline
        const shouldAdminRotate =
          stage === 'admin_dashboard' && diffMs <= 0;
        const shouldProctorFallbackRotate =
          stage === 'proctor_dashboard' && diffMs <= -15_000;

        if (shouldAdminRotate || shouldProctorFallbackRotate) {
          tokenEndTimeRef.current = Date.now() + TOKEN_DURATION_SECONDS * 1000;
          setTokenSecondsLeft(TOKEN_DURATION_SECONDS);
          const next = generateRandomToken();
          handleUpdateToken(next, false);
        }
      }
    };

    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [
    generateRandomToken,
    handleUpdateToken,
    isScheduleActive,
    stage,
    TOKEN_DURATION_SECONDS,
  ]);

  const [participant, setParticipant] = useState<ParticipantProfile>({
    username: 'SA20266475',
    nik: '3273011805080002',
    fullName: 'NADIA PUTRI PRATAMA',
    schoolName: 'SMA ISLAM DIPONEGORO WAGIR',
    gender: 'Perempuan',
    birthDay: '18',
    birthMonth: '05',
    birthYear: '2008',
    selectedPackageId: '',
    enteredToken: DEFAULT_EXAM_TOKEN,
  });
  const participantRef = useRef<ParticipantProfile>(participant);
  useEffect(() => {
    participantRef.current = participant;
  }, [participant]);

  const [latestExamSummary, setLatestExamSummary] =
    useState<ExamResultSummary | null>(null);
  const [isSubmittingExamResult, setIsSubmittingExamResult] =
    useState<boolean>(false);
  const [examSubmissionStatus, setExamSubmissionStatus] = useState<
    'syncing' | 'synced' | 'offline_queued'
  >('synced');
  const [examSubmissionError, setExamSubmissionError] = useState<string | null>(
    null
  );
  const [pendingSubmissions, setPendingSubmissions] = useState<
    PendingExamSubmission[]
  >(() => readPendingExamSubmissions());
  const refreshPendingSubmissionsState = useCallback(() => {
    setPendingSubmissions(readPendingExamSubmissions());
  }, []);

  const [answers, setAnswers] = useState<Record<string, StudentAnswer>>({});
  const answersRef = useRef<Record<string, StudentAnswer>>(answers);
  useEffect(() => {
    answersRef.current = answers;
  }, [answers]);
  const [lockedRunningPackage, setLockedRunningPackage] =
    useState<ExamPackage | null>(null);
  const [examInitialRemainingSeconds, setExamInitialRemainingSeconds] =
    useState<number | undefined>(undefined);
  const [activeServerDeadlineMs, setActiveServerDeadlineMs] =
    useState<number | undefined>(undefined);
  const examRemainingSecondsRef = useRef<number | undefined>(undefined);
  const [timeUsedSeconds, setTimeUsedSeconds] = useState(0);
  const [lastViolationInfo, setLastViolationInfo] =
    useState<ViolationAlertInfo | null>(null);

  // Automatically clear lastViolationInfo when participant is unlocked via Reset Login
  useEffect(() => {
    if (!lastViolationInfo) return;
    const matched = participants.find(
      (p) =>
        String(p?.username ?? '').trim().toUpperCase() ===
        String(lastViolationInfo.username ?? '').trim().toUpperCase()
    );
    if (!matched || !isParticipantLockedByViolation(matched)) {
      setLastViolationInfo(null);
    }
  }, [participants, lastViolationInfo]);

  // Sync localStorage whenever state changes
  useEffect(() => {
    try {
      const serialized = JSON.stringify(packages);
      localStorage.setItem(STORAGE_KEYS.PACKAGES, serialized);
      if (hasAnyUploadedQuestions(packages) && serialized.length <= 1_500_000) {
        localStorage.setItem(STORAGE_KEYS.PACKAGES_BACKUP, serialized);
      } else if (serialized.length > 1_500_000) {
        localStorage.removeItem(STORAGE_KEYS.PACKAGES_BACKUP);
      }
    } catch {
      // ignore
    }
  }, [packages]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
      if (!isDefaultInactiveSchedulesList(schedules)) {
        localStorage.setItem(
          STORAGE_KEYS.SCHEDULES_BACKUP,
          JSON.stringify(schedules)
        );
      } else {
        localStorage.removeItem(STORAGE_KEYS.SCHEDULES_BACKUP);
      }
    } catch {
      // ignore
    }
  }, [schedules]);

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEYS.PARTICIPANTS,
        JSON.stringify(participants)
      );
      if (!isDefaultDemoParticipantsList(participants)) {
        localStorage.setItem(
          STORAGE_KEYS.PARTICIPANTS_BACKUP,
          JSON.stringify(participants)
        );
      }
    } catch {
      // ignore
    }
  }, [participants]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROCTORS, JSON.stringify(proctors));
    } catch {
      // ignore
    }
  }, [proctors]);

  useEffect(() => {
    try {
      localStorage.setItem('cbt_proctor_session', JSON.stringify(proctorSession));
    } catch {
      // ignore
    }
  }, [proctorSession]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TOKEN, activeToken);
    } catch {
      // ignore
    }
  }, [activeToken]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(resultsHistory));
    } catch {
      // ignore
    }
  }, [resultsHistory]);

  const handleUpdatePackages = useCallback(
    (
      updater:
        | ExamPackage[]
        | ((prevPackages: ExamPackage[]) => ExamPackage[])
    ) => {
      lastLocalMutationAt.current = Date.now();
      const prev = packagesRef.current;
      const rawNext =
        typeof updater === 'function' ? updater(prev) : updater;
      const prevByIdForTs = new Map<string, ExamPackage>();
      prev.forEach((p) => {
        if (p?.id) prevByIdForTs.set(p.id, p);
      });
      const nowPkgTs = Date.now();
      const nextPackages = filterOutSimulasiTka(rawNext).map((pkg) => {
        const prevPkg = prevByIdForTs.get(pkg.id);
        if (!prevPkg) {
          return pkg.questions.length > 0 && !pkg.questionsUpdatedAt
            ? { ...pkg, questionsUpdatedAt: nowPkgTs }
            : pkg;
        }
        const questionsChanged =
          prevPkg.questions !== pkg.questions &&
          JSON.stringify(prevPkg.questions) !== JSON.stringify(pkg.questions);
        if (questionsChanged) {
          return {
            ...pkg,
            questionsUpdatedAt: Math.max(pkg.questionsUpdatedAt || 0, nowPkgTs),
          };
        }
        return pkg;
      });
      packagesRef.current = nextPackages;
      setPackages(nextPackages);

        const nextIds = new Set(
          nextPackages.map((p) => String(p.id || '').trim().toUpperCase())
        );
        const nextCodes = new Set(
          nextPackages.map((p) => String(p.code || '').trim().toUpperCase())
        );
        const deletedPackageIds: string[] = [];
        prev.forEach((p) => {
          const pId = String(p.id || '').trim().toUpperCase();
          const pCode = String(p.code || '').trim().toUpperCase();
          if (pId && !nextIds.has(pId)) deletedPackageIds.push(pId);
          if (pCode && !nextCodes.has(pCode)) deletedPackageIds.push(pCode);
        });

        if (deletedPackageIds.length > 0) {
          addLocalDeletedIds(STORAGE_KEYS.DELETED_PACKAGES, deletedPackageIds);
        }

        // If packages were added/re-added, remove their IDs/codes from local deleted packages
        try {
          const currentDeletedSet = readLocalDeletedSet(
            STORAGE_KEYS.DELETED_PACKAGES
          );
          let removedAny = false;
          nextIds.forEach((id) => {
            if (id && currentDeletedSet.has(id)) {
              currentDeletedSet.delete(id);
              removedAny = true;
            }
          });
          nextCodes.forEach((code) => {
            if (code && currentDeletedSet.has(code)) {
              currentDeletedSet.delete(code);
              removedAny = true;
            }
          });
          if (removedAny) {
            localStorage.setItem(
              STORAGE_KEYS.DELETED_PACKAGES,
              JSON.stringify(Array.from(currentDeletedSet))
            );
          }
        } catch {
          // ignore
        }

        const prevQuestionsTotal = getTotalUploadedQuestionsCount(prev);
        const nextQuestionsTotal = getTotalUploadedQuestionsCount(nextPackages);
        const explicitDeleteOrReduce =
          deletedPackageIds.length > 0 || nextQuestionsTotal < prevQuestionsTotal;

        try {
          const serializedPackages = JSON.stringify(nextPackages);
          // Avoid exhausting the ~5 MB browser localStorage quota when packages contain embedded images
          if (serializedPackages.length > 1_500_000) {
            try {
              localStorage.removeItem(STORAGE_KEYS.PACKAGES_BACKUP);
            } catch {
              // ignore
            }
            localStorage.setItem(STORAGE_KEYS.PACKAGES, serializedPackages);
          } else {
            localStorage.setItem(STORAGE_KEYS.PACKAGES, serializedPackages);
            localStorage.setItem(
              STORAGE_KEYS.PACKAGES_BACKUP,
              serializedPackages
            );
          }
        } catch {
          // ignore localStorage quota errors; server remains source of truth
        }

        let adminSettingsSnapshot:
          | (Record<string, unknown> & { updatedAt?: number })
          | undefined;
        if (
          stageRef.current === 'admin_dashboard' ||
          stageRef.current === 'proctor_dashboard'
        ) {
          try {
            const rawCfg = localStorage.getItem('cbt_admin_settings');
            const parsedCfg = rawCfg ? JSON.parse(rawCfg) : null;
            const latestCfg =
              parsedCfg && typeof parsedCfg === 'object'
                ? parsedCfg
                : adminSettingsRef.current;
            if (latestCfg && typeof latestCfg === 'object') {
              adminSettingsSnapshot = {
                ...latestCfg,
                updatedAt:
                  typeof latestCfg.updatedAt === 'number' &&
                  latestCfg.updatedAt > 0
                    ? latestCfg.updatedAt
                    : Date.now(),
              };
            }
          } catch {
            // ignore
          }
        }

        // Immediately cascade-sanitize schedules when packages are deleted so stale subjects never remain active
        let cascadedSchedulesChanged = false;
        if (deletedPackageIds.length > 0) {
          const cascadedSchedules = sanitizeClientSchedules(
            schedulesRef.current,
            nextPackages,
            adminSettingsSnapshot || adminSettingsRef.current,
            undefined,
            deletedPackageIds
          );
          if (cascadedSchedules.length !== schedulesRef.current.length) {
            cascadedSchedulesChanged = true;
            const keptIds = new Set(cascadedSchedules.map((s) => s.id));
            const cascadedDeletedSchIds = schedulesRef.current
              .filter((s) => s?.id && !keptIds.has(s.id))
              .map((s) => s.id);
            if (cascadedDeletedSchIds.length > 0) {
              addLocalDeletedIds(
                STORAGE_KEYS.DELETED_SCHEDULES,
                cascadedDeletedSchIds
              );
            }
            schedulesRef.current = cascadedSchedules;
            setSchedules(cascadedSchedules);
          }
        }

        const allDeletedScheduleIds = Array.from(
          readLocalDeletedSet(STORAGE_KEYS.DELETED_SCHEDULES)
        );

        broadcastLocalRealtimeUpdate({
          packages: nextPackages,
          schedules: schedulesRef.current,
          adminSettings: adminSettingsSnapshot || adminSettingsRef.current,
          deletedPackageIds,
          ...(cascadedSchedulesChanged
            ? { deletedScheduleIds: allDeletedScheduleIds }
            : {}),
        });

        // Diff only modified/added packages so uploading 1 subject with images never exceeds Vercel's 4.5 MB body limit
        const prevById = new Map<string, ExamPackage>();
        prev.forEach((p) => {
          if (p?.id) prevById.set(p.id, p);
        });
        const changedPackages = nextPackages.filter((pkg) => {
          const prevPkg = prevById.get(pkg.id);
          if (!prevPkg) return true;
          if (prevPkg === pkg) return false;
          try {
            return JSON.stringify(prevPkg) !== JSON.stringify(pkg);
          } catch {
            return true;
          }
        });

        const pushPackagesToCloud = async () => {
          const MAX_SAFE_CHUNK_BYTES = 3_000_000;
          const MAX_SINGLE_PKG_BYTES = 2_000_000;
          const usePatchMode =
            changedPackages.length > 0 &&
            changedPackages.length < nextPackages.length;
          const itemsToSend = usePatchMode ? changedPackages : nextPackages;

          const sendSinglePackageWithChunking = async (
            pkgItem: ExamPackage,
            includeTopMetadata: boolean
          ) => {
            let pkgApproxBytes = 0;
            try {
              pkgApproxBytes = JSON.stringify(pkgItem).length;
            } catch {
              pkgApproxBytes = 0;
            }

            if (
              pkgApproxBytes > MAX_SAFE_CHUNK_BYTES &&
              Array.isArray(pkgItem.questions) &&
              pkgItem.questions.length > 1
            ) {
              const questionChunks: Question[][] = [];
              let currentChunk: Question[] = [];
              let currentChunkBytes = 2048;
              for (const q of pkgItem.questions) {
                let qBytes = 1024;
                try {
                  qBytes = JSON.stringify(q).length;
                } catch {
                  qBytes = 1024;
                }
                if (
                  currentChunk.length > 0 &&
                  currentChunkBytes + qBytes > MAX_SINGLE_PKG_BYTES
                ) {
                  questionChunks.push(currentChunk);
                  currentChunk = [q];
                  currentChunkBytes = 2048 + qBytes;
                } else {
                  currentChunk.push(q);
                  currentChunkBytes += qBytes;
                }
              }
              if (currentChunk.length > 0) {
                questionChunks.push(currentChunk);
              }

              if (questionChunks.length > 1) {
                let lastRes = await saveVercelStorage({
                  packagePatch: [{ ...pkgItem, questions: questionChunks[0] }],
                  ...(includeTopMetadata && deletedPackageIds.length > 0
                    ? { deletedPackageIds }
                    : {}),
                  forceReplacePackages: explicitDeleteOrReduce,
                  ...(includeTopMetadata && adminSettingsSnapshot
                    ? { adminSettings: adminSettingsSnapshot }
                    : {}),
                });
                if (!lastRes.ok) {
                  return lastRes;
                }
                for (let cIdx = 1; cIdx < questionChunks.length; cIdx++) {
                  lastRes = await saveVercelStorage({
                    packageQuestionAppend: {
                      packageId: pkgItem.id,
                      questions: questionChunks[cIdx],
                      questionsUpdatedAt: pkgItem.questionsUpdatedAt,
                    },
                  });
                  if (!lastRes.ok) {
                    return lastRes;
                  }
                }
                return lastRes;
              }
            }

            return saveVercelStorage({
              packagePatch: [pkgItem],
              ...(includeTopMetadata && deletedPackageIds.length > 0
                ? { deletedPackageIds }
                : {}),
              forceReplacePackages: explicitDeleteOrReduce,
              ...(includeTopMetadata && adminSettingsSnapshot
                ? { adminSettings: adminSettingsSnapshot }
                : {}),
            });
          };

          let totalApproxBytes = 0;
          try {
            totalApproxBytes = JSON.stringify(itemsToSend).length;
          } catch {
            totalApproxBytes = 0;
          }

          if (totalApproxBytes > MAX_SAFE_CHUNK_BYTES && itemsToSend.length > 0) {
            let lastRes: Awaited<ReturnType<typeof saveVercelStorage>> | null =
              null;
            for (let i = 0; i < itemsToSend.length; i++) {
              const isFirst = i === 0;
              lastRes = await sendSinglePackageWithChunking(
                itemsToSend[i],
                isFirst
              );
              if (!lastRes.ok) {
                if (lastRes.error) {
                  console.warn('[CBT Packages Sync]', lastRes.error);
                }
                break;
              }
            }
            return lastRes;
          }

          return saveVercelStorage({
            ...(usePatchMode
              ? { packagePatch: changedPackages }
              : { packages: nextPackages }),
            deletedPackageIds,
            forceReplacePackages: explicitDeleteOrReduce,
            ...(adminSettingsSnapshot
              ? { adminSettings: adminSettingsSnapshot }
              : {}),
            ...(cascadedSchedulesChanged || deletedPackageIds.length > 0
              ? {
                  schedules: schedulesRef.current,
                  deletedScheduleIds: allDeletedScheduleIds,
                  forceReplaceSchedules: true,
                }
              : {}),
          });
        };

        pendingPushCount.current += 1;
        pushPackagesToCloud()
          .then((res) => {
            if (res?.ok) {
              setParticipantSyncError('');
              if (typeof res.updatedAt === 'number') {
                latestUpdatedAtRef.current = Math.max(
                  latestUpdatedAtRef.current,
                  res.updatedAt
                );
              }
              markSyncedSuccess(res.engine);
            } else {
              const errDetail =
                res?.status === 401
                  ? 'Sesi login Administrator/Proktor telah berakhir di server (401). Silakan keluar lalu login kembali agar perubahan Bank Soal tersimpan ke server.'
                  : res?.error ||
                    `Gagal menyimpan Bank Soal ke server (Kode ${res?.status || 'jaringan'}). Periksa ukuran gambar/koneksi lalu coba unggah atau simpan ulang.`;
              setParticipantSyncError(errDetail);
              console.warn('[CBT Packages Sync]', res?.status, errDetail);
            }
          })
          .finally(() => {
            pendingPushCount.current = Math.max(
              0,
              pendingPushCount.current - 1
            );
          });
    },
    [broadcastLocalRealtimeUpdate, filterOutSimulasiTka, markSyncedSuccess]
  );

  const handleUpdateParticipants = useCallback(
    (
      updater:
        | ProctorParticipantRow[]
        | ((prevRows: ProctorParticipantRow[]) => ProctorParticipantRow[]),
      syncOptions?: {
        overrideToken?: string | null;
        keepalive?: boolean;
        retryDelaysMs?: number[];
      }
    ) => {
      const nowTs = Date.now();
      const prev = participantsRef.current;
      const rawNext =
        typeof updater === 'function' ? updater(prev) : updater;

        const prevByUser = new Map<string, ProctorParticipantRow>();
        const prevById = new Map<string, ProctorParticipantRow>();
        prev.forEach((p) => {
          if (!p || typeof p !== 'object') return;
          const uKey = String(p.username ?? '').trim().toUpperCase();
          if (uKey) prevByUser.set(uKey, p);
          if (p.id) prevById.set(p.id, p);
        });

        let hasAnyRealFieldOrRowChange = rawNext.length !== prev.length;

        // Stamp monotonic CRDT timestamps on any modified fields so concurrent polls never revert changes
        const stampedNext = rawNext.map((row) => {
          const prevRow =
            prevById.get(row.id) ||
            prevByUser.get(String(row?.username ?? '').trim().toUpperCase());
          if (!prevRow) {
            hasAnyRealFieldOrRowChange = true;
            return {
              ...row,
              metaUpdatedAt: row.metaUpdatedAt || nowTs,
            };
          }
          const metaChanged =
            prevRow.status !== row.status ||
            prevRow.ruang !== row.ruang ||
            prevRow.kelompok !== row.kelompok ||
            prevRow.kelas !== row.kelas ||
            prevRow.namaPeserta !== row.namaPeserta ||
            (typeof row.metaUpdatedAt === 'number' &&
              row.metaUpdatedAt > (prevRow.metaUpdatedAt || 0));
          const loginChanged =
            prevRow.loginState !== row.loginState ||
            Boolean(prevRow.requestReset) !== Boolean(row.requestReset) ||
            prevRow.violationTimestamp !== row.violationTimestamp ||
            prevRow.violationCount !== row.violationCount ||
            prevRow.violationResetAt !== row.violationResetAt ||
            prevRow.lastResetAt !== row.lastResetAt ||
            prevRow.resetPackageId !== row.resetPackageId ||
            prevRow.resetSubjectTitle !== row.resetSubjectTitle;
          const draftChanged =
            prevRow.draftAnswers !== row.draftAnswers ||
            prevRow.draftPackageId !== row.draftPackageId ||
            prevRow.draftRemainingSeconds !== row.draftRemainingSeconds;

          if (metaChanged || loginChanged || draftChanged) {
            hasAnyRealFieldOrRowChange = true;
          }

          return {
            ...row,
            ...(metaChanged
              ? {
                  metaUpdatedAt: Math.max(
                    (prevRow.metaUpdatedAt || 0) + 1,
                    row.metaUpdatedAt || 0,
                    nowTs
                  ),
                }
              : {}),
            ...(loginChanged
              ? {
                  loginUpdatedAt: Math.max(
                    (prevRow.loginUpdatedAt || 0) + 1,
                    row.loginUpdatedAt || 0,
                    nowTs
                  ),
                }
              : {}),
            ...(draftChanged
              ? {
                  draftUpdatedAt: Math.max(
                    (prevRow.draftUpdatedAt || 0) + 1,
                    row.draftUpdatedAt || 0,
                    nowTs
                  ),
                }
              : {}),
          };
        });

        const nextParticipants = sanitizeParticipantRows(stampedNext);
        participantsRef.current = nextParticipants;
        setParticipants(nextParticipants);
        syncLocalDraftViolationResetForRows(nextParticipants);

        // If ONLY UI checkbox `selected` state changed, keep it purely local without flooding /api/storage
        if (!hasAnyRealFieldOrRowChange) {
          return;
        }

        lastLocalMutationAt.current = nowTs;
        try {
          localStorage.setItem(
            STORAGE_KEYS.PARTICIPANTS,
            JSON.stringify(nextParticipants)
          );
          if (!isDefaultDemoParticipantsList(nextParticipants)) {
            localStorage.setItem(
              STORAGE_KEYS.PARTICIPANTS_BACKUP,
              JSON.stringify(nextParticipants)
            );
          }
        } catch {
          // ignore
        }

        const isAdminOrProctor =
          stageRef.current === 'admin_dashboard' ||
          stageRef.current === 'proctor_dashboard';

        const changedPatches = nextParticipants
          .filter((row) => {
            const prevRow =
              prevById.get(row.id) ||
              prevByUser.get(String(row?.username ?? '').trim().toUpperCase());
            if (!prevRow) return true;
            return (
              prevRow.loginState !== row.loginState ||
              prevRow.requestReset !== row.requestReset ||
              prevRow.violationReason !== row.violationReason ||
              prevRow.violationTimestamp !== row.violationTimestamp ||
              prevRow.violationCount !== row.violationCount ||
              prevRow.violationPackageId !== row.violationPackageId ||
              prevRow.violationResetAt !== row.violationResetAt ||
              prevRow.lastResetAt !== row.lastResetAt ||
              prevRow.resetPackageId !== row.resetPackageId ||
              prevRow.resetSubjectTitle !== row.resetSubjectTitle ||
              prevRow.draftAnswers !== row.draftAnswers ||
              prevRow.draftPackageId !== row.draftPackageId ||
              prevRow.draftRemainingSeconds !== row.draftRemainingSeconds ||
              prevRow.status !== row.status ||
              prevRow.ruang !== row.ruang ||
              prevRow.kelompok !== row.kelompok ||
              prevRow.kelas !== row.kelas ||
              prevRow.namaPeserta !== row.namaPeserta ||
              (typeof row.metaUpdatedAt === 'number' &&
                row.metaUpdatedAt > (prevRow.metaUpdatedAt || 0))
            );
          })
          .map((row) => ({
            id: row.id,
            username: String(row.username ?? '').trim().toUpperCase(),
            namaPeserta: row.namaPeserta,
            kelas: row.kelas,
            kelompok: row.kelompok,
            ruang: row.ruang,
            kodeTes: row.kodeTes,
            status: row.status,
            loginState: row.loginState,
            requestReset: Boolean(row.requestReset),
            violationReason: (row.violationReason ?? null) as any,
            violationAt: (row.violationAt ?? null) as any,
            violationSchema: (row.violationSchema ?? null) as any,
            violationTimestamp: (row.violationTimestamp ?? null) as any,
            violationCount: row.violationCount ?? 0,
            violationPackageId: (row.violationPackageId ?? null) as any,
            draftAnswers: (row.draftAnswers ?? null) as any,
            draftPackageId: (row.draftPackageId ?? null) as any,
            draftRemainingSeconds: (row.draftRemainingSeconds ?? null) as any,
            lastResetAt: row.lastResetAt,
            resetPackageId: (row.resetPackageId ?? null) as any,
            resetSubjectTitle: (row.resetSubjectTitle ?? null) as any,
            violationResetAt: row.violationResetAt,
            loginUpdatedAt: row.loginUpdatedAt,
            metaUpdatedAt: row.metaUpdatedAt,
            draftUpdatedAt: row.draftUpdatedAt,
          }));

        if (!isAdminOrProctor) {
          // Student-side mutation: NEVER push the full participants array from a student browser.
          if (changedPatches.length > 0) {
            const capturedToken =
              syncOptions?.overrideToken ?? getAuthSessionToken();
            const useKeepalive = Boolean(syncOptions?.keepalive);
            const retryDelays =
              syncOptions?.retryDelaysMs && syncOptions.retryDelaysMs.length > 0
                ? syncOptions.retryDelaysMs
                : [1500];

            const dispatchStudentPatchWithRetry = async () => {
              let lastRes = await saveVercelStorage(
                { participantPatch: changedPatches },
                { overrideToken: capturedToken, keepalive: useKeepalive }
              );
              if (lastRes.ok || lastRes.status === 401 || lastRes.status === 403) {
                return lastRes;
              }

              // Wait for either the backoff delay OR device returning online/foreground
              const waitRetryTrigger = (delayMs: number) =>
                new Promise<void>((resolve) => {
                  let settled = false;
                  const done = () => {
                    if (settled) return;
                    settled = true;
                    window.clearTimeout(timerId);
                    window.removeEventListener('online', done);
                    document.removeEventListener('visibilitychange', onVis);
                    resolve();
                  };
                  const onVis = () => {
                    if (document.visibilityState === 'visible') done();
                  };
                  const timerId = window.setTimeout(done, delayMs);
                  window.addEventListener('online', done);
                  document.addEventListener('visibilitychange', onVis);
                });

              for (const delayMs of retryDelays) {
                await waitRetryTrigger(delayMs);
                lastRes = await saveVercelStorage(
                  { participantPatch: changedPatches },
                  { overrideToken: capturedToken, keepalive: useKeepalive }
                );
                if (
                  lastRes.ok ||
                  lastRes.status === 401 ||
                  lastRes.status === 403
                ) {
                  return lastRes;
                }
              }
              return lastRes;
            };

            pendingPushCount.current += 1;
            dispatchStudentPatchWithRetry()
              .then((res) => {
                if (res.ok) {
                  if (typeof res.updatedAt === 'number') {
                    latestUpdatedAtRef.current = Math.max(
                      latestUpdatedAtRef.current,
                      res.updatedAt
                    );
                  }
                  markSyncedSuccess(res.engine);
                }
              })
              .finally(() => {
                pendingPushCount.current = Math.max(
                  0,
                  pendingPushCount.current - 1
                );
              });
          }
          return;
        }

        // Admin / Proctor mutation: block pushing 8 demo rows if initial cloud hydration hasn't completed
        if (
          !isHydratedFromCloud.current &&
          isDefaultDemoParticipantsList(nextParticipants)
        ) {
          return;
        }

        const nextIdSet = new Set(nextParticipants.map((p) => p.id));
        const newlyDeletedIds = prev
          .filter((p) => !nextIdSet.has(p.id))
          .map((p) => p.id);
        const deletedParticipantIds = addLocalDeletedIds(
          STORAGE_KEYS.DELETED_PARTICIPANTS,
          newlyDeletedIds
        );

        // If no rows were added/deleted, always use atomic delta participantPatch (supports 1 to 500+ rows)
        // so bulk Assign/Unassign/Reset Login never overwrite concurrent student drafts/finishes or hit full-array conflicts
        const hasAddedRow = nextParticipants.some(
          (p) =>
            !prevById.has(p.id) &&
            !prevByUser.has(String(p?.username ?? '').trim().toUpperCase())
        );

        pendingPushCount.current += 1;
        const payloadToSave =
          newlyDeletedIds.length === 0 &&
          !hasAddedRow &&
          changedPatches.length > 0
            ? { participantPatch: changedPatches }
            : {
                participants: nextParticipants,
                deletedParticipantIds,
                forceReplaceParticipants: true,
              };

        const dispatchAdminParticipantSave = async () => {
          const firstRes = await saveVercelStorage(payloadToSave);
          if (firstRes.ok) {
            return firstRes;
          }
          // Retry once after brief delay on transient network/serverless failure
          if (firstRes.status !== 401 && firstRes.status !== 403) {
            await new Promise((resolve) => window.setTimeout(resolve, 1500));
            return saveVercelStorage(payloadToSave);
          }
          return firstRes;
        };

        const patchedStatusUserSet = new Set(
          changedPatches
            .filter((p) => typeof p.status === 'string' && p.status.trim() !== '')
            .map((p) => String(p.username || '').trim().toUpperCase())
            .filter(Boolean)
        );
        const dispatchTimestamp = nowTs;

        dispatchAdminParticipantSave()
          .then((res) => {
            if (res.ok) {
              updateParticipantSyncError('');
              if (typeof res.updatedAt === 'number') {
                latestUpdatedAtRef.current = Math.max(
                  latestUpdatedAtRef.current,
                  res.updatedAt
                );
                if (
                  patchedStatusUserSet.size > 0 &&
                  lastLocalMutationAt.current <= dispatchTimestamp
                ) {
                  const stampedSrvParticipants = participantsRef.current.map(
                    (row) => {
                      const u = String(row?.username ?? '').trim().toUpperCase();
                      return patchedStatusUserSet.has(u)
                        ? {
                            ...row,
                            serverStatusUpdatedAt: Math.max(
                              row.serverStatusUpdatedAt || 0,
                              res.updatedAt!
                            ),
                          }
                        : row;
                    }
                  );
                  participantsRef.current = stampedSrvParticipants;
                  setParticipants(stampedSrvParticipants);
                }
              }
              markSyncedSuccess(res.engine);
            } else {
              const errDetail =
                res.status === 401 || res.status === 403
                  ? 'Sesi login Administrator/Proktor telah berakhir di server (401). Perubahan status dibatalkan — silakan klik Keluar lalu login kembali, kemudian ubah status di Kelompok Tes lagi.'
                  : res.error ||
                    `Gagal menyimpan perubahan status peserta ke server (Kode ${res.status || 'jaringan'}). Periksa koneksi lalu klik Assign/Unassign ulang.`;
              updateParticipantSyncError(errDetail);
              console.warn('[CBT Participants Sync]', res.status, errDetail);
              if (
                (res.status === 401 || res.status === 403) &&
                lastLocalMutationAt.current <= dispatchTimestamp
              ) {
                // Revert rejected optimistic local status so Kelompok Tes never shows unpersisted Non Active/Active
                participantsRef.current = prev;
                setParticipants(prev);
                try {
                  localStorage.setItem(
                    STORAGE_KEYS.PARTICIPANTS,
                    JSON.stringify(prev)
                  );
                } catch {
                  // ignore
                }
              }
            }
          })
          .finally(() => {
            pendingPushCount.current = Math.max(
              0,
              pendingPushCount.current - 1
            );
          });
    },
    [markSyncedSuccess, updateParticipantSyncError]
  );

  const handleUpdateSchedules = useCallback(
    (
      updater:
        | AdminScheduleItem[]
        | ((prevSchedules: AdminScheduleItem[]) => AdminScheduleItem[])
    ) => {
      const localNow = Date.now();
      const nowTs = Math.max(localNow, getServerNow());
      lastLocalMutationAt.current = localNow;
      lastScheduleMutationAtRef.current = localNow;
      const prev = schedulesRef.current;
      const rawNext =
        typeof updater === 'function' ? updater(prev) : updater;
      const prevById = new Map<string, AdminScheduleItem>();
      prev.forEach((s) => prevById.set(s.id, s));

      const hasDeletedAny = rawNext.length < prev.length;
      const nextSchedules = rawNext.map((s) => {
        const prevItem = prevById.get(s.id);
        if (
          hasDeletedAny ||
          !prevItem ||
          prevItem.isActive !== s.isActive ||
          prevItem.mapel !== s.mapel ||
          prevItem.kelas !== s.kelas ||
          prevItem.hariTanggal !== s.hariTanggal ||
          prevItem.waktuMulai !== s.waktuMulai ||
          prevItem.durasi !== s.durasi
        ) {
          return {
            ...s,
            updatedAt: Math.max((s.updatedAt || 0) + 1, nowTs),
          };
        }
        return s;
      });

      schedulesRef.current = nextSchedules;
      setSchedules(nextSchedules);

      const nextIdSet = new Set(nextSchedules.map((s) => s.id));
      const newlyDeletedIds = prev
        .filter((s) => !nextIdSet.has(s.id))
        .map((s) => s.id);
      const deletedScheduleIds = addLocalDeletedIds(
        STORAGE_KEYS.DELETED_SCHEDULES,
        newlyDeletedIds
      );

      try {
        localStorage.setItem(
          STORAGE_KEYS.SCHEDULES,
          JSON.stringify(nextSchedules)
        );
        if (!isDefaultInactiveSchedulesList(nextSchedules)) {
          localStorage.setItem(
            STORAGE_KEYS.SCHEDULES_BACKUP,
            JSON.stringify(nextSchedules)
          );
        } else {
          localStorage.removeItem(STORAGE_KEYS.SCHEDULES_BACKUP);
        }
      } catch {
        // ignore
      }
      broadcastLocalRealtimeUpdate({
        schedules: nextSchedules,
        deletedScheduleIds,
        packages: packagesRef.current,
        adminSettings: adminSettingsRef.current,
        activeToken: activeTokenRef.current,
        tokenUpdatedAt: tokenUpdatedAtRef.current,
      });
      const hasAnyActiveSchedule = nextSchedules.some((s) => s.isActive);
      const schedulePayload = {
        schedules: nextSchedules,
        deletedScheduleIds,
        forceReplaceSchedules: true,
        schedulesUpdatedAt: nowTs,
        ...(hasAnyActiveSchedule && activeTokenRef.current
          ? {
              activeToken: activeTokenRef.current,
              tokenUpdatedAt: tokenUpdatedAtRef.current || nowTs,
              forceTokenUpdate: false,
            }
          : {}),
      };

      const dispatchScheduleSave = async () => {
        const firstRes = await saveVercelStorage(schedulePayload);
        if (firstRes.ok) return firstRes;
        if (firstRes.status !== 401 && firstRes.status !== 403) {
          await new Promise((resolve) => window.setTimeout(resolve, 1500));
          return saveVercelStorage(schedulePayload);
        }
        return firstRes;
      };

      pendingPushCount.current += 1;
      dispatchScheduleSave()
        .then((res) => {
          if (res.ok) {
            updateParticipantSyncError('');
            if (typeof res.updatedAt === 'number') {
              latestUpdatedAtRef.current = Math.max(
                latestUpdatedAtRef.current,
                res.updatedAt
              );
            }
            if (Array.isArray(res.data?.schedules)) {
              const authoritativeSchs = res.data.schedules.filter((s) =>
                Boolean(s && typeof s === 'object')
              );
              schedulesRef.current = authoritativeSchs;
              setSchedules(authoritativeSchs);
              try {
                localStorage.setItem(
                  STORAGE_KEYS.SCHEDULES,
                  JSON.stringify(authoritativeSchs)
                );
                if (!isDefaultInactiveSchedulesList(authoritativeSchs)) {
                  localStorage.setItem(
                    STORAGE_KEYS.SCHEDULES_BACKUP,
                    JSON.stringify(authoritativeSchs)
                  );
                } else {
                  localStorage.removeItem(STORAGE_KEYS.SCHEDULES_BACKUP);
                }
              } catch {
                // ignore
              }
            }
            const serverToken =
              typeof res.data?.activeToken === 'string'
                ? res.data.activeToken
                    .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
                    .toUpperCase()
                : '';
            const serverTokenTs =
              typeof res.data?.tokenUpdatedAt === 'number'
                ? res.data.tokenUpdatedAt
                : 0;
            if (serverToken) {
              if (serverToken !== activeTokenRef.current) {
                activeTokenRef.current = serverToken;
                setActiveToken(serverToken);
              }
              if (serverTokenTs > 0) {
                tokenUpdatedAtRef.current = Math.max(
                  tokenUpdatedAtRef.current,
                  serverTokenTs
                );
              }
              try {
                localStorage.setItem(STORAGE_KEYS.TOKEN, serverToken);
                if (tokenUpdatedAtRef.current > 0) {
                  localStorage.setItem(
                    STORAGE_KEYS.TOKEN_UPDATED_AT,
                    String(tokenUpdatedAtRef.current)
                  );
                }
              } catch {
                // ignore
              }
            }
            markSyncedSuccess(res.engine);
          } else {
            if (res.status === 401 || res.status === 403) {
              schedulesRef.current = prev;
              setSchedules(prev);
              try {
                localStorage.setItem(
                  STORAGE_KEYS.SCHEDULES,
                  JSON.stringify(prev)
                );
              } catch {
                // ignore
              }
            }
            const errDetail =
              res.status === 401
                ? 'Sesi login Administrator telah berakhir di server (401). Silakan keluar lalu login kembali, kemudian ubah ulang status jadwal ujian.'
                : res.error ||
                  `Gagal menyimpan perubahan jadwal ujian ke server (Kode ${res.status || 'jaringan'}). Periksa koneksi lalu ulangi tindakan Anda.`;
            updateParticipantSyncError(errDetail);
            console.warn('[CBT Schedules Sync]', res.status, errDetail);
          }
        })
        .finally(() => {
          pendingPushCount.current = Math.max(
            0,
            pendingPushCount.current - 1
          );
        });
    },
    [
      broadcastLocalRealtimeUpdate,
      markSyncedSuccess,
      updateParticipantSyncError,
    ]
  );

  const handleUpdateProctors = useCallback(
    (
      updater:
        | AdminProctorItem[]
        | ((prevProctors: AdminProctorItem[]) => AdminProctorItem[])
    ) => {
      lastLocalMutationAt.current = Date.now();
      const prev = proctorsRef.current;
      const nextProctors =
        typeof updater === 'function' ? updater(prev) : updater;
      proctorsRef.current = nextProctors;
      setProctors(nextProctors);
      try {
        localStorage.setItem(
          STORAGE_KEYS.PROCTORS,
          JSON.stringify(nextProctors)
        );
      } catch {
        // ignore
      }
      pendingPushCount.current += 1;
      saveVercelStorage({
        proctors: nextProctors,
      })
        .then((res) => {
          if (res.ok) {
            if (typeof res.updatedAt === 'number') {
              latestUpdatedAtRef.current = Math.max(
                latestUpdatedAtRef.current,
                res.updatedAt
              );
            }
            markSyncedSuccess(res.engine);
          }
        })
        .finally(() => {
          pendingPushCount.current = Math.max(
            0,
            pendingPushCount.current - 1
          );
        });
    },
    [markSyncedSuccess]
  );

  const handleUpdateResultsHistory = useCallback(
    (
      updater:
        | ExamResultSummary[]
        | ((prevHistory: ExamResultSummary[]) => ExamResultSummary[])
    ) => {
      const nowTs = Date.now();
      lastLocalMutationAt.current = nowTs;
      const prev = resultsHistoryRef.current;
      const nextHistory =
        typeof updater === 'function' ? updater(prev) : updater;
      resultsHistoryRef.current = nextHistory;
      setResultsHistory(nextHistory);
      const isExplicitClear = nextHistory.length === 0;
      if (isExplicitClear) {
        resultsClearedAtRef.current = nowTs;
      }
      try {
        localStorage.setItem(
          STORAGE_KEYS.HISTORY,
          JSON.stringify(nextHistory)
        );
      } catch {
        // ignore
      }
      pendingPushCount.current += 1;
      saveVercelStorage(
        isExplicitClear
          ? { resultsHistory: [], resultsClearedAt: nowTs }
          : { resultsHistory: nextHistory }
      )
        .then((res) => {
          if (res.ok) {
            if (typeof res.updatedAt === 'number') {
              latestUpdatedAtRef.current = Math.max(
                latestUpdatedAtRef.current,
                res.updatedAt
              );
            }
            markSyncedSuccess(res.engine);
          }
        })
        .finally(() => {
          pendingPushCount.current = Math.max(
            0,
            pendingPushCount.current - 1
          );
        });
    },
    [markSyncedSuccess]
  );

  // Initial Hydration & Background Polling from Vercel Storage (/api/storage)
  // Uses conflict-free per-entity timestamp resolution so multi-instance serverless split-brain
  // or 131 concurrent students never cause schedules or reset requests to flicker.
  const syncFromVercelCloud = useCallback(
    async (options?: { force?: boolean }): Promise<ProctorParticipantRow[]> => {
      const isForced = Boolean(options?.force);
      const currentAuthRole = getAuthSessionRole();
      if (isSyncInFlightRef.current && syncInFlightPromiseRef.current) {
        if (!isForced) {
          return participantsRef.current;
        }
        // Only coalesce if the in-flight sync has the same auth role; never reuse an unauthenticated sync after login
        if (syncInFlightAuthRoleRef.current === currentAuthRole) {
          return syncInFlightPromiseRef.current;
        }
      }
      const isStudentStage =
        stageRef.current === 'confirm_participant' ||
        stageRef.current === 'confirm_test' ||
        stageRef.current === 'login';
      if (
        !isForced &&
        !isStudentStage &&
        (pendingPushCount.current > 0 ||
          Date.now() - lastLocalMutationAt.current < 2500)
      ) {
        return participantsRef.current;
      }

      isSyncInFlightRef.current = true;
      syncInFlightAuthRoleRef.current = currentAuthRole;
      lastSyncAttemptAtRef.current = Date.now();
      const fetchStartedAt = Date.now();

      const runSync = async (): Promise<ProctorParticipantRow[]> => {
      try {
        const res = await fetchVercelStorage({
          since:
            !isForced && isHydratedFromCloud.current
              ? latestUpdatedAtRef.current
              : undefined,
          force: isForced,
        });
        if (!res.ok) return participantsRef.current;
        if (
          !isForced &&
          !isStudentStage &&
          (pendingPushCount.current > 0 ||
            lastLocalMutationAt.current >= fetchStartedAt ||
            Date.now() - lastLocalMutationAt.current < 2500)
        ) {
          return participantsRef.current;
        }
        setStorageEngine(res.engine);
        setEphemeralStorageWarning(
          Boolean(res.ephemeralStorageWarning && res.engine !== 'vercel-kv')
        );

        if (res.unchanged) {
          setLastSyncedLabel(
            new Date().toLocaleTimeString('id-ID', {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
            })
          );
          isHydratedFromCloud.current = true;
          return participantsRef.current;
        }

        const authRole = getAuthSessionRole();
        const isAdminStage =
          stageRef.current === 'admin_dashboard' || authRole === 'admin';
        const isAdminOrProctorStage =
          isAdminStage ||
          stageRef.current === 'proctor_dashboard' ||
          authRole === 'proctor';

        if (res.data) {
          const serverUpdatedAt =
            typeof res.data.updatedAt === 'number'
              ? res.data.updatedAt
              : typeof res.updatedAt === 'number'
              ? res.updatedAt
              : 0;
          if (serverUpdatedAt > 0) {
            latestUpdatedAtRef.current = Math.max(
              latestUpdatedAtRef.current,
              serverUpdatedAt
            );
          }

          if (Array.isArray(res.data.deletedScheduleIds)) {
            addLocalDeletedIds(
              STORAGE_KEYS.DELETED_SCHEDULES,
              res.data.deletedScheduleIds
            );
          }
          if (Array.isArray(res.data.deletedPackageIds)) {
            addLocalDeletedIds(
              STORAGE_KEYS.DELETED_PACKAGES,
              res.data.deletedPackageIds.map((id) =>
                String(id || '').trim().toUpperCase()
              )
            );
          }
          if (Array.isArray(res.data.deletedParticipantIds)) {
            addLocalDeletedIds(
              STORAGE_KEYS.DELETED_PARTICIPANTS,
              res.data.deletedParticipantIds
            );
          }

          // 1. Token CRDT reconciliation by tokenUpdatedAt (preserving remaining window & ensuring server always holds activeToken)
          const remoteTokenClean =
            typeof res.data.activeToken === 'string'
              ? res.data.activeToken
                  .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
                  .toUpperCase()
              : '';
          const remoteTokenTs =
            typeof res.data.tokenUpdatedAt === 'number'
              ? res.data.tokenUpdatedAt
              : 0;
          if (remoteTokenClean) {
            if (remoteTokenClean !== activeTokenRef.current) {
              if (
                remoteTokenTs >= tokenUpdatedAtRef.current ||
                tokenUpdatedAtRef.current === 0 ||
                !isAdminOrProctorStage
              ) {
                activeTokenRef.current = remoteTokenClean;
                tokenUpdatedAtRef.current = Math.max(
                  tokenUpdatedAtRef.current,
                  remoteTokenTs
                );
                const syncedEndMs = computeLocalTokenDeadlineMs(
                  remoteTokenTs,
                  tokenDurationSecondsRef.current
                );
                tokenEndTimeRef.current = syncedEndMs;
                setActiveToken(remoteTokenClean);
                setTokenSecondsLeft(
                  Math.max(0, Math.ceil((syncedEndMs - Date.now()) / 1000))
                );
                try {
                  localStorage.setItem(STORAGE_KEYS.TOKEN, remoteTokenClean);
                  if (remoteTokenTs > 0) {
                    localStorage.setItem(
                      STORAGE_KEYS.TOKEN_UPDATED_AT,
                      String(remoteTokenTs)
                    );
                  }
                } catch {
                  // ignore
                }
              } else if (isAdminOrProctorStage) {
                saveVercelStorage({
                  activeToken: activeTokenRef.current,
                  tokenUpdatedAt: tokenUpdatedAtRef.current,
                  forceTokenUpdate: false,
                }).then((saveRes) => {
                  const authServerToken =
                    typeof saveRes.data?.activeToken === 'string'
                      ? saveRes.data.activeToken
                          .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
                          .toUpperCase()
                      : '';
                  if (authServerToken && authServerToken !== activeTokenRef.current) {
                    activeTokenRef.current = authServerToken;
                    setActiveToken(authServerToken);
                  }
                });
              }
            } else if (remoteTokenTs > tokenUpdatedAtRef.current) {
              tokenUpdatedAtRef.current = remoteTokenTs;
              const syncedEndMs = computeLocalTokenDeadlineMs(
                remoteTokenTs,
                tokenDurationSecondsRef.current
              );
              tokenEndTimeRef.current = syncedEndMs;
              setTokenSecondsLeft(
                Math.max(0, Math.ceil((syncedEndMs - Date.now()) / 1000))
              );
            }
          } else if (isAdminOrProctorStage && activeTokenRef.current) {
            // Server has no activeToken stored yet while Admin/Proctor displays one -> push immediately so students can verify
            const seedTs = tokenUpdatedAtRef.current || Date.now();
            tokenUpdatedAtRef.current = seedTs;
            saveVercelStorage({
              activeToken: activeTokenRef.current,
              tokenUpdatedAt: seedTs,
              forceTokenUpdate: false,
            }).then((saveRes) => {
              const authServerToken =
                typeof saveRes.data?.activeToken === 'string'
                  ? saveRes.data.activeToken
                      .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
                      .toUpperCase()
                  : '';
              if (authServerToken && authServerToken !== activeTokenRef.current) {
                activeTokenRef.current = authServerToken;
                setActiveToken(authServerToken);
              }
            });
          }

          // Sync remote adminSettings (deleted/custom mapel config & exam settings) if newer than local
          if (
            res.data.adminSettings &&
            typeof res.data.adminSettings === 'object'
          ) {
            try {
              const rawLocalCfg = localStorage.getItem('cbt_admin_settings');
              const localCfg = rawLocalCfg ? JSON.parse(rawLocalCfg) : null;
              const localCfgTs = Math.max(
                typeof localCfg?.updatedAt === 'number' ? localCfg.updatedAt : 0,
                typeof adminSettingsRef.current?.updatedAt === 'number'
                  ? adminSettingsRef.current.updatedAt
                  : 0
              );
              const remoteRaw = res.data.adminSettings as Record<string, any>;
              const remoteCfgTs =
                typeof remoteRaw.updatedAt === 'number'
                  ? remoteRaw.updatedAt
                  : 0;
              const normalizedRemoteCfg: Record<string, any> = {
                ...adminSettingsRef.current,
                ...remoteRaw,
              };
              if (!remoteRaw.updatedAt && remoteRaw.tokenIntervalMenit === 15) {
                normalizedRemoteCfg.tokenIntervalMenit = 10;
              }
              if (
                !localCfg ||
                !isAdminOrProctorStage ||
                remoteCfgTs >= localCfgTs ||
                (isForced && isAdminOrProctorStage)
              ) {
                adminSettingsRef.current = normalizedRemoteCfg;
                setAdminSettings(normalizedRemoteCfg);
                localStorage.setItem(
                  'cbt_admin_settings',
                  JSON.stringify(normalizedRemoteCfg)
                );
              }
            } catch {
              // ignore
            }
          }

          isApplyingRemoteUpdate.current = true;

          // 2. Packages CRDT reconciliation (preserving uploaded questions while respecting deletedPackageIds)
          let healPackagesPayload: ExamPackage[] | undefined;
          if (Array.isArray(res.data.packages)) {
            const cleanedRemotePackages = filterOutSimulasiTka(
              res.data.packages
            );
            const mergedPackages = mergePackagesPreservingQuestions(
              cleanedRemotePackages,
              packagesRef.current,
              res.data.deletedPackageIds
            );
            packagesRef.current = mergedPackages;
            setPackages(mergedPackages);

            const serverNeedsPkgHeal =
              getTotalUploadedQuestionsCount(mergedPackages) >
                getTotalUploadedQuestionsCount(cleanedRemotePackages) ||
              mergedPackages.some((mp) => {
                const rp = cleanedRemotePackages.find((r) => r.id === mp.id);
                return (
                  (mp.questionsUpdatedAt || 0) > (rp?.questionsUpdatedAt || 0)
                );
              });
            if (isAdminOrProctorStage && serverNeedsPkgHeal) {
              healPackagesPayload = mergedPackages;
            }
          } else if (
            isAdminOrProctorStage &&
            hasAnyUploadedQuestions(packagesRef.current)
          ) {
            healPackagesPayload = packagesRef.current;
          }

          // 3. Schedules CRDT reconciliation by per-schedule updatedAt (Admin-only write authority)
          let healSchedulesPayload: AdminScheduleItem[] | undefined;
          const localHasActiveOrCustomSchedules =
            !isDefaultInactiveSchedulesList(schedulesRef.current);
          const remoteHasSchedulesArray = Array.isArray(res.data.schedules);
          const canTrustServerSchedules =
            !isAdminStage ||
            (res.engine !== 'vercel-serverless' &&
              pendingPushCount.current === 0 &&
              !participantSyncErrorRef.current &&
              Date.now() - lastScheduleMutationAtRef.current > 8_000);

          if (
            Array.isArray(res.data.deletedScheduleIds) &&
            res.data.deletedScheduleIds.length > 0
          ) {
            addLocalDeletedIds(
              STORAGE_KEYS.DELETED_SCHEDULES,
              res.data.deletedScheduleIds
            );
          }

          if (remoteHasSchedulesArray) {
            const rawRemoteSchedules = res.data.schedules!.filter((s) =>
              Boolean(s && typeof s === 'object')
            );
            const cleanRemoteSchedules = sanitizeClientSchedules(
              rawRemoteSchedules,
              packagesRef.current,
              adminSettingsRef.current,
              res.data.deletedScheduleIds,
              res.data.deletedPackageIds
            );
            const strippedRemoteScheduleIds = rawRemoteSchedules
              .filter(
                (rs) =>
                  rs?.id &&
                  !cleanRemoteSchedules.some((cs) => cs.id === rs.id)
              )
              .map((rs) => rs.id);
            if (strippedRemoteScheduleIds.length > 0) {
              addLocalDeletedIds(
                STORAGE_KEYS.DELETED_SCHEDULES,
                strippedRemoteScheduleIds
              );
            }
            // Non-admin callers (students, login page, proctors) AND idle Admin tabs on persistent DB
            // ALWAYS trust server schedules authoritatively so stale localStorage never resurrects old active schedules.
            const rawMergedSchedules =
              isAdminStage && !canTrustServerSchedules
                ? mergeSchedulesByTimestamp(
                    cleanRemoteSchedules,
                    schedulesRef.current,
                    res.data.deletedScheduleIds
                  )
                : cleanRemoteSchedules;
            const mergedSchedules = sanitizeClientSchedules(
              rawMergedSchedules,
              packagesRef.current,
              adminSettingsRef.current,
              res.data.deletedScheduleIds,
              res.data.deletedPackageIds
            );
            schedulesRef.current = mergedSchedules;
            setSchedules(mergedSchedules);

            // If server still returned zombie/deleted schedules that were stripped by sanitizeClientSchedules,
            // or if Admin has un-synced local mutations on ephemeral storage, heal schedules up to server
            const serverHadZombieOrDeletedSchedules =
              strippedRemoteScheduleIds.length > 0;
            if (
              (isAdminOrProctorStage && serverHadZombieOrDeletedSchedules) ||
              (isAdminStage && !canTrustServerSchedules)
            ) {
              const remoteById = new Map<string, AdminScheduleItem>();
              rawRemoteSchedules.forEach((s) => {
                if (s && s.id) remoteById.set(s.id, s);
              });
              const serverNeedsScheduleHeal =
                serverHadZombieOrDeletedSchedules ||
                mergedSchedules.length !== rawRemoteSchedules.length ||
                mergedSchedules.some((m) => {
                  const r = remoteById.get(m.id);
                  return (
                    !r ||
                    r.isActive !== m.isActive ||
                    (m.updatedAt || 0) > (r.updatedAt || 0)
                  );
                });
              if (serverNeedsScheduleHeal) {
                healSchedulesPayload = mergedSchedules;
              }
            }
          } else if (isAdminStage && localHasActiveOrCustomSchedules) {
            healSchedulesPayload = sanitizeClientSchedules(
              schedulesRef.current,
              packagesRef.current,
              adminSettingsRef.current
            );
          }

          // 4. Participants CRDT reconciliation (violationTimestamp vs lastResetAt vs loginUpdatedAt vs metaUpdatedAt)
          let healParticipantsPayload: ProctorParticipantRow[] | undefined;
          const localHasRealParticipants = !isDefaultDemoParticipantsList(
            participantsRef.current
          );
          const remoteHasParticipants =
            Array.isArray(res.data.participants) &&
            res.data.participants.length > 0;
          const remoteIsDemoOnly =
            !remoteHasParticipants ||
            isDefaultDemoParticipantsList(res.data.participants);

          if (localHasRealParticipants && remoteIsDemoOnly) {
            // Server instance cold-started or only has 8 demo students: keep our 131 real students and heal server
            healParticipantsPayload = sanitizeParticipantRows(
              participantsRef.current
            );
          } else if (remoteHasParticipants) {
            const canTrustServerStatus =
              !isAdminOrProctorStage ||
              (res.engine !== 'vercel-serverless' &&
                pendingPushCount.current === 0 &&
                !participantSyncErrorRef.current &&
                Date.now() - lastLocalMutationAt.current > 10_000);
            const mergedParticipants = mergeParticipantLists(
              res.data.participants!,
              participantsRef.current,
              res.data.deletedParticipantIds,
              { serverAuthoritativeStatus: canTrustServerStatus }
            );
            participantsRef.current = mergedParticipants;
            syncLocalDraftViolationResetForRows(mergedParticipants);
            setParticipants(mergedParticipants);

            // Jika siswa sedang berada di halaman konfirmasi lalu dinonaktifkan di Kelompok Tes, segera keluarkan ke halaman login
            if (
              !isAdminOrProctorStage &&
              (stageRef.current === 'confirm_participant' ||
                stageRef.current === 'confirm_test')
            ) {
              const activeUserUpper = String(
                participantRef.current?.username || ''
              )
                .trim()
                .toUpperCase();
              const activeStudentRow = mergedParticipants.find(
                (p) =>
                  String(p?.username ?? '').trim().toUpperCase() === activeUserUpper
              );
              if (
                activeStudentRow &&
                !isParticipantStatusActive(activeStudentRow.status)
              ) {
                clearAuthSessionToken();
                setStage('login');
              }
            }

            // Check if the polled serverless instance was missing students, resets, or violations that we just reconciled
            if (isAdminOrProctorStage) {
              const remoteByUser = new Map<string, ProctorParticipantRow>();
              res.data.participants!.forEach((r) => {
                if (r && typeof r === 'object' && r.username) {
                  remoteByUser.set(String(r.username).trim().toUpperCase(), r);
                }
              });
              const serverNeedsParticipantHeal =
                mergedParticipants.length !== res.data.participants!.length ||
                mergedParticipants.some((m) => {
                  const r = remoteByUser.get(
                    String(m?.username ?? '').trim().toUpperCase()
                  );
                  if (!r) return true;
                  return (
                    Boolean(r.requestReset) !== Boolean(m.requestReset) ||
                    r.loginState !== m.loginState ||
                    r.status !== m.status ||
                    (m.lastResetAt || 0) > (r.lastResetAt || 0) ||
                    (m.violationResetAt || 0) > (r.violationResetAt || 0) ||
                    (m.violationTimestamp || 0) > (r.violationTimestamp || 0) ||
                    (m.metaUpdatedAt || 0) > (r.metaUpdatedAt || 0) ||
                    ((m.resetPackageId || '') !== (r.resetPackageId || '') &&
                      (m.lastResetAt || 0) >= (r.lastResetAt || 0)) ||
                    ((m.resetSubjectTitle || '') !== (r.resetSubjectTitle || '') &&
                      (m.lastResetAt || 0) >= (r.lastResetAt || 0))
                  );
                });
              if (serverNeedsParticipantHeal) {
                healParticipantsPayload = mergedParticipants;
              }
            }
          }

          // Heal stale serverless instance if needed (only Admin/Proctor pushes schedules/packages, or real participants on cold start)
          if (
            healPackagesPayload ||
            healSchedulesPayload ||
            healParticipantsPayload
          ) {
            saveVercelStorage({
              ...(healPackagesPayload
                ? { packages: healPackagesPayload }
                : {}),
              ...(healSchedulesPayload
                ? {
                    schedules: healSchedulesPayload,
                    deletedScheduleIds: Array.from(
                      readLocalDeletedSet(STORAGE_KEYS.DELETED_SCHEDULES)
                    ),
                    deletedPackageIds: Array.from(
                      readLocalDeletedSet(STORAGE_KEYS.DELETED_PACKAGES)
                    ),
                    adminSettings: adminSettingsRef.current,
                    forceReplaceSchedules: true,
                  }
                : {}),
              ...(healParticipantsPayload
                ? {
                    participants: healParticipantsPayload,
                    deletedParticipantIds: Array.from(
                      readLocalDeletedSet(STORAGE_KEYS.DELETED_PARTICIPANTS)
                    ),
                    forceReplaceParticipants: true,
                  }
                : {}),
            }).then((healRes) => {
              if (healRes.ok && typeof healRes.updatedAt === 'number') {
                latestUpdatedAtRef.current = Math.max(
                  latestUpdatedAtRef.current,
                  healRes.updatedAt
                );
              } else if (!healRes.ok && (healRes.status === 401 || healRes.status === 403)) {
                updateParticipantSyncError(
                  'Sesi login Administrator/Proktor telah berakhir di server (401). Silakan klik Keluar lalu login kembali agar perubahan status tersimpan.'
                );
              }
            });
          }

          if (
            Array.isArray(res.data.proctors) &&
            res.data.proctors.length > 0
          ) {
            const validProctors = res.data.proctors.filter(
              (pr): pr is AdminProctorItem => Boolean(pr && typeof pr === 'object')
            );
            if (validProctors.length > 0) {
              setProctors(validProctors);
            }
          }

          const remoteClearedAt =
            typeof res.data.resultsClearedAt === 'number'
              ? res.data.resultsClearedAt
              : 0;
          if (remoteClearedAt > resultsClearedAtRef.current) {
            resultsClearedAtRef.current = remoteClearedAt;
            resultsHistoryRef.current = [];
            setResultsHistory([]);
          } else if (Array.isArray(res.data.resultsHistory)) {
            const getResultSortTs = (r?: ExamResultSummary | null): number => {
              if (!r) return 0;
              if (
                typeof r.completedAtTs === 'number' &&
                Number.isFinite(r.completedAtTs) &&
                r.completedAtTs > 0
              ) {
                return r.completedAtTs;
              }
              const m = String(r.id || '').match(/^res_(\d+)/);
              return m ? Number(m[1]) || 0 : 0;
            };
            const sortedCandidates = [
              ...res.data.resultsHistory,
              ...resultsHistoryRef.current,
            ]
              .filter((item): item is ExamResultSummary =>
                Boolean(item && typeof item === 'object' && item.id)
              )
              .sort((a, b) => getResultSortTs(b) - getResultSortTs(a));
            const seenIds = new Set<string>();
            const seenUserSubject = new Set<string>();
            const mergedHistory: ExamResultSummary[] = [];
            for (const item of sortedCandidates) {
              if (seenIds.has(item.id)) continue;
              const uKey = String(item?.participant?.username || '')
                .trim()
                .toUpperCase();
              const pkgKey = String(item?.packageTitle || '')
                .replace(/^Simulasi TKA\s*-\s*/i, '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
              const compositeKey = uKey && pkgKey ? `${uKey}__${pkgKey}` : '';
              if (compositeKey && seenUserSubject.has(compositeKey)) continue;
              seenIds.add(item.id);
              if (compositeKey) seenUserSubject.add(compositeKey);
              mergedHistory.push(item);
            }
            resultsHistoryRef.current = mergedHistory;
            setResultsHistory(mergedHistory);
          }
          setLastSyncedLabel(
            new Date().toLocaleTimeString('id-ID', {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
            })
          );
          setTimeout(() => {
            isApplyingRemoteUpdate.current = false;
          }, 150);
        } else if (!isHydratedFromCloud.current) {
          // Cold-start / empty server: Only seed from Admin/Proctor or if local holds real data.
          const localHasRealParticipants = !isDefaultDemoParticipantsList(
            participantsRef.current
          );
          const localHasActiveOrCustomSchedules =
            !isDefaultInactiveSchedulesList(schedulesRef.current);
          const localHasQuestions = hasAnyUploadedQuestions(
            packagesRef.current
          );

          if (
            localHasRealParticipants ||
            (isAdminOrProctorStage &&
              (localHasActiveOrCustomSchedules || localHasQuestions))
          ) {
            const seedRes = await saveVercelStorage({
              ...(isAdminOrProctorStage && localHasQuestions
                ? { packages: packagesRef.current }
                : {}),
              ...(isAdminOrProctorStage && localHasActiveOrCustomSchedules
                ? {
                    schedules: schedulesRef.current,
                    forceReplaceSchedules: true,
                  }
                : {}),
              ...(localHasRealParticipants
                ? {
                    participants: sanitizeParticipantRows(
                      participantsRef.current
                    ),
                    forceReplaceParticipants: true,
                  }
                : {}),
              ...(isAdminOrProctorStage
                ? {
                    proctors: proctorsRef.current,
                    activeToken: activeTokenRef.current,
                    tokenUpdatedAt: tokenUpdatedAtRef.current || Date.now(),
                    resultsHistory: resultsHistoryRef.current,
                  }
                : {}),
            });
            if (seedRes.ok) {
              if (typeof seedRes.updatedAt === 'number') {
                latestUpdatedAtRef.current = Math.max(
                  latestUpdatedAtRef.current,
                  seedRes.updatedAt
                );
              }
              setStorageEngine(seedRes.engine);
            }
          }
        }
        isHydratedFromCloud.current = true;
        return participantsRef.current;
      } catch (err) {
        console.error('Cloud sync failed safely:', err);
        isApplyingRemoteUpdate.current = false;
        return participantsRef.current;
      } finally {
        isSyncInFlightRef.current = false;
        syncInFlightPromiseRef.current = null;
        syncInFlightAuthRoleRef.current = null;
      }
      };

      const p = runSync();
      syncInFlightPromiseRef.current = p;
      return p;
    },
    [filterOutSimulasiTka, updateParticipantSyncError]
  );

  // Stage-aware adaptive polling with random jitter & visibility pause so 131+ students
  // on a single school Wi-Fi IP do not trigger Vercel Edge Firewall 403/429 blocks.
  const hasActiveViolationBanner = Boolean(lastViolationInfo);
  useEffect(() => {
    let cancelled = false;
    let pollTimeoutId: number | null = null;

    const getNextPollDelayMs = (): number | null => {
      if (stage === 'admin_dashboard' || stage === 'proctor_dashboard') {
        return 10_000 + Math.floor(Math.random() * 4_000); // 10–14s
      }
      if (stage === 'login') {
        return hasActiveViolationBanner
          ? 12_000 + Math.floor(Math.random() * 5_000) // 12–17s when waiting Reset Login
          : 25_000 + Math.floor(Math.random() * 10_000); // 25–35s normal login screen
      }
      if (stage === 'confirm_participant') {
        return 1_500 + Math.floor(Math.random() * 500); // 1.5–2.0s real-time lightweight ?since= check
      }
      if (stage === 'confirm_test') {
        return 2_500 + Math.floor(Math.random() * 500); // 2.5–3.0s
      }
      if (stage === 'exam_running') {
        return 75_000 + Math.floor(Math.random() * 30_000); // 75–105s (saves >93% GETs during exam)
      }
      // exam_result / proctor_login / admin_login: no background polling needed
      return null;
    };

    const scheduleNext = () => {
      if (cancelled) return;
      const delayMs = getNextPollDelayMs();
      if (delayMs === null) return;
      pollTimeoutId = window.setTimeout(async () => {
        if (cancelled) return;
        if (document.visibilityState !== 'hidden') {
          await syncFromVercelCloud();
        }
        scheduleNext();
      }, delayMs);
    };

    if (
      !isHydratedFromCloud.current ||
      stage === 'confirm_participant' ||
      stage === 'confirm_test'
    ) {
      syncFromVercelCloud({
        force: stage === 'confirm_participant' || stage === 'confirm_test',
      }).finally(() => {
        scheduleNext();
      });
    } else {
      scheduleNext();
    }

    const handleVisibilityOrFocusResume = () => {
      if (document.visibilityState === 'hidden') return;
      if (getNextPollDelayMs() === null) return;
      const minGapMs =
        stage === 'confirm_participant' || stage === 'confirm_test'
          ? 300
          : 5_000;
      if (Date.now() - lastSyncAttemptAtRef.current > minGapMs) {
        syncFromVercelCloud({
          force: stage === 'confirm_participant' || stage === 'confirm_test',
        });
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityOrFocusResume);
    window.addEventListener('focus', handleVisibilityOrFocusResume);

    // Real-time instant push via BroadcastChannel (same browser across tabs), localStorage storage event, and Server-Sent Events (SSE)
    const applyIncomingRealtimeSchedules = (incomingPayload: {
      schedules?: AdminScheduleItem[];
      packages?: ExamPackage[];
      adminSettings?: Record<string, any>;
      activeToken?: string;
      tokenUpdatedAt?: number;
      deletedScheduleIds?: string[];
      deletedPackageIds?: string[];
      updatedAt?: number;
    }) => {
      if (cancelled) return;
      const isAdminActiveTab =
        stageRef.current === 'admin_dashboard' &&
        Date.now() - lastScheduleMutationAtRef.current < 3_000;
      if (isAdminActiveTab) return;

      if (Array.isArray(incomingPayload.deletedScheduleIds)) {
        addLocalDeletedIds(
          STORAGE_KEYS.DELETED_SCHEDULES,
          incomingPayload.deletedScheduleIds
        );
      }
      if (Array.isArray(incomingPayload.deletedPackageIds)) {
        addLocalDeletedIds(
          STORAGE_KEYS.DELETED_PACKAGES,
          incomingPayload.deletedPackageIds.map((id) =>
            String(id || '').trim().toUpperCase()
          )
        );
      }
      if (
        incomingPayload.adminSettings &&
        typeof incomingPayload.adminSettings === 'object'
      ) {
        adminSettingsRef.current = {
          ...adminSettingsRef.current,
          ...incomingPayload.adminSettings,
        };
        setAdminSettings(adminSettingsRef.current);
      }
      if (Array.isArray(incomingPayload.packages)) {
        const cleanedPkgs = filterOutSimulasiTka(incomingPayload.packages);
        const mergedPkgs = mergePackagesPreservingQuestions(
          cleanedPkgs,
          packagesRef.current,
          incomingPayload.deletedPackageIds
        );
        packagesRef.current = mergedPkgs;
        setPackages(mergedPkgs);
      }
      if (Array.isArray(incomingPayload.schedules)) {
        const sanitized = sanitizeClientSchedules(
          incomingPayload.schedules.filter((s) =>
            Boolean(s && typeof s === 'object')
          ),
          packagesRef.current,
          adminSettingsRef.current,
          incomingPayload.deletedScheduleIds,
          incomingPayload.deletedPackageIds
        );
        schedulesRef.current = sanitized;
        setSchedules(sanitized);
      }
      if (
        typeof incomingPayload.activeToken === 'string' &&
        incomingPayload.activeToken.trim()
      ) {
        const cleanTok = incomingPayload.activeToken
          .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
          .toUpperCase();
        if (cleanTok) {
          activeTokenRef.current = cleanTok;
          setActiveToken(cleanTok);
        }
      }
    };

    let bc: BroadcastChannel | null = null;
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        bc = new BroadcastChannel('smadip_cbt_realtime_v1');
        bc.onmessage = (evt) => {
          if (!evt?.data || evt.data.type !== 'cbt_state_updated') return;
          applyIncomingRealtimeSchedules(evt.data);
          syncFromVercelCloud({ force: true });
        };
      }
    } catch {
      bc = null;
    }

    const handleStorageEvent = (evt: StorageEvent) => {
      if (!evt.key) return;
      if (
        evt.key === STORAGE_KEYS.SCHEDULES ||
        evt.key === STORAGE_KEYS.DELETED_SCHEDULES ||
        evt.key === STORAGE_KEYS.PACKAGES ||
        evt.key === STORAGE_KEYS.DELETED_PACKAGES ||
        evt.key === 'cbt_admin_settings' ||
        evt.key === STORAGE_KEYS.TOKEN
      ) {
        try {
          const rawCfg = localStorage.getItem('cbt_admin_settings');
          const parsedCfg = rawCfg ? JSON.parse(rawCfg) : undefined;
          const rawPkgs = localStorage.getItem(STORAGE_KEYS.PACKAGES);
          const parsedPkgs = rawPkgs ? JSON.parse(rawPkgs) : undefined;
          const rawSchs = localStorage.getItem(STORAGE_KEYS.SCHEDULES);
          const parsedSchs = rawSchs ? JSON.parse(rawSchs) : undefined;
          const rawTok = localStorage.getItem(STORAGE_KEYS.TOKEN) || undefined;
          applyIncomingRealtimeSchedules({
            adminSettings: parsedCfg,
            packages: Array.isArray(parsedPkgs) ? parsedPkgs : undefined,
            schedules: Array.isArray(parsedSchs) ? parsedSchs : undefined,
            activeToken: rawTok,
          });
        } catch {
          // ignore
        }
        syncFromVercelCloud({ force: true });
      }
    };
    window.addEventListener('storage', handleStorageEvent);

    let sse: EventSource | null = null;
    if (
      typeof EventSource !== 'undefined' &&
      (stage === 'confirm_participant' ||
        stage === 'confirm_test' ||
        stage === 'login' ||
        stage === 'proctor_dashboard' ||
        stage === 'admin_dashboard')
    ) {
      try {
        sse = new EventSource('/api/storage?stream=1');
        sse.onmessage = (evt) => {
          if (cancelled || !evt.data) return;
          try {
            const payload = JSON.parse(evt.data);
            if (!payload || typeof payload !== 'object') return;
            if (payload.type === 'storage_updated') {
              applyIncomingRealtimeSchedules(payload);
              syncFromVercelCloud({ force: true });
            } else if (
              payload.type === 'connected' &&
              Array.isArray(payload.schedules)
            ) {
              applyIncomingRealtimeSchedules(payload);
            }
          } catch {
            // ignore
          }
        };
      } catch {
        sse = null;
      }
    }

    return () => {
      cancelled = true;
      if (pollTimeoutId !== null) {
        window.clearTimeout(pollTimeoutId);
      }
      document.removeEventListener(
        'visibilitychange',
        handleVisibilityOrFocusResume
      );
      window.removeEventListener('focus', handleVisibilityOrFocusResume);
      window.removeEventListener('storage', handleStorageEvent);
      try {
        bc?.close();
      } catch {
        // ignore
      }
      try {
        sse?.close();
      } catch {
        // ignore
      }
    };
  }, [syncFromVercelCloud, stage, hasActiveViolationBanner, filterOutSimulasiTka]);

  // Manual Force Sync from Admin Dashboard
  const pushToVercelCloud = useCallback(async () => {
    lastLocalMutationAt.current = Date.now();
    pendingPushCount.current += 1;
    try {
      const hasRealParticipants = !isDefaultDemoParticipantsList(participants);
      const hasActiveOrCustomSchedules =
        !isDefaultInactiveSchedulesList(schedules);
      let localAdminSettings:
        | (Record<string, unknown> & { updatedAt?: number })
        | undefined;
      try {
        const rawCfg = localStorage.getItem('cbt_admin_settings');
        if (rawCfg) {
          const parsedCfg = JSON.parse(rawCfg);
          if (parsedCfg && typeof parsedCfg === 'object') {
            localAdminSettings = parsedCfg;
          }
        }
      } catch {
        // ignore
      }
      const res = await saveVercelStorage({
        packages,
        schedules: sanitizedSchedules,
        deletedScheduleIds: Array.from(
          readLocalDeletedSet(STORAGE_KEYS.DELETED_SCHEDULES)
        ),
        forceReplaceSchedules: true,
        ...(hasRealParticipants || isHydratedFromCloud.current
          ? { participants, forceReplaceParticipants: hasRealParticipants }
          : {}),
        proctors,
        activeToken,
        tokenUpdatedAt: tokenUpdatedAtRef.current || Date.now(),
        resultsHistory,
        ...(localAdminSettings ? { adminSettings: localAdminSettings } : {}),
      });
      if (res.ok) {
        if (
          res.data?.participants &&
          Array.isArray(res.data.participants) &&
          !hasRealParticipants &&
          !isDefaultDemoParticipantsList(res.data.participants)
        ) {
          setParticipants(sanitizeParticipantRows(res.data.participants));
        }
        markSyncedSuccess(res.engine);
      }
    } finally {
      pendingPushCount.current = Math.max(0, pendingPushCount.current - 1);
    }
  }, [
    activeToken,
    markSyncedSuccess,
    packages,
    participants,
    proctors,
    resultsHistory,
    sanitizedSchedules,
    schedules,
  ]);

  // Manual Pull Storage Data from Local (/api/storage), Server 1 Web URL, or Previous Vercel KV / Upstash Redis
  const pullFromStorageUrl = useCallback(
    async (
      rawTargetUrl?: string,
      rawSourceToken?: string
    ): Promise<{ ok: boolean; message: string }> => {
      const cleanUrl = String(rawTargetUrl || '').trim();
      const cleanSourceToken = String(rawSourceToken || '').trim();
      const isLocalDefault =
        !cleanUrl ||
        cleanUrl === '/api/storage' ||
        cleanUrl.startsWith('/api/storage?');

      try {
        if (isLocalDefault) {
          await syncFromVercelCloud({ force: true });
          const pulledRes = await pullStorageFromUrl('/api/storage');
          if (!pulledRes.ok || !pulledRes.data) {
            return {
              ok: false,
              message:
                pulledRes.error ||
                'Gagal menarik data dari storage server saat ini (/api/storage).',
            };
          }
          markSyncedSuccess(pulledRes.engine);
          const pCount = Array.isArray(pulledRes.data.participants)
            ? pulledRes.data.participants.length
            : participantsRef.current.length;
          const sCount = Array.isArray(pulledRes.data.schedules)
            ? pulledRes.data.schedules.length
            : schedulesRef.current.length;
          const pkgCount = Array.isArray(pulledRes.data.packages)
            ? pulledRes.data.packages.length
            : packagesRef.current.length;
          const qCount = getTotalUploadedQuestionsCount(
            Array.isArray(pulledRes.data.packages)
              ? pulledRes.data.packages
              : packagesRef.current
          );
          return {
            ok: true,
            message: `Berhasil menyegarkan data dari Storage Server ini (/api/storage): ${pCount} peserta, ${sCount} jadwal, ${pkgCount} paket (${qCount} butir soal). Untuk mengambil semua data dari Server 1 / Storage sebelumnya, masukkan URL Web Server 1 atau KV_REST_API_URL lama pada kolom URL.`,
          };
        }

        const res = await pullStorageFromUrl(cleanUrl, cleanSourceToken);
        if (!res.ok || !res.data) {
          return {
            ok: false,
            message:
              res.error ||
              `Gagal menarik data storage dari URL (${cleanUrl}). Pastikan URL Server 1 atau KV_REST_API_URL & Token valid.`,
          };
        }

        const pulled = res.data;
        isApplyingRemoteUpdate.current = true;

        if (Array.isArray(pulled.deletedScheduleIds)) {
          addLocalDeletedIds(
            STORAGE_KEYS.DELETED_SCHEDULES,
            pulled.deletedScheduleIds
          );
        }
        if (Array.isArray(pulled.deletedPackageIds)) {
          addLocalDeletedIds(
            STORAGE_KEYS.DELETED_PACKAGES,
            pulled.deletedPackageIds.map((id) =>
              String(id || '').trim().toUpperCase()
            )
          );
        }
        if (Array.isArray(pulled.deletedParticipantIds)) {
          addLocalDeletedIds(
            STORAGE_KEYS.DELETED_PARTICIPANTS,
            pulled.deletedParticipantIds
          );
        }

        let nextCfg = adminSettingsRef.current;
        if (pulled.adminSettings && typeof pulled.adminSettings === 'object') {
          nextCfg = {
            ...adminSettingsRef.current,
            ...pulled.adminSettings,
            updatedAt: Date.now(),
          };
          if (Array.isArray(nextCfg.mapelList)) {
            nextCfg.mapelList = nextCfg.mapelList.filter(
              (m: any) =>
                Boolean(m && typeof m === 'object') &&
                !isLegacyZombieSimulasi(m.nama, m)
            );
          }
          adminSettingsRef.current = nextCfg;
          setAdminSettings(nextCfg);
          try {
            localStorage.setItem('cbt_admin_settings', JSON.stringify(nextCfg));
          } catch {
            // ignore
          }
        }

        let nextPkgs = packagesRef.current;
        if (Array.isArray(pulled.packages) && pulled.packages.length > 0) {
          const cleanedRemotePkgs = filterOutSimulasiTka(pulled.packages);
          nextPkgs = mergePackagesPreservingQuestions(
            cleanedRemotePkgs,
            packagesRef.current,
            pulled.deletedPackageIds
          );
          packagesRef.current = nextPkgs;
          setPackages(nextPkgs);
        }

        let nextScheds = schedulesRef.current;
        if (Array.isArray(pulled.schedules)) {
          nextScheds = sanitizeClientSchedules(
            pulled.schedules.filter((s) => Boolean(s && typeof s === 'object')),
            nextPkgs,
            nextCfg,
            pulled.deletedScheduleIds,
            pulled.deletedPackageIds
          );
          schedulesRef.current = nextScheds;
          setSchedules(nextScheds);
        }

        let nextParts = participantsRef.current;
        if (
          Array.isArray(pulled.participants) &&
          pulled.participants.length > 0
        ) {
          nextParts = sanitizeParticipantRows(pulled.participants);
          participantsRef.current = nextParts;
          setParticipants(nextParts);
        }

        let nextProctors = proctorsRef.current;
        if (Array.isArray(pulled.proctors) && pulled.proctors.length > 0) {
          const validPr = pulled.proctors.filter(
            (pr): pr is AdminProctorItem =>
              Boolean(pr && typeof pr === 'object')
          );
          if (validPr.length > 0) {
            nextProctors = validPr;
            proctorsRef.current = validPr;
            setProctors(validPr);
          }
        }

        let nextHistory = resultsHistoryRef.current;
        if (Array.isArray(pulled.resultsHistory)) {
          nextHistory = pulled.resultsHistory.filter(
            (r): r is ExamResultSummary =>
              Boolean(r && typeof r === 'object' && r.id)
          );
          resultsHistoryRef.current = nextHistory;
          setResultsHistory(nextHistory);
        }

        if (
          typeof pulled.activeToken === 'string' &&
          pulled.activeToken.trim()
        ) {
          const cleanTok = pulled.activeToken
            .replace(/[\s\u200B-\u200D\uFEFF]+/g, '')
            .toUpperCase();
          if (cleanTok) {
            activeTokenRef.current = cleanTok;
            setActiveToken(cleanTok);
          }
        }

        broadcastLocalRealtimeUpdate({
          schedules: nextScheds,
          packages: nextPkgs,
          adminSettings: nextCfg,
          activeToken: activeTokenRef.current,
          deletedScheduleIds: Array.from(
            readLocalDeletedSet(STORAGE_KEYS.DELETED_SCHEDULES)
          ),
          deletedPackageIds: Array.from(
            readLocalDeletedSet(STORAGE_KEYS.DELETED_PACKAGES)
          ),
        });

        // If backend already saved the pulled data directly to Server 2's storage,
        // skip re-uploading massive Bank Soal images from the browser (which could hit 4.5MB limit).
        let finalEngine = res.engine;
        if (!res.savedOnServer) {
          const saveRes = await saveVercelStorage({
            packages: nextPkgs,
            schedules: nextScheds,
            deletedScheduleIds: Array.from(
              readLocalDeletedSet(STORAGE_KEYS.DELETED_SCHEDULES)
            ),
            deletedPackageIds: Array.from(
              readLocalDeletedSet(STORAGE_KEYS.DELETED_PACKAGES)
            ),
            forceReplaceSchedules: true,
            forceReplacePackages: true,
            participants: nextParts,
            forceReplaceParticipants: true,
            proctors: nextProctors,
            activeToken: activeTokenRef.current,
            tokenUpdatedAt: Date.now(),
            resultsHistory: nextHistory,
            adminSettings: nextCfg,
          });
          if (saveRes.ok) {
            finalEngine = saveRes.engine;
          }
        }

        setTimeout(() => {
          isApplyingRemoteUpdate.current = false;
        }, 150);

        markSyncedSuccess(finalEngine);

        const totalQuestions = getTotalUploadedQuestionsCount(nextPkgs);
        return {
          ok: true,
          message: `Berhasil menarik & menyimpan semua data dari Storage Sebelumnya ke Server 2: ${nextParts.length} peserta, ${nextScheds.length} jadwal, ${nextPkgs.length} paket soal (${totalQuestions} butir soal), ${nextProctors.length} proktor, dan ${nextHistory.length} riwayat nilai.`,
        };
      } catch (err) {
        isApplyingRemoteUpdate.current = false;
        return {
          ok: false,
          message:
            err instanceof Error
              ? err.message
              : 'Terjadi kesalahan saat menarik data storage.',
        };
      }
    },
    [
      broadcastLocalRealtimeUpdate,
      filterOutSimulasiTka,
      markSyncedSuccess,
      syncFromVercelCloud,
    ]
  );

  const safeParticipantsList = Array.isArray(participants) ? participants : [];
  const safePackagesList = Array.isArray(packages) ? packages : [];
  const currentStudentKelas =
    normalizeKelasCode(
      participant.kelas ||
        safeParticipantsList.find(
          (p) =>
            String(p?.username ?? '').trim().toUpperCase() ===
            String(participant?.username ?? '').trim().toUpperCase()
        )?.kelas
    ) || 'X';

  const currentStudentActiveSchedules = activeSchedules.filter((s) =>
    doesKelasMatch(currentStudentKelas, s.kelas)
  );

  const matchedStudentSchedule =
    (participant.activeSubjectTitle
      ? currentStudentActiveSchedules.find(
          (s) =>
            String(s?.mapel ?? '').trim().toLowerCase() ===
            String(participant.activeSubjectTitle ?? '').trim().toLowerCase()
        )
      : undefined) || currentStudentActiveSchedules[0];

  const pkgBySelectedId = safePackagesList.find(
    (p) => p && p.id === participant.selectedPackageId
  );
  const pkgBySchedule = matchedStudentSchedule
    ? resolvePackageForSchedule(matchedStudentSchedule, safePackagesList)
    : undefined;

  const selectedPackage: ExamPackage =
    pkgBySchedule ||
    pkgBySelectedId ||
    FALLBACK_EMPTY_PACKAGE;

  const effectiveExamPackage: ExamPackage =
    stage === 'exam_running' &&
    lockedRunningPackage &&
    lockedRunningPackage.id !== FALLBACK_EMPTY_PACKAGE.id
      ? lockedRunningPackage
      : selectedPackage;

  const isStandaloneAppOrWebView = useCallback(() => {
    if (typeof window === 'undefined') return false;
    const isFullscreenPwa = Boolean(
      window.matchMedia?.('(display-mode: fullscreen)').matches
    );
    const isAndroidWebView = /; wv\)/i.test(navigator.userAgent || '');
    return isFullscreenPwa || isAndroidWebView;
  }, []);

  const isMobilePhoneDevice = useCallback(() => {
    if (typeof window === 'undefined') return false;
    const isCoarseTouchOnly =
      Boolean(window.matchMedia?.('(pointer: coarse)').matches) &&
      Boolean(window.matchMedia?.('(hover: none)').matches) &&
      window.innerWidth < 1024;
    return (
      window.innerWidth < 768 ||
      isCoarseTouchOnly ||
      /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '')
    );
  }, []);

  const [isFullscreenActive, setIsFullscreenActive] = useState<boolean>(false);

  const requestCbtFullscreen = useCallback(() => {
    const docEl = document.documentElement as HTMLElement & {
      webkitRequestFullscreen?: (options?: FullscreenOptions) => Promise<void>;
      msRequestFullscreen?: () => Promise<void>;
    };
    const doc = document as Document & {
      webkitFullscreenElement?: Element | null;
      msFullscreenElement?: Element | null;
    };

    // Request wakeLock to keep exam active and suppress system idle/status overlays
    try {
      if ('wakeLock' in navigator && navigator.wakeLock) {
        navigator.wakeLock.request('screen').catch(() => {});
      }
    } catch {
      // Ignore
    }

    if (isMobilePhoneDevice() && isStandaloneAppOrWebView()) {
      setIsFullscreenActive(true);
      return;
    }

    if (adminSettingsRef.current?.wajibFullscreen === false) {
      return;
    }

    if (doc.fullscreenElement || doc.webkitFullscreenElement || doc.msFullscreenElement) {
      setIsFullscreenActive(true);
      return;
    }

    lastFullscreenRequestAtRef.current = Date.now();
    if (docEl.requestFullscreen) {
      docEl
        .requestFullscreen({ navigationUI: 'hide' })
        .then(() => {
          setIsFullscreenActive(true);
          try {
            const nav = navigator as Navigator & {
              keyboard?: { lock?: (keys?: string[]) => Promise<void> };
            };
            nav.keyboard?.lock?.(['Escape']).catch(() => {});
          } catch {
            // Ignore
          }
        })
        .catch(() => {
          // Deferred to subsequent user click gesture
        });
    } else if (docEl.webkitRequestFullscreen) {
      try {
        docEl.webkitRequestFullscreen();
        setIsFullscreenActive(true);
      } catch {
        // Ignore
      }
    }
  }, [isStandaloneAppOrWebView, isMobilePhoneDevice]);

  const exitCbtFullscreen = useCallback(() => {
    const doc = document as Document & {
      webkitFullscreenElement?: Element | null;
      msFullscreenElement?: Element | null;
      webkitExitFullscreen?: () => Promise<void>;
    };
    intentionalFullscreenExitAtRef.current = Date.now();
    try {
      const nav = navigator as Navigator & {
        keyboard?: { unlock?: () => void };
      };
      nav.keyboard?.unlock?.();
    } catch {
      // Ignore
    }

    if (doc.fullscreenElement || doc.webkitFullscreenElement || doc.msFullscreenElement) {
      if (document.exitFullscreen) {
        document
          .exitFullscreen()
          .then(() => setIsFullscreenActive(false))
          .catch(() => {});
      } else if (doc.webkitExitFullscreen) {
        try {
          doc.webkitExitFullscreen();
          setIsFullscreenActive(false);
        } catch {
          // Ignore
        }
      }
    } else {
      setIsFullscreenActive(false);
    }
  }, []);

  const requestMobileImmersiveFullscreen = useCallback(() => {
    if (typeof window === 'undefined') return;
    const docEl = document.documentElement as HTMLElement & {
      webkitRequestFullscreen?: (options?: FullscreenOptions) => Promise<void>;
      msRequestFullscreen?: () => Promise<void>;
    };
    const doc = document as Document & {
      webkitFullscreenElement?: Element | null;
      msFullscreenElement?: Element | null;
    };

    try {
      if ('wakeLock' in navigator && navigator.wakeLock) {
        navigator.wakeLock.request('screen').catch(() => {});
      }
    } catch {
      // Ignore
    }

    if (isMobilePhoneDevice() && isStandaloneAppOrWebView()) {
      setIsFullscreenActive(true);
      return;
    }

    if (
      doc.fullscreenElement ||
      doc.webkitFullscreenElement ||
      doc.msFullscreenElement
    ) {
      setIsFullscreenActive(true);
      return;
    }

    lastFullscreenRequestAtRef.current = Date.now();
    if (typeof docEl.requestFullscreen === 'function') {
      docEl
        .requestFullscreen({ navigationUI: 'hide' })
        .then(() => {
          setIsFullscreenActive(true);
          try {
            const nav = navigator as Navigator & {
              keyboard?: { lock?: (keys?: string[]) => Promise<void> };
            };
            nav.keyboard?.lock?.(['Escape']).catch(() => {});
          } catch {
            // Ignore
          }
        })
        .catch(() => {
          // Browsers require a first user touch gesture before entering fullscreen
        });
    } else if (typeof docEl.webkitRequestFullscreen === 'function') {
      try {
        docEl.webkitRequestFullscreen();
        setIsFullscreenActive(true);
      } catch {
        // Ignore
      }
    } else if (typeof docEl.msRequestFullscreen === 'function') {
      try {
        docEl.msRequestFullscreen();
        setIsFullscreenActive(true);
      } catch {
        // Ignore
      }
    }
  }, [isStandaloneAppOrWebView, isMobilePhoneDevice]);

  const [showExitAppConfirmModal, setShowExitAppConfirmModal] = useState(false);

  const isAdminOrProctorStageOrAuth =
    stage === 'admin_dashboard' ||
    stage === 'proctor_dashboard' ||
    stage === 'admin_login' ||
    stage === 'proctor_login';

  // Automatically enter immersive fullscreen on laptop (student CBT stages only) and mobile phones
  // (hiding status bar & browser chrome) on open and on user interaction
  useEffect(() => {
    if (showExitAppConfirmModal) return;
    if (isAdminOrProctorStageOrAuth) return;

    const triggerImmersiveFullscreen = (evt?: Event) => {
      if (isAdminOrProctorStageOrAuth) {
        return;
      }
      const target = evt?.target as HTMLElement | null;
      if (
        target &&
        target.closest(
          'input, textarea, select, label[for], button[data-skip-fullscreen="true"]'
        )
      ) {
        return;
      }
      if (
        !isMobilePhoneDevice() &&
        Date.now() - intentionalFullscreenExitAtRef.current < 1500
      ) {
        return;
      }
      if (Date.now() - lastFullscreenRequestAtRef.current < 450) {
        return;
      }
      requestMobileImmersiveFullscreen();
    };

    const handleVisibilityOrShow = () => {
      if (document.visibilityState === 'visible') {
        requestMobileImmersiveFullscreen();
      }
    };

    // Block top-edge downward swipe & pull-to-refresh / overscroll-down on mobile phones
    // so students cannot drag down the browser bar or top status-bar area from inside the app
    let touchStartX = 0;
    let touchStartY = 0;
    let isTopEdgeSwipe = false;

    const hasScrollableAncestorAboveTop = (target: EventTarget | null): boolean => {
      let el = target instanceof HTMLElement ? target : null;
      while (el && el !== document.body && el !== document.documentElement) {
        if (el.scrollHeight > el.clientHeight + 1 && el.scrollTop > 1) {
          const style = window.getComputedStyle(el);
          if (
            style.overflowY === 'auto' ||
            style.overflowY === 'scroll' ||
            style.overflowY === 'overlay'
          ) {
            return true;
          }
        }
        el = el.parentElement;
      }
      return false;
    };

    const handleMobileTouchStart = (evt: TouchEvent) => {
      if (!isMobilePhoneDevice()) return;
      if (evt.touches.length === 1) {
        touchStartX = evt.touches[0].clientX;
        touchStartY = evt.touches[0].clientY;
        isTopEdgeSwipe = touchStartY <= 48;
      } else if (evt.touches.length > 1) {
        touchStartY = evt.touches[0]?.clientY ?? 0;
        isTopEdgeSwipe = touchStartY <= 64;
      }
    };

    const handleMobileTouchMove = (evt: TouchEvent) => {
      if (!isMobilePhoneDevice()) return;
      if (!evt.cancelable) return;
      if (evt.touches.length > 1) {
        if (isTopEdgeSwipe) {
          evt.preventDefault();
        }
        return;
      }
      if (evt.touches.length !== 1) return;
      const dy = evt.touches[0].clientY - touchStartY;
      const dx = evt.touches[0].clientX - touchStartX;
      const isDownwardDrag = dy > 4 && Math.abs(dy) >= Math.abs(dx) * 0.75;
      if (!isDownwardDrag) return;

      if (isTopEdgeSwipe) {
        evt.preventDefault();
        return;
      }

      const pageScrollTop =
        window.scrollY ||
        document.documentElement.scrollTop ||
        document.body.scrollTop ||
        0;
      if (
        dy > 6 &&
        pageScrollTop <= 1 &&
        !hasScrollableAncestorAboveTop(evt.target)
      ) {
        evt.preventDefault();
      }
    };

    const handleFocusIn = (evt: FocusEvent) => {
      const target = evt.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT')
      ) {
        mobileInputFocusedAtRef.current = Date.now();
      }
    };

    // Attempt immediately on mount / stage load
    requestMobileImmersiveFullscreen();

    // Re-enter fullscreen seamlessly on click (without interrupting input focus/virtual keyboards on touchstart)
    document.addEventListener('touchstart', handleMobileTouchStart, {
      capture: true,
      passive: true,
    });
    document.addEventListener('touchmove', handleMobileTouchMove, {
      capture: true,
      passive: false,
    });
    document.addEventListener('focusin', handleFocusIn, { capture: true });
    document.addEventListener('click', triggerImmersiveFullscreen, {
      capture: true,
      passive: true,
    });
    document.addEventListener('visibilitychange', handleVisibilityOrShow);
    window.addEventListener('pageshow', handleVisibilityOrShow, {
      passive: true,
    });
    window.addEventListener('orientationchange', handleVisibilityOrShow, {
      passive: true,
    });

    return () => {
      document.removeEventListener('touchstart', handleMobileTouchStart, {
        capture: true,
      });
      document.removeEventListener('touchmove', handleMobileTouchMove, {
        capture: true,
      });
      document.removeEventListener('focusin', handleFocusIn, {
        capture: true,
      });
      document.removeEventListener('click', triggerImmersiveFullscreen, {
        capture: true,
      });
      document.removeEventListener('visibilitychange', handleVisibilityOrShow);
      window.removeEventListener('pageshow', handleVisibilityOrShow);
      window.removeEventListener('orientationchange', handleVisibilityOrShow);
    };
  }, [
    showExitAppConfirmModal,
    isAdminOrProctorStageOrAuth,
    isMobilePhoneDevice,
    requestMobileImmersiveFullscreen,
  ]);

  const handleExitApp = useCallback(() => {
    setShowExitAppConfirmModal(true);
  }, []);

  const handleConfirmExitApp = useCallback(() => {
    // 1. Keluar dari mode fullscreen
    exitCbtFullscreen();

    // 2. Coba tutup jendela browser (window.close)
    try {
      window.close();
    } catch {
      // Ignore
    }

    // 3. Fallback jika browser membatasi window.close: arahkan ke blank atau riwayat sebelumnya
    try {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = 'about:blank';
      }
    } catch {
      // Ignore
    }
  }, [exitCbtFullscreen]);

  const lockStudentByViolation = useCallback(
    (reason: string) => {
      if (draftSyncTimerRef.current) {
        window.clearTimeout(draftSyncTimerRef.current);
        draftSyncTimerRef.current = null;
      }
      activeFinishCleanupRef.current?.();
      if (submitRetryTimerRef.current) {
        window.clearTimeout(submitRetryTimerRef.current);
        submitRetryTimerRef.current = null;
      }
      hasActiveFinishMutexRef.current = false;
      setLockedRunningPackage(null);
      setActiveServerDeadlineMs(undefined);
      const nowTs = Date.now();
      const timeStr = new Date().toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      const cleanUser = participant.username.trim().toUpperCase();
      const currentPkgId =
        effectiveExamPackage?.id || FALLBACK_EMPTY_PACKAGE.id;

      // Hitung jumlah pelanggaran siswa pada mata pelajaran aktif (maksimal 6x)
      const existingRow = participantsRef.current.find(
        (r) => r.username.trim().toUpperCase() === cleanUser
      );
      const localDraft = readStudentDraftFromLocal(cleanUser, currentPkgId);
      const localViolationCleared = isLocalDraftViolationClearedByRow(
        localDraft,
        existingRow
      );
      const rowViolationResetAt =
        typeof existingRow?.violationResetAt === 'number'
          ? existingRow.violationResetAt
          : 0;
      const sameViolationPkg =
        !existingRow?.violationPackageId ||
        existingRow.violationPackageId === currentPkgId;

      const prevRowVCount =
        sameViolationPkg &&
        typeof existingRow?.violationCount === 'number' &&
        existingRow.violationCount > 0 &&
        existingRow.violationCount < MAX_VIOLATION_LIMIT
          ? existingRow.violationCount
          : 0;
      const prevLocalVCount =
        !localViolationCleared &&
        typeof localDraft?.violationCount === 'number' &&
        localDraft.violationCount > 0 &&
        localDraft.violationCount < MAX_VIOLATION_LIMIT
          ? localDraft.violationCount
          : 0;

      const nextViolationCount = Math.max(prevRowVCount, prevLocalVCount) + 1;
      const shouldWipeAnswers = nextViolationCount >= MAX_VIOLATION_LIMIT;

      const currentAnswersSnapshot = { ...answersRef.current };
      const currentRemainingSecs = examRemainingSecondsRef.current;

      if (shouldWipeAnswers) {
        // Pelanggaran mencapai 6x: hapus seluruh jawaban dan reset sisa waktu ujian
        setAnswers({});
        answersRef.current = {};
        examRemainingSecondsRef.current = undefined;
        setExamInitialRemainingSeconds(undefined);
        clearStudentDraftInLocal(cleanUser, currentPkgId);
      } else {
        // Pelanggaran 1x s/d 5x: simpan draft jawaban dan sisa waktu agar tidak hilang saat Reset Login
        writeStudentDraftToLocal({
          username: cleanUser,
          packageId: currentPkgId,
          answers: currentAnswersSnapshot,
          remainingSeconds: currentRemainingSecs,
          violationCount: nextViolationCount,
          violationUpdatedAt: nowTs,
          lastAppliedViolationResetAt: Math.max(
            localDraft?.lastAppliedViolationResetAt || 0,
            rowViolationResetAt
          ),
          updatedAt: nowTs,
        });
      }

      const formattedReason = shouldWipeAnswers
        ? `Pelanggaran ${nextViolationCount}/${MAX_VIOLATION_LIMIT} (Batas Maksimal — Seluruh Jawaban Dihapus Otomatis): ${reason}`
        : `Pelanggaran ${nextViolationCount}/${MAX_VIOLATION_LIMIT}: ${reason}`;

      // Capture active student Bearer token before clearing session so retry attempts
      // can still authenticate and deliver the violation lock to the Proctor dashboard
      // even if mobile connectivity drops momentarily while switching apps.
      const capturedViolationToken = getAuthSessionToken();

      handleUpdateParticipants(
        (prev) => {
          const exists = prev.some(
            (row) => row.username.trim().toUpperCase() === cleanUser
          );
          const nextList: ProctorParticipantRow[] = exists
            ? prev.map((row) =>
                row.username.trim().toUpperCase() === cleanUser
                  ? {
                      ...row,
                      loginState: 'Terkunci (Pelanggaran)',
                      requestReset: true,
                      violationReason: formattedReason,
                      violationAt: timeStr,
                      violationSchema: 3,
                      violationTimestamp: nowTs,
                      violationCount: nextViolationCount,
                      violationPackageId: currentPkgId,
                      draftAnswers: shouldWipeAnswers
                        ? undefined
                        : currentAnswersSnapshot,
                      draftPackageId: shouldWipeAnswers
                        ? undefined
                        : currentPkgId,
                      draftRemainingSeconds: shouldWipeAnswers
                        ? undefined
                        : currentRemainingSecs,
                    }
                  : row
              )
            : [
                {
                  id: `p_viol_${nowTs}`,
                  selected: false,
                  status: 'Active',
                  kodeTes: 'SAS26SMADIP1',
                  username: cleanUser,
                  namaPeserta: participant.fullName,
                  kelompok: '1',
                  kelas: 'XII IPA',
                  loginState: 'Terkunci (Pelanggaran)',
                  requestReset: true,
                  violationReason: formattedReason,
                  violationAt: timeStr,
                  violationSchema: 3,
                  violationTimestamp: nowTs,
                  violationCount: nextViolationCount,
                  violationPackageId: currentPkgId,
                  draftAnswers: shouldWipeAnswers
                    ? undefined
                    : currentAnswersSnapshot,
                  draftPackageId: shouldWipeAnswers ? undefined : currentPkgId,
                  draftRemainingSeconds: shouldWipeAnswers
                    ? undefined
                    : currentRemainingSecs,
                },
                ...prev,
              ];
          return nextList;
        },
        {
          overrideToken: capturedViolationToken,
          keepalive: true,
          retryDelaysMs: [1500, 4000, 8000, 15000],
        }
      );

      // Clear active session token immediately so the login screen never retains an authenticated student session
      // (retry loop above holds its own scoped token snapshot solely for delivering this violation lock).
      clearAuthSessionToken();

      setLastViolationInfo({
        username: cleanUser,
        fullName: participant.fullName,
        reason: formattedReason,
        timestamp: timeStr,
        violationCount: nextViolationCount,
        answersWiped: shouldWipeAnswers,
      });
      setStage('login');
    },
    [
      handleUpdateParticipants,
      participant.fullName,
      participant.username,
      effectiveExamPackage?.id,
    ]
  );

  // Automatically enter fullscreen on laptop and mobile when in active exam
  useEffect(() => {
    const updateFullscreenState = () => {
      const doc = document as Document & {
        webkitFullscreenElement?: Element | null;
        msFullscreenElement?: Element | null;
      };
      const active = Boolean(
        doc.fullscreenElement ||
          doc.webkitFullscreenElement ||
          doc.msFullscreenElement
      );
      setIsFullscreenActive(active);
      return active;
    };

    const suppressIncomingNotifications = () => {
      try {
        if ('serviceWorker' in navigator && navigator.serviceWorker?.getRegistrations) {
          navigator.serviceWorker
            .getRegistrations()
            .then((regs) => {
              regs.forEach((reg) => {
                if (reg.getNotifications) {
                  reg.getNotifications().then((notifications) => {
                    notifications.forEach((n) => n.close());
                  });
                }
              });
            })
            .catch(() => {});
        }
      } catch {
        // Ignore
      }
    };

    const handleActiveExamUserInteraction = (evt?: Event) => {
      suppressIncomingNotifications();
      const target = evt?.target as HTMLElement | null;
      if (target && target.closest('input, textarea, select')) {
        return;
      }
      if (
        stage === 'exam_running' &&
        Date.now() - lastFullscreenRequestAtRef.current >= 450
      ) {
        requestCbtFullscreen();
      }
    };

    window.addEventListener('load', handleActiveExamUserInteraction, { passive: true });
    window.addEventListener('pageshow', handleActiveExamUserInteraction, { passive: true });
    document.addEventListener('click', handleActiveExamUserInteraction, { capture: true, passive: true });

    // Handle Esc key on keyboard to exit CBT on laptop (never hijack Esc on Admin/Proctor dashboards)
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Esc' || e.keyCode === 27) {
        if (stage === 'admin_dashboard' || stage === 'proctor_dashboard') {
          return;
        }
        exitCbtFullscreen();

        // Hanya catat pelanggaran jika siswa sudah berada di halaman soal (exam_running)
        // dengan paket yang sudah memiliki butir soal dan pengaturan kunciKeluarSistem aktif
        if (
          stage === 'exam_running' &&
          (effectiveExamPackage?.questions?.length || 0) > 0 &&
          adminSettingsRef.current?.kunciKeluarSistem !== false &&
          Date.now() - examStartedAtRef.current > 2000
        ) {
          lockStudentByViolation(
            'Keluar dari halaman soal ujian CBT (Menekan tombol Esc pada keyboard laptop)'
          );
        } else if (
          stage === 'exam_running' &&
          (effectiveExamPackage?.questions?.length || 0) === 0
        ) {
          handleUpdateParticipants((prev) =>
            prev.map((row) =>
              row.username.trim().toUpperCase() === participant.username.trim().toUpperCase() &&
              row.loginState === 'Sedang Mengerjakan'
                ? {
                    ...row,
                    loginState: 'Belum Login',
                    requestReset: false,
                    draftAnswers: undefined,
                    draftPackageId: undefined,
                    draftRemainingSeconds: undefined,
                  }
                : row
            )
          );
          clearAuthSessionToken();
          setStage('login');
        } else if (
          stage === 'confirm_participant' ||
          stage === 'confirm_test'
        ) {
          handleUpdateParticipants((prev) =>
            prev.map((row) =>
              row.username.toUpperCase() === participant.username.toUpperCase() &&
              row.loginState === 'Sedang Mengerjakan'
                ? { ...row, loginState: 'Belum Login', requestReset: false }
                : row
            )
          );
          clearAuthSessionToken();
          setStage('login');
        } else if (stage === 'exam_result') {
          // Never drop out of ExamResultView via Esc while answers are still syncing or queued offline
          if (examSubmissionStatus === 'synced') {
            clearAuthSessionToken();
            setStage('login');
          }
        }
      }
    };

    let fullscreenCheckTimer: number | null = null;
    const handleFullscreenChange = () => {
      const active = updateFullscreenState();
      if (fullscreenCheckTimer !== null) {
        window.clearTimeout(fullscreenCheckTimer);
        fullscreenCheckTimer = null;
      }
      if (
        !active &&
        isMobilePhoneDevice() &&
        !isStandaloneAppOrWebView() &&
        !showExitAppConfirmModal
      ) {
        const now = Date.now();
        if (
          stage === 'exam_running' &&
          (effectiveExamPackage?.questions?.length || 0) > 0 &&
          adminSettingsRef.current?.kunciKeluarSistem !== false &&
          now - examStartedAtRef.current > 2000 &&
          now - lastFullscreenRequestAtRef.current > 1200 &&
          now - intentionalFullscreenExitAtRef.current > 1500
        ) {
          fullscreenCheckTimer = window.setTimeout(() => {
            fullscreenCheckTimer = null;
            const activeTag = document.activeElement?.tagName;
            const recentlyFocusedInput =
              (activeTag === 'INPUT' || activeTag === 'TEXTAREA') &&
              Date.now() - mobileInputFocusedAtRef.current < 900;
            if (
              !recentlyFocusedInput &&
              (document.visibilityState === 'hidden' || !document.hasFocus())
            ) {
              lockStudentByViolation(
                'Menarik status bar atau keluar dari mode layar penuh saat ujian berlangsung'
              );
              return;
            }
            requestMobileImmersiveFullscreen();
          }, 350);
        } else {
          requestMobileImmersiveFullscreen();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown, { capture: true });
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);

    return () => {
      if (fullscreenCheckTimer !== null) {
        window.clearTimeout(fullscreenCheckTimer);
      }
      window.removeEventListener('load', handleActiveExamUserInteraction);
      window.removeEventListener('pageshow', handleActiveExamUserInteraction);
      document.removeEventListener('click', handleActiveExamUserInteraction, { capture: true });
      window.removeEventListener('keydown', handleKeyDown, { capture: true });
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
    };
  }, [
    requestCbtFullscreen,
    requestMobileImmersiveFullscreen,
    exitCbtFullscreen,
    isMobilePhoneDevice,
    isStandaloneAppOrWebView,
    showExitAppConfirmModal,
    stage,
    examSubmissionStatus,
    lockStudentByViolation,
    handleUpdateParticipants,
    participant.username,
    effectiveExamPackage?.questions?.length,
  ]);

  // Detect student exit violation ONLY when inside active question page (exam_running)
  // with non-empty questions and student genuinely hides the tab, pulls down OS status bar, or switches app
  useEffect(() => {
    if (stage !== 'exam_running') return;
    if ((effectiveExamPackage?.questions?.length || 0) === 0) return;

    const clearBlurTimer = () => {
      if (mobileStatusBarBlurTimerRef.current) {
        window.clearTimeout(mobileStatusBarBlurTimerRef.current);
        mobileStatusBarBlurTimerRef.current = null;
      }
    };

    const handleVisibilityViolation = () => {
      if (adminSettingsRef.current?.kunciKeluarSistem === false) return;
      const now = Date.now();
      if (
        document.visibilityState === 'hidden' &&
        now - examStartedAtRef.current > 2000 &&
        now - lastFullscreenRequestAtRef.current > 1200
      ) {
        clearBlurTimer();
        lockStudentByViolation(
          'Keluar dari halaman soal CBT / berpindah tab atau aplikasi saat ujian berlangsung'
        );
      }
    };

    const handleWindowBlur = () => {
      if (adminSettingsRef.current?.kunciKeluarSistem === false) return;
      const now = Date.now();
      if (
        now - examStartedAtRef.current <= 2000 ||
        now - lastFullscreenRequestAtRef.current <= 1200 ||
        now - intentionalFullscreenExitAtRef.current <= 1500
      ) {
        return;
      }
      clearBlurTimer();
      mobileStatusBarBlurTimerRef.current = window.setTimeout(() => {
        mobileStatusBarBlurTimerRef.current = null;
        if (document.visibilityState !== 'visible') return;
        if (document.hasFocus()) return;
        const activeTag = document.activeElement?.tagName;
        const recentlyFocusedInput =
          (activeTag === 'INPUT' || activeTag === 'TEXTAREA') &&
          Date.now() - mobileInputFocusedAtRef.current < 900;
        if (recentlyFocusedInput) return;
        lockStudentByViolation(
          isMobilePhoneDevice()
            ? 'Menarik status bar / panel notifikasi atau membuka jendela lain saat ujian berlangsung'
            : 'Berpindah jendela aplikasi / kehilangan fokus layar ujian saat ujian berlangsung'
        );
      }, 700);
    };

    const handleWindowFocus = () => {
      clearBlurTimer();
      if (isMobilePhoneDevice()) {
        requestMobileImmersiveFullscreen();
      } else {
        requestCbtFullscreen();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityViolation);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    return () => {
      clearBlurTimer();
      document.removeEventListener(
        'visibilitychange',
        handleVisibilityViolation
      );
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [
    stage,
    lockStudentByViolation,
    effectiveExamPackage?.questions?.length,
    isMobilePhoneDevice,
    requestMobileImmersiveFullscreen,
    requestCbtFullscreen,
  ]);

  const handleRequestResetFromLogin = useCallback((username: string) => {
    const cleanUser = username.trim().toUpperCase();
    const timeStr = new Date().toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    // Use the scoped unauthenticated request_reset server action instead of participantPatch (which requires an active token)
    // and preserve existing violationTimestamp locally so we never override a recent Proctor reset.
    requestResetFromServer(cleanUser).catch(() => {});
    setParticipants((prev) => {
      const nextList = prev.map((row) =>
        row.username.toUpperCase() === cleanUser
          ? {
              ...row,
              requestReset: true,
              violationReason:
                row.violationReason ||
                'Siswa mengajukan permintaan Reset Login ke Proktor/Administrator',
              violationAt: row.violationAt || timeStr,
            }
          : row
      );
      participantsRef.current = nextList;
      try {
        localStorage.setItem(STORAGE_KEYS.PARTICIPANTS, JSON.stringify(nextList));
      } catch {
        // ignore
      }
      return nextList;
    });
  }, []);

  const handleLoginSuccess = (
    username: string,
    serverAccount?: {
      username?: string;
      namaPeserta?: string;
      kelas?: string;
      ruang?: string;
      status?: string;
    },
    serverSchedules?: AdminScheduleItem[]
  ) => {
    const cleanUser = String(serverAccount?.username || username)
      .trim()
      .toUpperCase();
    const shortUser = shortenStudentUsername(cleanUser);
    const matchedRow = participantsRef.current.find(
      (p) =>
        p.username.trim().toUpperCase() === cleanUser ||
        shortenStudentUsername(p.username) === shortUser ||
        p.namaPeserta.trim().toUpperCase() === cleanUser
    );

    const serverVerifiedActive =
      Boolean(serverAccount) &&
      (serverAccount?.status === undefined ||
        isParticipantStatusActive(serverAccount.status));

    // Only enforce local row guards when serverAccount was not already authoritatively verified
    if (!serverVerifiedActive) {
      if (!matchedRow) {
        return;
      }
      if (!isParticipantStatusActive(matchedRow.status)) {
        return;
      }
      if (isParticipantLockedByViolation(matchedRow)) {
        return;
      }
    }

    const resolvedUsername =
      String(serverAccount?.username || matchedRow?.username || cleanUser)
        .trim()
        .toUpperCase();
    const resolvedFullName =
      String(serverAccount?.namaPeserta || matchedRow?.namaPeserta || cleanUser).trim();
    const resolvedKelas =
      normalizeKelasCode(serverAccount?.kelas || matchedRow?.kelas) || 'X';

    // If local cache still showed Non Active while server just verified Active, sync local state immediately
    if (
      serverVerifiedActive &&
      matchedRow &&
      !isParticipantStatusActive(matchedRow.status)
    ) {
      const updatedLocal = participantsRef.current.map((r) =>
        r.username.trim().toUpperCase() === resolvedUsername
          ? { ...r, status: 'Active' as const }
          : r
      );
      participantsRef.current = updatedLocal;
      setParticipants(updatedLocal);
    }

    // If this student has an unsent offline exam submission queued on this browser,
    // immediately flush it with their freshly authenticated Bearer session token and show the result screen!
    const queuedForStudent = readPendingExamSubmissions().filter(
      (item) =>
        String(item?.participant?.username || '').trim().toUpperCase() ===
        resolvedUsername
    );
    if (queuedForStudent.length > 0 && hasAuthSessionToken()) {
      const latestQueued = queuedForStudent[queuedForStudent.length - 1];
      setLastViolationInfo(null);
      setParticipant({
        ...latestQueued.participant,
        username: resolvedUsername,
        fullName: resolvedFullName,
        kelas: resolvedKelas,
      });
      setAnswers(latestQueued.answers || {});
      answersRef.current = latestQueued.answers || {};
      setTimeUsedSeconds(latestQueued.timeUsedSeconds || 0);
      setLatestExamSummary(null);
      setExamSubmissionError(null);
      setIsSubmittingExamResult(true);
      setExamSubmissionStatus('syncing');
      setStage('exam_result');
      flushPendingExamSubmissions({ targetUsername: resolvedUsername })
        .then((res) => {
          if (res.syncedSummaries.length > 0) {
            setLatestExamSummary(
              res.syncedSummaries[res.syncedSummaries.length - 1]
            );
            setExamSubmissionError(null);
            setExamSubmissionStatus('synced');
          } else {
            const stillQueued = readPendingExamSubmissions().some(
              (item) =>
                String(item?.participant?.username || '')
                  .trim()
                  .toUpperCase() === resolvedUsername
            );
            if (stillQueued && res.lastError) {
              setExamSubmissionError(res.lastError);
            }
            setExamSubmissionStatus(stillQueued ? 'offline_queued' : 'synced');
          }
        })
        .catch(() => {
          setExamSubmissionStatus('offline_queued');
        })
        .finally(() => {
          setIsSubmittingExamResult(false);
        });
      return;
    }

    if (Array.isArray(serverSchedules)) {
      const freshSchs = sanitizeClientSchedules(
        serverSchedules.filter((s) => Boolean(s && typeof s === 'object')),
        packagesRef.current,
        adminSettingsRef.current
      );
      schedulesRef.current = freshSchs;
      setSchedules(freshSchs);
    }

    const latestActiveSchedules = sanitizeClientSchedules(
      schedulesRef.current,
      packagesRef.current,
      adminSettingsRef.current
    ).filter((s) => Boolean(s && typeof s === 'object' && s.isActive));

    const studentClassSchedules = latestActiveSchedules.filter((s) =>
      doesKelasMatch(resolvedKelas, s.kelas)
    );

    const isRowReset = Boolean(
      matchedRow && matchedRow.loginState !== 'Selesai'
    );
    const lastResetAt =
      typeof matchedRow?.lastResetAt === 'number' && matchedRow.lastResetAt > 0
        ? matchedRow.lastResetAt
        : 0;
    const rawResetSubjectTitle =
      matchedRow?.resetSubjectTitle ||
      packagesRef.current.find(
        (p) =>
          p.id ===
          (matchedRow?.resetPackageId ||
            matchedRow?.violationPackageId ||
            matchedRow?.draftPackageId)
      )?.title ||
      '';
    const resetSubjectKey = cleanMapelTitle(rawResetSubjectTitle).toLowerCase();

    const getResultTs = (r: ExamResultSummary): number => {
      if (typeof r.completedAtTs === 'number' && r.completedAtTs > 0) {
        return r.completedAtTs;
      }
      const match = String(r.id || '').match(/^res_(\d{10,})/);
      if (match) {
        const parsed = Number(match[1]);
        if (Number.isFinite(parsed) && parsed > 0) return parsed;
      }
      return 0;
    };

    const completedSubjects = new Set(
      resultsHistoryRef.current
        .filter((r) => {
          if (
            (r.participant?.username || '').trim().toUpperCase() !==
            resolvedUsername
          ) {
            return false;
          }
          if (isRowReset && lastResetAt > 0) {
            const resultTs = getResultTs(r);
            const resultSubjectKey = cleanMapelTitle(
              r.packageTitle || ''
            ).toLowerCase();
            if (resetSubjectKey) {
              if (
                resultSubjectKey === resetSubjectKey &&
                (resultTs === 0 || resultTs <= lastResetAt)
              ) {
                return false;
              }
              return true;
            }
            if (resultTs === 0 || resultTs <= lastResetAt) {
              return false;
            }
            return true;
          }
          return true;
        })
        .map((r) => cleanMapelTitle(r.packageTitle || '').toLowerCase())
        .filter(Boolean)
    );

    const firstUncompletedSchedule =
      (isRowReset && resetSubjectKey
        ? studentClassSchedules.find(
            (s) =>
              cleanMapelTitle(s.mapel).toLowerCase() === resetSubjectKey &&
              !completedSubjects.has(cleanMapelTitle(s.mapel).toLowerCase())
          )
        : undefined) ||
      studentClassSchedules.find(
        (s) => !completedSubjects.has(cleanMapelTitle(s.mapel).toLowerCase())
      ) ||
      studentClassSchedules[0];

    if (
      !serverVerifiedActive &&
      matchedRow?.loginState === 'Selesai' &&
      (studentClassSchedules.length === 0 ||
        studentClassSchedules.every((s) =>
          completedSubjects.has(cleanMapelTitle(s.mapel).toLowerCase())
        ))
    ) {
      return;
    }

    requestCbtFullscreen();

    // Update or register participant in shared Vercel Storage (without locking or marking exam running yet)
    handleUpdateParticipants((prev) => {
      const exists = prev.some(
        (row) => row.username.trim().toUpperCase() === resolvedUsername
      );
      if (exists) {
        return prev.map((row) =>
          row.username.trim().toUpperCase() === resolvedUsername
            ? {
                ...row,
                requestReset: false,
                violationReason: undefined,
                violationAt: undefined,
                violationSchema: undefined,
                violationTimestamp: undefined,
              }
            : row
        );
      }
      return [
        {
          id: `p_${Date.now()}`,
          selected: false,
          status: 'Active',
          kodeTes: 'SAS26SMADIP1',
          username: resolvedUsername,
          namaPeserta: resolvedFullName,
          kelompok: '1',
          kelas: resolvedKelas,
          loginState: 'Belum Login',
          requestReset: false,
        },
        ...prev,
      ];
    });

    const scheduledPkg = firstUncompletedSchedule
      ? resolvePackageForSchedule(firstUncompletedSchedule, packages)
      : undefined;

    setLastViolationInfo(null);
    setParticipant((prev) => ({
      ...prev,
      username: resolvedUsername,
      fullName: resolvedFullName,
      kelas: resolvedKelas,
      activeSubjectTitle: firstUncompletedSchedule?.mapel || '',
      selectedPackageId: scheduledPkg?.id || '',
    }));
    setStage('confirm_participant');
  };

  const handleRefreshToken = () => {
    handleUpdateToken(generateRandomToken());
  };

  const handleConfirmParticipant = (updatedProfile: ParticipantProfile) => {
    requestCbtFullscreen();
    setParticipant(updatedProfile);
    setStage('confirm_test');
  };

  const handleStartExam = () => {
    const pkgAtStart = selectedPackage;
    if (getRealQuestionsCount(pkgAtStart) === 0) {
      return;
    }
    const cleanUser = participant.username.trim().toUpperCase();
    const currentPkgId = pkgAtStart?.id || FALLBACK_EMPTY_PACKAGE.id;
    const matchedRow = participantsRef.current.find(
      (r) => r.username.trim().toUpperCase() === cleanUser
    );
    if (!matchedRow || !isParticipantStatusActive(matchedRow.status)) {
      clearAuthSessionToken();
      setStage('login');
      return;
    }
    examStartedAtRef.current = Date.now();
    requestCbtFullscreen();
    const localDraft = readStudentDraftFromLocal(cleanUser, currentPkgId);
    const localViolationCleared = isLocalDraftViolationClearedByRow(
      localDraft,
      matchedRow
    );
    const rowViolationResetAt =
      typeof matchedRow?.violationResetAt === 'number'
        ? matchedRow.violationResetAt
        : 0;

    if (localViolationCleared && localDraft) {
      writeStudentDraftToLocal({
        ...localDraft,
        violationCount: 0,
        violationUpdatedAt: 0,
        lastAppliedViolationResetAt: rowViolationResetAt,
      });
    }

    const sameViolationPkg =
      !matchedRow?.violationPackageId ||
      matchedRow.violationPackageId === currentPkgId;
    const rowVCount =
      sameViolationPkg && typeof matchedRow?.violationCount === 'number'
        ? matchedRow.violationCount
        : 0;
    const localVCount =
      !localViolationCleared &&
      sameViolationPkg &&
      typeof localDraft?.violationCount === 'number'
        ? localDraft.violationCount
        : 0;
    const mergedViolationCount = Math.max(rowVCount, localVCount);

    const isRemoteResetNewerThanLocalDraft = Boolean(
      matchedRow &&
        !matchedRow.draftAnswers &&
        (matchedRow.lastResetAt || 0) > (localDraft?.updatedAt || 0)
    );
    if (isRemoteResetNewerThanLocalDraft) {
      clearStudentDraftInLocal(cleanUser, currentPkgId);
    }

    let restoredAnswers: Record<string, StudentAnswer> = {};
    let restoredRemainingSecs: number | undefined = undefined;
    let effectiveViolationCount = mergedViolationCount;

    if (mergedViolationCount >= MAX_VIOLATION_LIMIT) {
      // Siswa sebelumnya telah mencapai 6x pelanggaran: jawaban sudah dihapus, mulai dari awal (0/6)
      effectiveViolationCount = 0;
      clearStudentDraftInLocal(cleanUser, currentPkgId);
    } else {
      // Pulihkan jawaban dan sisa waktu jika siswa kembali masuk setelah Reset Login (pelanggaran 1x-5x)
      const hasLocalAnswers =
        !isRemoteResetNewerThanLocalDraft &&
        Boolean(
          localDraft &&
            localDraft.packageId === currentPkgId &&
            localDraft.answers &&
            Object.keys(localDraft.answers).length > 0
        );
      const hasRemoteAnswers =
        matchedRow?.draftPackageId === currentPkgId &&
        matchedRow?.draftAnswers &&
        Object.keys(matchedRow.draftAnswers).length > 0;

      if (hasLocalAnswers && hasRemoteAnswers) {
        restoredAnswers = {
          ...matchedRow!.draftAnswers!,
          ...localDraft!.answers,
        };
      } else if (hasLocalAnswers) {
        restoredAnswers = { ...localDraft!.answers };
      } else if (hasRemoteAnswers) {
        restoredAnswers = { ...matchedRow!.draftAnswers! };
      }

      if (
        !isRemoteResetNewerThanLocalDraft &&
        typeof localDraft?.remainingSeconds === 'number' &&
        localDraft.remainingSeconds > 0
      ) {
        restoredRemainingSecs = localDraft.remainingSeconds;
      } else if (
        matchedRow?.draftPackageId === currentPkgId &&
        typeof matchedRow?.draftRemainingSeconds === 'number' &&
        matchedRow.draftRemainingSeconds > 0
      ) {
        restoredRemainingSecs = matchedRow.draftRemainingSeconds;
      }
    }

    const effectiveRowResetAt = Math.max(
      typeof matchedRow.lastResetAt === 'number' ? matchedRow.lastResetAt : 0,
      typeof matchedRow.violationResetAt === 'number'
        ? matchedRow.violationResetAt
        : 0
    );
    const hasValidServerDeadline =
      typeof matchedRow.examStartedAt === 'number' &&
      matchedRow.examStartedAt > effectiveRowResetAt &&
      typeof matchedRow.examDeadlineAt === 'number' &&
      matchedRow.examDeadlineAt > 0 &&
      (!matchedRow.draftPackageId || matchedRow.draftPackageId === currentPkgId);
    const initialServerDeadline = hasValidServerDeadline
      ? matchedRow.examDeadlineAt
      : undefined;

    if (initialServerDeadline) {
      const serverRemSecs = Math.max(
        1,
        Math.ceil((initialServerDeadline - getServerNow()) / 1000)
      );
      if (
        typeof restoredRemainingSecs !== 'number' ||
        serverRemSecs < restoredRemainingSecs
      ) {
        restoredRemainingSecs = serverRemSecs;
      }
    }

    hasActiveFinishMutexRef.current = false;
    setAnswers(restoredAnswers);
    answersRef.current = restoredAnswers;
    setExamInitialRemainingSeconds(restoredRemainingSecs);
    setActiveServerDeadlineMs(initialServerDeadline);
    examRemainingSecondsRef.current = restoredRemainingSecs;
    setTimeUsedSeconds(0);

    handleUpdateParticipants((prev) =>
      prev.map((row) =>
        row.username.trim().toUpperCase() === cleanUser
          ? {
              ...row,
              loginState: 'Sedang Mengerjakan',
              requestReset: false,
              violationReason: undefined,
              violationAt: undefined,
              violationSchema: undefined,
              violationTimestamp: undefined,
              violationCount: effectiveViolationCount,
              violationPackageId:
                effectiveViolationCount > 0 ? currentPkgId : undefined,
              loginUpdatedAt: Date.now(),
              draftPackageId: currentPkgId,
              draftAnswers: restoredAnswers,
              draftRemainingSeconds: restoredRemainingSecs,
              draftUpdatedAt: Date.now(),
            }
          : row
      )
    );
    setLockedRunningPackage(pkgAtStart);
    setStage('exam_running');

    // Synchronize authoritative server exam start timestamp and deadline
    if (hasAuthSessionToken()) {
      startExamOnServer({
        username: cleanUser,
        packageId: currentPkgId,
        packageTitle: pkgAtStart?.title,
        durationMinutes: pkgAtStart?.durationMinutes,
      })
        .then((startRes) => {
          if (
            startRes.ok &&
            typeof startRes.examDeadlineAt === 'number' &&
            startRes.examDeadlineAt > 0 &&
            stageRef.current === 'exam_running' &&
            participantRef.current.username.trim().toUpperCase() === cleanUser
          ) {
            setActiveServerDeadlineMs(startRes.examDeadlineAt);
            if (
              typeof startRes.remainingSeconds === 'number' &&
              startRes.remainingSeconds > 0
            ) {
              const clamped =
                typeof examRemainingSecondsRef.current === 'number'
                  ? Math.min(
                      examRemainingSecondsRef.current,
                      startRes.remainingSeconds
                    )
                  : startRes.remainingSeconds;
              examRemainingSecondsRef.current = clamped;
            }
            setParticipants((prev) =>
              prev.map((r) =>
                r.username.trim().toUpperCase() === cleanUser
                  ? {
                      ...r,
                      examStartedAt: startRes.examStartedAt,
                      examDeadlineAt: startRes.examDeadlineAt,
                    }
                  : r
              )
            );
          }
        })
        .catch(() => {});
    }
  };

  const handleRemainingSecondsChange = useCallback(
    (secsLeft: number) => {
      examRemainingSecondsRef.current = secsLeft;
      const cleanUser = participant.username.trim().toUpperCase();
      const currentPkgId =
        effectiveExamPackage?.id || FALLBACK_EMPTY_PACKAGE.id;
      const matchedRow = participantsRef.current.find(
        (r) => r.username.trim().toUpperCase() === cleanUser
      );
      const currentVCount =
        typeof matchedRow?.violationCount === 'number'
          ? matchedRow.violationCount
          : 0;
      const existingDraft = readStudentDraftFromLocal(cleanUser, currentPkgId);
      writeStudentDraftToLocal({
        username: cleanUser,
        packageId: currentPkgId,
        answers: answersRef.current,
        remainingSeconds: secsLeft,
        violationCount: currentVCount,
        violationUpdatedAt:
          currentVCount > 0 ? existingDraft?.violationUpdatedAt : 0,
        lastAppliedViolationResetAt: Math.max(
          existingDraft?.lastAppliedViolationResetAt || 0,
          matchedRow?.violationResetAt || 0
        ),
        updatedAt: Date.now(),
      });
    },
    [participant.username, effectiveExamPackage?.id]
  );

  const handleUpdateAnswer = useCallback(
    (questionId: string, updater: (prev: StudentAnswer) => StudentAnswer) => {
      const cleanUser = participant.username.trim().toUpperCase();
      const currentPkgId =
        effectiveExamPackage?.id || FALLBACK_EMPTY_PACKAGE.id;
      setAnswers((prevMap) => {
        const current = prevMap[questionId] || { questionId };
        const nextMap = {
          ...prevMap,
          [questionId]: updater(current),
        };
        answersRef.current = nextMap;

        const matchedRow = participantsRef.current.find(
          (r) => r.username.trim().toUpperCase() === cleanUser
        );
        const currentVCount =
          typeof matchedRow?.violationCount === 'number'
            ? matchedRow.violationCount
            : 0;
        const existingDraft = readStudentDraftFromLocal(cleanUser, currentPkgId);

        writeStudentDraftToLocal({
          username: cleanUser,
          packageId: currentPkgId,
          answers: nextMap,
          remainingSeconds: examRemainingSecondsRef.current,
          violationCount: currentVCount,
          violationUpdatedAt:
            currentVCount > 0 ? existingDraft?.violationUpdatedAt : 0,
          lastAppliedViolationResetAt: Math.max(
            existingDraft?.lastAppliedViolationResetAt || 0,
            matchedRow?.violationResetAt || 0
          ),
          updatedAt: Date.now(),
        });

        // Debounce remote server sync by 5000ms so 131 concurrent students answering/typing
        // do not flood /api/storage (or trigger Vercel 403 rate limits) while keeping localStorage 0ms instant
        if (draftSyncTimerRef.current) {
          window.clearTimeout(draftSyncTimerRef.current);
        }
        draftSyncTimerRef.current = window.setTimeout(() => {
          draftSyncTimerRef.current = null;
          lastDraftServerSyncAtRef.current = Date.now();
          handleUpdateParticipants((prev) =>
            prev.map((row) =>
              row.username.trim().toUpperCase() === cleanUser
                ? {
                    ...row,
                    draftPackageId: currentPkgId,
                    draftAnswers: answersRef.current,
                    draftRemainingSeconds: examRemainingSecondsRef.current,
                    draftUpdatedAt: Date.now(),
                  }
                : row
            )
          );
        }, 5000);

        return nextMap;
      });
    },
    [handleUpdateParticipants, participant.username, effectiveExamPackage?.id]
  );

  // Immediately flush pending debounced answers & keep remaining time fresh every 60s during active exam
  useEffect(() => {
    if (stage !== 'exam_running') return;
    const flushPendingDraftKeepalive = (forceOnLeave = false) => {
      const hadTimer = Boolean(draftSyncTimerRef.current);
      if (draftSyncTimerRef.current) {
        window.clearTimeout(draftSyncTimerRef.current);
        draftSyncTimerRef.current = null;
      }
      const nowTs = Date.now();
      if (!hadTimer && (!forceOnLeave || nowTs - lastDraftServerSyncAtRef.current < 10_000)) {
        return;
      }
      const cleanUser = participantRef.current?.username?.trim().toUpperCase();
      const currentPkgId =
        effectiveExamPackage?.id || FALLBACK_EMPTY_PACKAGE.id;
      if (!cleanUser || !hasAuthSessionToken()) return;
      lastDraftServerSyncAtRef.current = nowTs;
      saveVercelStorage(
        {
          participantPatch: [
            {
              username: cleanUser,
              draftPackageId: currentPkgId,
              draftAnswers: answersRef.current,
              draftRemainingSeconds: examRemainingSecondsRef.current,
              draftUpdatedAt: nowTs,
            },
          ],
        },
        { keepalive: true }
      ).catch(() => {});
    };
    const onPageHide = () => flushPendingDraftKeepalive(true);
    const onVisibilityHidden = () => {
      if (document.visibilityState === 'hidden') {
        flushPendingDraftKeepalive(true);
      }
    };
    const heartbeatTimer = window.setInterval(() => {
      if (Date.now() - lastDraftServerSyncAtRef.current < 55_000) return;
      const cleanUser = participantRef.current?.username?.trim().toUpperCase();
      const currentPkgId =
        effectiveExamPackage?.id || FALLBACK_EMPTY_PACKAGE.id;
      if (!cleanUser || !hasAuthSessionToken()) return;
      const nowTs = Date.now();
      lastDraftServerSyncAtRef.current = nowTs;
      handleUpdateParticipants((prev) =>
        prev.map((row) =>
          row.username.trim().toUpperCase() === cleanUser
            ? {
                ...row,
                draftPackageId: currentPkgId,
                draftAnswers: answersRef.current,
                draftRemainingSeconds: examRemainingSecondsRef.current,
                draftUpdatedAt: nowTs,
              }
            : row
        )
      );
    }, 60_000);
    window.addEventListener('pagehide', onPageHide);
    document.addEventListener('visibilitychange', onVisibilityHidden);
    return () => {
      window.clearInterval(heartbeatTimer);
      window.removeEventListener('pagehide', onPageHide);
      document.removeEventListener('visibilitychange', onVisibilityHidden);
    };
  }, [stage, effectiveExamPackage?.id, handleUpdateParticipants]);

  const applyAuthoritativeResultSummary = useCallback(
    (localResultId: string, serverSummary: ExamResultSummary) => {
      setResultsHistory((prev) => {
        const targetUser = String(serverSummary?.participant?.username || '')
          .trim()
          .toUpperCase();
        const targetPkg = String(serverSummary?.packageTitle || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .replace(/\s+/g, ' ')
          .trim()
          .toLowerCase();
        const filteredPrev = prev.filter((item) => {
          if (!item) return false;
          if (item.id === localResultId || item.id === serverSummary.id) {
            return false;
          }
          if (targetUser && targetPkg) {
            const itemUser = String(item?.participant?.username || '')
              .trim()
              .toUpperCase();
            const itemPkg = String(item?.packageTitle || '')
              .replace(/^Simulasi TKA\s*-\s*/i, '')
              .replace(/\s+/g, ' ')
              .trim()
              .toLowerCase();
            if (itemUser === targetUser && itemPkg === targetPkg) {
              return false;
            }
          }
          return true;
        });
        const finalHistory = [serverSummary, ...filteredPrev];
        resultsHistoryRef.current = finalHistory;
        try {
          localStorage.setItem(
            STORAGE_KEYS.HISTORY,
            JSON.stringify(finalHistory)
          );
        } catch {
          // ignore
        }
        return finalHistory;
      });
    },
    []
  );

  const flushPendingExamSubmissions = useCallback(
    async (options?: {
      targetUsername?: string;
    }): Promise<{
      syncedCount: number;
      remainingCount: number;
      syncedSummaries: ExamResultSummary[];
      lastError?: string;
    }> => {
      const queue = readPendingExamSubmissions();
      if (queue.length === 0) {
        refreshPendingSubmissionsState();
        return { syncedCount: 0, remainingCount: 0, syncedSummaries: [] };
      }
      // Never fire unauthenticated requests that would always 401; wait until a session token exists
      if (!hasAuthSessionToken()) {
        refreshPendingSubmissionsState();
        return {
          syncedCount: 0,
          remainingCount: queue.length,
          syncedSummaries: [],
        };
      }

      const authRole = getAuthSessionRole();
      const targetUpper = String(options?.targetUsername || '')
        .trim()
        .toUpperCase();
      const currentStudentUpper = String(participantRef.current?.username || '')
        .trim()
        .toUpperCase();

      const syncedSummaries: ExamResultSummary[] = [];
      let lastError: string | undefined;

      for (const item of queue) {
        const itemUser = String(item?.participant?.username || '')
          .trim()
          .toUpperCase();
        if (targetUpper && itemUser !== targetUpper) continue;
        // Student sessions can only submit their own queued results; admin/proctor can flush all queued items on the PC
        if (
          authRole === 'student' &&
          currentStudentUpper &&
          itemUser &&
          itemUser !== currentStudentUpper &&
          (!targetUpper || itemUser !== targetUpper)
        ) {
          continue;
        }
        if (inFlightSubmissionIdsRef.current.has(item.localResultId)) {
          continue;
        }

        inFlightSubmissionIdsRef.current.add(item.localResultId);
        try {
          const res = await submitExamToServer({
            packageId: item.packageId,
            packageTitle: item.packageTitle,
            answers: item.answers,
            timeUsedSeconds: item.timeUsedSeconds,
            participant: item.participant,
            submissionId: item.localResultId,
          });
          if (res.ok && res.summary) {
            removePendingExamSubmission(item.localResultId);
            syncedSummaries.push(res.summary);
            applyAuthoritativeResultSummary(item.localResultId, res.summary);
            if (
              stageRef.current === 'exam_result' &&
              itemUser === currentStudentUpper
            ) {
              setLatestExamSummary(res.summary);
              setExamSubmissionError(null);
              setExamSubmissionStatus('synced');
              setIsSubmittingExamResult(false);
            }
            if (typeof res.updatedAt === 'number') {
              latestUpdatedAtRef.current = Math.max(
                latestUpdatedAtRef.current,
                res.updatedAt
              );
            }
            markSyncedSuccess(res.engine || 'vercel-serverless');
          } else if (res.error) {
            lastError = res.error;
            if (
              stageRef.current === 'exam_result' &&
              itemUser === currentStudentUpper
            ) {
              setExamSubmissionError(res.error);
            }
          }
        } catch {
          // Keep in queue until next online/retry cycle
        } finally {
          inFlightSubmissionIdsRef.current.delete(item.localResultId);
        }
      }

      const remaining = readPendingExamSubmissions();
      refreshPendingSubmissionsState();
      return {
        syncedCount: syncedSummaries.length,
        remainingCount: remaining.length,
        syncedSummaries,
        lastError,
      };
    },
    [
      applyAuthoritativeResultSummary,
      markSyncedSuccess,
      refreshPendingSubmissionsState,
    ]
  );

  const reconcilePendingWithCompletedSubjects = useCallback(
    (username: string, completedSubjects?: string[]): number => {
      const cleanUser = String(username || '').trim().toUpperCase();
      if (!cleanUser) return 0;
      const queue = readPendingExamSubmissions();
      if (queue.length === 0) return 0;
      const normalizeTitle = (raw?: string) =>
        String(raw || '')
          .replace(/^Simulasi TKA\s*-\s*/i, '')
          .trim()
          .toLowerCase();
      const completedSet = new Set(
        (Array.isArray(completedSubjects) ? completedSubjects : [])
          .map((t) => normalizeTitle(t))
          .filter(Boolean)
      );
      let removed = 0;
      for (const item of queue) {
        const itemUser = String(item?.participant?.username || '')
          .trim()
          .toUpperCase();
        if (itemUser !== cleanUser) continue;
        const itemTitle = normalizeTitle(item.packageTitle);
        if (completedSet.size === 0 || (itemTitle && completedSet.has(itemTitle))) {
          removePendingExamSubmission(item.localResultId);
          removed += 1;
        }
      }
      if (removed > 0) {
        refreshPendingSubmissionsState();
      }
      return removed;
    },
    [refreshPendingSubmissionsState]
  );

  // Automatically clear any local pending queue entries ONLY when synced server resultsHistory is at least as new as the queued retake
  useEffect(() => {
    if (resultsHistory.length === 0) return;
    const queue = readPendingExamSubmissions();
    if (queue.length === 0) return;
    const normalizeTitle = (raw?: string) =>
      String(raw || '')
        .replace(/^Simulasi TKA\s*-\s*/i, '')
        .trim()
        .toLowerCase();
    const getResultTs = (r: ExamResultSummary): number => {
      if (
        typeof r.completedAtTs === 'number' &&
        Number.isFinite(r.completedAtTs) &&
        r.completedAtTs > 0
      ) {
        return r.completedAtTs;
      }
      const m = String(r.id || '').match(/^res_(\d+)/);
      return m ? Number(m[1]) || 0 : 0;
    };
    const latestCompletedTsByKey = new Map<string, number>();
    for (const r of resultsHistory) {
      const u = String(r?.participant?.username || '').trim().toUpperCase();
      const t = normalizeTitle(r?.packageTitle);
      if (!u || !t) continue;
      const key = `${u}::${t}`;
      const ts = getResultTs(r);
      if (ts > (latestCompletedTsByKey.get(key) || 0)) {
        latestCompletedTsByKey.set(key, ts);
      }
    }
    let removed = 0;
    for (const item of queue) {
      const u = String(item?.participant?.username || '').trim().toUpperCase();
      const t = normalizeTitle(item.packageTitle);
      const serverTs = u && t ? latestCompletedTsByKey.get(`${u}::${t}`) : undefined;
      if (
        typeof serverTs === 'number' &&
        serverTs > 0 &&
        serverTs >= (item.queuedAt || 0)
      ) {
        removePendingExamSubmission(item.localResultId);
        removed += 1;
      }
    }
    if (removed > 0) {
      refreshPendingSubmissionsState();
    }
  }, [resultsHistory, refreshPendingSubmissionsState]);

  const retryCurrentExamSubmission = useCallback(() => {
    const cleanUser = String(participantRef.current?.username || '')
      .trim()
      .toUpperCase();
    if (!cleanUser) return;
    setIsSubmittingExamResult(true);
    setExamSubmissionError(null);
    setExamSubmissionStatus('syncing');
    flushPendingExamSubmissions({ targetUsername: cleanUser })
      .then((res) => {
        if (res.syncedSummaries.length > 0) {
          setLatestExamSummary(
            res.syncedSummaries[res.syncedSummaries.length - 1]
          );
          setExamSubmissionError(null);
          setExamSubmissionStatus('synced');
        } else {
          const cleanUserItems = readPendingExamSubmissions().filter(
            (item) =>
              String(item?.participant?.username || '')
                .trim()
                .toUpperCase() === cleanUser
          );
          const stillQueued = cleanUserItems.length > 0;
          const hasInFlight = cleanUserItems.some((item) =>
            inFlightSubmissionIdsRef.current.has(item.localResultId)
          );
          if (stillQueued && !hasInFlight && res.lastError) {
            setExamSubmissionError(res.lastError);
          }
          setExamSubmissionStatus(
            hasInFlight ? 'syncing' : stillQueued ? 'offline_queued' : 'synced'
          );
        }
      })
      .catch(() => {
        setExamSubmissionStatus('offline_queued');
      })
      .finally(() => {
        setIsSubmittingExamResult(false);
      });
  }, [flushPendingExamSubmissions]);

  useEffect(() => {
    flushPendingExamSubmissions().catch(() => {});
    const onOnline = () => {
      flushPendingExamSubmissions().catch(() => {});
    };
    window.addEventListener('online', onOnline);
    return () => window.removeEventListener('online', onOnline);
  }, [flushPendingExamSubmissions]);

  // While staying on ExamResultView with an offline-queued submission, auto-retry every 15s using live in-memory token
  useEffect(() => {
    if (stage !== 'exam_result' || examSubmissionStatus !== 'offline_queued') {
      return;
    }
    const timer = window.setInterval(() => {
      if (navigator.onLine !== false && hasAuthSessionToken()) {
        retryCurrentExamSubmission();
      }
    }, 15_000);
    return () => window.clearInterval(timer);
  }, [stage, examSubmissionStatus, retryCurrentExamSubmission]);

  const handleFinishExam = useCallback(
    (usedSeconds: number) => {
      if (hasActiveFinishMutexRef.current) return;
      hasActiveFinishMutexRef.current = true;
      if (draftSyncTimerRef.current) {
        window.clearTimeout(draftSyncTimerRef.current);
        draftSyncTimerRef.current = null;
      }
      activeFinishCleanupRef.current?.();
      if (submitRetryTimerRef.current) {
        window.clearTimeout(submitRetryTimerRef.current);
        submitRetryTimerRef.current = null;
      }
      setTimeUsedSeconds(usedSeconds);

      // Never grade redacted student questions on the client (that would produce bogus 0 scores).
      // Raw answers are persisted to PENDING_RESULTS and graded authoritatively by the server.
      const latestAnswers = answersRef.current || answers;
      const nowTs = Date.now();
      const localResultId = `res_${nowTs}_${Math.random().toString(36).slice(2, 6)}`;
      const finishingPkg = effectiveExamPackage;
      const pkgTitle = finishingPkg?.title || FALLBACK_EMPTY_PACKAGE.title;

      const cleanUser = participant.username.trim().toUpperCase();
      const pkgId = finishingPkg?.id || FALLBACK_EMPTY_PACKAGE.id;
      clearStudentDraftInLocal(cleanUser, pkgId);
      setLockedRunningPackage(null);
      examRemainingSecondsRef.current = undefined;
      setExamInitialRemainingSeconds(undefined);
      setActiveServerDeadlineMs(undefined);
      lastLocalMutationAt.current = nowTs;

      setParticipants((prev) => {
        const nextList = sanitizeParticipantRows(
          prev.map((row) =>
            row.username.trim().toUpperCase() === cleanUser
              ? {
                  ...row,
                  loginState: 'Selesai',
                  requestReset: false,
                  violationReason: undefined,
                  violationAt: undefined,
                  violationSchema: undefined,
                  violationTimestamp: undefined,
                  violationCount: 0,
                  violationPackageId: undefined,
                  loginUpdatedAt: Math.max(
                    (row.loginUpdatedAt || 0) + 1,
                    nowTs
                  ),
                  draftAnswers: undefined,
                  draftPackageId: undefined,
                  draftRemainingSeconds: undefined,
                  examStartedAt: undefined,
                  examDeadlineAt: undefined,
                  draftUpdatedAt: Math.max(
                    (row.draftUpdatedAt || 0) + 1,
                    nowTs
                  ),
                }
              : row
          )
        );
        participantsRef.current = nextList;
        try {
          localStorage.setItem(
            STORAGE_KEYS.PARTICIPANTS,
            JSON.stringify(nextList)
          );
        } catch {
          // ignore
        }
        return nextList;
      });

      const submissionPayload: PendingExamSubmission = {
        localResultId,
        packageId: pkgId,
        packageTitle: pkgTitle,
        answers: latestAnswers,
        timeUsedSeconds: usedSeconds,
        participant,
        queuedAt: nowTs,
      };
      enqueuePendingExamSubmission(submissionPayload);
      refreshPendingSubmissionsState();
      setLatestExamSummary(null);
      setExamSubmissionError(null);
      setIsSubmittingExamResult(true);
      setExamSubmissionStatus('syncing');

      // Authoritative server grading & persistence with jittered retry backoff
      pendingPushCount.current += 1;
      inFlightSubmissionIdsRef.current.add(submissionPayload.localResultId);
      let didReleaseAttempt = false;
      const cleanupFinishAttempt = () => {
        if (submitRetryTimerRef.current) {
          window.clearTimeout(submitRetryTimerRef.current);
          submitRetryTimerRef.current = null;
        }
        if (!didReleaseAttempt) {
          didReleaseAttempt = true;
          inFlightSubmissionIdsRef.current.delete(
            submissionPayload.localResultId
          );
          pendingPushCount.current = Math.max(0, pendingPushCount.current - 1);
        }
        if (activeFinishCleanupRef.current === cleanupFinishAttempt) {
          activeFinishCleanupRef.current = null;
        }
      };
      activeFinishCleanupRef.current = cleanupFinishAttempt;

      const attemptSubmit = async (retryIdx: number) => {
        try {
          const res = await submitExamToServer({
            packageId: submissionPayload.packageId,
            packageTitle: submissionPayload.packageTitle,
            answers: submissionPayload.answers,
            timeUsedSeconds: submissionPayload.timeUsedSeconds,
            participant: submissionPayload.participant,
            submissionId: submissionPayload.localResultId,
          });
          if (res.ok && res.summary) {
            removePendingExamSubmission(submissionPayload.localResultId);
            refreshPendingSubmissionsState();
            applyAuthoritativeResultSummary(
              submissionPayload.localResultId,
              res.summary
            );
            setLatestExamSummary(res.summary);
            setExamSubmissionError(null);
            setExamSubmissionStatus('synced');
            setIsSubmittingExamResult(false);
            if (typeof res.updatedAt === 'number') {
              latestUpdatedAtRef.current = Math.max(
                latestUpdatedAtRef.current,
                res.updatedAt
              );
            }
            markSyncedSuccess(res.engine || 'vercel-serverless');
            cleanupFinishAttempt();
            return;
          }
          if (res.fallbackClientGrade) {
            // Server does not yet have answer keys for this package: keep raw answers safely queued (never save 0)
            setExamSubmissionError(
              res.error ||
                'Bank soal dengan kunci jawaban belum tersedia di server untuk menilai ujian ini. Jawaban tetap tersimpan aman di antrean perangkat.'
            );
            setExamSubmissionStatus('offline_queued');
            setIsSubmittingExamResult(false);
            cleanupFinishAttempt();
            return;
          }
          if (res.error) {
            setExamSubmissionError(res.error);
          }
        } catch {
          // Fall through to retry schedule
        }

        if (didReleaseAttempt) return;

        const backoffMs = [2500, 6000, 12000][retryIdx];
        if (typeof backoffMs === 'number' && hasAuthSessionToken()) {
          const jitterMs = backoffMs + Math.floor(Math.random() * 1500);
          submitRetryTimerRef.current = window.setTimeout(() => {
            submitRetryTimerRef.current = null;
            attemptSubmit(retryIdx + 1);
          }, jitterMs);
        } else {
          // Remain persisted in PENDING_RESULTS queue for auto-flush on reconnect or next authenticated login
          setExamSubmissionStatus('offline_queued');
          setIsSubmittingExamResult(false);
          cleanupFinishAttempt();
        }
      };

      attemptSubmit(0);
      setStage('exam_result');
    },
    [
      answers,
      applyAuthoritativeResultSummary,
      markSyncedSuccess,
      participant,
      refreshPendingSubmissionsState,
      effectiveExamPackage,
    ]
  );

  const handleCancelEmptyExam = useCallback(() => {
    if (draftSyncTimerRef.current) {
      window.clearTimeout(draftSyncTimerRef.current);
      draftSyncTimerRef.current = null;
    }
    activeFinishCleanupRef.current?.();
    if (submitRetryTimerRef.current) {
      window.clearTimeout(submitRetryTimerRef.current);
      submitRetryTimerRef.current = null;
    }
    hasActiveFinishMutexRef.current = false;
    setLockedRunningPackage(null);
    setActiveServerDeadlineMs(undefined);
    const cleanUser = participant.username.trim().toUpperCase();
    clearStudentDraftInLocal(
      cleanUser,
      effectiveExamPackage?.id || FALLBACK_EMPTY_PACKAGE.id
    );
    examRemainingSecondsRef.current = undefined;
    setExamInitialRemainingSeconds(undefined);
    handleUpdateParticipants((prev) =>
      prev.map((row) =>
        row.username.trim().toUpperCase() === cleanUser
          ? {
              ...row,
              loginState:
                row.loginState === 'Sedang Mengerjakan'
                  ? 'Belum Login'
                  : row.loginState,
              requestReset: false,
              draftAnswers: undefined,
              draftPackageId: undefined,
              draftRemainingSeconds: undefined,
              examStartedAt: undefined,
              examDeadlineAt: undefined,
            }
          : row
      )
    );
    exitCbtFullscreen();
    clearAuthSessionToken();
    setAnswers({});
    answersRef.current = {};
    setStage('login');
  }, [
    exitCbtFullscreen,
    handleUpdateParticipants,
    participant.username,
    effectiveExamPackage?.id,
  ]);

  const cancelAuthSpinner = () => {
    if (authSpinTimerRef.current) {
      window.clearTimeout(authSpinTimerRef.current);
      authSpinTimerRef.current = null;
    }
    setIsAuthSpinning(false);
  };

  const handleLogout = () => {
    cancelAuthSpinner();
    activeFinishCleanupRef.current?.();
    if (submitRetryTimerRef.current) {
      window.clearTimeout(submitRetryTimerRef.current);
      submitRetryTimerRef.current = null;
    }
    hasActiveFinishMutexRef.current = false;
    setActiveServerDeadlineMs(undefined);
    if (stage === 'exam_running') {
      if ((effectiveExamPackage?.questions?.length || 0) === 0) {
        handleCancelEmptyExam();
        return;
      }
      // Jangan panggil setAnswers({}) di sini agar lockStudentByViolation
      // menyimpan jawaban untuk pelanggaran 1..5 dan hanya menghapus jika mencapai 6x
      lockStudentByViolation(
        'Keluar dari halaman soal CBT sebelum menyelesaikan ujian'
      );
      return;
    }
    setLockedRunningPackage(null);
    if (stage === 'confirm_participant' || stage === 'confirm_test') {
      handleUpdateParticipants((prev) =>
        prev.map((row) =>
          row.username.toUpperCase() === participant.username.toUpperCase() &&
          row.loginState === 'Sedang Mengerjakan'
            ? { ...row, loginState: 'Belum Login', requestReset: false }
            : row
        )
      );
    }
    clearAuthSessionToken();
    setLatestExamSummary(null);
    setExamSubmissionError(null);
    setAnswers({});
    answersRef.current = {};
    setStage('login');
  };

  // Dedicated Full-Screen Proctor Dashboard (matches the reference image)
  if (stage === 'proctor_dashboard') {
    const handleExitProctorToLogin = () => {
      cancelAuthSpinner();
      clearAuthSessionToken();
      setStage('login');
    };
    return (
      <ErrorBoundary onResetToLogin={handleExitProctorToLogin}>
        {participantSyncError && (
          <div className="fixed bottom-4 right-4 z-[9998] max-w-md bg-rose-600 text-white px-4 py-3 rounded-xl shadow-xl border border-rose-400 flex items-start gap-3 text-xs leading-relaxed">
            <div className="flex-1 font-medium">{participantSyncError}</div>
            <button
              type="button"
              onClick={() => updateParticipantSyncError('')}
              className="shrink-0 px-2 py-0.5 rounded bg-white/20 hover:bg-white/30 font-bold cursor-pointer"
            >
              Tutup
            </button>
          </div>
        )}
        <ProctorDashboardView
          proctorName={proctorSession.name}
          proctorId={proctorSession.proctorId}
          encryptionCode={proctorSession.encryptionCode}
          onUpdateProctorName={(newName: string) => {
            setProctorSession((prev) => ({ ...prev, name: newName }));
          }}
          proctors={proctors}
          onUpdateProctors={handleUpdateProctors}
          activeToken={activeToken}
          tokenSecondsLeft={tokenSecondsLeft}
          tokenDurationSeconds={TOKEN_DURATION_SECONDS}
          onUpdateToken={handleUpdateToken}
          adminSettings={adminSettings}
          onUpdateAdminSettings={handleUpdateAdminSettings}
          isScheduleActive={isScheduleActive}
          activeSchedules={activeSchedules}
          participants={participants}
          onUpdateParticipants={handleUpdateParticipants}
          packages={packages}
          onUpdatePackages={handleUpdatePackages}
          onResetDefaultPackages={() => handleUpdatePackages(INITIAL_EXAM_PACKAGES)}
          resultsHistory={resultsHistory}
          onClearHistory={() => handleUpdateResultsHistory([])}
          onLogoutProctor={handleExitProctorToLogin}
        />
      </ErrorBoundary>
    );
  }

  // Dedicated Full-Screen Administrator Dashboard
  if (stage === 'admin_dashboard') {
    const handleExitAdminToLogin = () => {
      cancelAuthSpinner();
      clearAuthSessionToken();
      setStage('login');
    };
    return (
      <ErrorBoundary onResetToLogin={handleExitAdminToLogin}>
        {participantSyncError && (
          <div className="fixed bottom-4 right-4 z-[9998] max-w-md bg-rose-600 text-white px-4 py-3 rounded-xl shadow-xl border border-rose-400 flex items-start gap-3 text-xs leading-relaxed">
            <div className="flex-1 font-medium">{participantSyncError}</div>
            <button
              type="button"
              onClick={() => updateParticipantSyncError('')}
              className="shrink-0 px-2 py-0.5 rounded bg-white/20 hover:bg-white/30 font-bold cursor-pointer"
            >
              Tutup
            </button>
          </div>
        )}
        <AdminDashboardView
          adminUsername={adminUsername}
          activeToken={activeToken}
          tokenSecondsLeft={tokenSecondsLeft}
          tokenDurationSeconds={TOKEN_DURATION_SECONDS}
          onUpdateToken={handleUpdateToken}
          adminSettings={adminSettings}
          onUpdateAdminSettings={handleUpdateAdminSettings}
          schedules={sanitizedSchedules}
          onUpdateSchedules={handleUpdateSchedules}
          participants={participants}
          onUpdateParticipants={handleUpdateParticipants}
          proctors={proctors}
          onUpdateProctors={handleUpdateProctors}
          packages={packages}
          onUpdatePackages={handleUpdatePackages}
          onResetDefaultPackages={() => handleUpdatePackages(INITIAL_EXAM_PACKAGES)}
          resultsHistory={resultsHistory}
          onClearHistory={() => handleUpdateResultsHistory([])}
          storageEngine={storageEngine}
          ephemeralStorageWarning={ephemeralStorageWarning}
          lastSyncedLabel={lastSyncedLabel}
          onForceSyncStorage={pushToVercelCloud}
          onPullStorage={pullFromStorageUrl}
          onLogoutAdmin={handleExitAdminToLogin}
        />
      </ErrorBoundary>
    );
  }

  const isAuthScreen =
    stage === 'login' || stage === 'proctor_login' || stage === 'admin_login';

  return (
    <div className="min-h-dvh flex flex-col bg-[#eef1f6] text-slate-800">
      {/* Top Official Geometric Blue Header */}
      <PusmendikHeader
        participantName={!isAuthScreen ? participant.fullName : undefined}
        participantCode={!isAuthScreen ? participant.username : undefined}
        onLogout={!isAuthScreen ? handleLogout : undefined}
        onOpenAdminLogin={
          stage !== 'exam_running'
            ? () => {
                cancelAuthSpinner();
                setStage('admin_login');
              }
            : undefined
        }
        onOpenProctorModal={
          stage !== 'exam_running'
            ? () => {
                cancelAuthSpinner();
                setStage('proctor_login');
              }
            : undefined
        }
        onExitApp={stage === 'login' ? handleExitApp : undefined}
        compact={stage === 'exam_running'}
      />

      {/* Stage 1: Login Card (Peserta) */}
      {stage === 'login' && (
        <LoginView
          onLoginSuccess={handleLoginSuccess}
          onOpenProctorModal={() => {
            cancelAuthSpinner();
            setStage('proctor_login');
          }}
          onExitApp={handleExitApp}
          participants={participants}
          activeSchedules={activeSchedules}
          resultsHistory={resultsHistory}
          lastViolationInfo={lastViolationInfo}
          violationMessage={
            typeof adminSettings.pesanPelanggaran === 'string'
              ? adminSettings.pesanPelanggaran
              : undefined
          }
          pendingSubmissions={pendingSubmissions.map((item) => ({
            localResultId: item.localResultId,
            username: item.participant?.username || '-',
            fullName: item.participant?.fullName || item.participant?.username || 'Peserta',
            packageTitle: item.packageTitle || 'Ujian SAS',
          }))}
          onRequestResetLogin={handleRequestResetFromLogin}
          onReconcileCompletedSubjects={reconcilePendingWithCompletedSubjects}
          onRefreshParticipants={() => syncFromVercelCloud({ force: true })}
          sessionNotice={sessionReplacedNotice}
          onClearSessionNotice={() => setSessionReplacedNotice(null)}
        />
      )}

      {/* Stage 1B: Halaman Login Khusus Proktor */}
      {stage === 'proctor_login' && (
        <ProctorLoginView
          proctors={proctors}
          onRefreshProctors={async () => {
            await syncFromVercelCloud({ force: true });
            return proctorsRef.current;
          }}
          onProctorLoginSuccess={(proctorName, encryptionCode, proctorId) => {
            setProctorSession({
              name: proctorName,
              encryptionCode,
              ...(proctorId ? { proctorId } : {}),
            });
            flushPendingExamSubmissions()
              .catch(() => {})
              .finally(() => {
                syncFromVercelCloud({ force: true }).catch(() => {});
              });
            if (authSpinTimerRef.current) {
              window.clearTimeout(authSpinTimerRef.current);
            }
            setIsAuthSpinning(true);
            authSpinTimerRef.current = window.setTimeout(() => {
              authSpinTimerRef.current = null;
              setIsAuthSpinning(false);
              setStage('proctor_dashboard');
            }, 5000);
          }}
          onBackToStudentLogin={() => {
            cancelAuthSpinner();
            setStage('login');
          }}
          onGoToAdminLogin={() => {
            cancelAuthSpinner();
            setStage('admin_login');
          }}
        />
      )}

      {/* Stage 1C: Halaman Login Khusus Administrator */}
      {stage === 'admin_login' && (
        <AdminLoginView
          adminSettings={adminSettings}
          onRefreshAdminSettings={async () => {
            await syncFromVercelCloud({ force: true });
            return adminSettingsRef.current;
          }}
          onAdminLoginSuccess={(adminUser) => {
            setAdminUsername(adminUser);
            flushPendingExamSubmissions()
              .catch(() => {})
              .finally(() => {
                syncFromVercelCloud({ force: true }).catch(() => {});
              });
            if (authSpinTimerRef.current) {
              window.clearTimeout(authSpinTimerRef.current);
            }
            setIsAuthSpinning(true);
            authSpinTimerRef.current = window.setTimeout(() => {
              authSpinTimerRef.current = null;
              setIsAuthSpinning(false);
              setStage('admin_dashboard');
            }, 5000);
          }}
          onBackToStudentLogin={() => {
            cancelAuthSpinner();
            setStage('login');
          }}
          onGoToProctorLogin={() => {
            cancelAuthSpinner();
            setStage('proctor_login');
          }}
        />
      )}

      {/* Overlay Animasi Berputar 5 Detik (Background Blur, Tanpa Tulisan Apapun) */}
      {isAuthSpinning && (
        <div
          className="fixed inset-0 z-[9999] bg-slate-900/35 backdrop-blur-md flex items-center justify-center"
          aria-hidden="true"
        >
          <div className="relative w-16 h-16 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border-4 border-white/25" />
            <div className="w-16 h-16 rounded-full border-4 border-transparent border-t-[#0088ff] border-r-[#0088ff] animate-spin" />
          </div>
        </div>
      )}

      {/* Stage 2: Konfirmasi Data Peserta & Token */}
      {stage === 'confirm_participant' && (
        <ParticipantConfirmationView
          initialProfile={participant}
          packages={packages}
          participants={participants}
          resultsHistory={resultsHistory}
          activeToken={activeToken}
          isScheduleActive={isScheduleActive}
          activeSchedules={activeSchedules}
          onRefreshToken={handleRefreshToken}
          onSyncRemoteData={({
            packages: remotePkgs,
            schedules: remoteSchs,
            activeToken: remoteTok,
            tokenUpdatedAt: remoteTokenTs,
          }) => {
            if (Array.isArray(remotePkgs)) {
              const cleaned = filterOutSimulasiTka(remotePkgs);
              const merged = mergePackagesPreservingQuestions(
                cleaned,
                packagesRef.current
              );
              packagesRef.current = merged;
              setPackages(merged);
            }
            if (Array.isArray(remoteSchs)) {
              const authoritativeSchs = sanitizeClientSchedules(
                remoteSchs.filter((s) => Boolean(s && typeof s === 'object')),
                packagesRef.current,
                adminSettingsRef.current
              );
              schedulesRef.current = authoritativeSchs;
              setSchedules(authoritativeSchs);
            }
            if (typeof remoteTok === 'string' && remoteTok) {
              activeTokenRef.current = remoteTok;
              setActiveToken(remoteTok);
              if (typeof remoteTokenTs === 'number' && remoteTokenTs > 0) {
                tokenUpdatedAtRef.current = Math.max(
                  tokenUpdatedAtRef.current,
                  remoteTokenTs
                );
                const nextEndMs = computeLocalTokenDeadlineMs(
                  remoteTokenTs,
                  TOKEN_DURATION_SECONDS
                );
                tokenEndTimeRef.current = nextEndMs;
                setTokenSecondsLeft(
                  Math.max(0, Math.ceil((nextEndMs - Date.now()) / 1000))
                );
              }
            }
          }}
          onSubmitProfile={handleConfirmParticipant}
        />
      )}

      {/* Stage 3: Konfirmasi Tes */}
      {stage === 'confirm_test' && (
        <TestConfirmationView
          profile={participant}
          examPackage={selectedPackage}
          onStartExam={handleStartExam}
          onBackToProfile={() => setStage('confirm_participant')}
        />
      )}

      {/* Stage 4: Lembar Ujian CBT */}
      {stage === 'exam_running' && (
        <ExamRunnerView
          key={effectiveExamPackage.id}
          examPackage={effectiveExamPackage}
          participantUsername={participant.username}
          answers={answers}
          onUpdateAnswer={handleUpdateAnswer}
          onFinishExam={handleFinishExam}
          onCancelEmptyExam={handleCancelEmptyExam}
          initialRemainingSeconds={examInitialRemainingSeconds}
          serverDeadlineMs={activeServerDeadlineMs}
          onRemainingSecondsChange={handleRemainingSecondsChange}
          shuffleQuestions={adminSettings.acakSoal !== false}
          shuffleOptions={adminSettings.acakOpsi !== false}
          minMinutesBeforeFinish={
            adminSettings.enforceMinFinishTime
              ? Number(adminSettings.minMinutesBeforeFinish) || 0
              : 0
          }
          showResultScore={Boolean(adminSettings.tampilkanNilaiPeserta)}
          violationCount={(() => {
            const vRow = participants.find(
              (p) =>
                p.username.trim().toUpperCase() ===
                participant.username.trim().toUpperCase()
            );
            if (
              !vRow ||
              (vRow.violationPackageId &&
                vRow.violationPackageId !== effectiveExamPackage.id)
            ) {
              return 0;
            }
            return vRow.violationCount || 0;
          })()}
        />
      )}

      {/* Stage 5: Laporan Hasil & Pembahasan */}
      {stage === 'exam_result' && (() => {
        const cleanUser = participant.username.trim().toUpperCase();
        const completedSet = new Set(
          resultsHistory
            .filter(
              (r) =>
                (r?.participant?.username || '').trim().toUpperCase() ===
                cleanUser
            )
            .map((r) => cleanMapelTitle(r.packageTitle || '').toLowerCase())
            .filter(Boolean)
        );
        const justFinishedTitle = cleanMapelTitle(
          latestExamSummary?.packageTitle || selectedPackage?.title || ''
        ).toLowerCase();
        if (justFinishedTitle) {
          completedSet.add(justFinishedTitle);
        }
        const hasRemainingSchedules = currentStudentActiveSchedules.some(
          (s) => !completedSet.has(cleanMapelTitle(s.mapel).toLowerCase())
        );
        return (
          <ExamResultView
            profile={participant}
            examPackage={selectedPackage}
            answers={answers}
            timeUsedSeconds={timeUsedSeconds}
            showResultScore={Boolean(adminSettings.tampilkanNilaiPeserta)}
            serverSummary={latestExamSummary}
            isSyncingResult={isSubmittingExamResult}
            syncStatus={examSubmissionStatus}
            syncError={examSubmissionError}
            onRetrySubmit={retryCurrentExamSubmission}
            hasRemainingSchedules={hasRemainingSchedules}
            onRetakeOrChangePackage={() => setStage('confirm_participant')}
            onLogout={handleLogout}
          />
        );
      })()}

      {/* Modal Konfirmasi Tutup / Keluar Aplikasi CBT */}
      {showExitAppConfirmModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 text-center space-y-4 animate-cbt-slide-up">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-100 flex items-center justify-center text-rose-600">
              <Power className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800">
                Tutup Aplikasi CBT?
              </h3>
              <p className="mt-1.5 text-xs text-slate-600 leading-relaxed">
                Apakah Anda yakin ingin keluar dan menutup aplikasi CBT SMA Islam Diponegoro Wagir?
              </p>
            </div>
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowExitAppConfirmModal(false)}
                className="flex-1 py-2 px-3 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowExitAppConfirmModal(false);
                  handleConfirmExitApp();
                }}
                className="flex-1 py-2 px-3 rounded-lg bg-rose-600 hover:bg-rose-700 active:scale-[0.99] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Ya, Keluar CBT
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
