import {
  AdminScheduleItem,
  ExamPackage,
  ExamResultSummary,
  ParticipantProfile,
  StudentAnswer,
} from '../types/cbt';
import { ProctorParticipantRow } from '../components/ProctorDashboardView';
import { AdminProctorItem } from '../components/AdminViews';

export interface CBTCloudPayload {
  packages?: ExamPackage[];
  packagePatch?: ExamPackage | ExamPackage[];
  packageQuestionAppend?: {
    packageId: string;
    questions: unknown[];
    questionsUpdatedAt?: number;
  };
  deletedPackageIds?: string[];
  forceReplacePackages?: boolean;
  packagesUpdatedAt?: number;
  schedules?: AdminScheduleItem[];
  deletedScheduleIds?: string[];
  forceReplaceSchedules?: boolean;
  schedulesUpdatedAt?: number;
  participants?: ProctorParticipantRow[];
  participantPatch?:
    | Partial<ProctorParticipantRow>
    | Partial<ProctorParticipantRow>[];
  deletedParticipantIds?: string[];
  forceReplaceParticipants?: boolean;
  proctors?: AdminProctorItem[];
  activeToken?: string;
  tokenUpdatedAt?: number;
  forceTokenUpdate?: boolean;
  resultsHistory?: ExamResultSummary[];
  resultAppend?: ExamResultSummary;
  resultsClearedAt?: number;
  adminSettings?: Record<string, unknown> & { updatedAt?: number };
  updatedAt?: number;
  clientNow?: number;
  schemaVersion?: number;
}

export interface VercelStorageResponse {
  ok: boolean;
  engine: 'vercel-kv' | 'vercel-serverless' | 'local';
  serverTime?: number;
  ephemeralStorageWarning?: boolean;
  savedOnServer?: boolean;
  updatedAt?: number;
  unchanged?: boolean;
  rateLimited?: boolean;
  status?: number;
  reason?: string;
  error?: string;
  data: CBTCloudPayload | null;
}

export interface AuthLoginRequest {
  role: 'admin' | 'proctor' | 'student';
  username: string;
  password: string;
  encryptionCode?: string;
}

export interface AuthLoginResponse {
  ok: boolean;
  status?: number;
  serverEmpty?: boolean;
  networkError?: boolean;
  error?: string;
  reason?: string;
  token?: string;
  role?: 'admin' | 'proctor' | 'student';
  serverTime?: number;
  completedSubjects?: string[];
  schedules?: AdminScheduleItem[];
  account?: Record<string, any>;
}

export interface VerifyExamEntryResponse {
  ok: boolean;
  networkError?: boolean;
  status?: number;
  serverTime?: number;
  error?: string;
  reason?:
    | 'non_active'
    | 'locked'
    | 'invalid_token'
    | 'no_schedule'
    | 'unauthorized'
    | 'session_replaced';
  schedule?: AdminScheduleItem;
  participantStatus?: 'Active' | 'Non Active';
}

export interface StartExamServerResponse {
  ok: boolean;
  engine?: 'vercel-kv' | 'vercel-serverless' | 'local';
  networkError?: boolean;
  timeout?: boolean;
  status?: number;
  reason?: string;
  serverTime?: number;
  examStartedAt?: number;
  examDeadlineAt?: number;
  remainingSeconds?: number;
  error?: string;
}

export interface SubmitExamServerResponse {
  ok: boolean;
  engine?: 'vercel-kv' | 'vercel-serverless' | 'local';
  networkError?: boolean;
  timeout?: boolean;
  fallbackClientGrade?: boolean;
  status?: number;
  reason?: string;
  serverTime?: number;
  error?: string;
  updatedAt?: number;
  summary?: ExamResultSummary;
}

// Keep Bearer session token strictly in JS memory (never in localStorage/sessionStorage)
let authSessionToken: string | null = null;
let authSessionRole: 'admin' | 'proctor' | 'student' | null = null;

// Track server-vs-client clock offset so CRDT timestamps stay consistent even on skewed devices
let serverClockOffsetMs = 0;

function syncServerClock(serverTime?: number): void {
  if (typeof serverTime === 'number' && Number.isFinite(serverTime) && serverTime > 0) {
    serverClockOffsetMs = serverTime - Date.now();
  }
}

export function getServerNow(): number {
  return Date.now() + serverClockOffsetMs;
}

export function setAuthSessionToken(
  token: string | null,
  role?: 'admin' | 'proctor' | 'student' | null
): void {
  authSessionToken = token && token.trim() ? token.trim() : null;
  authSessionRole = authSessionToken ? role || authSessionRole : null;
}

export function getAuthSessionRole(): 'admin' | 'proctor' | 'student' | null {
  return authSessionToken ? authSessionRole : null;
}

export function hasAuthSessionToken(): boolean {
  return Boolean(authSessionToken);
}

export function getAuthSessionToken(): string | null {
  return authSessionToken;
}

export function clearAuthSessionToken(): void {
  authSessionToken = null;
  authSessionRole = null;
}

type SessionReplacedHandler = (message: string) => void;
const sessionReplacedHandlers = new Set<SessionReplacedHandler>();

export function onSessionReplaced(handler: SessionReplacedHandler): () => void {
  sessionReplacedHandlers.add(handler);
  return () => {
    sessionReplacedHandlers.delete(handler);
  };
}

function notifyIfSessionReplaced(
  status: number,
  reason?: string,
  errorMsg?: string,
  tokenUsed?: string | null
): void {
  if (
    status === 401 &&
    reason === 'session_replaced' &&
    (!tokenUsed || tokenUsed === authSessionToken)
  ) {
    clearAuthSessionToken();
    const msg =
      errorMsg ||
      'Sesi Anda dihentikan karena akun ini login di perangkat lain.';
    sessionReplacedHandlers.forEach((fn) => {
      try {
        fn(msg);
      } catch {
        // ignore
      }
    });
  }
}

function buildAuthHeaders(
  extra?: Record<string, string>,
  overrideToken?: string | null
): Record<string, string> {
  const effectiveToken =
    overrideToken && overrideToken.trim()
      ? overrideToken.trim()
      : authSessionToken;
  return {
    Accept: 'application/json',
    ...(effectiveToken ? { Authorization: `Bearer ${effectiveToken}` } : {}),
    ...(extra || {}),
  };
}

function isAbortTimeoutError(err: unknown): boolean {
  return Boolean(
    err &&
      typeof err === 'object' &&
      'name' in err &&
      (err as { name?: string }).name === 'AbortError'
  );
}

async function fetchWithTimeout(
  input: RequestInfo | URL,
  init: RequestInit,
  timeoutMs = 12_000
): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timer);
  }
}

let cooldownUntilMs = 0;
let consecutiveThrottleCount = 0;

function markThrottleBackoff(status: number): void {
  if (status === 403 || status === 429 || status === 503) {
    consecutiveThrottleCount = Math.min(consecutiveThrottleCount + 1, 4);
    const baseMs = 30_000 * Math.pow(2, consecutiveThrottleCount - 1);
    const jitterMs = Math.floor(Math.random() * 10_000);
    cooldownUntilMs = Date.now() + Math.min(240_000, baseMs) + jitterMs;
  }
}

function clearThrottleBackoff(): void {
  consecutiveThrottleCount = 0;
  cooldownUntilMs = 0;
}

export function isCloudSyncCoolingDown(): boolean {
  return Date.now() < cooldownUntilMs;
}

export async function authenticateWithServer(
  req: AuthLoginRequest
): Promise<AuthLoginResponse> {
  try {
    const res = await fetchWithTimeout(
      '/api/storage',
      {
        method: 'POST',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          action: 'auth_login',
          role: req.role,
          username: req.username,
          password: req.password,
          encryptionCode: req.encryptionCode,
          schemaVersion: 3,
        }),
      },
      12_000
    );
    const json = (await res.json().catch(() => ({}))) as AuthLoginResponse;
    syncServerClock(json.serverTime);
    if (res.ok && json.ok && json.token) {
      setAuthSessionToken(json.token, json.role || req.role);
      clearThrottleBackoff();
      return json;
    }
    return {
      ok: false,
      status: res.status,
      serverEmpty: Boolean(json.serverEmpty),
      error: json.error,
      reason: json.reason,
      completedSubjects: Array.isArray(json.completedSubjects)
        ? json.completedSubjects
        : undefined,
    };
  } catch (err) {
    return {
      ok: false,
      networkError: true,
      ...(isAbortTimeoutError(err)
        ? { error: 'Koneksi ke server melebihi batas waktu (timeout). Silakan coba lagi.' }
        : {}),
    };
  }
}

export async function verifyExamEntryWithServer(params: {
  username: string;
  enteredToken: string;
  selectedScheduleId?: string;
}): Promise<VerifyExamEntryResponse> {
  try {
    const res = await fetchWithTimeout(
      '/api/storage',
      {
        method: 'POST',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          action: 'verify_exam_entry',
          username: params.username,
          enteredToken: params.enteredToken,
          selectedScheduleId: params.selectedScheduleId,
          schemaVersion: 3,
        }),
      },
      12_000
    );
    const json = (await res.json().catch(() => ({}))) as VerifyExamEntryResponse;
    syncServerClock(json.serverTime);
    if (res.ok && json.ok) {
      clearThrottleBackoff();
      return json;
    }
    notifyIfSessionReplaced(res.status, json.reason, json.error);
    return {
      ok: false,
      status: res.status,
      error: json.error,
      reason: json.reason,
      participantStatus: json.participantStatus,
    };
  } catch (err) {
    return {
      ok: false,
      networkError: true,
      ...(isAbortTimeoutError(err)
        ? { error: 'Verifikasi token ke server melebihi batas waktu (timeout). Coba ulangi.' }
        : {}),
    };
  }
}

export async function startExamOnServer(params: {
  username: string;
  packageId: string;
  packageTitle?: string;
  durationMinutes?: number;
}): Promise<StartExamServerResponse> {
  try {
    const res = await fetchWithTimeout(
      '/api/storage',
      {
        method: 'POST',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          action: 'start_exam',
          username: params.username,
          packageId: params.packageId,
          packageTitle: params.packageTitle,
          durationMinutes: params.durationMinutes,
          schemaVersion: 3,
        }),
      },
      10_000
    );
    const json = (await res.json().catch(() => ({}))) as StartExamServerResponse;
    syncServerClock(json.serverTime);
    if (res.ok && json.ok) {
      return json;
    }
    notifyIfSessionReplaced(res.status, json.reason, json.error);
    return {
      ok: false,
      status: res.status,
      reason: json.reason,
      error: json.error,
    };
  } catch (err) {
    return {
      ok: false,
      networkError: true,
      timeout: isAbortTimeoutError(err),
    };
  }
}

export async function submitExamToServer(params: {
  packageId: string;
  packageTitle: string;
  answers: Record<string, StudentAnswer>;
  timeUsedSeconds: number;
  participant: ParticipantProfile;
  submissionId?: string;
}): Promise<SubmitExamServerResponse> {
  try {
    const res = await fetchWithTimeout(
      '/api/storage',
      {
        method: 'POST',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          action: 'submit_exam',
          packageId: params.packageId,
          packageTitle: params.packageTitle,
          answers: params.answers,
          timeUsedSeconds: params.timeUsedSeconds,
          participant: params.participant,
          ...(params.submissionId ? { submissionId: params.submissionId } : {}),
          schemaVersion: 3,
        }),
      },
      15_000
    );
    if (res.status === 429 || res.status === 403) {
      markThrottleBackoff(res.status);
    }
    const json = (await res.json().catch(() => ({}))) as SubmitExamServerResponse;
    syncServerClock(json.serverTime);
    if (res.ok && json.ok) {
      clearThrottleBackoff();
      return {
        ...json,
        engine: json.engine || 'vercel-serverless',
      };
    }
    notifyIfSessionReplaced(res.status, json.reason, json.error);
    return {
      ok: false,
      status: res.status,
      reason: json.reason,
      fallbackClientGrade: Boolean(json.fallbackClientGrade),
      error: json.error,
    };
  } catch (err) {
    const timedOut = isAbortTimeoutError(err);
    return {
      ok: false,
      networkError: true,
      timeout: timedOut,
      ...(timedOut
        ? {
            error:
              'Pengiriman jawaban ke server melebihi batas waktu (timeout). Jawaban tetap tersimpan aman di antrean perangkat dan akan dikirim ulang otomatis.',
          }
        : {}),
    };
  }
}

export async function requestResetFromServer(username: string): Promise<boolean> {
  try {
    const res = await fetchWithTimeout(
      '/api/storage',
      {
        method: 'POST',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          action: 'request_reset',
          username,
          schemaVersion: 3,
        }),
      },
      8_000
    );
    return res.ok;
  } catch {
    return false;
  }
}

export async function fetchVercelStorage(options?: {
  since?: number;
  force?: boolean;
}): Promise<VercelStorageResponse> {
  if (!options?.force && Date.now() < cooldownUntilMs) {
    return {
      ok: false,
      engine: 'local',
      rateLimited: true,
      data: null,
    };
  }

  try {
    const sinceQuery =
      typeof options?.since === 'number' && options.since > 0
        ? `?since=${Math.floor(options.since)}`
        : '';
    const res = await fetchWithTimeout(
      `/api/storage${sinceQuery}`,
      {
        method: 'GET',
        headers: buildAuthHeaders(),
        cache: 'no-store',
      },
      12_000
    );
    if (!res.ok) {
      if (res.status === 403 || res.status === 429 || res.status === 503) {
        markThrottleBackoff(res.status);
        return {
          ok: false,
          engine: 'local',
          rateLimited: true,
          status: res.status,
          data: null,
        };
      }
      const errJson = (await res.json().catch(() => ({}))) as {
        reason?: string;
        error?: string;
      };
      notifyIfSessionReplaced(res.status, errJson.reason, errJson.error);
      return {
        ok: false,
        engine: 'local',
        status: res.status,
        reason: errJson.reason,
        error: errJson.error,
        data: null,
      };
    }
    clearThrottleBackoff();
    const json = (await res.json()) as VercelStorageResponse;
    syncServerClock(json.serverTime);
    return json;
  } catch {
    return { ok: false, engine: 'local', data: null };
  }
}

export async function saveVercelStorage(
  payload: Partial<CBTCloudPayload>,
  options?: {
    overrideToken?: string | null;
    keepalive?: boolean;
  }
): Promise<VercelStorageResponse> {
  try {
    const serializedBody = JSON.stringify({
      ...payload,
      clientNow: Date.now(),
      schemaVersion: 3,
    });
    const useKeepalive =
      Boolean(options?.keepalive) && serializedBody.length < 55_000;
    const res = await fetchWithTimeout(
      '/api/storage',
      {
        method: 'POST',
        headers: buildAuthHeaders(
          { 'Content-Type': 'application/json' },
          options?.overrideToken
        ),
        body: serializedBody,
        ...(useKeepalive ? { keepalive: true } : {}),
      },
      12_000
    );
    if (!res.ok) {
      if (res.status === 413) {
        return {
          ok: false,
          engine: 'local',
          status: 413,
          error:
            'Ukuran data soal/gambar melebihi batas kirim server (4,5 MB). Kurangi resolusi gambar atau unggah secara bertahap per mata pelajaran.',
          data: null,
        };
      }
      if (res.status === 403 || res.status === 429 || res.status === 503) {
        markThrottleBackoff(res.status);
        return {
          ok: false,
          engine: 'local',
          rateLimited: true,
          status: res.status,
          data: null,
        };
      }
      const errJson = (await res.json().catch(() => ({}))) as {
        reason?: string;
        error?: string;
      };
      notifyIfSessionReplaced(
        res.status,
        errJson.reason,
        errJson.error,
        options?.overrideToken
      );
      return {
        ok: false,
        engine: 'local',
        status: res.status,
        reason: errJson.reason,
        error: errJson.error,
        data: null,
      };
    }
    clearThrottleBackoff();
    const json = (await res.json()) as VercelStorageResponse;
    syncServerClock(json.serverTime);
    return json;
  } catch {
    return { ok: false, engine: 'local', data: null };
  }
}

export async function pullStorageFromUrl(
  targetUrl?: string,
  sourceToken?: string
): Promise<VercelStorageResponse> {
  const cleanUrl = String(targetUrl || '').trim();
  const cleanToken = String(sourceToken || '').trim();
  if (
    !cleanUrl ||
    cleanUrl === '/api/storage' ||
    cleanUrl.startsWith('/api/storage?')
  ) {
    return fetchVercelStorage({ force: true });
  }

  try {
    const res = await fetchWithTimeout(
      '/api/storage',
      {
        method: 'POST',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          action: 'pull_external_storage',
          targetUrl: cleanUrl,
          ...(cleanToken ? { sourceToken: cleanToken } : {}),
          schemaVersion: 3,
        }),
      },
      25_000
    );
    const json = (await res.json().catch(() => ({}))) as VercelStorageResponse;
    syncServerClock(json.serverTime);
    if (res.ok && json.ok && json.data) {
      clearThrottleBackoff();
      return json;
    }

    // Fallback: try direct browser GET if same-origin or CORS-enabled JSON endpoint
    let directEndpoint = cleanUrl;
    if (!directEndpoint.startsWith('/')) {
      const withProto = /^https?:\/\//i.test(directEndpoint)
        ? directEndpoint
        : `https://${directEndpoint}`;
      const u = new URL(withProto);
      if (!u.pathname || u.pathname === '/') {
        u.pathname = '/api/storage';
      }
      directEndpoint = u.toString();
    }
    const directRes = await fetchWithTimeout(
      directEndpoint,
      {
        method: 'GET',
        headers: buildAuthHeaders(),
        cache: 'no-store',
      },
      12_000
    );
    if (directRes.ok) {
      const directJson = (await directRes.json().catch(() => null)) as Record<
        string,
        any
      > | null;
      const extracted =
        directJson &&
        typeof directJson === 'object' &&
        directJson.data &&
        typeof directJson.data === 'object'
          ? (directJson.data as CBTCloudPayload)
          : directJson &&
            typeof directJson === 'object' &&
            (Array.isArray(directJson.participants) ||
              Array.isArray(directJson.schedules) ||
              Array.isArray(directJson.packages) ||
              Array.isArray(directJson.proctors))
          ? (directJson as CBTCloudPayload)
          : null;
      if (extracted) {
        return {
          ok: true,
          engine:
            (directJson?.engine as VercelStorageResponse['engine']) ||
            'vercel-serverless',
          updatedAt: Date.now(),
          data: extracted,
        };
      }
    }

    return {
      ok: false,
      engine: 'local',
      status: res.status,
      error:
        json.error ||
        `Gagal menarik data storage dari URL (${cleanUrl}). Pastikan URL valid dan dapat diakses.`,
      data: null,
    };
  } catch (err) {
    return {
      ok: false,
      engine: 'local',
      error: isAbortTimeoutError(err)
        ? 'Koneksi ke URL Storage melebihi batas waktu (timeout).'
        : 'Gagal menarik data dari URL Storage. Periksa format URL atau jaringan Anda.',
      data: null,
    };
  }
}

